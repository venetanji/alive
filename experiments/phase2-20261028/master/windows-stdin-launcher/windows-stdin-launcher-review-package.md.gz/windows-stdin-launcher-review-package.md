# Windows stdin launcher frozen review package

Base 0f3776c87b79069e989c5e5be24312ed455ee3ce
Candidate 4fb8e3abfab7cba99cbb8e6b9f178b9733f5410c
Diff SHA-256 e27c7389cb9bed14a798086e46250ccb43e4aca8e999c57a4a6560f0378a31fc

```diff
diff --git a/apps/ultra/tests/windows/master_resolver_fixtures.ps1 b/apps/ultra/tests/windows/master_resolver_fixtures.ps1
index 5be69df..d42f071 100644
--- a/apps/ultra/tests/windows/master_resolver_fixtures.ps1
+++ b/apps/ultra/tests/windows/master_resolver_fixtures.ps1
@@ -27,18 +27,7 @@ try {
     $rustc = (Get-Command rustc).Source
     $probe = Join-Path $results "master_resolver_probe.exe"
     $probeSource = Join-Path $sourceDir "master_resolver_probe.rs"
-    $command = "call `"$vcvars`" >nul && `"$rustc`" --edition=2021 -C opt-level=2 `"$probeSource`" -L `"native=$native`" -o `"$probe`""
-    & cmd.exe /d /s /c "`"$command`""
-    if ($LASTEXITCODE -ne 0) {
-        $originalExit = $LASTEXITCODE
-        Write-Host "original command=$command exit=$originalExit native-argument-passing=$PSNativeCommandArgumentPassing"
-        try {
-            & (Join-Path $sourceDir "master_resolver_launcher_diagnostic.ps1") $vcvars $rustc $probeSource $native $probe
-        } catch {
-            Write-Host "launcher diagnostic failed: $_"
-        }
-        throw "probe compile failed: $originalExit"
-    }
+    & (Join-Path $sourceDir "master_resolver_launcher_diagnostic.ps1") $vcvars $rustc $probeSource $native $probe
 
     $failed = @()
     foreach ($case in @("real", "full", "old", "partial", "forwarded", "bad_limits")) {
diff --git a/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1 b/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1
index 95cac24..ea7d64d 100644
--- a/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1
+++ b/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1
@@ -46,8 +46,11 @@ try {
     $remaining = [Math]::Max(0, 45000 - [int]$clock.ElapsedMilliseconds)
     if (!$process.WaitForExit($remaining)) { throw 'cmd timed out' }
     Write-Host "launcher-diagnostic cmd-exit=$($process.ExitCode) probe-exists=$(Test-Path -LiteralPath $Probe)"
+    if ($process.ExitCode -ne 0) { throw "probe compile failed: $($process.ExitCode)" }
+    if (!(Test-Path -LiteralPath $Probe -PathType Leaf)) { throw 'probe compile produced no output' }
 } catch {
     Write-Host "launcher-diagnostic error: $_"
+    throw
 } finally {
     if ($started -and !$process.HasExited) {
         try {
```
