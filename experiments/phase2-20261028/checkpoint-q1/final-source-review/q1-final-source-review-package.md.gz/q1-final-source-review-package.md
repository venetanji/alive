# Final Q1 Phase 2 source integration review

Base 1ebf2161e0fa2a62484566fac65c7e940567f357
Head 0f1deaecc34e8a54bc9b1ec136876831ebb132e5
Diff SHA-256 df65293992f788c55d055b208197669ab8437ef66dfe2e8f1b16699607269cc7

## Commits

```text
4326b0b test(alive): use verified stdin route for Windows probe compiler
ece6090 test(alive): bound Windows compiler-launch diagnostics
64fcacd fix(alive): keep mixer rows aligned while device actions are open
66249c5 ci(alive): add opt-in cloud playback qualification
71e6108 fix(alive): preserve originating session for device actions
210b37e test(alive): exercise Windows Master resolver fixtures
fc320f5 fix(alive): bind the Windows Master anchor to its DLL
85adb2e test(alive): qualify Master and sustained desktop playback
3ca670d test(alive): trace the Windows Master cache initializer
da7c6fb docs(alive): record Master workspace checkpoint and correction evidence
f69125c fix(alive): keep Master rejection observations current
36b0b39 feat(alive): add shared Master controls and compact workspaces
d025c91 test(alive): coordinate conservative sustained observations
f0f7871 docs: record native Master proof and pending UI gate
c71b608 feat(alive): apply native Master gain and coherent metering
13d3061 test(alive): preserve Arrangement drag across lane redraws
6f407a4 feat(alive): preserve Master ownership in versioned sessions
ce84e2a feat(alive): validate Master snapshots and retain authoritative state
422d608 test: read live Arrangement geometry without detached handles
c272c4a test: attribute native chooser input with bounded observations
b4b1a5c fix(ultra): preserve saved device metadata when repackaging
9997589 fix(ultra): flush linked editor drafts before save and quit
003024f test(ultra): account for retained comments in native import fixture
65dbf5a test(alive): trace Apply and qualify Arrangement native harness
5d45a43 fix(alive): preserve queued source and device edit intent
```

## Scope

```text
 .github/workflows/ultra-ci.yml                     |  96 +++-
 .github/workflows/ultra-desktop.yml                |  12 +
 .impeccable/surfaces/alive-session.md              |  17 +-
 DESIGN.md                                          |  18 +
 PRODUCT.md                                         |   6 +
 apps/alive/README.md                               |  16 +-
 apps/alive/SESSION_CONTRACT.md                     |  36 +-
 apps/ultra/src-tauri/native/alive-master-v1.h      |  42 ++
 apps/ultra/src-tauri/native/alive_session.hpp      |  85 +++-
 .../ultra/src-tauri/native/alive_session_clips.hpp |   2 +
 .../src-tauri/native/alive_session_v3_policy.md    |   3 +
 .../src-tauri/native/alive_session_v4_policy.md    |   4 +
 .../src-tauri/native/alive_session_workspaces.hpp  |   1 +
 apps/ultra/src-tauri/native/backend.cpp            |  22 +-
 apps/ultra/src-tauri/src/audio_instrumentation.rs  |   2 +-
 apps/ultra/src-tauri/src/document_commands.rs      |  45 ++
 apps/ultra/src-tauri/src/document_windows.rs       |  99 +++-
 apps/ultra/src-tauri/src/documents.rs              |   5 +
 apps/ultra/src-tauri/src/documents_close.rs        |   3 +
 apps/ultra/src-tauri/src/documents_save.rs         |  75 +++
 apps/ultra/src-tauri/src/documents_tests.rs        |  68 +++
 apps/ultra/src-tauri/src/lib.rs                    |   2 +
 apps/ultra/src-tauri/src/session/clips.rs          |   6 +-
 apps/ultra/src-tauri/src/session/desktop.rs        | 552 +++++++++++++++++----
 apps/ultra/src-tauri/src/session/history.rs        |   2 +-
 apps/ultra/src-tauri/src/session/host.rs           |  81 ++-
 apps/ultra/src-tauri/src/session/master.rs         |  22 +
 apps/ultra/src-tauri/src/session/mod.rs            |   3 +
 apps/ultra/src-tauri/src/session/native.rs         |  42 ++
 apps/ultra/src-tauri/src/session/native_master.rs  | 274 ++++++++++
 apps/ultra/src-tauri/src/session/persistence.rs    |  69 ++-
 apps/ultra/src-tauri/src/session/prepare.rs        |  24 +-
 .../src-tauri/src/session/prepare_workspaces.rs    |   6 +-
 apps/ultra/src-tauri/src/session/probe.rs          |  44 +-
 apps/ultra/src-tauri/src/session/runtime.rs        |  23 +-
 .../src-tauri/src/session/runtime_workspaces.rs    |  22 +-
 apps/ultra/src-tauri/src/session/tests.rs          | 351 +++++++++----
 .../ultra/src-tauri/src/session/workspace_edits.rs |   2 +-
 apps/ultra/src-tauri/src/session/workspaces.rs     |   5 +-
 .../src-tauri/src/session/workspaces_tests.rs      |   6 +-
 apps/ultra/tests/alive_session_capacity.cpp        |   4 +
 .../alive_session_master_partial_library_test.sh   |  24 +
 .../tests/alive_session_master_resolver_test.sh    |  37 ++
 apps/ultra/tests/alive_session_master_test.cpp     | 196 ++++++++
 apps/ultra/tests/alive_session_test.cpp            |  35 +-
 apps/ultra/tests/alive_session_v2_test.cpp         |  32 +-
 apps/ultra/tests/alive_session_v3_measure.cpp      |  10 +
 apps/ultra/tests/alive_session_v3_test.cpp         |  74 +++
 apps/ultra/tests/alive_session_v4_measure.cpp      |   5 +
 apps/ultra/tests/alive_session_v4_test.cpp         |  73 +++
 apps/ultra/tests/alive_workspace_navigation.py     |   2 +-
 apps/ultra/tests/check_alive_arrangement.py        |  35 +-
 apps/ultra/tests/check_alive_capacity.py           |   2 +-
 .../ultra/tests/check_alive_chooser_diagnostics.py |   7 +
 apps/ultra/tests/check_alive_clips.py              |   3 +-
 apps/ultra/tests/check_alive_desktop.py            | 290 +++++++++--
 apps/ultra/tests/check_alive_editor_diagnostics.py |   5 +
 apps/ultra/tests/check_alive_master.py             | 185 +++++++
 apps/ultra/tests/check_alive_native_input.py       |   2 +-
 apps/ultra/tests/check_alive_packaged.py           |   2 +-
 apps/ultra/tests/check_alive_scene_modes.py        |   5 +-
 apps/ultra/tests/check_alive_scenes.py             |   2 +-
 apps/ultra/tests/check_canvas_desktop.py           |  45 +-
 apps/ultra/tests/check_canvas_desktop.sh           |  25 +-
 apps/ultra/tests/check_document_startup.py         |   2 +-
 apps/ultra/tests/check_instrument_desktop.py       |   2 +-
 apps/ultra/tests/check_ultra_drafts.py             | 332 +++++++++++++
 apps/ultra/tests/chooser_observation.py            |  40 ++
 apps/ultra/tests/ci/alive-chain.spec.mjs           | 162 +++++-
 apps/ultra/tests/ci/canvas-documents.spec.mjs      |  32 ++
 apps/ultra/tests/ci/check-native.sh                |   5 +
 apps/ultra/tests/desktop_checkpoint.py             | 161 ++++++
 apps/ultra/tests/desktop_launch_config.sh          |  20 +
 apps/ultra/tests/desktop_process_helpers.py        |  62 +++
 apps/ultra/tests/desktop_sustained.py              | 206 ++++++++
 apps/ultra/tests/stage_alive_session.py            |  19 +
 apps/ultra/tests/sustained_measurement.py          | 138 ++++++
 .../ultra/tests/test_alive_workspace_navigation.py |  27 +
 apps/ultra/tests/test_chooser_observation.py       |  54 ++
 apps/ultra/tests/test_desktop_checkpoint.py        | 227 +++++++++
 apps/ultra/tests/test_desktop_launch_config.py     |  51 ++
 apps/ultra/tests/test_desktop_process_helpers.py   |  59 +++
 .../tests/test_desktop_sustained_integration.py    | 250 ++++++++++
 apps/ultra/tests/test_slider_help_fixture.py       |  47 ++
 apps/ultra/tests/test_stage_alive_session.py       |  27 +
 apps/ultra/tests/test_sustained_measurement.py     | 218 ++++++++
 apps/ultra/tests/windows/CMakeLists.txt            |  23 +
 apps/ultra/tests/windows/forward_target.def        |   3 +
 apps/ultra/tests/windows/forwarded.def             |   9 +
 apps/ultra/tests/windows/full.def                  |   9 +
 apps/ultra/tests/windows/master_fixture.c          |  18 +
 apps/ultra/tests/windows/master_forward_target.c   |   4 +
 .../tests/windows/master_resolver_fixtures.ps1     |  66 +++
 .../master_resolver_launcher_diagnostic.ps1        |  72 +++
 apps/ultra/tests/windows/master_resolver_probe.rs  |  84 ++++
 apps/ultra/tests/windows/old.def                   |   3 +
 apps/ultra/tests/windows/partial.def               |   4 +
 apps/ultra/ui/alive-dom.test.mjs                   |  82 +++
 apps/ultra/ui/alive-master-producer.test.mjs       |  79 +++
 apps/ultra/ui/alive-master.mjs                     |  52 ++
 apps/ultra/ui/alive-master.test.mjs                |  23 +
 apps/ultra/ui/alive-model.mjs                      |   7 +-
 apps/ultra/ui/alive-model.test.mjs                 |  43 ++
 apps/ultra/ui/alive-timeline.mjs                   |  30 +-
 apps/ultra/ui/alive-workspace.mjs                  |  27 +-
 apps/ultra/ui/alive.css                            |  34 ++
 apps/ultra/ui/alive.html                           |  14 +-
 apps/ultra/ui/alive.mjs                            |  97 +++-
 apps/ultra/ui/canvas-device-panel.mjs              |  28 +-
 apps/ultra/ui/canvas-documents-view.mjs            |   7 +-
 apps/ultra/ui/canvas-documents.mjs                 |  31 +-
 apps/ultra/ui/canvas-documents.test.mjs            |  25 +
 apps/ultra/ui/canvas-dom.test.mjs                  | 237 ++++++++-
 apps/ultra/ui/canvas-entry.mjs                     |  27 +-
 apps/ultra/ui/canvas-focused-drafts.mjs            |  17 +
 apps/ultra/ui/canvas-inspector.mjs                 |  46 +-
 apps/ultra/ui/canvas-instrument.mjs                |   7 +-
 apps/ultra/ui/canvas-instrument.test.mjs           |  28 ++
 apps/ultra/ui/canvas-node.mjs                      |  20 +-
 apps/ultra/ui/canvas-shared.mjs                    |   7 +-
 apps/ultra/ui/canvas-shared.test.mjs               |  39 ++
 apps/ultra/ui/canvas.html                          |   2 +-
 apps/ultra/ui/canvas.mjs                           |  46 +-
 123 files changed, 6255 insertions(+), 529 deletions(-)
```

## Complete Source Diff

```diff
diff --git a/.github/workflows/ultra-ci.yml b/.github/workflows/ultra-ci.yml
index 536c561..0c9550d 100644
--- a/.github/workflows/ultra-ci.yml
+++ b/.github/workflows/ultra-ci.yml
@@ -5,6 +5,16 @@ on:
   push:
     branches: [main]
   workflow_dispatch:
+    inputs:
+      alive_endurance:
+        description: 'Optional Alive sustained desktop journey'
+        type: choice
+        required: true
+        default: 'off'
+        options:
+          - 'off'
+          - pilot
+          - endurance
 
 # Fork PRs execute untrusted source without secrets or repository write access.
 permissions:
@@ -44,6 +54,15 @@ jobs:
         run: |
           python -m unittest discover -s apps/ultra/tests -p test_desktop_timing.py -v
           python -m unittest discover -s apps/ultra/tests -p test_desktop_frames.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_desktop_launch_config.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_alive_workspace_navigation.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_stage_alive_session.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_chooser_observation.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_desktop_process_helpers.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_desktop_checkpoint.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_desktop_sustained_integration.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_sustained_measurement.py -v
+          python -m unittest discover -s apps/ultra/tests -p test_slider_help_fixture.py -v
 
   browser:
     name: Chromium canvas editing smoke
@@ -83,13 +102,22 @@ jobs:
   native:
     name: Linux native build, Rust bridge, and CPAL loopback
     runs-on: ubuntu-24.04
-    timeout-minutes: 40
+    timeout-minutes: ${{ github.event_name == 'workflow_dispatch' && (inputs.alive_endurance == 'pilot' || inputs.alive_endurance == 'endurance') && 120 || 40 }}
     env:
       JOBS: '2'
       CARGO_BUILD_JOBS: '2'
       CARGO_NET_RETRY: '2'
       CARGO_HTTP_TIMEOUT: '60'
     steps:
+      - name: Validate Alive endurance selection
+        if: ${{ github.event_name == 'workflow_dispatch' }}
+        env:
+          ALIVE_ENDURANCE_MODE: ${{ inputs.alive_endurance }}
+        run: |
+          case "$ALIVE_ENDURANCE_MODE" in
+            ''|off|pilot|endurance) ;;
+            *) echo "Invalid Alive endurance mode: $ALIVE_ENDURANCE_MODE" >&2; exit 1 ;;
+          esac
       - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
         with:
           persist-credentials: false
@@ -102,7 +130,11 @@ jobs:
             libasound2-dev libpipewire-0.3-dev libspa-0.2-dev libclang-dev \
             libayatana-appindicator3-dev librsvg2-dev patchelf \
             pipewire-bin wireplumber dbus xvfb xauth python3-gi \
-            gir1.2-atspi-2.0 gir1.2-gtk-3.0 at-spi2-core libxtst6
+            gir1.2-atspi-2.0 gir1.2-gtk-3.0 at-spi2-core libxtst6 ffmpeg
+          ffmpeg -version | head -n 1
+          Xvfb -help 2>&1 | head -n 1 || true
+          pipewire --version
+          wireplumber --version
       - name: Cache downloaded, checksum-verified native dependencies
         uses: actions/cache@0400d5f644dc74513175e3cd8d07132dd4860809 # v4.2.4
         with:
@@ -163,12 +195,34 @@ jobs:
           path: apps/ultra/build/session-evidence/
           if-no-files-found: warn
           retention-days: 7
+      - name: Record sustained source and build identities
+        if: ${{ github.event_name == 'workflow_dispatch' && (inputs.alive_endurance == 'pilot' || inputs.alive_endurance == 'endurance') }}
+        env:
+          ALIVE_ENDURANCE_MODE: ${{ inputs.alive_endurance }}
+          ALIVE_ENDURANCE_TARGET: ${{ inputs.alive_endurance == 'pilot' && '500' || '1800' }}
+        run: |
+          evidence=apps/ultra/build/session-desktop-evidence
+          mkdir -p "$evidence"
+          git rev-parse HEAD > "$evidence/source-commit.txt"
+          sha256sum apps/ultra/src-tauri/target/release/alive \
+            apps/ultra/src-tauri/target/release/ultra \
+            apps/ultra/src-tauri/target/release/libultra_native.so \
+            > "$evidence/build-sha256.txt"
+          {
+            printf 'mode=%s\ntarget_playing_seconds=%s\n' "$ALIVE_ENDURANCE_MODE" "$ALIVE_ENDURANCE_TARGET"
+            printf 'runner_os=%s\nrunner_arch=%s\nimage_os=%s\nimage_version=%s\n' "$RUNNER_OS" "$RUNNER_ARCH" "${ImageOS:-unknown}" "${ImageVersion:-unknown}"
+            printf 'backend=private software-only CPAL PipeWire at 48 kHz / 512 frames\n'
+            uname -a
+            lscpu
+            pipewire --version
+          } > "$evidence/sustained-context.txt"
       - name: Exercise the actual Alive desktop session and hosted editor
         # Provisional diagnostic allowance; runner phase/query evidence must set the permanent bound.
-        timeout-minutes: 8
+        timeout-minutes: ${{ github.event_name == 'workflow_dispatch' && (inputs.alive_endurance == 'pilot' || inputs.alive_endurance == 'endurance') && 60 || 8 }}
         env:
           ULTRA_TEST_ALIVE: '1'
           ULTRA_TEST_SCRIPT: ${{ github.workspace }}/apps/ultra/tests/check_alive_desktop.py
+          ALIVE_ENDURANCE_SECONDS: ${{ github.event_name == 'workflow_dispatch' && inputs.alive_endurance == 'pilot' && '500' || github.event_name == 'workflow_dispatch' && inputs.alive_endurance == 'endurance' && '1800' || '0' }}
         run: bash apps/ultra/tests/check_canvas_desktop.sh "$GITHUB_WORKSPACE/apps/ultra/build/session-desktop-evidence"
       - name: Save actual Alive desktop evidence
         if: always()
@@ -178,6 +232,42 @@ jobs:
           path: apps/ultra/build/session-desktop-evidence/
           if-no-files-found: warn
           retention-days: 7
+      - name: Exercise the real Alive Arrangement journey
+        if: ${{ !cancelled() }}
+        timeout-minutes: 8
+        env:
+          ULTRA_TEST_ALIVE: '1'
+          ULTRA_TEST_SCREEN_SIZE: 1600x1000
+          ULTRA_TEST_ALIVE_BINARY: ${{ github.workspace }}/apps/ultra/src-tauri/target/release/alive
+          ULTRA_TEST_ALIVE_SESSION: ${{ github.workspace }}/apps/alive/examples/midi-arrangement.alive
+          ULTRA_TEST_SCRIPT: ${{ github.workspace }}/apps/ultra/tests/check_alive_arrangement.py
+        run: bash apps/ultra/tests/check_canvas_desktop.sh "$GITHUB_WORKSPACE/apps/ultra/build/arrangement-desktop-evidence"
+      - name: Save Arrangement evidence even on failure
+        if: always()
+        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02 # v4.6.2
+        with:
+          name: alive-arrangement-${{ github.run_id }}-${{ github.run_attempt }}
+          path: apps/ultra/build/arrangement-desktop-evidence/
+          if-no-files-found: warn
+          retention-days: 7
+      - name: Exercise native Master save, Quit and restart
+        if: ${{ !cancelled() }}
+        timeout-minutes: 8
+        env:
+          ULTRA_TEST_ALIVE: '1'
+          ULTRA_TEST_SCREEN_SIZE: 1600x1000
+          ULTRA_TEST_ALIVE_BINARY: ${{ github.workspace }}/apps/ultra/src-tauri/target/release/alive
+          ULTRA_TEST_ALIVE_SESSION: ${{ github.workspace }}/apps/alive/examples/midi-arrangement.alive
+          ULTRA_TEST_SCRIPT: ${{ github.workspace }}/apps/ultra/tests/check_alive_master.py
+        run: bash apps/ultra/tests/check_canvas_desktop.sh "$GITHUB_WORKSPACE/apps/ultra/build/master-desktop-evidence"
+      - name: Save Master evidence even on failure
+        if: always()
+        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02 # v4.6.2
+        with:
+          name: alive-master-${{ github.run_id }}-${{ github.run_attempt }}
+          path: apps/ultra/build/master-desktop-evidence/
+          if-no-files-found: warn
+          retention-days: 7
       - name: Verify native clip observation boundaries and failure isolation
         timeout-minutes: 4
         env:
diff --git a/.github/workflows/ultra-desktop.yml b/.github/workflows/ultra-desktop.yml
index c304feb..2a45c2b 100644
--- a/.github/workflows/ultra-desktop.yml
+++ b/.github/workflows/ultra-desktop.yml
@@ -106,6 +106,18 @@ jobs:
           ASC_API_KEY_ID: ${{ secrets.ASC_API_KEY_ID }}
           ASC_API_ISSUER_ID: ${{ secrets.ASC_API_ISSUER_ID }}
         run: bash apps/ultra/scripts/sign-macos.sh '${{ matrix.target }}'
+      - name: Test Windows Master resolver fixtures
+        if: runner.os == 'Windows'
+        shell: pwsh
+        run: ./apps/ultra/tests/windows/master_resolver_fixtures.ps1
+      - name: Retain Windows Master resolver report
+        if: ${{ always() && runner.os == 'Windows' }}
+        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02 # v4.6.2
+        with:
+          name: windows-master-resolver-report
+          path: test-results/windows-master-resolver/report.txt
+          if-no-files-found: warn
+          retention-days: 14
       - name: Collect exact target artifacts and checksums
         run: |
           python apps/ultra/scripts/release.py collect --target '${{ matrix.target }}'
diff --git a/.impeccable/surfaces/alive-session.md b/.impeccable/surfaces/alive-session.md
index 56e7053..1e232d8 100644
--- a/.impeccable/surfaces/alive-session.md
+++ b/.impeccable/surfaces/alive-session.md
@@ -6,20 +6,25 @@ owner PR comment 6383966857. Reuse the existing Liberation Sans, charcoal,
 amber selection and thin original controls. Earlier two-track/no-scenes
 exclusions are stale; runtime capacities still come from native capabilities.
 
-Session opens as fixed-width track columns with four compact, flat slots,
-aligned scene launch rows at right, and each column's mixer below. Occupied
+Session opens with 128px track columns adjustable from 112 to 180px, four
+24px flat slots and 28px single-line headers. Four scene launch rows sit above
+the mixer in a fixed-right 128px Master column. Occupied
 cells carry the track color; launch triangles stay separate from selection.
 Empty cells are real available slots, not decorative capacity. Original SVG
 icons and vertical gain/native peak controls follow the observed Live density;
 runtime receipts remain inspectable. Eight tracks use internal horizontal
 scrolling. A compact top transport, collapsible left browser,
-resizable bottom Clip/Devices detail and status footer stay shared. Numerical
+resizable bottom Clip/Devices/Master detail and status footer stay shared.
+The browser defaults to 220px and resizes from 180 to 280px. Numerical
 notes, automation, device structure and diagnostics remain secondary inspectors.
 No decorative entrance motion; focus and selection remain explicit.
 
-Task 1 provides the working v3 Session and presentation shell. Arrangement is
-visibly unavailable until the placement/audio model and native runtime exist.
-Do not show invented placements or waveforms. Navigation preserves native
+Arrangement presents admitted MIDI placements with track controls on the right
+and one Master lane below; source and placement fields sit in selected detail.
+No audio clips, fabricated waveforms or unsupported Master automation appear.
+Master gain, reset and coherent native stereo interval observations share one
+owner across views. Pending, admitted, applied, stale and unavailable states
+remain explicit; digital overload is not a physical clipping claim. Navigation preserves native
 commands, receipt labels, selected identities, editor lifecycle and drafts.
 Plain Tab switches only outside interactive controls; modified Tab preserves
 normal focus navigation. Detail resize supports keyboard and cancel.
diff --git a/DESIGN.md b/DESIGN.md
index 63cf1b7..2f2a93f 100644
--- a/DESIGN.md
+++ b/DESIGN.md
@@ -329,6 +329,24 @@ Basic dismisses the reference and selects its object locally. Native child
 windows keep their bound scope and independent overlays. Saves include helper
 roles and geometry, with reference text and navigation state kept out of patches.
 
+## Alive Workspaces
+
+Alive uses the same compact charcoal and Liberation Sans language, with a
+separate Session and Arrangement workspace. Its browser defaults to 220px and
+resizes from 180 to 280px. Session columns default to 128px and can be adjusted
+from 112 to 180px. One-line 28px headers and four 24px slots align with the four
+scene actions in the fixed-right Master column. Empty workspace remains empty;
+it does not imply unsupported tracks, sends or clips.
+
+Master is an output selection, not a musical track. Both views use the same
+native gain owner and publication: the Session column and Arrangement bottom
+lane expose gain, dB, separate interval peaks, digital overload and explicit
+reset. Pending intent, admitted saved target and applied observation remain
+separate; unavailable and stale observations are named rather than synthesized.
+The Arrangement track controls sit to the right of the musical lanes, and source
+and placement edits live in selected Clip detail. Browser and detail changes,
+selection and Tab navigation stay local and preserve parked input and bindings.
+
 ## Do's and Don'ts
 
 ### Do:
diff --git a/PRODUCT.md b/PRODUCT.md
index e197fa4..b6435b5 100644
--- a/PRODUCT.md
+++ b/PRODUCT.md
@@ -34,6 +34,12 @@ instruments in a small, reopenable Alive session with clips, automation and a mi
   duration, metadata-selected instance/parameter automation, gain/mute/solo and
   stereo peak meters. Each selected-track chain exposes an instrument and up to
   two ordered stereo effects, live bases/effect bypass and optional instance editors.
+  A saved stereo Master follows the track sum, with live gain, interval L/R
+  peaks and explicit digital-overload reset. Session's fixed-right Master strip
+  and MIDI Arrangement's bottom output lane share that owner; compact headers,
+  four aligned slot/scene rows, original icons and a shared detail area retain
+  the current admitted musical profiles. The final local build, save/restart
+  and endurance checkpoint remains separate from the focused UI qualification.
   Canonical session-v3 files preserve four clip slots per track, stable score IDs,
   stopped saved defaults, independent instance IDs, original-source fingerprints,
   order, bases, bypass, musical data and mixer values. Existing v1/v2 sessions
diff --git a/apps/alive/README.md b/apps/alive/README.md
index 004dd4d..7caa8f1 100644
--- a/apps/alive/README.md
+++ b/apps/alive/README.md
@@ -3,8 +3,20 @@
 Alive is a separate `alive` executable with a compact Rust/Tauri session UI.
 Ultra remains the `ultra` patch-editor executable. Both share the native engine
 and Rust library; Alive hosts saved Ultra instruments and ordered stereo effect
-chains through versioned device manifests and the native Faust evaluator. Canonical
-`alive-session-v3` files preserve four clip slots per track, stable clip/note IDs,
+chains through versioned device manifests and the native Faust evaluator.
+New files use an `alive-session-v5` envelope around the score and saved Master
+gain. Existing bare scores remain readable. The Linux native host supports
+saved Master gain, 64-frame live ramps, coherent stereo peaks and an explicit
+digital-overload reset. Old or partial native libraries allow unity sessions
+and refuse non-unity before retiring the current owner. Session now has a
+fixed-right Master strip and four aligned slot/scene rows; MIDI Arrangement
+has right-hand track controls and a bottom Master lane. Both views share gain,
+native stereo meters, unity and digital-overload reset controls. See `PLAN.md`
+for exact source, build and acceptance status. The current test launcher uses
+the coherent `f69125c` build; complete native save/restart and endurance
+qualification of this new checkpoint is in progress.
+`alive-session-v3` scores
+preserve four clip slots per track, stable clip/note IDs,
 saved defaults, instance IDs, original-source fingerprints, ordered effects,
 parameter bases, bypass and automation targets. Existing v1/v2 sessions upgrade
 in memory on Open when admitted; Save writes the upgrade. A playable legacy
diff --git a/apps/alive/SESSION_CONTRACT.md b/apps/alive/SESSION_CONTRACT.md
index f92dc9b..8a5feea 100644
--- a/apps/alive/SESSION_CONTRACT.md
+++ b/apps/alive/SESSION_CONTRACT.md
@@ -222,7 +222,41 @@ latency declaration; Alive desktop uses CPAL and the tested native host profile.
 
 ## Persistence And Errors
 
-Admitted clip-bank saves use strict camelCase `alive-session-v3` JSON; legacy
+New sessions save an `alive-session-v5` envelope containing a strict v2, v3,
+or v4 score and `master: { "gain": 1.0 }`. Older files retain their bare score
+wire until an admitted Master change requires v5. The saved gain is bounded
+from 0 through 4. A capable Linux native host initializes the saved gain before
+the first output sample; a missing or partial capability permits unity sessions
+and refuses non-unity before retiring the current audio owner. Score
+snapshots remain the existing v2/v3/v4 shapes. See
+`docs/contracts/alive-master-v1.md` for the complete wire and ownership rules.
+
+Master is one output owner outside the musical track/solo/voice arrays. Its
+gain follows the track/effect/mixer stereo sum and precedes output conversion.
+Live commands enter the existing bounded FIFO, preserve the reserved Stop
+route, apply at an observed callback boundary and ramp from the current
+coefficient over exactly 64 output frames. Quiescent I/O-off initialization
+sets the saved coefficient directly without advancing the frame clock; stopped
+transport with running I/O uses the live path. Master adds no pipeline buffer
+or limiter and does not move the native Faust kernels into Clockwork.
+
+Gain/reset IPC authenticates the project generation. Saved gain changes only
+after admission; accepted serial and applied serial/frame remain distinct.
+Failed admission preserves saved gain, wire, dirty state, score draft and
+history. Score Apply/Undo/Redo/Discard preserve accepted live Master state.
+Post-gain L/R interval peaks, absolute interval boundaries and sticky digital
+overload bits share the score's native publication. Stop, seek and loop do not
+clear the latch; explicit reset or project installation does. An unavailable
+observation stays null/stale rather than becoming invented silence. This
+contract does not imply Master effects, mute/solo, automation or physical clip
+and underrun detection. Session's fixed-right Master strip and Arrangement's
+bottom output lane share one bounded gain/reset command producer, with pending
+intent, admission and observed application displayed separately. Selecting
+Master is local view state and preserves musical drafts and device bindings.
+Final root builds, complete desktop/save/Quit/restart, endurance and cloud
+qualification are tracked separately in `PLAN.md`.
+
+Admitted clip-bank scores use strict camelCase `alive-session-v3` JSON; legacy
 fallback saves remain v2. `Track.device` is the
 instrument and `Track.effects` is its ordered effect list. Each instance has a
 persisted UUID-shaped `instanceId`, independent of reusable manifest `id`, source
diff --git a/apps/ultra/src-tauri/native/alive-master-v1.h b/apps/ultra/src-tauri/native/alive-master-v1.h
new file mode 100644
index 0000000..fae20bf
--- /dev/null
+++ b/apps/ultra/src-tauri/native/alive-master-v1.h
@@ -0,0 +1,42 @@
+#ifndef ALIVE_MASTER_V1_H
+#define ALIVE_MASTER_V1_H
+#include <stddef.h>
+#include <stdint.h>
+#include "alive_session.h"
+#define ALIVE_MASTER_V1 1u
+#define ALIVE_MASTER_OK 1
+#define ALIVE_MASTER_INVALID 0
+#define ALIVE_MASTER_UNSUPPORTED (-1)
+#define ALIVE_MASTER_FULL (-2)
+#define ALIVE_MASTER_BUSY (-3)
+#define ALIVE_MASTER_UNCONFIGURED (-4)
+#define ALIVE_MASTER_EXHAUSTED (-5)
+#define ALIVE_MASTER_FEATURE_GAIN 1u
+#define ALIVE_MASTER_FEATURE_METER 2u
+#define ALIVE_MASTER_FEATURE_RESET 4u
+#ifdef __cplusplus
+extern "C" {
+#endif
+typedef struct { uint32_t version, struct_bytes, features, ramp_frames; double max_gain; } AliveMasterLimitsV1;
+typedef struct { uint32_t version, struct_bytes, clip_mask, reserved; double target_gain, current_gain, peak_left, peak_right; uint64_t applied_serial, applied_frame, observation_start_frame, observation_end_frame; } AliveMasterStateV1;
+int alive_session_master_limits(AliveMasterLimitsV1 *out);
+int alive_session_master_set(uint32_t version, double gain, uint64_t serial);
+int alive_session_master_reset_clip(uint32_t version, uint64_t serial);
+int alive_session_master_snapshot_v2(AliveSessionStateV2 *score, AliveMasterStateV1 *master);
+int alive_session_master_snapshot_v3(AliveSessionStateV3 *score, AliveMasterStateV1 *master);
+int alive_session_master_snapshot_v4(AliveSessionStateV4 *score, AliveMasterStateV1 *master);
+#ifdef __cplusplus
+}
+#define MASTER_ASSERT static_assert
+#define MASTER_ALIGN alignof
+#else
+#define MASTER_ASSERT _Static_assert
+#define MASTER_ALIGN _Alignof
+#endif
+MASTER_ASSERT(sizeof(AliveMasterLimitsV1)==24 && MASTER_ALIGN(AliveMasterLimitsV1)==8, "limits layout");
+MASTER_ASSERT(offsetof(AliveMasterLimitsV1,version)==0 && offsetof(AliveMasterLimitsV1,struct_bytes)==4 && offsetof(AliveMasterLimitsV1,features)==8 && offsetof(AliveMasterLimitsV1,ramp_frames)==12 && offsetof(AliveMasterLimitsV1,max_gain)==16, "limits offsets");
+MASTER_ASSERT(sizeof(AliveMasterStateV1)==80 && MASTER_ALIGN(AliveMasterStateV1)==8, "state layout");
+MASTER_ASSERT(offsetof(AliveMasterStateV1,version)==0 && offsetof(AliveMasterStateV1,struct_bytes)==4 && offsetof(AliveMasterStateV1,clip_mask)==8 && offsetof(AliveMasterStateV1,reserved)==12 && offsetof(AliveMasterStateV1,target_gain)==16 && offsetof(AliveMasterStateV1,current_gain)==24 && offsetof(AliveMasterStateV1,peak_left)==32 && offsetof(AliveMasterStateV1,peak_right)==40 && offsetof(AliveMasterStateV1,applied_serial)==48 && offsetof(AliveMasterStateV1,applied_frame)==56 && offsetof(AliveMasterStateV1,observation_start_frame)==64 && offsetof(AliveMasterStateV1,observation_end_frame)==72, "state offsets");
+#undef MASTER_ASSERT
+#undef MASTER_ALIGN
+#endif
diff --git a/apps/ultra/src-tauri/native/alive_session.hpp b/apps/ultra/src-tauri/native/alive_session.hpp
index 944911d..9b3adb1 100644
--- a/apps/ultra/src-tauri/native/alive_session.hpp
+++ b/apps/ultra/src-tauri/native/alive_session.hpp
@@ -1,5 +1,6 @@
 #pragma once
 #include "alive_session.h"
+#include "alive-master-v1.h"
 #include "canvas_workspace.hpp"
 #include "alive_session_clip_policy.hpp"
 #include "alive_session_workspace_envelope.hpp"
@@ -12,6 +13,7 @@
 namespace ultra {
 #ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
 inline void (*alive_session_test_boundary)()noexcept=nullptr;
+inline void (*alive_session_test_publication)()noexcept=nullptr;
 inline void (*alive_session_test_charge)(unsigned,const clip_admission::Cost&)noexcept=nullptr;
 inline unsigned alive_session_test_fault_resource=0;
 inline void (*alive_session_test_dispatch)(uint64_t,unsigned,unsigned,const AliveSessionEventV2&)noexcept=nullptr;
@@ -49,7 +51,10 @@ class AliveSession {
  std::atomic<uint64_t> stop_epoch_{0},rejected_{0};uint64_t applied_stop_=0;
  static constexpr unsigned Words=(sizeof(AliveSessionStateV4)+7)/8;
  std::array<std::atomic<uint64_t>,Words> published_{};
+ std::array<std::atomic<uint64_t>,sizeof(AliveMasterStateV1)/8> published_master_{};
  std::atomic<uint64_t> publication_{0};
+ AliveMasterStateV1 master_{ALIVE_MASTER_V1,sizeof(AliveMasterStateV1),0,0,1.,1.,0.,0.,0,0,0,0};
+ double master_from_=1.;unsigned master_ramp_=0;bool master_quiescent_=false;
  unsigned next_event_=0;
  // Control-thread snapshots retain structural constraints for queued base edits.
  std::array<CanvasPlan,16> parameter_plans_{};
@@ -134,6 +139,22 @@ class AliveSession {
  }
  const char* error()const noexcept{return error_;}
  bool configured()const noexcept{return state_.configured!=0;}
+ void clear_master()noexcept{master_={ALIVE_MASTER_V1,sizeof(AliveMasterStateV1),0,0,1.,1.,0.,0.,0,0,state_.absolute_frame,state_.absolute_frame};master_from_=1.;master_ramp_=0;}
+ void apply_master(const Command& c)noexcept{
+  if(c.kind==7){master_.target_gain=c.value;master_from_=master_.current_gain;master_ramp_=master_quiescent_?0:64;if(master_quiescent_)master_.current_gain=c.value;}
+  else master_.clip_mask=0;
+  master_.applied_serial=c.frame;master_.applied_frame=state_.absolute_frame;
+ }
+ int master_command(uint32_t version,double value,uint64_t serial,bool reset,bool quiescent,CanvasWorkspace& workspace)noexcept{
+  if(version!=ALIVE_MASTER_V1)return ALIVE_MASTER_UNSUPPORTED;
+  if(!serial||(!reset&&!gain(value)))return ALIVE_MASTER_INVALID;
+  if(!configured())return ALIVE_MASTER_UNCONFIGURED;
+  if(quiescent){master_quiescent_=true;begin(workspace);}
+  Command c{};c.kind=reset?8:7;c.value=value;c.frame=serial;
+  if(!enqueue(c,false)){master_quiescent_=false;return ALIVE_MASTER_FULL;}
+  if(quiescent){begin(workspace);publish(workspace);master_quiescent_=false;}
+  return ALIVE_MASTER_OK;
+ }
  bool hosted(unsigned document)const noexcept{for(unsigned d=0;d<config_.device_count;++d)if(config_.devices[d].document==document)return true;return false;}
  bool validate(const AliveSessionConfig& c)noexcept{AliveSessionConfigV2 normalized{};return normalize_v1(c,normalized)&&validate_config(normalized,true);}
  bool validate_v2(const AliveSessionConfigV2& c)noexcept{return validate_config(c,false);}
@@ -250,7 +271,7 @@ class AliveSession {
   for(unsigned d=0;d<CanvasWorkspace::MaxDocuments;++d)if(workspace.live(d)&&documents[d]<0)return reject("Alive session cannot mix unrelated document roots.");
   parameter_plans_=parameter_plans;document_devices_=documents;config_.legacy(c);mode_=Mode::Legacy;
   const uint64_t absolute=state_.absolute_frame,generation=state_.generation;state_={};state_.version=3;state_.struct_bytes=sizeof state_;state_.absolute_frame=absolute;state_.generation=generation;
-  state_.configured=1;state_.track_count=c.track_count;state_.device_count=c.device_count;head_=0;tail_=0;applied_stop_=stop_epoch_.load();
+  state_.configured=1;state_.track_count=c.track_count;state_.device_count=c.device_count;head_=0;tail_=0;applied_stop_=stop_epoch_.load();clear_master();
   for(unsigned t=0;t<c.track_count;++t){auto& ts=state_.tracks[t].mixer;ts.gain=c.tracks[t].gain;ts.mute=c.tracks[t].mute;ts.solo=c.tracks[t].solo;}
   for(unsigned d=0;d<c.device_count;++d){auto& ds=state_.devices[d];const auto& device=c.devices[d];ds.document=device.document;ds.revision=device.revision;ds.bypassed=device.bypassed;ds.parameter_count=device.parameter_count;
    for(unsigned p=0;p<device.parameter_count;++p)ds.base[p]=device.parameters[p].base;
@@ -262,7 +283,7 @@ class AliveSession {
  void reset(CanvasWorkspace& workspace)noexcept{
   if(mode_!=Mode::Legacy){terminate_v3(workspace,ALIVE_SESSION_V3_STOP_CANCELED);const auto absolute=state_.absolute_frame,generation=state_.generation;state_={};state_.absolute_frame=absolute;state_.generation=generation;}
   else {state_.playing=0;discontinuity(workspace);}
-  mode_=Mode::Legacy;state_.profile=0;config_={};state_.configured=0;state_.track_count=0;state_.device_count=0;head_=0;tail_=0;document_devices_.fill(-1);publish(workspace);
+  mode_=Mode::Legacy;state_.profile=0;config_={};state_.configured=0;state_.track_count=0;state_.device_count=0;head_=0;tail_=0;document_devices_.fill(-1);clear_master();publish(workspace);
  }
  bool start()noexcept{if(mode_!=Mode::Legacy)return reject("Use identity-bearing v3 requests.");if(!configured())return reject("No Alive session configured.");Command c{};c.kind=1;return enqueue(c);}
  uint64_t stop()noexcept{
@@ -289,6 +310,7 @@ class AliveSession {
   Command c{};c.kind=4;c.track=track;c.value=level;c.mute=mute;c.solo=solo;return enqueue(c);
  }
  void begin(CanvasWorkspace& workspace)noexcept{
+  master_.peak_left=master_.peak_right=0;master_.observation_start_frame=master_.observation_end_frame=state_.absolute_frame;
   // An acquired command head also orders the producer's preceding Stop.
   // Snapshot it first so a newly published Start/Seek cannot look stale.
   const unsigned end=head_.load(std::memory_order_acquire);
@@ -305,9 +327,10 @@ class AliveSession {
    else if(c.kind==3){auto& ds=state_.devices[c.track];ds.base[c.param]=c.value;if(!ds.owned[c.param])parameter(workspace,c.track,c.param,c.value);}
    else if(c.kind==4){auto& ts=state_.tracks[c.track].mixer;ts.gain=c.value;ts.mute=c.mute;ts.solo=c.solo;}
    else if(c.kind==5)state_.devices[c.track].bypassed=c.mute;
+   else if(c.kind==7||c.kind==8)apply_master(c);
   }tail_.store(tail,std::memory_order_release);state_.peak_left=state_.peak_right=0;for(auto& ts:state_.tracks)ts.mixer.peak_left=ts.mixer.peak_right=0;
  }
- void device_stopped(CanvasWorkspace& workspace)noexcept{stop();begin(workspace);publish(workspace);}
+ void device_stopped(CanvasWorkspace& workspace)noexcept{stop();master_quiescent_=true;begin(workspace);publish(workspace);master_quiescent_=false;}
  void dispatch_event(CanvasWorkspace& workspace,const AliveSessionEventV2& event)noexcept{
 #ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
    if(mode_==Mode::Workspaces&&alive_session_test_dispatch)alive_session_test_dispatch(state_.absolute_frame,resolved_[event.track].source,resolved_[event.track].occurrence,event);
@@ -329,7 +352,10 @@ class AliveSession {
   bool solo=false;for(unsigned t=0;t<config_.track_count;++t)solo|=state_.tracks[t].mixer.solo;
   for(unsigned t=0;t<config_.track_count;++t)if(config_.devices[config_.tracks[t].instrument].document==document){auto& ts=state_.tracks[t].mixer;
    if(!state_.playing||(mode_!=Mode::Legacy&&state_.tracks[t].active_clip==ALIVE_SESSION_V3_NONE)||ts.mute||(solo&&!ts.solo))return {};
-   const std::array<double,2> output{signal[0]*ts.gain,signal[1]*ts.gain};ts.peak_left=std::max(ts.peak_left,std::abs(output[0]));ts.peak_right=std::max(ts.peak_right,std::abs(output[1]));return output;
+   const std::array<double,2> output{signal[0]*ts.gain,signal[1]*ts.gain};
+   if(std::isfinite(output[0]))ts.peak_left=std::max(ts.peak_left,std::abs(output[0]));
+   if(std::isfinite(output[1]))ts.peak_right=std::max(ts.peak_right,std::abs(output[1]));
+   return output;
   }return signal;
  }
  template<class Emit> std::array<double,2> render_sample(CanvasWorkspace& workspace,const std::array<float,alive::DocumentDevices>& voices,unsigned next_offset,Emit& emit)noexcept{
@@ -342,10 +368,24 @@ class AliveSession {
     if(!state_.devices[d].bypassed)signal=wet;
    }
    const auto endpoint=mix(doc,signal);sum[0]+=endpoint[0];sum[1]+=endpoint[1];
-  }return sum;
+  }
+  if(master_ramp_){const unsigned step=65-master_ramp_;master_.current_gain=master_from_+(master_.target_gain-master_from_)*double(step)/64.;--master_ramp_;}
+  else master_.current_gain=master_.target_gain;
+  sum[0]*=master_.current_gain;sum[1]*=master_.current_gain;
+  if(std::isfinite(sum[0])){
+   if(std::abs(sum[0])>1.)master_.clip_mask|=1;
+  }
+  if(std::isfinite(sum[1])){
+   if(std::abs(sum[1])>1.)master_.clip_mask|=2;
+  }
+  return sum;
+ }
+ void observe_master(const std::array<double,2>& sample)noexcept{
+  if(std::isfinite(sample[0]))master_.peak_left=std::max(master_.peak_left,std::abs(sample[0]));
+  if(std::isfinite(sample[1]))master_.peak_right=std::max(master_.peak_right,std::abs(sample[1]));
  }
  void advance(CanvasWorkspace& workspace,double left,double right)noexcept{
-  ++state_.absolute_frame;state_.peak_left=std::max(state_.peak_left,std::abs(left));state_.peak_right=std::max(state_.peak_right,std::abs(right));if(mode_!=Mode::Legacy){advance_v3(workspace);return;}if(!state_.playing)return;
+  ++state_.absolute_frame;master_.observation_end_frame=state_.absolute_frame;state_.peak_left=std::max(state_.peak_left,std::abs(left));state_.peak_right=std::max(state_.peak_right,std::abs(right));if(mode_!=Mode::Legacy){advance_v3(workspace);return;}if(!state_.playing)return;
   ++state_.position;if(config_.loop_enabled&&state_.position>=config_.loop_end){state_.position=config_.loop_start;discontinuity(workspace);}
   else if(state_.position>=config_.length_frames){state_.playing=0;discontinuity(workspace);}
  }
@@ -356,7 +396,11 @@ class AliveSession {
  }
  template<class T> void publish_wire(const T& value)noexcept{
   publication_.fetch_add(1);
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+  if(alive_session_test_publication)alive_session_test_publication();
+#endif
   for(unsigned i=0;i<sizeof(T)/8;++i){uint64_t word;std::memcpy(&word,reinterpret_cast<const char*>(&value)+i*8,8);published_[i].store(word);}
+  for(unsigned i=0;i<sizeof(master_)/8;++i){uint64_t word;std::memcpy(&word,reinterpret_cast<const char*>(&master_)+i*8,8);published_master_[i].store(word);}
   publication_.fetch_add(1);
  }
  template<class T> bool coherent_wire(T& result,unsigned version)const noexcept{
@@ -370,6 +414,35 @@ class AliveSession {
   }return false;
  }
  bool coherent(AliveSessionStateV3& result)const noexcept{return coherent_wire(result,3);}
+ template<class T> int master_snapshot_wire(T& score,AliveMasterStateV1& master,unsigned version)const noexcept{
+  for(unsigned attempt=0;attempt<4;++attempt){
+   const auto before=publication_.load();if(before&1)continue;
+   std::array<uint64_t,sizeof(T)/8> words{};
+   for(unsigned i=0;i<words.size();++i)words[i]=published_[i].load();
+   std::array<uint64_t,sizeof(AliveMasterStateV1)/8> mw{};
+   for(unsigned i=0;i<mw.size();++i)mw[i]=published_master_[i].load();
+   if(before!=publication_.load())continue;
+   T value{};AliveMasterStateV1 observation{};std::memcpy(&value,words.data(),sizeof value);std::memcpy(&observation,mw.data(),sizeof observation);
+   if(!value.configured)return ALIVE_MASTER_UNCONFIGURED;
+   if(value.version!=version||value.struct_bytes!=sizeof value)return ALIVE_MASTER_UNSUPPORTED;
+   value.rejected=rejected_.load();
+   score=value;master=observation;return ALIVE_MASTER_OK;
+  }return ALIVE_MASTER_BUSY;
+ }
+ int master_snapshot(AliveSessionStateV2& score,AliveMasterStateV1& master)const noexcept{
+  AliveSessionStateV3 value{};AliveMasterStateV1 observation{};const int result=master_snapshot_wire(value,observation,3);
+  if(result!=ALIVE_MASTER_OK)return result;
+  if(value.profile||!project_v2(value,score))return ALIVE_MASTER_UNSUPPORTED;
+  master=observation;return ALIVE_MASTER_OK;
+ }
+ int master_snapshot(AliveSessionStateV3& score,AliveMasterStateV1& master)const noexcept{
+  AliveSessionStateV3 value{};AliveMasterStateV1 observation{};const int result=master_snapshot_wire(value,observation,3);
+  if(result!=ALIVE_MASTER_OK)return result;
+  if(!value.profile)return ALIVE_MASTER_UNSUPPORTED;
+  for(auto& receipt:value.receipts){receipt.version=3;receipt.struct_bytes=sizeof receipt;}
+  score=value;master=observation;return ALIVE_MASTER_OK;
+ }
+ int master_snapshot(AliveSessionStateV4& score,AliveMasterStateV1& master)const noexcept{return master_snapshot_wire(score,master,4);}
  bool receipt_available(unsigned cell,uint64_t preparation,uint64_t serial,unsigned version)const noexcept{
   for(unsigned attempt=0;attempt<4;++attempt){
    const auto before=publication_.load();if(before&1)continue;
diff --git a/apps/ultra/src-tauri/native/alive_session_clips.hpp b/apps/ultra/src-tauri/native/alive_session_clips.hpp
index 2a30a66..e3c2bb3 100644
--- a/apps/ultra/src-tauri/native/alive_session_clips.hpp
+++ b/apps/ultra/src-tauri/native/alive_session_clips.hpp
@@ -643,6 +643,7 @@ bool configure_v3(const AliveSessionConfigV3 &c, CanvasWorkspace &workspace) noe
   state_.preparation_revision = c.preparation_revision;
   head_ = 0;
   tail_ = 0;
+  clear_master();
   applied_stop_ = stop_epoch_.load();
   state_.requested_stop_epoch = state_.applied_stop_epoch = applied_stop_;
   reservations_ = {};
@@ -948,6 +949,7 @@ void begin_v3(CanvasWorkspace &workspace, unsigned end, uint64_t stop) noexcept
   for (unsigned budget = 0; tail != end && budget < 64; ++budget) {
     const auto &c = commands_[tail];
     tail = (tail + 1) % 65;
+    if (c.kind == 7 || c.kind == 8) { trace_charge(3, Cost{0, 0, 0, 0, 1}); apply_master(c); continue; }
     if (c.kind == 3) {
       trace_charge(3, Cost{0, 0, 0, 1, 0});
       auto &ds = state_.devices[c.track];
diff --git a/apps/ultra/src-tauri/native/alive_session_v3_policy.md b/apps/ultra/src-tauri/native/alive_session_v3_policy.md
index f9e87c7..5a1f457 100644
--- a/apps/ultra/src-tauri/native/alive_session_v3_policy.md
+++ b/apps/ultra/src-tauri/native/alive_session_v3_policy.md
@@ -29,6 +29,9 @@ The actual single strict-prefix scan can do fewer scans/writes. Track-local
 clears never reset another track. Already-accepted base/bypass/mixer commands
 have a separate fixed allowance of 64 commands per callback, including up to
 64 direct parameter applications even when a seek is rejected.
+Master set and latch reset share those same 64 slots. Their bounded reducer
+steps are recorded in trace family 3, and the Master burst qualification
+measures those steps, per-frame gain/meter work and combined publication reads.
 
 The minimum period is 188 frames. A 1024-frame interval has at most six
 quantization boundaries and seven positive-length segments. Across those
diff --git a/apps/ultra/src-tauri/native/alive_session_v4_policy.md b/apps/ultra/src-tauri/native/alive_session_v4_policy.md
index 21217cf..4a7bb69 100644
--- a/apps/ultra/src-tauri/native/alive_session_v4_policy.md
+++ b/apps/ultra/src-tauri/native/alive_session_v4_policy.md
@@ -31,6 +31,10 @@ Direct base commands have their existing separate fixed queue allowance of up
 to 64 parameter writes. They are counted in addition to, and separately from,
 the scheduled/optional/emergency writes. Failed expensive optional checks retain
 their guard/placement charge; Stop does not reset rolling history.
+Master set and latch reset consume the same 64 queue slots; trace family 3
+records their bounded reducer steps. The separate `master_burst64` cases add
+one combined v4/Master read to the timed render, including the largest snapshot
+copy. Results for those cases require the Task 7 measurement receipt.
 
 ## What The Runner Measures
 
diff --git a/apps/ultra/src-tauri/native/alive_session_workspaces.hpp b/apps/ultra/src-tauri/native/alive_session_workspaces.hpp
index f0e24d7..077576d 100644
--- a/apps/ultra/src-tauri/native/alive_session_workspaces.hpp
+++ b/apps/ultra/src-tauri/native/alive_session_workspaces.hpp
@@ -701,6 +701,7 @@ bool configure_v4(const AliveSessionConfigV4 &c, const AliveSessionAudioBufferV4
   state_.preparation_revision = c.preparation_revision;
   head_ = 0;
   tail_ = 0;
+  clear_master();
   applied_stop_ = stop_epoch_.load();
   state_.requested_stop_epoch = state_.applied_stop_epoch = applied_stop_;
   reservations_ = {};
diff --git a/apps/ultra/src-tauri/native/backend.cpp b/apps/ultra/src-tauri/native/backend.cpp
index 1500616..a8e8064 100644
--- a/apps/ultra/src-tauri/native/backend.cpp
+++ b/apps/ultra/src-tauri/native/backend.cpp
@@ -2,6 +2,7 @@
 #include "sequence.hpp"
 #include "canvas_workspace.hpp"
 #include "alive_session.hpp"
+#include "alive-master-v1.h"
 #include "../../core/engine.hpp"
 #include <atomic>
 #include <array>
@@ -430,7 +431,7 @@ int render_audio(Frames n,float* l,float* r,bool with_midi){
    if(canvas.failed()||!std::isfinite(left)||!std::isfinite(right)||std::abs(left)>std::numeric_limits<float>::max()||std::abs(right)>std::numeric_limits<float>::max()){
     engine.panic();break;
    }
-   l[frame]=float(left);r[frame]=float(right);
+   session.observe_master(hosted);l[frame]=float(left);r[frame]=float(right);
    session.advance(canvas,left,right);
   }else {sequence.sample(frame,emit);session.advance(canvas,0,0);}
  }
@@ -462,6 +463,25 @@ void put16(FILE*f,uint16_t n){unsigned char b[]={static_cast<unsigned char>(n),s
 void put32(FILE*f,uint32_t n){put16(f,n);put16(f,n>>16);}
 }
 extern "C" {
+int alive_session_master_limits(AliveMasterLimitsV1* out){
+ if(!out)return ALIVE_MASTER_INVALID;
+ if(out->version!=ALIVE_MASTER_V1||out->struct_bytes!=sizeof(*out))return ALIVE_MASTER_UNSUPPORTED;
+ *out={ALIVE_MASTER_V1,sizeof(*out),ALIVE_MASTER_FEATURE_GAIN|ALIVE_MASTER_FEATURE_METER|ALIVE_MASTER_FEATURE_RESET,64,4.};
+ return ALIVE_MASTER_OK;
+}
+int alive_session_master_set(uint32_t version,double gain,uint64_t serial){return session.master_command(version,gain,serial,false,!running.load()&&!engine.status().ready,canvas);}
+int alive_session_master_reset_clip(uint32_t version,uint64_t serial){return session.master_command(version,0,serial,true,!running.load()&&!engine.status().ready,canvas);}
+#define MASTER_SNAPSHOT(N) \
+int alive_session_master_snapshot_v##N(AliveSessionStateV##N* score,AliveMasterStateV1* master){ \
+ if(!score||!master)return ALIVE_MASTER_INVALID; \
+ if(master->version!=ALIVE_MASTER_V1||master->struct_bytes!=sizeof(*master)||score->version!=N||score->struct_bytes!=sizeof(*score))return ALIVE_MASTER_UNSUPPORTED; \
+ if(master->reserved)return ALIVE_MASTER_INVALID; \
+ return session.master_snapshot(*score,*master); \
+}
+MASTER_SNAPSHOT(2)
+MASTER_SNAPSHOT(3)
+MASTER_SNAPSHOT(4)
+#undef MASTER_SNAPSHOT
 int alive_session_validate_v2(const AliveSessionConfigV2* config){return config&&session.validate_v2(*config);}
 int alive_session_validate_device_v2(const AliveSessionDeviceV2* device,const UltraCanvasGraph* graph){return device&&graph&&session.validate_device_v2(*device,*graph);}
 int alive_session_validate_prepared_v2(const AliveSessionConfigV2* config,const UltraCanvasGraph* graphs,uint32_t count){return config&&session.validate_prepared_v2(*config,graphs,count);}
diff --git a/apps/ultra/src-tauri/src/audio_instrumentation.rs b/apps/ultra/src-tauri/src/audio_instrumentation.rs
index ef8db5e..163b1cf 100644
--- a/apps/ultra/src-tauri/src/audio_instrumentation.rs
+++ b/apps/ultra/src-tauri/src/audio_instrumentation.rs
@@ -156,7 +156,7 @@ fn native_saved_clip_release_overhead() {
     let fixture_sha = format!("{:x}", Sha256::digest(std::fs::read(&fixture).unwrap()));
     let mut host = Host::default();
     let prepared = host.enable_clips(read(&fixture).unwrap()).unwrap();
-    assert!(prepared.document.is_clips() && prepared.document.loop_enabled());
+    assert!(prepared.saved.score.is_clips() && prepared.saved.score.loop_enabled());
     let count:usize=std::env::var("ALIVE_MEASUREMENT_SAMPLES").map(|value|value.parse().unwrap()).unwrap_or(5000);
     assert!((1000..=20000).contains(&count));
     let raw_output=std::env::var_os("ALIVE_MEASUREMENT_OUTPUT").map(PathBuf::from);
diff --git a/apps/ultra/src-tauri/src/document_commands.rs b/apps/ultra/src-tauri/src/document_commands.rs
index 321dc30..d13d601 100644
--- a/apps/ultra/src-tauri/src/document_commands.rs
+++ b/apps/ultra/src-tauri/src/document_commands.rs
@@ -14,6 +14,13 @@ pub struct Parameter { pub node: u32, pub key: String, pub value: f64, #[serde(d
 #[serde(deny_unknown_fields)]
 pub struct MessageText { pub node: u32, pub text: String }
 
+pub(crate) fn trace_document(event: &str, document: &Document, token: u64, code: u8) {
+    if std::env::var_os("ULTRA_TRACE_DOCUMENT_COMMANDS").is_some() {
+        eprintln!("ultra-document-trace event={event} owner={} revision={} scope={} depth={} token={token} code={code}",
+            document.id, document.authoring_revision, document.view_path.last().copied().unwrap_or(0), document.view_path.len());
+    }
+}
+
 pub(crate) fn canvas_parameter(registry: &mut Registry, audio: &mut crate::AudioControl,
     io: &mut crate::audio::Driver, label: &str, revision: u64, parameter: Parameter) -> Result<CommitResult, String> {
     let owner = registry.get_open(label)?;
@@ -129,6 +136,9 @@ pub fn close_cancelled(app: &AppHandle, notice: Option<documents::CloseNotice>)
 pub fn request_close_flush(app: &AppHandle, notice: documents::CloseNotice) {
     let payload = serde_json::json!({"requestLabel":notice.request_label,"token":notice.token});
     for label in notice.views {
+        if let Ok(registry) = app.state::<Documents>().0.lock() {
+            if let Ok(document) = registry.descriptor(&label) { trace_document("close_flush", &document, notice.token, 0); }
+        }
         let sent = app.get_webview_window(&label).ok_or_else(|| "Editor window is unavailable".to_string())
             .and_then(|target| target.emit_to(tauri::EventTarget::webview_window(&label), "document-flush-before-close", &payload).map_err(|e| e.to_string()));
         if let Err(error) = sent {
@@ -141,9 +151,43 @@ pub fn request_close_flush(app: &AppHandle, notice: documents::CloseNotice) {
     }
 }
 
+pub fn request_save_flush(app: &AppHandle, notice: &documents::SaveNotice) {
+    let payload = serde_json::json!({"owner":notice.owner,"token":notice.token});
+    for label in &notice.views {
+        let sent = app.get_webview_window(label).ok_or_else(|| "Editor window is unavailable".to_string())
+            .and_then(|target| target.emit_to(tauri::EventTarget::webview_window(label), "document-flush-before-save", &payload).map_err(|e| e.to_string()));
+        if sent.is_err() {
+            if let Ok(mut registry) = app.state::<Documents>().0.lock() {
+                let _ = registry.acknowledge_save(label, &notice.owner, notice.token, Some("Editor window is unavailable".into()));
+            }
+        }
+    }
+}
+
+pub fn release_save_flush(app: &AppHandle, notice: documents::SaveNotice) {
+    let payload = serde_json::json!({"owner":notice.owner,"token":notice.token});
+    for label in notice.views { let _ = app.emit_to(tauri::EventTarget::webview_window(label), "document-save-flush-released", &payload); }
+}
+
+#[tauri::command]
+pub fn document_save_flushed(window: WebviewWindow, state: tauri::State<Documents>, owner: String, token: u64, error: Option<String>) -> Result<(), String> {
+    let mut registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
+    let document = registry.descriptor(window.label())?;
+    let accepted = u8::from(error.is_none());
+    registry.acknowledge_save(window.label(), &owner, token, error)?;
+    trace_document("save_ack", &document, token, accepted);
+    Ok(())
+}
+
+#[tauri::command]
+pub fn document_save_barrier_active(window: WebviewWindow, state: tauri::State<Documents>, owner: String, token: u64) -> Result<bool, String> {
+    state.0.lock().map_err(|_| "Document lock poisoned")?.save_barrier_active(window.label(), &owner, token)
+}
+
 #[tauri::command]
 pub fn document_close_flushed(window: WebviewWindow, state: tauri::State<Documents>, request_label: String, token: u64, error: Option<String>) -> Result<bool, String> {
     let mut registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
+    if let Ok(document) = registry.descriptor(window.label()) { trace_document("close_ack", &document, token, u8::from(error.is_none())); }
     if let Some(error) = error {
         let cancelled = registry.reject_close(window.label(), &request_label, token)?;
         drop(registry);
@@ -173,6 +217,7 @@ pub fn document_commit(window: WebviewWindow, state: tauri::State<Documents>, au
     let result = registry.commit(window.label(), base_revision, patch, history.unwrap_or(true), |owner, patch| {
         admit_owned(&mut io, &mut audio.graphs[owner.id as usize], owner, patch, parameter.as_ref(), message_text.as_ref(), force.unwrap_or(false))
     })?;
+    trace_document("commit", &result.document, base_revision, u8::from(result.accepted));
     drop(io);
     drop(audio);
     let obsolete = if result.accepted { changed(window.app_handle(), &mut registry, &result.document.owner_label) } else { vec![] };
diff --git a/apps/ultra/src-tauri/src/document_windows.rs b/apps/ultra/src-tauri/src/document_windows.rs
index 2507188..6c108ef 100644
--- a/apps/ultra/src-tauri/src/document_windows.rs
+++ b/apps/ultra/src-tauri/src/document_windows.rs
@@ -70,6 +70,10 @@ impl QuitSession {
     fn can_exit(&self, registry: &Registry) -> bool {
         self.saves == 0 && (registry.list().is_empty() || (self.committed && self.owners == owner_labels(registry)))
     }
+    fn resume_after_save(&self) -> Option<(String, u64)> {
+        if self.saves != 0 { return None; }
+        self.current().map(|label| (label.to_owned(), self.generation))
+    }
 }
 
 fn owner_labels(registry: &Registry) -> Vec<String> {
@@ -210,8 +214,10 @@ pub fn document_current(window: WebviewWindow, state: tauri::State<Documents>, a
     })?;
     registry.set_reveal(window.label(), None, None)?;
     let flushes = registry.mark_ready(window.label())?;
+    let save_flush = registry.mark_save_ready(window.label())?;
     drop(registry);
     for notice in flushes { commands::request_close_flush(window.app_handle(), notice); }
+    if let Some(notice) = save_flush { commands::request_save_flush(window.app_handle(), &notice); }
     Ok(document)
 }
 
@@ -258,16 +264,39 @@ pub async fn document_save(window: WebviewWindow, save_as: bool) -> Result<Optio
     let app = window.app_handle().clone();
     let label = window.label().to_owned();
     let save_quit_token = quit_token_for(&app, &label);
-    {
+    let (wake, receiver) = std::sync::mpsc::sync_channel(1);
+    let notice = {
         let state = app.state::<Documents>();
-        let registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
+        let mut registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
         registry.get_open(&label)?;
-        state.1.lock().map_err(|_| "Quit lock poisoned")?.saves += 1;
-    }
-    let result = tauri::async_runtime::spawn_blocking(move || {
+        let mut quit = state.1.lock().map_err(|_| "Quit lock poisoned")?;
+        let notice = registry.begin_save(&label, wake)?;
+        quit.saves += 1;notice
+    };
+    let lease=SaveLease { app:app.clone(), owner:notice.owner.clone(), token:notice.token, label, quit_token:save_quit_token, clean:false };
+    commands::request_save_flush(&app, &notice);
+    tauri::async_runtime::spawn_blocking(move || {
+      let mut lease=lease;
+      let result: Result<Option<Document>, String> = (|| {
         let app = window.app_handle();
         let state = app.state::<Documents>();
-        let current = state.0.lock().map_err(|_| "Document lock poisoned")?.get_open(window.label())?.clone();
+        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(15);
+        let current = loop {
+            let timeout = receiver.recv_timeout(deadline.saturating_duration_since(std::time::Instant::now())).is_err();
+            let completed = state.0.lock().map_err(|_| "Document lock poisoned")?.finish_save_preflight(&notice.owner, notice.token, timeout)?;
+            if let Some(completed) = completed {
+                commands::release_save_flush(app, completed.notice);
+                if completed.document.is_err() {
+                    if let Ok(registry) = state.0.lock() {
+                        if let Ok(document) = registry.descriptor(window.label()) { commands::trace_document("save_refused", &document, notice.token, 0); }
+                    }
+                }
+                break completed.document?;
+            }
+        };
+        let mut view = state.0.lock().map_err(|_| "Document lock poisoned")?.descriptor(window.label())?;
+        view.authoring_revision = current.authoring_revision;
+        commands::trace_document("save_begin", &view, 0, u8::from(save_as));
         let patch = current.patch.clone().ok_or("Patch is not ready to save")?;
         let direct = !save_as && current.kind == Kind::Patch && current.source.is_none();
         let path = if direct { current.path.clone() } else { None };
@@ -278,7 +307,7 @@ pub async fn document_save(window: WebviewWindow, save_as: bool) -> Result<Optio
                 let mut picker = window.dialog().file().set_parent(&window).set_title("Save Ultra Patch")
                     .add_filter("Ultra patch", &["ultra"]).set_file_name(format!("{name}.ultra"));
                 if let Some(parent) = current.path.as_ref().and_then(|p| p.parent()) { picker = picker.set_directory(parent); }
-                let Some(path) = picker.blocking_save_file() else { return Ok(None); };
+                let Some(path) = picker.blocking_save_file() else { commands::trace_document("save_cancel", &view, 0, u8::from(save_as)); return Ok(None); };
                 path.into_path().map_err(|e| format!("Choose a local save location: {e}"))?
             }
         };
@@ -287,14 +316,30 @@ pub async fn document_save(window: WebviewWindow, save_as: bool) -> Result<Optio
         registry.check_save_path(window.label(), &path)?;
         let path = documents::save_patch(&path, &patch)?;
         let document = registry.saved(window.label(), path, patch)?;
+        commands::trace_document("save_done", &document, 0, u8::from(save_as));
         drop(registry);
         let registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
         commands::broadcast(app, &registry, &document.owner_label);
         Ok(Some(document))
-    }).await.map_err(|e| format!("Save task failed: {e}")).and_then(|result| result);
-    if let Ok(mut quit) = app.state::<Documents>().1.lock() { quit.saves = quit.saves.saturating_sub(1); }
-    if !matches!(&result, Ok(Some(document)) if !document.dirty) { cancel_quit_for(&app, &label, save_quit_token); }
-    result
+      })();
+      lease.clean=matches!(&result, Ok(Some(document)) if !document.dirty);
+      result
+    }).await.map_err(|e| format!("Save task failed: {e}"))?
+}
+
+struct SaveLease { app: AppHandle, owner: String, token: u64, label: String, quit_token: Option<u64>, clean: bool }
+impl Drop for SaveLease {
+    fn drop(&mut self) {
+        if let Ok(registry) = self.app.state::<Documents>().0.lock() {
+            if let Ok(document) = registry.descriptor(&self.label) { commands::trace_document("save_cleanup", &document, self.token, u8::from(self.clean)); }
+        }
+        let cleanup = self.app.state::<Documents>().0.lock().ok().and_then(|mut registry| registry.end_save(&self.owner, self.token).ok().flatten());
+        if let Some(notice) = cleanup { commands::release_save_flush(&self.app, notice); }
+        if let Ok(mut quit) = self.app.state::<Documents>().1.lock() { quit.saves = quit.saves.saturating_sub(1); }
+        if !self.clean { cancel_quit_for(&self.app, &self.label, self.quit_token); }
+        let resume = self.app.state::<Documents>().1.lock().ok().and_then(|quit| quit.resume_after_save());
+        if let Some((label, token)) = resume { queue_quit_prepare(&self.app, label, token); }
+    }
 }
 
 #[tauri::command]
@@ -339,6 +384,9 @@ pub fn document_open_help(app: AppHandle, key: String) -> Result<Document, Strin
 
 #[tauri::command]
 pub fn document_close_confirmed(window: WebviewWindow, state: tauri::State<Documents>, quit_token: Option<u64>) -> Result<bool, String> {
+    if let Ok(registry) = state.0.lock() {
+        if let Ok(document) = registry.descriptor(window.label()) { commands::trace_document("close_confirm", &document, quit_token.unwrap_or(0), 0); }
+    }
     if !valid_quit_token(window.app_handle(), window.label(), quit_token) { return Ok(false); }
     if let Some(token) = quit_token {
         let registry = state.0.lock().map_err(|_| "Document lock poisoned")?;
@@ -393,6 +441,7 @@ fn prepare_quit_owner(app: &AppHandle, label: &str, token: u64) {
     let (Ok(mut registry), Ok(quit)) = (state.0.lock(), state.1.lock()) else { return; };
     if quit.current() != Some(label) || quit.generation != token || quit.saves != 0 { return; }
     let Ok(document) = registry.get(label) else { drop(quit); drop(registry); cancel_quit(app); return; };
+    commands::trace_document("quit_prepare", document, token, 0);
     if document.close_pending { return; }
     let gate = registry.begin_close(label);
     match gate {
@@ -687,7 +736,11 @@ fn document_menu(app: &AppHandle, label: &str) -> tauri::Result<tauri::menu::Men
     use tauri::menu::{MenuBuilder, SubmenuBuilder};
     let id = |action| format!("doc:{label}:{action}");
     let file = SubmenuBuilder::new(app, "File").text(id("new"), "New Patch").text(id("open"), "Open...")
-        .separator().text(id("save"), "Save").text(id("save-as"), "Save As...").separator().text(id("close"), "Close Window").build()?;
+        .separator().text(id("save"), "Save").text(id("save-as"), "Save As...").separator().text(id("close"), "Close Window");
+    #[cfg(not(target_os = "macos"))]
+    let file = file.separator().item(&tauri::menu::MenuItemBuilder::with_id("ultra-quit", "Quit Ultra")
+        .accelerator("CmdOrCtrl+Q").build(app)?);
+    let file = file.build()?;
     let help = SubmenuBuilder::new(app, "Help").text(id("library"), "Help & Examples").build()?;
     let menu = MenuBuilder::new(app);
     #[cfg(target_os = "macos")]
@@ -770,6 +823,28 @@ mod lifecycle_tests {
         assert_eq!(quit.approve("b"), QuitStep::Commit);
     }
 
+    #[test]
+    fn last_unrelated_save_resumes_the_current_quit_generation() {
+        let mut quit=QuitSession::default();
+        assert_eq!(quit.start(vec!["a".into(),"b".into()]),QuitStep::Prepare("a".into()));
+        let generation=quit.generation;quit.saves=2;
+        assert_eq!(quit.resume_after_save(),None);quit.saves-=1;assert_eq!(quit.resume_after_save(),None);
+        quit.saves-=1;assert_eq!(quit.resume_after_save(),Some(("a".into(),generation)));
+        assert_eq!(quit.approve("a"),QuitStep::Prepare("b".into()));
+        assert_eq!(quit.resume_after_save(),Some(("b".into(),generation)));
+        quit.active=false;assert_eq!(quit.resume_after_save(),None);
+    }
+
+    #[test]
+    fn worker_owns_and_drops_the_complete_save_lease_after_marking_clean() {
+        use std::sync::{Arc, atomic::{AtomicU8, Ordering}};
+        struct Lease { clean: bool, receipt: Arc<AtomicU8> }
+        impl Drop for Lease { fn drop(&mut self) { self.receipt.store(if self.clean { 1 } else { 2 }, Ordering::SeqCst); } }
+        let receipt=Arc::new(AtomicU8::new(0));let lease=Lease { clean:false,receipt:receipt.clone() };
+        std::thread::spawn(move || { let mut lease=lease;lease.clean=true; }).join().unwrap();
+        assert_eq!(receipt.load(Ordering::SeqCst),1);
+    }
+
     #[test]
     fn native_quit_requests_coalesce_and_old_dispatch_dies_after_cancel() {
         let mut quit = QuitSession::default();
diff --git a/apps/ultra/src-tauri/src/documents.rs b/apps/ultra/src-tauri/src/documents.rs
index 075d9b7..a2f2350 100644
--- a/apps/ultra/src-tauri/src/documents.rs
+++ b/apps/ultra/src-tauri/src/documents.rs
@@ -8,7 +8,10 @@ pub const MAX_DOCUMENTS: usize = 16;
 mod shared;
 #[path = "documents_close.rs"]
 mod close;
+#[path = "documents_save.rs"]
+mod save;
 pub use close::{CloseGate, CloseNotice};
+pub use save::{SaveNotice, SaveSnapshot};
 const MAX_IMPORT_BYTES: u64 = 8 * 1024 * 1024;
 static NEXT_TEMP: AtomicU64 = AtomicU64::new(1);
 
@@ -66,6 +69,7 @@ pub struct Registry {
     views: BTreeMap<String, View>,
     consoles: BTreeMap<String, ConsoleCache>,
     close: close::CloseState,
+    save: save::SaveState,
     serial: u64,
 }
 #[derive(Default)]
@@ -114,6 +118,7 @@ impl Registry {
         self.entries.get_mut(&owner).ok_or_else(|| "This patch window is closed".into())
     }
     pub fn remove(&mut self, label: &str) -> Option<Document> {
+        self.detach_save(label);
         self.detach_close(label);
         if let Some(view) = self.views.remove(label) {
             if let Some(cache) = self.consoles.get_mut(&view.owner) { cache.cursors.remove(label); }
diff --git a/apps/ultra/src-tauri/src/documents_close.rs b/apps/ultra/src-tauri/src/documents_close.rs
index ff84ab5..8d8d33d 100644
--- a/apps/ultra/src-tauri/src/documents_close.rs
+++ b/apps/ultra/src-tauri/src/documents_close.rs
@@ -18,6 +18,9 @@ pub(super) struct CloseState {
 }
 
 impl Registry {
+    pub(super) fn ready_owner_views(&self, label: &str) -> Result<Vec<String>, String> {
+        Ok(self.owner_views(label)?.into_iter().filter(|view| self.close.ready.contains(view)).collect())
+    }
     pub fn mark_ready(&mut self, label: &str) -> Result<Vec<CloseNotice>, String> {
         let owner = self.get_open(label)?.label.clone();
         if !self.close.ready.insert(label.into()) { return Ok(vec![]); }
diff --git a/apps/ultra/src-tauri/src/documents_save.rs b/apps/ultra/src-tauri/src/documents_save.rs
new file mode 100644
index 0000000..2bd4eff
--- /dev/null
+++ b/apps/ultra/src-tauri/src/documents_save.rs
@@ -0,0 +1,75 @@
+//! One bounded, token-fenced snapshot preflight per document owner.
+use super::*;
+use std::{collections::BTreeSet, sync::mpsc::SyncSender};
+
+struct Request { token: u64, awaiting: BTreeSet<String>, members: BTreeSet<String>, wake: SyncSender<()>, error: Option<String> }
+#[derive(Default)]
+pub(super) struct SaveState { requests: BTreeMap<String, Request>, reservations: BTreeMap<String, u64>, serial: u64 }
+pub struct SaveNotice { pub owner: String, pub token: u64, pub views: Vec<String> }
+pub struct SaveSnapshot { pub notice: SaveNotice, pub document: Result<Document, String> }
+
+impl Registry {
+    pub fn begin_save(&mut self, label: &str, wake: SyncSender<()>) -> Result<SaveNotice, String> {
+        let owner = self.get_open(label)?.label.clone();
+        if self.save.reservations.contains_key(&owner) { return Err("A Save is already in progress for this patch".into()); }
+        let views = self.ready_owner_views(label)?;
+        let token = self.save.serial.checked_add(1).ok_or("Save request identity exhausted")?;
+        self.save.serial = token;
+        let request = Request { token, awaiting: views.iter().cloned().collect(), members: views.iter().cloned().collect(), wake, error: None };
+        if request.awaiting.is_empty() { let _ = request.wake.try_send(()); }
+        self.save.reservations.insert(owner.clone(), token);
+        self.save.requests.insert(owner.clone(), request);
+        Ok(SaveNotice { owner, token, views })
+    }
+
+    pub fn mark_save_ready(&mut self, label: &str) -> Result<Option<SaveNotice>, String> {
+        let owner = self.get_open(label)?.label.clone();
+        let Some(request) = self.save.requests.get_mut(&owner) else { return Ok(None); };
+        if request.members.insert(label.into()) {
+            request.awaiting.insert(label.into());
+            return Ok(Some(SaveNotice { owner, token: request.token, views: vec![label.into()] }));
+        }
+        Ok(None)
+    }
+
+    pub fn acknowledge_save(&mut self, caller: &str, owner: &str, token: u64, error: Option<String>) -> Result<(), String> {
+        if self.get_open(caller)?.label != owner { return Err("Save acknowledgement belongs to another owner".into()); }
+        let request = self.save.requests.get_mut(owner).ok_or("No pending Save request")?;
+        if request.token != token || !request.awaiting.remove(caller) { return Err("Stale or unrelated Save acknowledgement".into()); }
+        if error.is_some() { request.error = Some("A linked view has an invalid or unadmitted draft".into()); }
+        if request.error.is_some() || request.awaiting.is_empty() { let _ = request.wake.try_send(()); }
+        Ok(())
+    }
+
+    pub fn finish_save_preflight(&mut self, owner: &str, token: u64, timeout: bool) -> Result<Option<SaveSnapshot>, String> {
+        let request = self.save.requests.get(owner).ok_or("No pending Save request")?;
+        if request.token != token { return Err("Stale Save request".into()); }
+        if !timeout && request.error.is_none() && !request.awaiting.is_empty() { return Ok(None); }
+        let request = self.save.requests.remove(owner).unwrap();
+        let document = if timeout { Err("Timed out waiting for linked views to flush".into()) }
+            else if let Some(error) = request.error { Err(error) }
+            else { self.get_open(owner).cloned() };
+        Ok(Some(SaveSnapshot { notice: SaveNotice { owner: owner.into(), token, views: request.members.into_iter().collect() }, document }))
+    }
+
+    pub fn save_barrier_active(&self, caller: &str, owner: &str, token: u64) -> Result<bool, String> {
+        if self.get_open(caller)?.label != owner { return Err("Save barrier belongs to another owner".into()); }
+        Ok(self.save.requests.get(owner).is_some_and(|request| request.token == token && request.members.contains(caller)))
+    }
+
+    pub fn end_save(&mut self, owner: &str, token: u64) -> Result<Option<SaveNotice>, String> {
+        if self.save.reservations.get(owner) != Some(&token) { return Err("Stale Save reservation".into()); }
+        self.save.reservations.remove(owner);
+        Ok(self.save.requests.remove(owner).map(|request| SaveNotice { owner: owner.into(), token, views: request.members.into_iter().collect() }))
+    }
+
+    pub(super) fn detach_save(&mut self, label: &str) {
+        let Ok(owner) = self.get(label).map(|document| document.label.clone()) else { return; };
+        if let Some(request) = self.save.requests.get_mut(&owner) {
+            if label == owner || request.members.contains(label) {
+                request.error = Some("A linked view closed during Save preflight".into());
+                let _ = request.wake.try_send(());
+            }
+        }
+    }
+}
diff --git a/apps/ultra/src-tauri/src/documents_tests.rs b/apps/ultra/src-tauri/src/documents_tests.rs
index 7f49ddf..63b1a6f 100644
--- a/apps/ultra/src-tauri/src/documents_tests.rs
+++ b/apps/ultra/src-tauri/src/documents_tests.rs
@@ -376,6 +376,74 @@ fn flush_request(gate: CloseGate) -> (u64, Vec<String>) {
     match gate { CloseGate::Flush { token, views } => (token, views), _ => panic!("close did not request editor flush") }
 }
 
+#[test]
+fn save_preflight_waits_for_all_views_and_rejects_stale_or_foreign_acknowledgements() {
+    let mut registry = Registry::default();
+    let root = registry.add("Owner".into(), Kind::Patch, Some(hierarchy()), None, None).unwrap();
+    let child = registry.open_view(&root.label, 1).unwrap().0;
+    let other = registry.add("Other".into(), Kind::Patch, Some(empty_patch()), None, None).unwrap();
+    for label in [&root.label, &child.label, &other.label] { registry.mark_ready(label).unwrap(); }
+    let (wake, receiver) = std::sync::mpsc::sync_channel(1);
+    let notice = registry.begin_save(&child.label, wake).unwrap();
+    assert_eq!(notice.views, vec![root.label.clone(), child.label.clone()]);
+    assert!(registry.begin_save(&root.label, std::sync::mpsc::sync_channel(1).0).is_err());
+    assert!(registry.acknowledge_save(&other.label, &root.label, notice.token, None).is_err());
+    assert!(registry.acknowledge_save(&child.label, &root.label, notice.token + 1, None).is_err());
+    registry.acknowledge_save(&root.label, &root.label, notice.token, None).unwrap();
+    assert!(receiver.try_recv().is_err());assert!(registry.finish_save_preflight(&root.label, notice.token, false).unwrap().is_none());
+    registry.acknowledge_save(&child.label, &root.label, notice.token, None).unwrap();receiver.try_recv().unwrap();
+    let snapshot=registry.finish_save_preflight(&root.label, notice.token, false).unwrap().unwrap();
+    assert_eq!(snapshot.notice.views, vec![root.label.clone(), child.label.clone()]);assert!(snapshot.document.is_ok());
+    assert!(!registry.save_barrier_active(&root.label,&root.label,notice.token).unwrap());
+    assert!(registry.begin_save(&child.label, std::sync::mpsc::sync_channel(1).0).is_err(), "reservation survives snapshot while picker or write runs");
+    assert!(registry.end_save(&root.label,notice.token+1).is_err());
+    registry.end_save(&root.label, notice.token).unwrap();
+    assert!(registry.acknowledge_save(&child.label, &root.label, notice.token, None).is_err());
+}
+
+#[test]
+fn aborted_save_releases_members_and_stale_tokens_cannot_affect_the_next_request() {
+    let mut registry=Registry::default();let root=registry.add("Owner".into(),Kind::Patch,Some(hierarchy()),None,None).unwrap();
+    let child=registry.open_view(&root.label,1).unwrap().0;registry.mark_ready(&root.label).unwrap();registry.mark_ready(&child.label).unwrap();
+    let first=registry.begin_save(&root.label,std::sync::mpsc::sync_channel(1).0).unwrap();
+    let released=registry.end_save(&root.label,first.token).unwrap().unwrap();assert_eq!(released.views,vec![root.label.clone(),child.label.clone()]);
+    let next=registry.begin_save(&child.label,std::sync::mpsc::sync_channel(1).0).unwrap();assert!(next.token>first.token);
+    assert!(registry.acknowledge_save(&child.label,&root.label,first.token,None).is_err());
+    assert!(registry.end_save(&root.label,first.token).is_err());
+    assert!(registry.save_barrier_active(&child.label,&root.label,next.token).unwrap());
+    registry.end_save(&root.label,next.token).unwrap();
+}
+
+#[test]
+fn save_preflight_includes_newly_ready_views_and_refuses_disappearing_or_invalid_peers() {
+    let mut registry = Registry::default();
+    let root = registry.add("Owner".into(), Kind::Patch, Some(hierarchy()), None, None).unwrap();
+    let child = registry.open_view(&root.label, 1).unwrap().0;registry.mark_ready(&root.label).unwrap();
+    let (wake, receiver)=std::sync::mpsc::sync_channel(1);let notice=registry.begin_save(&root.label,wake).unwrap();
+    registry.acknowledge_save(&root.label,&root.label,notice.token,None).unwrap();receiver.try_recv().unwrap();
+    registry.mark_ready(&child.label).unwrap();let late=registry.mark_save_ready(&child.label).unwrap().unwrap();assert_eq!(late.token,notice.token);
+    assert!(registry.finish_save_preflight(&root.label,notice.token,false).unwrap().is_none());
+    registry.acknowledge_save(&child.label,&root.label,notice.token,Some("invalid".into())).unwrap();receiver.try_recv().unwrap();
+    assert!(registry.finish_save_preflight(&root.label,notice.token,false).unwrap().unwrap().document.is_err());
+    registry.end_save(&root.label,notice.token).unwrap();
+    let (wake, receiver)=std::sync::mpsc::sync_channel(1);let next=registry.begin_save(&root.label,wake).unwrap();
+    registry.remove(&child.label);receiver.try_recv().unwrap();
+    assert!(registry.finish_save_preflight(&root.label,next.token,false).unwrap().unwrap().document.is_err());
+}
+
+#[test]
+fn save_snapshot_keeps_later_owner_edits_dirty_during_picker() {
+    let mut registry=Registry::default();
+    let root=registry.add("Owner".into(),Kind::Patch,Some(hierarchy()),None,None).unwrap();registry.mark_ready(&root.label).unwrap();
+    let (wake,receiver)=std::sync::mpsc::sync_channel(1);let notice=registry.begin_save(&root.label,wake).unwrap();
+    registry.acknowledge_save(&root.label,&root.label,notice.token,None).unwrap();receiver.try_recv().unwrap();
+    let snapshot=registry.finish_save_preflight(&root.label,notice.token,false).unwrap().unwrap().document.unwrap();
+    let mut changed=snapshot.patch.clone().unwrap();changed["nodes"][0]["x"]=serde_json::json!(321);
+    let result=registry.commit(&root.label,snapshot.authoring_revision,changed.clone(),true,|_,_|Ok(1.into())).unwrap();assert!(result.accepted);
+    let saved=registry.saved(&root.label,std::path::PathBuf::from("/tmp/snapshot.ultra"),snapshot.patch.unwrap()).unwrap();
+    assert!(saved.dirty);assert_eq!(saved.patch.unwrap(),changed);registry.end_save(&root.label,notice.token).unwrap();
+}
+
 #[test]
 fn owner_close_waits_for_all_ready_views_and_rejects_stale_or_forged_acknowledgements() {
     let mut registry = Registry::default();
diff --git a/apps/ultra/src-tauri/src/lib.rs b/apps/ultra/src-tauri/src/lib.rs
index 7829828..3e4bdb9 100644
--- a/apps/ultra/src-tauri/src/lib.rs
+++ b/apps/ultra/src-tauri/src/lib.rs
@@ -920,6 +920,8 @@ pub fn run_ultra(context: fn() -> tauri::Context<tauri::Wry>) {
             document_windows::commands::document_history,
             document_windows::commands::document_open_patcher,
             document_windows::commands::document_close_flushed,
+            document_windows::commands::document_save_flushed,
+            document_windows::commands::document_save_barrier_active,
             document_windows::document_new,
             document_windows::document_instantiate,
             document_windows::document_open,
diff --git a/apps/ultra/src-tauri/src/session/clips.rs b/apps/ultra/src-tauri/src/session/clips.rs
index 433bba6..9a10a6f 100644
--- a/apps/ultra/src-tauri/src/session/clips.rs
+++ b/apps/ultra/src-tauri/src/session/clips.rs
@@ -169,8 +169,8 @@ pub(super) fn decode_v3_candidate(text:&str)->Result<Document,String> {
     let wire:Wire=serde_json::from_str(text).map_err(|e|format!("Invalid Alive v3 session JSON: {e}"))?;
     Ok(Document::from_wire(wire))
 }
-// This pass runs only on v3, before a Value could discard duplicate map members.
-fn reject_duplicates(text:&str)->Result<(),String> {
+// Scan original JSON before any typed or Value parse can discard map members.
+pub(super) fn reject_duplicates(text:&str)->Result<(),String> {
     struct Unique;
     impl<'de> Deserialize<'de> for Unique {
         fn deserialize<D:Deserializer<'de>>(d:D)->Result<Self,D::Error>{
@@ -189,5 +189,5 @@ fn reject_duplicates(text:&str)->Result<(),String> {
             }d.deserialize_any(Visitor)
         }
     }
-    serde_json::from_str::<Unique>(text).map(|_|()).map_err(|e|format!("Invalid Alive v3 session JSON: {e}"))
+    serde_json::from_str::<Unique>(text).map(|_|()).map_err(|e|format!("Invalid Alive session JSON: {e}"))
 }
diff --git a/apps/ultra/src-tauri/src/session/desktop.rs b/apps/ultra/src-tauri/src/session/desktop.rs
index 5607732..f21777c 100644
--- a/apps/ultra/src-tauri/src/session/desktop.rs
+++ b/apps/ultra/src-tauri/src/session/desktop.rs
@@ -6,14 +6,19 @@ use std::{path::{Path, PathBuf}, sync::{Mutex, MutexGuard}, collections::BTreeMa
 use tauri::{Emitter, Manager, WebviewWindow};
 use tauri_plugin_dialog::{DialogExt, MessageDialogButtons, MessageDialogResult};
 
+fn trace_commands() -> bool { std::env::var_os("ALIVE_TRACE_COMMANDS").as_deref() == Some(std::ffi::OsStr::new("1")) }
+
 struct Control {
     host: Host,
     runtime: runtime::Runtime,
     snapshot_sequence: u64,
+    accepted_serial: u64,
     driver: crate::audio::Driver,
     generation: u64,
     dirty: bool,
     saved_path: Option<PathBuf>,
+    saved_wire: Option<SaveWire>,
+    save_feedback: Option<String>,
     draft: Option<Session>,
     draft_revision: u64,
     history: History,
@@ -37,6 +42,7 @@ fn ui_lock<T>(mutex: &Mutex<T>) -> Result<MutexGuard<'_, T>, String> {
 #[serde(rename_all = "camelCase")]
 pub struct Snapshot {
     document: Session,
+    master: MasterSnapshot,
     path: Option<PathBuf>,
     devices: Vec<crate::canvas::device::HostManifest>,
     generation: u64,
@@ -61,6 +67,30 @@ pub struct Snapshot {
     patch: Option<serde_json::Value>,
     track: Option<usize>,
 }
+#[derive(Serialize)]
+#[serde(rename_all = "camelCase")]
+struct MasterSnapshot {
+    gain: f64,
+    accepted_serial: String,
+    available: bool,
+    unavailable_reason: Option<&'static str>,
+    observation: Option<serde_json::Value>,
+    observation_stale: bool,
+}
+#[derive(Debug,Serialize)]
+pub struct MasterError { code:&'static str, message:String }
+#[derive(Debug,Serialize)]
+#[serde(rename_all="camelCase")]
+pub struct MasterReceipt { generation:u64, accepted_gain:f64, accepted_serial:String, changed:bool }
+#[derive(Serialize)]
+#[serde(rename_all="camelCase")]
+pub struct MasterResetReceipt { generation:u64, accepted_serial:String }
+fn master_error(code:&'static str,message:impl Into<String>)->MasterError{MasterError{code,message:message.into()}}
+fn master_native_error(code:i32)->MasterError {match code {
+    -2=>master_error("FULL","Native command queue is full; retry."),-3=>master_error("BUSY","Native state is busy; retry."),
+    -1=>master_error("UNSUPPORTED","Native Master support is unavailable; upgrade or reinstall."),-4=>master_error("UNCONFIGURED","Open a session first."),
+    -5=>master_error("EXHAUSTED","Master serial exhausted."),0=>master_error("INVALID","Invalid Master request."),_=>master_error("INTERNAL","Native Master request failed.")
+}}
 fn main_only(label: &str) -> Result<(), String> {
     if label == "main" { Ok(()) } else { Err("This action belongs to the Alive session window".into()) }
 }
@@ -99,23 +129,48 @@ fn musical_draft(mut draft: Session, live: &Session) -> Result<Session, String>
     Ok(draft)
 }
 impl Control {
+    fn master_auth(&mut self,label:&str,generation:u64)->Result<&'static super::native_master::Capability,MasterError>{
+        if label!="main"{return Err(master_error("INVALID","This action belongs to the Alive session window."));}
+        if generation>9007199254740991{return Err(master_error("INVALID","Invalid desktop generation."));}
+        if self.generation!=generation{return Err(master_error("STALE_GENERATION","Session changed; refresh and retry."));}
+        let capability=native::master_capability().ok_or_else(||master_error("UNSUPPORTED","Native Master support is unavailable; upgrade or reinstall."))?;
+        if self.host.prepared.is_none(){return Err(master_error("UNCONFIGURED","Open a session first."));}
+        self.driver.reject_retiring().map_err(|message|master_error("BUSY",message))?;
+        Ok(capability)
+    }
+    fn master_gain(&mut self,label:&str,generation:u64,gain:f64)->Result<MasterReceipt,MasterError>{
+        if !gain.is_finite()||!(0. ..=4.).contains(&gain){return Err(master_error("INVALID","Master gain must be finite and between 0 and 4."));}
+        let capability=self.master_auth(label,generation)?;
+        let prepared=self.host.prepared.as_mut().unwrap();
+        if gain==prepared.saved.master.gain{return Ok(MasterReceipt{generation,accepted_gain:gain,accepted_serial:self.accepted_serial.to_string(),changed:false});}
+        let serial=super::native_master::next_serial().ok_or_else(||master_error("EXHAUSTED","Master serial exhausted."))?;
+        let result=unsafe{(capability.set)(1,gain,serial)};if result!=1{return Err(master_native_error(result));}
+        prepared.saved.master.gain=gain;prepared.saved.wire=SaveWire::V5;self.dirty=true;self.accepted_serial=serial;
+        Ok(MasterReceipt{generation,accepted_gain:gain,accepted_serial:serial.to_string(),changed:true})
+    }
+    fn master_reset(&mut self,label:&str,generation:u64)->Result<MasterResetReceipt,MasterError>{
+        let capability=self.master_auth(label,generation)?;
+        let serial=super::native_master::next_serial().ok_or_else(||master_error("EXHAUSTED","Master serial exhausted."))?;
+        let result=unsafe{(capability.reset)(1,serial)};if result!=1{return Err(master_native_error(result));}
+        self.accepted_serial=serial;Ok(MasterResetReceipt{generation,accepted_serial:serial.to_string()})
+    }
     fn workspace_edit(&mut self,label:&str,operation:workspaces::WorkspaceEditV4,generation:u64,revision:u64)->Result<workspace_edits::Affected,String>{
         main_only(label)?;self.version(generation,revision)?;
         let prepared=self.host.prepared.as_ref().ok_or("No session")?;
-        let before=self.draft.as_ref().unwrap_or(&prepared.document);
+        let before=self.draft.as_ref().unwrap_or(&prepared.saved.score);
         let Document::WorkspacesV4(project)=before else{return Err("Enable MIDI workspaces first".into())};
         let mut reserved=self.history.identities();
-        if let Document::WorkspacesV4(p)=&prepared.document {reserved.extend(p.identities());}
+        if let Document::WorkspacesV4(p)=&prepared.saved.score {reserved.extend(p.identities());}
         let edited=workspaces::apply_edit(project,operation.clone(),&reserved)?;
         let affected=workspace_edits::primary(project,&edited.project,&operation)?;
         let mut document=Document::WorkspacesV4(edited.project);
-        merge_live(&mut document,&prepared.document);prepare::validate_musical(&document,prepared)?;
+        merge_live(&mut document,&prepared.saved.score);prepare::validate_musical(&document,prepared)?;
         if self.history.record(before,&document,"Workspace edit")?{self.retain(document);self.draft_revision+=1;}Ok(affected)
     }
     fn workspace_action(&mut self,label:&str,generation:u64,preparation_revision:&str,action:runtime_workspaces::Action)->Result<runtime_workspaces::RequestResult,String>{
         main_only(label)?;check_generation(self.generation,generation)?;
         if runtime::decimal(preparation_revision)?!=self.host.preparation_revision{return Err("Prepared workspace changed. Refresh before playback".into());}
-        if !self.host.prepared.as_ref().is_some_and(|p|p.document.is_workspaces()){return Err("Enable MIDI workspaces first".into());}
+        if !self.host.prepared.as_ref().is_some_and(|p|p.saved.score.is_workspaces()){return Err("Enable MIDI workspaces first".into());}
         if !self.driver.snapshot().running{return Err("Start Audio before workspace playback".into());}
         self.runtime.workspace_request(&self.host,action)
     }
@@ -124,10 +179,11 @@ impl Control {
         if self.draft.is_some(){return Err("Apply or discard pending edits before enabling MIDI workspaces".into());}
         host::workspace_limits()?;
         let current=self.host.prepared.as_ref().ok_or("No session")?;
-        if current.document.is_workspaces(){return Err("MIDI workspaces are already enabled".into());}
-        let project=workspaces::prospective_from_document(&current.document)?;
-        let mut candidate=prepare(&Document::WorkspacesV4(project),&current.origin)?;
-        candidate.notice=Some("MIDI workspaces enabled: stopped Arrangement at zero. Profile 1 is measured for practical device buffers of at least 256 frames; delivered periods may differ. Audio settings were not changed. Save writes v4.".into());
+        if current.saved.score.is_workspaces(){return Err("MIDI workspaces are already enabled".into());}
+        let project=workspaces::prospective_from_document(&current.saved.score)?;
+        let mut candidate=prepare(&current.saved.with_score(Document::WorkspacesV4(project)),&current.origin)?;
+        let wire_notice=match candidate.saved.wire {SaveWire::LegacyScore=>"Save writes v4.",SaveWire::V5=>"Save writes session v5 with a v4 score."};
+        candidate.notice=Some(format!("MIDI workspaces enabled: stopped Arrangement at zero. Profile 1 is measured for practical device buffers of at least 256 frames; delivered periods may differ. Audio settings were not changed. {wire_notice}"));
         self.install(candidate)
     }
     fn launch_scene(&mut self,label:&str,generation:u64,preparation_revision:&str,slot:usize)->Result<runtime::RequestResult,String>{
@@ -146,35 +202,35 @@ impl Control {
     }
     fn clear_scope(&mut self)->Result<(),String> {ensure_counter(self.draft_revision)?;self.draft=None;self.history.clear();self.draft_revision+=1;Ok(())}
     fn retain(&mut self,document:Session) {
-        let live=&self.host.prepared.as_ref().unwrap().document;
+        let live=&self.host.prepared.as_ref().unwrap().saved.score;
         self.draft=if Projection::from(&document)==Projection::from(live) {None}else{Some(document)};
     }
     fn edit(&mut self,document:Session,label:&str,generation:u64,revision:u64)->Result<(),String> {
         self.version(generation,revision)?;
         let prepared=self.host.prepared.as_ref().ok_or("No session")?;
-        clips::guard_identities(&document,self.draft.as_ref().unwrap_or(&prepared.document))?;
-        let document=musical_draft(document,&prepared.document)?;
+        clips::guard_identities(&document,self.draft.as_ref().unwrap_or(&prepared.saved.score))?;
+        let document=musical_draft(document,&prepared.saved.score)?;
         prepare::validate_musical(&document,prepared)?;
-        let before=self.draft.as_ref().unwrap_or(&prepared.document);
+        let before=self.draft.as_ref().unwrap_or(&prepared.saved.score);
         if self.history.record(before,&document,label)? {self.retain(document);self.draft_revision+=1;} Ok(())
     }
     fn clip_edit(&mut self,operation:clips::Edit,generation:u64,revision:u64)->Result<clips::Affected,String>{
         self.version(generation,revision)?;
         let prepared=self.host.prepared.as_ref().ok_or("No session")?;
-        let before=self.draft.as_ref().unwrap_or(&prepared.document);let mut document=before.clone();
+        let before=self.draft.as_ref().unwrap_or(&prepared.saved.score);let mut document=before.clone();
         let mut identities=self.history.identities();
-        for clip in prepared.document.banks().iter().flat_map(|bank|bank.slots.iter().flatten()) {
+        for clip in prepared.saved.score.banks().iter().flat_map(|bank|bank.slots.iter().flatten()) {
             identities.insert(clip.id.clone());identities.extend(clip.notes.iter().map(|note|note.id.clone()));
         }
         let affected=clips::apply_edit(&mut document,operation,identities)?;
-        merge_live(&mut document,&prepared.document);prepare::validate_musical(&document,prepared)?;
+        merge_live(&mut document,&prepared.saved.score);prepare::validate_musical(&document,prepared)?;
         if self.history.record(before,&document,"Clip edit")?{self.retain(document);self.draft_revision+=1;}Ok(affected)
     }
     fn history(&mut self,direction:Direction,generation:u64,revision:u64)->Result<(),String> {
         self.version(generation,revision)?;
         let prepared=self.host.prepared.as_ref().ok_or("No session")?;
-        let mut document=self.history.target(direction)?.materialize(&prepared.document)?;
-        merge_live(&mut document,&prepared.document);prepare::validate_musical(&document,prepared)?;
+        let mut document=self.history.target(direction)?.materialize(&prepared.saved.score)?;
+        merge_live(&mut document,&prepared.saved.score);prepare::validate_musical(&document,prepared)?;
         self.history.advance(direction);self.retain(document);self.draft_revision+=1;Ok(())
     }
     fn editor_instance(&self, label: &str) -> Result<Option<&str>, String> {
@@ -193,42 +249,47 @@ impl Control {
         let (native_state,runtime)=self.runtime.poll(&self.host)?;
         self.snapshot_sequence=sequence;
         let prepared = self.host.prepared.as_ref().ok_or("Open an Alive session")?;
-        let (max_tracks,max_devices,max_clips)=document_capacity(&prepared.document)?;
+        let (max_tracks,max_devices,max_clips)=document_capacity(&prepared.saved.score)?;
         let device_index = instance_id.as_ref().map(|id| prepared.devices.iter().position(|d| &d.instance_id == id).ok_or("Unknown editor instance")).transpose()?;
         let track = device_index.map(|i| prepared.devices[i].track);
-        let workspace=prepared.document.is_workspaces();
+        let workspace=prepared.saved.score.is_workspaces();
         let limits=if workspace{Some(host::workspace_limits()?)}else{None};
-        Ok(Snapshot { document: prepared.document.clone(), path: self.saved_path.clone(),
-            capabilities: Capabilities { clip_bank: prepared.document.is_clips()||workspace, max_tracks, max_devices, slots_per_track: if prepared.document.is_clips()||workspace{4}else{1}, max_clips, atomic_track_actions: if let Some(l)=&limits{l.features&native::V4_FEATURE_ATOMIC_TRACK_ACTIONS!=0}else{runtime::scenes_available(prepared)?},workspaces:workspace,arrangement:workspace,audio_sources:false,max_sources:limits.as_ref().map_or(0,|l|l.max_sources as usize),max_placements:limits.as_ref().map_or(0,|l|l.max_placements as usize),workspace_conversion_available:!workspace&&host::workspace_limits().is_ok() },
-            track_chains:if workspace{prepared.document.tracks().into_iter().map(|t|serde_json::json!({"trackId":t.id(),"kind":if t.instrument().is_some(){"midi"}else{"audio"},"instrumentId":t.instrument().map(|d|&d.instance_id),"effectIds":t.effects().iter().map(|d|&d.instance_id).collect::<Vec<_>>() })).collect()}else{vec![]},prepared_workspaces:runtime_workspaces::prepared(&self.host)?,
-            devices: if prepared.document.is_workspaces(){vec![]}else{prepared.tracks.iter().map(|t| Ok(prepared.devices[t.midi_instrument()?].manifest.clone())).collect::<Result<_,String>>()?}, generation: self.generation,
+        let available=native::master_capability().is_some();
+        let observation=self.runtime.master_observation.map(|m|serde_json::json!({"targetGain":m.target_gain,"currentGain":m.current_gain,"peakLeft":m.peak_left,"peakRight":m.peak_right,"clipMask":m.clip_mask,"appliedSerial":m.applied_serial.to_string(),"appliedFrame":m.applied_frame.to_string(),"observationStartFrame":m.observation_start_frame.to_string(),"observationEndFrame":m.observation_end_frame.to_string()}));
+        Ok(Snapshot { document: prepared.saved.score.clone(), master: MasterSnapshot { gain:prepared.saved.master.gain, accepted_serial:self.accepted_serial.to_string(), available, unavailable_reason:(!available).then_some("Native Master support is unavailable; upgrade or reinstall the native library."), observation, observation_stale:false }, path: self.saved_path.clone(),
+            capabilities: Capabilities { clip_bank: prepared.saved.score.is_clips()||workspace, max_tracks, max_devices, slots_per_track: if prepared.saved.score.is_clips()||workspace{4}else{1}, max_clips, atomic_track_actions: if let Some(l)=&limits{l.features&native::V4_FEATURE_ATOMIC_TRACK_ACTIONS!=0}else{runtime::scenes_available(prepared)?},workspaces:workspace,arrangement:workspace,audio_sources:false,max_sources:limits.as_ref().map_or(0,|l|l.max_sources as usize),max_placements:limits.as_ref().map_or(0,|l|l.max_placements as usize),workspace_conversion_available:!workspace&&host::workspace_limits().is_ok() },
+            track_chains:if workspace{prepared.saved.score.tracks().into_iter().map(|t|serde_json::json!({"trackId":t.id(),"kind":if t.instrument().is_some(){"midi"}else{"audio"},"instrumentId":t.instrument().map(|d|&d.instance_id),"effectIds":t.effects().iter().map(|d|&d.instance_id).collect::<Vec<_>>() })).collect()}else{vec![]},prepared_workspaces:runtime_workspaces::prepared(&self.host)?,
+            devices: if prepared.saved.score.is_workspaces(){vec![]}else{prepared.tracks.iter().map(|t| Ok(prepared.devices[t.midi_instrument()?].manifest.clone())).collect::<Result<_,String>>()?}, generation: self.generation,
             device_instances: prepared.devices.iter().enumerate().map(|(index, device)| (device.instance_id.clone(), DeviceView { index, track: device.track, manifest: device.manifest.clone() })).collect(),
-            dirty: self.dirty || self.draft.is_some(), draft: self.draft.clone(), draft_revision:self.draft_revision,history:self.history.view(), state: native_state,mode:if workspace{"workspacesV4"}else if prepared.document.is_clips(){"clipsV3"}else{"legacyV2"}.into(),notice:prepared.notice.clone(),preparation_revision:self.host.preparation_revision.to_string(),snapshot_sequence:sequence.to_string(),prepared_clips:runtime::prepared(&self.host),runtime,
+            dirty: self.dirty || self.draft.is_some(), draft: self.draft.clone(), draft_revision:self.draft_revision,history:self.history.view(), state: native_state,mode:if workspace{"workspacesV4"}else if prepared.saved.score.is_clips(){"clipsV3"}else{"legacyV2"}.into(),notice:match (&prepared.notice,&self.save_feedback) {(Some(a),Some(b))=>Some(format!("{a} {b}")),(Some(a),None)=>Some(a.clone()),(None,Some(b))=>Some(b.clone()),_=>None},preparation_revision:self.host.preparation_revision.to_string(),snapshot_sequence:sequence.to_string(),prepared_clips:runtime::prepared(&self.host),runtime,
             audio: self.driver.snapshot(), patch: device_index.map(|i| prepared.devices[i].patch.clone()), track, instance_id, device_index })
     }
     fn stopped(&self) -> Result<(), String> {
         if let Some(p)=&self.host.prepared{Host::check_schedule(p)?;}
-        let playing=if self.host.prepared.as_ref().is_some_and(|p|p.document.is_workspaces()){
+        let playing=if self.host.prepared.as_ref().is_some_and(|p|p.saved.score.is_workspaces()){
             let mut state=native::StateV4::default();if unsafe{native::alive_session_state_v4(&mut state)}==0{return Err("Workspace state is temporarily unavailable".into());}state.playing
-        }else if self.host.prepared.as_ref().is_some_and(|p|p.document.is_clips()){
+        }else if self.host.prepared.as_ref().is_some_and(|p|p.saved.score.is_clips()){
             let mut state=native::StateV3::default();if unsafe{native::alive_session_state_v3(&mut state)}==0{return Err("Session state is temporarily unavailable".into());}state.playing
         }else{native::state()?.playing};
         if playing != 0 { Err("Stop transport before preparing a schedule or changing devices. Your edits are retained.".into()) } else { Ok(()) }
     }
     fn install(&mut self, prepared: PreparedSession) -> Result<(), String> {
         ensure_counter(self.generation)?;ensure_counter(self.draft_revision)?;
+        Host::preflight_master(&prepared)?;
         self.stopped()?;
         self.host.validate(&prepared)?;
+        let serials=if native::master_capability().is_some(){Some(super::native_master::reserve_pair().ok_or("Master serial exhausted")?)}else{None};
         self.driver.stop()?;
-        self.host.install(prepared)?;
+        if let Err(failure)=self.host.install_reserved(prepared,serials){if let Some(serial)=failure.rollback_serial{self.accepted_serial=serial;}return Err(failure.message);}
+        self.accepted_serial=serials.map_or(0,|s|s.0);
         self.generation += 1; self.editors.clear(); self.dirty = true; self.clear_scope()?;
         Ok(())
     }
     fn apply_draft(&mut self) -> Result<(), String> {
         let Some(mut document) = self.draft.clone() else { self.clear_scope()?; return Ok(()); };
         let current = self.host.prepared.as_ref().ok_or("No session")?;
-        merge_live(&mut document, &current.document);
-        let prepared = prepare(&document, &current.origin)?;
+        merge_live(&mut document, &current.saved.score);
+        let prepared = prepare(&current.saved.with_score(document), &current.origin)?;
         self.install(prepared)
     }
 }
@@ -238,6 +299,16 @@ pub fn alive_current(window: WebviewWindow, state: tauri::State<Desktop>) -> Res
     ui_lock(&state.0)?.snapshot(window.label())
 }
 #[tauri::command]
+pub fn alive_master(window:WebviewWindow,state:tauri::State<Desktop>,generation:u64,gain:f64)->Result<MasterReceipt,MasterError>{
+    let mut control=ui_lock(&state.0).map_err(|message|master_error("BUSY",message))?;
+    control.master_gain(window.label(),generation,gain)
+}
+#[tauri::command]
+pub fn alive_master_reset_clip(window:WebviewWindow,state:tauri::State<Desktop>,generation:u64)->Result<MasterResetReceipt,MasterError>{
+    let mut control=ui_lock(&state.0).map_err(|message|master_error("BUSY",message))?;
+    control.master_reset(window.label(),generation)
+}
+#[tauri::command]
 pub fn alive_enable_workspaces(window:WebviewWindow,state:tauri::State<Desktop>,generation:u64,draft_revision:u64)->Result<Snapshot,String>{
     let mut c=ui_lock(&state.0)?;c.enable_workspaces(window.label(),generation,draft_revision)?;close_stale_editors(window.app_handle(),c.generation);c.snapshot(window.label())
 }
@@ -262,7 +333,7 @@ pub fn alive_enable_clips(window:WebviewWindow,state:tauri::State<Desktop>,gener
     main_only(window.label())?;let mut c=ui_lock(&state.0)?;c.version(generation,draft_revision)?;c.stopped()?;
     if c.draft.is_some(){return Err("Apply or discard pending edits before enabling clips".into());}
     let prepared=c.host.enable_clips(c.host.prepared.clone().ok_or("No session")?)?;
-    if prepared.document.is_clips(){c.install(prepared)?;close_stale_editors(window.app_handle(),c.generation);}else{c.host.prepared=Some(prepared);}
+    if prepared.saved.score.is_clips(){c.install(prepared)?;close_stale_editors(window.app_handle(),c.generation);}else{c.host.prepared=Some(prepared);}
     c.snapshot(window.label())
 }
 #[tauri::command]
@@ -276,7 +347,7 @@ pub fn alive_clip_action(window:WebviewWindow,state:tauri::State<Desktop>,action
     if !c.driver.snapshot().running{return Err("Start Audio to cue or stop a track".into());}
     let p=c.host.prepared.as_ref().ok_or("No session")?;let Schedule::Clips(clips)=&p.schedule else{return Err("Enable the clip bank first".into())};
     let (track_id,clip_id)=match action{runtime::Action::Launch{track_id,clip_id}=>(track_id,Some(clip_id)),runtime::Action::Stop{track_id}=>(track_id,None)};
-    let track=p.document.tracks().iter().position(|t|t.id()==track_id).ok_or("Unknown track")?;
+    let track=p.saved.score.tracks().iter().position(|t|t.id()==track_id).ok_or("Unknown track")?;
     let mut request=native::RequestV3::default();request.kind=native::V3_TRACK_ACTIONS;request.track_mask=1<<track;
     request.tracks[track]=if let Some(id)=&clip_id{let clip=clips.iter().find(|c|c.track==track&&&c.id==id).ok_or("Apply while stopped to launch this draft-only clip")?;native::TrackActionV3{action:native::V3_LAUNCH,slot:clip.slot as u32}}else{native::TrackActionV3{action:native::V3_TRACK_STOP,slot:native::V3_NONE}};
     let Control{host,runtime,..}=&mut *c;runtime.request(host,request,Some(track_id),clip_id)
@@ -301,8 +372,17 @@ pub fn alive_discard(window:WebviewWindow,state:tauri::State<Desktop>,generation
 }
 #[tauri::command]
 pub fn alive_apply(window: WebviewWindow, state: tauri::State<Desktop>, generation: u64,draft_revision:u64) -> Result<Snapshot, String> {
-    main_only(window.label())?;let mut control=ui_lock(&state.0)?;control.version(generation,draft_revision)?;
-    control.apply_draft()?;close_stale_editors(window.app_handle(),control.generation);control.snapshot(window.label())
+    if trace_commands() { eprintln!("ALIVE_TRACE apply_begin requested_generation={generation} requested_draft={draft_revision}"); }
+    let result = (|| {
+        main_only(window.label())?;let mut control=ui_lock(&state.0)?;
+        if trace_commands() { eprintln!("ALIVE_TRACE apply_before generation={} draft={} preparation={}", control.generation, control.draft_revision, control.host.preparation_revision); }
+        control.version(generation,draft_revision)?;
+        control.apply_draft()?;
+        if trace_commands() { eprintln!("ALIVE_TRACE apply_installed generation={} draft={} preparation={}", control.generation, control.draft_revision, control.host.preparation_revision); }
+        close_stale_editors(window.app_handle(),control.generation);control.snapshot(window.label())
+    })();
+    if trace_commands() { eprintln!("ALIVE_TRACE apply_end result={}", if result.is_ok() { "ok" } else { "error" }); }
+    result
 }
 #[tauri::command]
 pub fn alive_base(window: WebviewWindow, state: tauri::State<Desktop>, instance_id: String, key: String, value: f64, generation: u64) -> Result<(), String> {
@@ -331,14 +411,14 @@ pub fn alive_transport(window: WebviewWindow, state: tauri::State<Desktop>, acti
     if action=="stop" {if let Some(p)=&control.host.prepared{Host::check_schedule(p)?;}let epoch=if control.host.prepared.as_ref().is_some_and(|p|matches!(p.schedule,Schedule::Workspaces(_))){unsafe{native::alive_session_stop_v4()}}else{unsafe{native::alive_session_stop_v3()}};return Ok(serde_json::json!({"stopEpoch":epoch.to_string()}));}
     check_generation(control.generation,generation)?;
     let p=control.host.prepared.as_ref().ok_or("No session")?;
-    if p.document.is_workspaces(){return Err("Use the authenticated workspace Start or Seek action".into());}
-    if p.document.is_clips(){
+    if p.saved.score.is_workspaces(){return Err("Use the authenticated workspace Start or Seek action".into());}
+    if p.saved.score.is_clips(){
         if runtime::decimal(preparation_revision.as_deref().ok_or("Prepared identity required")?)?!=control.host.preparation_revision{return Err("Prepared bank changed. Refresh transport controls".into());}
         let mut request=native::RequestV3::default();
-        match action.as_str(){"start"=>{request.kind=native::V3_START;control.driver.start()?;},"seek"=>{let beat=beat.ok_or("Enter a seek beat")?;if !beat.is_finite()||beat<0.||beat>=p.document.length_beats(){return Err("Seek beat must be within the transport region".into());}request.kind=native::V3_SEEK;request.position=(beat*48_000.*60./p.document.tempo()).round() as u64;},_=>return Err("Unknown transport action".into())}
+        match action.as_str(){"start"=>{request.kind=native::V3_START;control.driver.start()?;},"seek"=>{let beat=beat.ok_or("Enter a seek beat")?;if !beat.is_finite()||beat<0.||beat>=p.saved.score.length_beats(){return Err("Seek beat must be within the transport region".into());}request.kind=native::V3_SEEK;request.position=(beat*48_000.*60./p.saved.score.tempo()).round() as u64;},_=>return Err("Unknown transport action".into())}
         let Control{host,runtime,..}=&mut *control;return serde_json::to_value(runtime.request(host,request,None,None)?).map_err(|e|e.to_string());
     }
-    match action.as_str(){"start"=>{control.driver.start()?;if unsafe{native::alive_session_start()}==0{return Err(native::error());}},"seek"=>{let beat=beat.ok_or("Enter a seek beat")?;if !beat.is_finite()||beat<0.||beat>=p.document.length_beats(){return Err("Seek beat must be within the prepared clip".into());}if unsafe{native::alive_session_seek((beat*48_000.*60./p.document.tempo()).round() as u64)}==0{return Err(native::error());}},_=>return Err("Unknown transport action".into())}Ok(serde_json::Value::Null)
+    match action.as_str(){"start"=>{control.driver.start()?;if unsafe{native::alive_session_start()}==0{return Err(native::error());}},"seek"=>{let beat=beat.ok_or("Enter a seek beat")?;if !beat.is_finite()||beat<0.||beat>=p.saved.score.length_beats(){return Err("Seek beat must be within the prepared clip".into());}if unsafe{native::alive_session_seek((beat*48_000.*60./p.saved.score.tempo()).round() as u64)}==0{return Err(native::error());}},_=>return Err("Unknown transport action".into())}Ok(serde_json::Value::Null)
 }
 #[tauri::command]
 pub fn alive_audio_devices(window: WebviewWindow, state: tauri::State<Desktop>, host: Option<String>) -> Result<crate::audio::Catalog, String> {
@@ -377,7 +457,7 @@ pub async fn alive_editor(window: WebviewWindow, state: tauri::State<'_, Desktop
     check_generation(control.generation, generation)?;
     let prepared = control.host.prepared.as_ref().ok_or("No session")?;
     let device = prepared.devices.iter().find(|d| d.instance_id == instance_id).ok_or("Unknown instance")?;
-    let name = prepared.document.tracks()[device.track].name();
+    let name = prepared.saved.score.tracks()[device.track].name();
     let label = editor_label(generation, &instance_id);
     if let Some(editor) = window.app_handle().get_webview_window(&label) { editor.set_focus().map_err(|e| e.to_string())?; }
     else { let editor = tauri::WebviewWindowBuilder::new(window.app_handle(), label.clone(), tauri::WebviewUrl::App("alive-editor.html".into()))
@@ -394,8 +474,10 @@ pub async fn alive_editor(window: WebviewWindow, state: tauri::State<'_, Desktop
 #[cfg(target_os = "linux")]
 fn install_editor_teardown(editor: &WebviewWindow) -> tauri::Result<()> {
     use gtk::{glib::{self, subclass::SignalId, translate::IntoGlib}, prelude::*};
-    editor.with_webview(|webview| {
-        webview.inner().connect_destroy(|view| {
+    let generation = editor.label().strip_prefix("alive-editor-").and_then(|s| s.split('-').next()).and_then(|s| s.parse::<u64>().ok());
+    editor.with_webview(move |webview| {
+        webview.inner().connect_destroy(move |view| {
+            if trace_commands() { eprintln!("ALIVE_TRACE editor_destroyed generation={}", generation.unwrap_or(0)); }
             let manager: glib::Object = view.property("user-content-manager");
             if let Some(signal) = SignalId::lookup("script-message-received", manager.type_()) {
                 // Wry 0.53.5's IPC closure strongly captures its WebView. Break
@@ -409,7 +491,11 @@ fn install_editor_teardown(editor: &WebviewWindow) -> tauri::Result<()> {
 }
 fn close_stale_editors(app: &tauri::AppHandle, generation: u64) {
     for (label, window) in app.webview_windows() {
-        if label.starts_with("alive-editor-") && !label.starts_with(&format!("alive-editor-{generation}-")) { let _ = window.close(); }
+        if label.starts_with("alive-editor-") && !label.starts_with(&format!("alive-editor-{generation}-")) {
+            let stale = label.strip_prefix("alive-editor-").and_then(|s| s.split('-').next()).and_then(|s| s.parse::<u64>().ok()).unwrap_or(0);
+            let result = window.close();
+            if trace_commands() { eprintln!("ALIVE_TRACE editor_close requested_generation={stale} installed_generation={generation} result={}", if result.is_ok() { "ok" } else { "error" }); }
+        }
     }
 }
 fn chosen(result: MessageDialogResult, name: &str, yes: bool) -> bool {
@@ -431,19 +517,26 @@ fn save_current(window: &WebviewWindow, control: &mut Control, save_as: bool, pa
         Some(path) => path,
         None => {
             let Some(path) = window.dialog().file().set_parent(window).set_title("Save Alive Session")
-                .add_filter("Alive session", &["alive"]).set_file_name(format!("{}.alive", prepared.document.title())).blocking_save_file() else { return Ok(false); };
+                .add_filter("Alive session", &["alive"]).set_file_name(format!("{}.alive", prepared.saved.score.title())).blocking_save_file() else { return Ok(false); };
             path.into_path().map_err(|e| e.to_string())?
         }
     };
+    save_to_path(control,&path)?;
+    Ok(true)
+}
+fn save_to_path(control: &mut Control, path: &Path) -> Result<(), String> {
+    let prepared = control.host.prepared.as_ref().ok_or("No session")?;
     ensure_counter(control.draft_revision)?;
-    control.host.validate(&prepare(&prepared.document,&prepared.origin)?)?;
-    let (path,document) = persistence::save_document(&path, &prepared.document, &prepared.origin)?;
+    control.host.validate(&prepare(&prepared.saved,&prepared.origin)?)?;
+    let (path,saved) = persistence::save_document(path, &prepared.saved, &prepared.origin)?;
+    let migrated = control.saved_wire == Some(SaveWire::LegacyScore) && saved.wire == SaveWire::V5;
     let current = control.host.prepared.as_mut().unwrap();
-    if current.origin != path || current.document != document {control.draft_revision+=1;}
+    if current.origin != path || current.saved != saved {control.draft_revision+=1;}
     let current=control.host.prepared.as_mut().unwrap();
-    current.document = document; current.origin = path.clone();
-    if current.document.is_clips(){current.notice=None;}
-    control.saved_path = Some(path); control.dirty = false; Ok(true)
+    current.saved = saved; current.origin = path.clone();
+    if current.saved.score.is_clips(){current.notice=None;}
+    control.save_feedback=migrated.then(||"Saved in Alive session v5 format".into());
+    control.saved_wire=Some(current.saved.wire); control.saved_path = Some(path); control.dirty = false; Ok(())
 }
 fn resolve_dirty(window: &WebviewWindow, control: &mut Control) -> Result<bool, String> {
     if !control.dirty { return Ok(true); }
@@ -466,7 +559,18 @@ fn example(app: &tauri::AppHandle) -> Result<PreparedSession, String> {
     let resources = app.path().resource_dir().map_err(|e| e.to_string())?;
     let executable = std::env::current_exe().map_err(|e| e.to_string())?;
     let path = example_path(&resources, executable.parent().ok_or("Missing executable directory")?, Path::new(env!("CARGO_MANIFEST_DIR")));
-    read(&path)
+    Ok(new_session(read(&path)?))
+}
+fn new_session(mut prepared: PreparedSession) -> PreparedSession {
+    prepared.saved.master=MasterSettings{gain:1.};
+    prepared.saved.wire=SaveWire::V5;
+    prepared
+}
+fn enable_clips_for_load(host: &Host, prepared: PreparedSession) -> Result<(PreparedSession,bool),String> {
+    let was_legacy=matches!(prepared.saved.score,Document::LegacyV2(_));
+    let prepared=host.enable_clips(prepared)?;
+    let converted=was_legacy && prepared.saved.score.is_clips();
+    Ok((prepared,converted))
 }
 #[tauri::command]
 pub async fn alive_file(window: WebviewWindow, action: String, path: Option<PathBuf>, generation:u64,draft_revision:u64) -> Result<Option<Snapshot>, String> {
@@ -478,27 +582,29 @@ pub async fn alive_file(window: WebviewWindow, action: String, path: Option<Path
         control.closing = false;
         // Resolve prospective dependencies before any dirty-state decision or native replacement.
         let prospective = match action.as_str() {
-            "new" => { let prepared = control.host.enable_clips(example(window.app_handle())?)?; Some(prepared) },
+            "new" => { Some(enable_clips_for_load(&control.host,example(window.app_handle())?)?) },
             "open" => {
                 let path = match path.clone() { Some(path) => path, None => {
                     let Some(path) = window.dialog().file().set_parent(&window).set_title("Open Alive Session").add_filter("Alive session", &["alive", "json"]).blocking_pick_file() else { return Ok(None); };
                     path.into_path().map_err(|e| e.to_string())?
                 }};
-                let prepared = control.host.enable_clips(read(&path)?)?; Some(prepared)
+                Some(enable_clips_for_load(&control.host,read(&path)?)?)
             }
             "save" | "saveAs" | "quit" => None,
             _ => return Err("Unknown session action".into()),
         };
-        if matches!(action.as_str(),"new"|"open"){control.driver.reject_retiring()?;}
+        if let Some((prepared,_))=&prospective { Host::preflight_master(prepared)?; control.driver.reject_retiring()?; }
         if !resolve_draft(&window, &mut control)? { return Ok(None); }
         match action.as_str() {
             "save" | "saveAs" => { if !save_current(&window, &mut control, action == "saveAs", path)? { return Ok(None); } }
             "new" | "open" => {
                 if !resolve_dirty(&window, &mut control)? { return Ok(None); }
-                let prepared = prospective.unwrap();
-                let origin = prepared.origin.clone(); control.install(prepared)?;
+                let (prepared,converted) = prospective.unwrap();
+                let origin = prepared.origin.clone(); let wire=prepared.saved.wire; control.install(prepared)?;
                 control.saved_path = if action == "open" { Some(origin) } else { None };
-                control.dirty = action == "new" || control.host.prepared.as_ref().is_some_and(|p|p.notice.as_deref()==Some("Upgraded in memory; Save writes session v3"));
+                control.saved_wire = if action == "open" { Some(wire) } else { None };
+                control.save_feedback = None;
+                control.dirty = action == "new" || converted;
             }
             "quit" => {
                 if !resolve_dirty(&window, &mut control)? { return Ok(None); }
@@ -625,19 +731,19 @@ pub async fn alive_workspace_track(window:WebviewWindow,operation:WorkspaceTrack
         let state=window.state::<Desktop>();let mut c=ui_lock(&state.0)?;c.version(generation,draft_revision)?;c.stopped()?;
         if c.draft.is_some(){return Err("Apply or discard pending edits before changing tracks".into());}
         let current=c.host.prepared.as_ref().ok_or("No session")?;
-        let Document::WorkspacesV4(project)=&current.document else{return Err("Enable MIDI workspaces first".into())};
+        let Document::WorkspacesV4(project)=&current.saved.score else{return Err("Enable MIDI workspaces first".into())};
         let mut candidate=project.clone();let mut ids=c.history.identities();ids.extend(project.identities());
         let track_id=match operation {
             WorkspaceTrackOperation::AddMidi{path}=>{
                 let limits=host::workspace_limits()?;
                 if candidate.tracks.len()>=limits.max_tracks as usize||candidate.tracks.iter().map(|t|t.devices().count()).sum::<usize>()>=limits.max_devices as usize{return Err("Measured workspace track/root storage capacity is reached; no dependency was opened".into());}
                 let path=match path{Some(path)=>path,None=>{let Some(path)=window.dialog().file().set_parent(&window).set_title("Add MIDI Track").add_filter("Ultra instrument",&["ultra"]).blocking_pick_file()else{return Ok(WorkspaceEditResult{snapshot:c.snapshot(window.label())?,affected:workspace_edits::Affected::default()})};path.into_path().map_err(|e|e.to_string())?}};
-                let mut instrument=capture_device(&path,&current.document)?;instrument.instance_id=clips::fresh("instance",&mut ids);let id=clips::fresh("track",&mut ids);
+                let mut instrument=capture_device(&path,&current.saved.score)?;instrument.instance_id=clips::fresh("instance",&mut ids);let id=clips::fresh("track",&mut ids);
                 candidate.tracks.push(workspaces::TrackV4{id:id.clone(),name:format!("Track {}",candidate.tracks.len()+1),color:if candidate.tracks.len()%2==0{"#c77b61"}else{"#86a59c"}.into(),chain:workspaces::ChainV4::Midi{instrument},effects:vec![],slots:[None,None,None,None],gain:0.7,mute:false,solo:false});id
             },
             WorkspaceTrackOperation::Remove{track_id}=>{if candidate.tracks.len()==1{return Err("Keep at least one track".into());}let index=candidate.tracks.iter().position(|t|t.id==track_id).ok_or("Unknown workspace track")?;candidate.tracks.remove(index);candidate.sources.retain(|s|s.track_id()!=track_id);candidate.placements.retain(|p|p.track_id!=track_id);track_id}
         };
-        let prepared=prepare(&Document::WorkspacesV4(candidate),&current.origin)?;c.install(prepared)?;close_stale_editors(window.app_handle(),c.generation);
+        let prepared=prepare(&current.saved.with_score(Document::WorkspacesV4(candidate)),&current.origin)?;c.install(prepared)?;close_stale_editors(window.app_handle(),c.generation);
         Ok(WorkspaceEditResult{snapshot:c.snapshot(window.label())?,affected:workspace_edits::Affected{track_id:Some(track_id),..Default::default()}})
     }).await.map_err(|e|e.to_string())?
 }
@@ -650,7 +756,7 @@ pub async fn alive_device(window: WebviewWindow, track_id: String, action: Strin
         control.version(generation,draft_revision)?; control.stopped()?;
         if control.draft.is_some() { return Err("Apply or discard pending schedule edits before changing devices".into()); }
         let current = control.host.prepared.as_ref().ok_or("No session")?;
-        let mut document = current.document.clone();
+        let mut document = current.saved.score.clone();
         addition_capacity(&document,&track_id,&action)?;
         if let Document::WorkspacesV4(project)=&document {
             let track=project.tracks.iter().find(|t|t.id==track_id).ok_or("Unknown workspace track")?;
@@ -668,8 +774,8 @@ pub async fn alive_device(window: WebviewWindow, track_id: String, action: Strin
             Some({let mut reference=capture_device(&path,&document)?;if let Document::WorkspacesV4(p)=&document{let mut ids=control.history.identities();ids.extend(p.identities());reference.instance_id=clips::fresh("instance",&mut ids);}reference})
         } else { None };
         change_device(&mut document, &track_id, &action, instance_id.as_deref(), before_instance_id.as_deref(), reference)?;
-        prepare::check_sources(&document,&current.origin,Some(&current.document))?;
-        let prepared = prepare(&document, &current.origin)?; control.install(prepared)?;
+        prepare::check_sources(&document,&current.origin,Some(&current.saved.score))?;
+        let prepared = prepare(&current.saved.with_score(document), &current.origin)?; control.install(prepared)?;
         close_stale_editors(window.app_handle(), control.generation);
         control.snapshot(window.label())
     }).await.map_err(|e| e.to_string())?
@@ -691,14 +797,15 @@ pub fn run(mut context: tauri::Context<tauri::Wry>, path: Option<PathBuf>) {
             let prepared = match path.as_ref() { Some(path) => read(path), None => example(app.handle()) }
                 .map_err(std::io::Error::other)?;
             let saved_path = path.as_ref().map(|_| prepared.origin.clone());
-            let mut host = Host::default(); let prepared=host.enable_clips(prepared).map_err(std::io::Error::other)?;let upgraded=prepared.notice.as_deref()==Some("Upgraded in memory; Save writes session v3");host.install(prepared).map_err(std::io::Error::other)?;
-            app.manage(Desktop(Mutex::new(Control { host, runtime:runtime::Runtime::default(),snapshot_sequence:0, driver: crate::audio::Driver::load(app.path().app_data_dir()?.join("audio-settings.json")), generation: 1,
-                dirty: upgraded, saved_path, draft: None, draft_revision:0,history:History::default(), closing: false, allow_exit: false, editors: BTreeMap::new() })));
+            let saved_wire = path.as_ref().map(|_| prepared.saved.wire);
+            let mut host = Host::default(); let (prepared,upgraded)=enable_clips_for_load(&host,prepared).map_err(std::io::Error::other)?;let accepted_serial=host.install(prepared).map_err(std::io::Error::other)?;
+            app.manage(Desktop(Mutex::new(Control { host, runtime:runtime::Runtime::default(),snapshot_sequence:0, accepted_serial, driver: crate::audio::Driver::load(app.path().app_data_dir()?.join("audio-settings.json")), generation: 1,
+                dirty: upgraded, saved_path, saved_wire, save_feedback:None, draft: None, draft_revision:0,history:History::default(), closing: false, allow_exit: false, editors: BTreeMap::new() })));
             tauri::WebviewWindowBuilder::new(app, "main", tauri::WebviewUrl::App("alive.html".into()))
                 .title("Alive").inner_size(1200., 800.).min_inner_size(900., 660.).build()?;
             Ok(())
         })
-        .invoke_handler(tauri::generate_handler![alive_current, alive_enable_workspaces, alive_workspace_action, alive_workspace_edit, alive_workspace_track, alive_clip_edit, alive_clip_action, alive_launch_scene, alive_enable_clips, alive_edit, alive_history, alive_discard, alive_apply, alive_base, alive_bypass, alive_mixer, alive_transport, alive_audio_devices, alive_audio_configure, alive_audio_diagnostics, alive_audio, alive_editor, alive_file, alive_device])
+        .invoke_handler(tauri::generate_handler![alive_current, alive_master, alive_master_reset_clip, alive_enable_workspaces, alive_workspace_action, alive_workspace_edit, alive_workspace_track, alive_clip_edit, alive_clip_action, alive_launch_scene, alive_enable_clips, alive_edit, alive_history, alive_discard, alive_apply, alive_base, alive_bypass, alive_mixer, alive_transport, alive_audio_devices, alive_audio_configure, alive_audio_diagnostics, alive_audio, alive_editor, alive_file, alive_device])
         .on_window_event(|window,event| { if window.label() == "main" { if let tauri::WindowEvent::CloseRequested { api, .. } = event { api.prevent_close(); request_close(window.app_handle()); } } })
         .build(context).expect("Unable to start Alive")
         .run(|app,event| match event {
@@ -748,7 +855,7 @@ mod tests {
     }
     #[test]
     fn draft_rejects_device_substitution_and_overload_before_retention() {
-        let live = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().document;
+        let live = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().saved.score;
         let mut draft = live.clone();
         draft.legacy_mut().unwrap().tracks[0].device.path = "other.ultra".into();
         assert!(musical_draft(draft, &live).unwrap_err().contains("stopped"));
@@ -763,14 +870,14 @@ mod tests {
     }
     #[test]
     fn pending_schedule_merges_latest_live_bases_and_mixer() {
-        let mut live = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().document;
+        let mut live = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().saved.score;
         let mut draft = live.clone(); draft.legacy_mut().unwrap().tracks[0].notes[0].pitch = 61;
         live.legacy_mut().unwrap().tracks[0].device.parameters.insert("cutoff".into(), 1234.); live.legacy_mut().unwrap().tracks[0].gain = 0.4;
         merge_live(&mut draft, &live);
         assert_eq!(draft.legacy().unwrap().tracks[0].notes[0].pitch, 61); assert_eq!(draft.legacy().unwrap().tracks[0].device.parameters["cutoff"], 1234.); assert_eq!(draft.legacy().unwrap().tracks[0].gain, 0.4);
     }
     fn chain() -> Session {
-        let mut session = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().document;
+        let mut session = read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().saved.score;
         for id in ["effect-a", "effect-b"] {
             let mut d = session.legacy().unwrap().tracks[0].device.clone(); d.instance_id = id.into();
             session.legacy_mut().unwrap().tracks[0].effects.push(d);
@@ -806,8 +913,8 @@ mod tests {
     }
     #[test]
     fn actual_registered_window_binding_authenticates_instance_and_generation() {
-        let mut control=Control { host:Host::default(),runtime:runtime::Runtime::default(),snapshot_sequence:0, driver:crate::audio::Driver::load(PathBuf::from("/nonexistent/alive-test.json")), generation:7,
-            dirty:false,saved_path:None,draft:None,draft_revision:0,history:History::default(),closing:false,allow_exit:false,editors:BTreeMap::new() };
+        let mut control=Control { host:Host::default(),runtime:runtime::Runtime::default(),snapshot_sequence:0, accepted_serial:0, driver:crate::audio::Driver::load(PathBuf::from("/nonexistent/alive-test.json")), generation:7,
+            dirty:false,saved_path:None,saved_wire:None,save_feedback:None,draft:None,draft_revision:0,history:History::default(),closing:false,allow_exit:false,editors:BTreeMap::new() };
         let label=editor_label(7,"effect-a");
         assert!(control.authorize_instance(&label,"effect-a").is_err());
         control.editors.insert(label.clone(),EditorBinding {generation:7,instance_id:"effect-a".into()});
@@ -845,27 +952,223 @@ mod tests {
     fn musical_control()->Control {
         let prepared=read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap();
         let mut host=Host::default();host.prepared=Some(prepared);
-        Control {host,runtime:runtime::Runtime::default(),snapshot_sequence:0,driver:crate::audio::Driver::load(PathBuf::from("/nonexistent/alive-test.json")),generation:7,
-            dirty:false,saved_path:None,draft:None,draft_revision:0,history:History::default(),closing:false,allow_exit:false,editors:BTreeMap::new()}
+        Control {host,runtime:runtime::Runtime::default(),snapshot_sequence:0,accepted_serial:0,driver:crate::audio::Driver::load(PathBuf::from("/nonexistent/alive-test.json")),generation:7,
+            dirty:false,saved_path:None,saved_wire:None,save_feedback:None,draft:None,draft_revision:0,history:History::default(),closing:false,allow_exit:false,editors:BTreeMap::new()}
+    }
+    #[test]
+    fn master_stale_generation_refuses_without_owner_mutation() {
+        let mut control=musical_control();let before=control.host.prepared.as_ref().unwrap().saved.clone();
+        let error=control.master_gain("main",8,0.5).unwrap_err();
+        assert_eq!(error.code,"STALE_GENERATION");assert_eq!(control.host.prepared.as_ref().unwrap().saved,before);
+        assert_eq!(control.accepted_serial,0);assert!(!control.dirty);
+    }
+    #[test]
+    fn master_failed_install_rolls_back_gain_and_receipt() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_failed_install_rolls_back_gain_and_receipt"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let mut original=c.host.prepared.clone().unwrap();original.saved.master.gain=0.5;original.saved.wire=SaveWire::V5;
+        let ids=original.saved.score.tracks().iter().map(|track|track.id().to_owned()).collect::<Vec<_>>();
+        original.saved.score.set_mixer(&ids[0],1.,false,false).unwrap();original.saved.score.set_mixer(&ids[1],1.,true,false).unwrap();
+        original.events.clear();original.devices[0].manifest.parameters.clear();
+        let note=original.devices[0].manifest.note_node.unwrap();let mut graph=crate::canvas::NativeGraph::default();
+        graph.node_count=3;graph.edge_count=2;graph.nodes[0].id=note;graph.nodes[0].kind=60;graph.nodes[0].p0=4.;
+        graph.nodes[1].id=100001;graph.nodes[1].kind=38;graph.nodes[1].text[..4].copy_from_slice(b"0.25");
+        graph.nodes[2].id=100002;graph.nodes[2].kind=49;graph.nodes[2].text[..3].copy_from_slice(b"1 2");
+        graph.edges[0]=crate::canvas::NativeEdge{from:100001,outlet:0,to:100002,inlet:0};graph.edges[1]=crate::canvas::NativeEdge{from:100001,outlet:0,to:100002,inlet:1};
+        original.devices[0].graph=graph;
+        c.accepted_serial=c.host.install(original.clone()).unwrap();let first=c.accepted_serial;
+        let mut before_left=[0f32;512];let mut before_right=[0f32;512];
+        unsafe{assert_eq!(native::ultra_external_start(),1);assert_eq!(native::alive_session_start(),1);assert_eq!(native::ultra_external_render(512,before_left.as_mut_ptr(),before_right.as_mut_ptr()),1);native::ultra_audio_stop();}
+        assert_eq!(before_left[0],0.125);assert_eq!(before_right[0],0.125);
+        let mut candidate=original.clone();candidate.saved.master.gain=0.75;
+        super::super::native_master::set_serial_for_test(u64::MAX-2);
+        host::test_fail_after_reset(1);
+        assert!(c.install(candidate).unwrap_err().contains("prior session retained"));
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved,original.saved);assert_eq!(c.generation,7);assert!(!c.dirty);
+        assert!(c.accepted_serial>first);assert_eq!(c.accepted_serial,u64::MAX);
+        let mut score=native::StateV2::default();let mut master=super::super::native_master::State::output();
+        assert_eq!(unsafe{(native::master_capability().unwrap().snapshot_v2)((&mut score as *mut native::StateV2).cast(),&mut master)},1);
+        assert_eq!(master.applied_serial,c.accepted_serial);
+        let mut after_left=[0f32;512];let mut after_right=[0f32;512];
+        unsafe{assert_eq!(native::ultra_external_start(),1);assert_eq!(native::alive_session_start(),1);assert_eq!(native::ultra_external_render(512,after_left.as_mut_ptr(),after_right.as_mut_ptr()),1);native::ultra_audio_stop();}
+        assert_eq!(after_left[0],0.125);assert_eq!(after_right[0],0.125);
+        assert_eq!(master.target_gain,original.saved.master.gain);assert_eq!(master.current_gain,original.saved.master.gain);
+        assert_eq!(before_left,after_left);assert_eq!(before_right,after_right);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_gain_admission_promotes_only_on_change() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_gain_admission_promotes_only_on_change"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let original=c.host.prepared.clone().unwrap();
+        c.accepted_serial=c.host.install(original).unwrap();let install=c.accepted_serial;
+        let no_op=c.master_gain("main",7,1.).unwrap();assert!(!no_op.changed);assert_eq!(c.accepted_serial,install);assert!(!c.dirty);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.wire,SaveWire::LegacyScore);
+        let changed=c.master_gain("main",7,0.5).unwrap();assert!(changed.changed);assert!(c.accepted_serial>install);assert!(c.dirty);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.wire,SaveWire::V5);
+        let accepted=c.accepted_serial;let error=c.master_gain("main",7,f64::NAN).unwrap_err();assert_eq!(error.code,"INVALID");assert_eq!(c.accepted_serial,accepted);
+        c.master_gain("main",7,1.).unwrap();assert_eq!(c.host.prepared.as_ref().unwrap().saved.wire,SaveWire::V5);
+        c.dirty=false;c.master_reset("main",7).unwrap();assert!(!c.dirty);assert_eq!(c.host.prepared.as_ref().unwrap().saved.master.gain,1.);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_queue_full_preserves_owner_and_allows_retry() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_queue_full_preserves_owner_and_allows_retry"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let original=c.host.prepared.clone().unwrap();
+        c.accepted_serial=c.host.install(original).unwrap();let accepted=c.accepted_serial;
+        let before=c.host.prepared.as_ref().unwrap().saved.clone();let mut draft=before.score.clone();draft.legacy_mut().unwrap().tempo=130.;
+        c.edit(draft,"Pending tempo",7,0).unwrap();let draft=c.draft.clone();let revision=c.draft_revision;let history=serde_json::to_value(c.history.view()).unwrap();
+        unsafe{assert_eq!(native::ultra_external_start(),1);}
+        let capability=native::master_capability().unwrap();
+        for index in 0..64 {let serial=super::super::native_master::next_serial().unwrap();if index==0{assert_eq!(serial,accepted+2);}assert_eq!(unsafe{(capability.set)(1,1.,serial)},1);}
+        let error=c.master_gain("main",7,0.5).unwrap_err();assert_eq!(error.code,"FULL");
+        let wire=serde_json::to_value(&error).unwrap();assert_eq!(wire["code"],"FULL");assert!(wire["message"].as_str().is_some_and(|message|!message.is_empty()));
+        assert!(matches!(c.master_reset("main",7),Err(MasterError{code:"FULL",..})));
+        assert_eq!(c.accepted_serial,accepted);assert!(!c.dirty);assert_eq!(c.host.prepared.as_ref().unwrap().saved,before);
+        assert_eq!(c.draft,draft);assert_eq!(c.draft_revision,revision);assert_eq!(serde_json::to_value(c.history.view()).unwrap(),history);
+        unsafe{native::ultra_audio_stop();}
+        let receipt=c.master_gain("main",7,0.5).unwrap();assert!(receipt.changed);assert_eq!(receipt.accepted_gain,0.5);
+        assert!(c.accepted_serial>accepted);assert_eq!(receipt.accepted_serial,c.accepted_serial.to_string());assert!(c.dirty);assert_eq!(c.draft,draft);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.master.gain,0.5);assert_eq!(c.host.prepared.as_ref().unwrap().saved.wire,SaveWire::V5);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_failed_rollback_does_not_claim_receipt() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_failed_rollback_does_not_claim_receipt"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let original=c.host.prepared.clone().unwrap();
+        c.accepted_serial=c.host.install(original.clone()).unwrap();let accepted=c.accepted_serial;
+        let mut candidate=original.clone();candidate.saved.master.gain=0.5;
+        host::test_fail_after_reset(2);
+        assert!(c.install(candidate).unwrap_err().contains("audio restoration failed"));
+        assert_eq!(c.accepted_serial,accepted);assert_eq!(c.generation,7);assert_eq!(c.host.prepared.as_ref().unwrap().saved,original.saved);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_pending_retirement_burns_pair_without_replacement() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_pending_retirement_burns_pair_without_replacement"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let original=c.host.prepared.clone().unwrap();
+        c.accepted_serial=c.host.install(original.clone()).unwrap();let accepted=c.accepted_serial;
+        let previous=super::super::native_master::current_serial();let preparation=c.host.preparation_revision;
+        let owner=crate::audio::tests::hold_retiring(&mut c.driver);
+        assert_eq!(c.master_gain("main",7,0.5).unwrap_err().code,"BUSY");
+        assert!(matches!(c.master_reset("main",7),Err(MasterError{code:"BUSY",..})));
+        assert_eq!(super::super::native_master::current_serial(),previous);assert_eq!(c.accepted_serial,accepted);
+        let mut candidate=original.clone();candidate.saved.master.gain=0.5;
+        assert!(c.install(candidate.clone()).unwrap_err().starts_with("retirement_pending"));
+        assert_eq!(super::super::native_master::current_serial(),previous+2);
+        assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.accepted_serial,accepted);assert_eq!(c.generation,7);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved,original.saved);
+        drop(owner);c.driver.stop().unwrap();c.install(candidate).unwrap();assert!(c.accepted_serial>previous+2);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_install_refuses_serial_exhaustion_before_retirement() {
+        if super::super::native_master::fresh_process("session::desktop::tests::master_install_refuses_serial_exhaustion_before_retirement"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let original=c.host.prepared.clone().unwrap();c.accepted_serial=c.host.install(original.clone()).unwrap();
+        let accepted=c.accepted_serial;let preparation=c.host.preparation_revision;let before=native::state().unwrap();
+        super::super::native_master::set_serial_for_test(u64::MAX-1);
+        let mut candidate=original.clone();candidate.saved.master.gain=0.5;
+        assert!(c.install(candidate).unwrap_err().contains("serial exhausted"));
+        let after=native::state().unwrap();assert_eq!(after.absolute_frame,before.absolute_frame);assert_eq!(after.generation,before.generation);
+        assert_eq!(c.accepted_serial,accepted);assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.generation,7);assert_eq!(c.host.prepared.as_ref().unwrap().saved,original.saved);
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn new_session_explicitly_starts_with_unity_v5() {
+        let source=read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap();
+        assert_eq!(source.saved.wire,SaveWire::LegacyScore);
+        let new=new_session(source.clone());
+        assert_eq!(new.saved.wire,SaveWire::V5);assert_eq!(new.saved.master.gain,1.);
+        assert_eq!(new.saved.score,source.saved.score);
+    }
+    #[test]
+    fn master_survives_score_history_and_nonunity_install_is_refused() {
+        let mut c=musical_control();
+        let owner=&mut c.host.prepared.as_mut().unwrap().saved;
+        owner.master.gain=0.5;owner.wire=SaveWire::V5;
+        let before=owner.clone();
+        let mut edit=before.score.clone();edit.legacy_mut().unwrap().tempo=130.;
+        c.edit(edit,"Change tempo",7,0).unwrap();
+        c.history(Direction::Undo,7,1).unwrap();
+        c.history(Direction::Redo,7,2).unwrap();
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved,before);
+        let draft=c.draft.clone();let revision=c.draft_revision;
+        assert!(Host::preflight_master_with_capability(c.host.prepared.as_ref().unwrap(),false).unwrap_err().contains("Master gain"));
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved,before);
+        assert_eq!(c.draft,draft);assert_eq!(c.draft_revision,revision);
+        c.clear_scope().unwrap();assert_eq!(c.host.prepared.as_ref().unwrap().saved,before);
+        let current=c.host.prepared.as_ref().unwrap();
+        let clips=prepare(&current.saved.with_score(current.saved.score.to_clips().unwrap()),&current.origin).unwrap();
+        assert_eq!(clips.saved.master,before.master);assert_eq!(clips.saved.wire,before.wire);
+        let project=workspaces::prospective_from_document(&current.saved.score).unwrap();
+        let workspace=prepare(&current.saved.with_score(Document::WorkspacesV4(project)),&current.origin).unwrap();
+        assert_eq!(workspace.saved.master,before.master);assert_eq!(workspace.saved.wire,before.wire);
+    }
+    #[test]
+    fn unavailable_master_snapshot_is_explicit() {
+        let dto=MasterSnapshot{gain:0.5,accepted_serial:"0".into(),available:false,unavailable_reason:Some("Native Master support is unavailable"),observation:None,observation_stale:false};
+        let value=serde_json::to_value(dto).unwrap();
+        assert_eq!(value["gain"],0.5);assert_eq!(value["acceptedSerial"],"0");
+        assert_eq!(value["available"],false);assert!(value["observation"].is_null());
+        assert_eq!(value["observationStale"],false);assert!(value["unavailableReason"].as_str().unwrap().contains("unavailable"));
+    }
+    #[test]
+    fn master_old_library_snapshot_exposes_no_observation() {
+        if std::env::var_os("ALIVE_MASTER_EXPECT_UNAVAILABLE").is_none(){return;}
+        if super::super::native_master::fresh_process("session::desktop::tests::master_old_library_snapshot_exposes_no_observation"){return;}
+        let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+        let mut c=musical_control();let prepared=c.host.prepared.clone().unwrap();c.accepted_serial=c.host.install(prepared).unwrap();
+        let snapshot=c.snapshot("main").unwrap();assert!(!snapshot.master.available);assert_eq!(snapshot.master.accepted_serial,"0");
+        assert!(snapshot.master.observation.is_none());assert!(snapshot.master.unavailable_reason.is_some());
+        unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+    }
+    #[test]
+    fn master_save_commit_follows_rename_and_reports_migration() {
+        let mut c=musical_control();c.saved_wire=Some(SaveWire::LegacyScore);c.dirty=true;
+        c.host.prepared.as_mut().unwrap().notice=Some("Existing score conversion notice".into());
+        let owner=&mut c.host.prepared.as_mut().unwrap().saved;
+        owner.master.gain=0.5;owner.wire=SaveWire::V5;
+        let mut edit=owner.score.clone();edit.legacy_mut().unwrap().tempo=130.;
+        c.edit(edit,"Change tempo",7,0).unwrap();
+        let original=c.host.prepared.as_ref().unwrap().saved.clone();let draft=c.draft.clone();
+        let revision=c.draft_revision;let history=serde_json::to_value(c.history.view()).unwrap();
+        let root=std::env::temp_dir().join(format!("alive-master-control-save-{}",std::process::id()));
+        std::fs::create_dir_all(&root).unwrap();let blocked=root.join("blocked.alive");std::fs::create_dir(&blocked).unwrap();
+        assert!(save_to_path(&mut c,&blocked).is_err());
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved,original);assert_eq!(c.draft,draft);
+        assert_eq!(c.draft_revision,revision);assert_eq!(serde_json::to_value(c.history.view()).unwrap(),history);
+        assert!(c.dirty);assert!(c.saved_path.is_none());assert_eq!(c.saved_wire,Some(SaveWire::LegacyScore));
+        let path=root.join("saved.alive");save_to_path(&mut c,&path).unwrap();
+        assert!(!c.dirty);assert_eq!(c.draft,draft);assert_eq!(c.saved_wire,Some(SaveWire::V5));
+        let p=c.host.prepared.as_ref().unwrap();assert_eq!(p.saved.master.gain,0.5);
+        assert_eq!(p.notice.as_deref(),Some("Existing score conversion notice"));
+        assert_eq!(c.save_feedback.as_deref(),Some("Saved in Alive session v5 format"));
+        assert_eq!(persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).unwrap().master.gain,0.5);
+        save_to_path(&mut c,&path).unwrap();assert!(c.save_feedback.is_none());
+        std::fs::remove_dir_all(root).unwrap();
     }
     #[test]
     fn scenes_authenticate_origin_generation_preparation_and_audio_before_mutation(){
-        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();c.host.prepared=Some(prepare(&p.document.to_clips().unwrap(),&p.origin).unwrap());
-        let before=c.host.prepared.as_ref().unwrap().document.clone();
+        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();c.host.prepared=Some(prepare(&p.saved.with_score(p.saved.score.to_clips().unwrap()),&p.origin).unwrap());
+        let before=c.host.prepared.as_ref().unwrap().saved.score.clone();
         assert!(c.launch_scene("alive-editor-7-0",7,"0",0).err().unwrap().contains("session window"));
         assert!(c.launch_scene("main",6,"0",0).err().unwrap().contains("stale"));
         assert!(c.launch_scene("main",7,"1",0).err().unwrap().contains("Prepared bank changed"));
         assert!(c.launch_scene("main",7,"00",0).err().unwrap().contains("canonical"));
         assert_eq!(c.launch_scene("main",7,"0",0).err().unwrap(),"Start Audio to launch a scene");
         assert!(c.launch_scene("main",7,"0",4).is_err());
-        assert_eq!(c.host.prepared.as_ref().unwrap().document,before);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.score,before);
         assert!(c.draft.is_none()&&!c.dirty&&c.draft_revision==0&&c.generation==7);
     }
     #[test]
     fn focused_clips_duplicate_scores_and_history_retains_ids_without_changing_devices() {
-        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();c.host.prepared=Some(prepare(&p.document.to_clips().unwrap(),&p.origin).unwrap());
-        let track=c.host.prepared.as_ref().unwrap().document.legacy().unwrap().tracks[0].id.clone();
-        let original=c.host.prepared.as_ref().unwrap().document.bank(&track).unwrap().slots[0].clone().unwrap();
+        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();c.host.prepared=Some(prepare(&p.saved.with_score(p.saved.score.to_clips().unwrap()),&p.origin).unwrap());
+        let track=c.host.prepared.as_ref().unwrap().saved.score.legacy().unwrap().tracks[0].id.clone();
+        let original=c.host.prepared.as_ref().unwrap().saved.score.bank(&track).unwrap().slots[0].clone().unwrap();
         let affected=c.clip_edit(clips::Edit::Duplicate{track_id:track.clone(),clip_id:original.id.clone(),destination_slot:1},7,0).unwrap();
         let copied=c.draft.as_ref().unwrap().bank(&track).unwrap().slots[1].clone().unwrap();
         assert_eq!(affected.clip_id,Some(copied.id.clone()));assert_ne!(copied.id,original.id);assert_ne!(copied.notes[0].id,original.notes[0].id);
@@ -878,38 +1181,38 @@ mod tests {
     }
     #[test]
     fn shared_changed_source_blocks_either_selected_replace_until_original_is_restored(){
-        let mut c=musical_control();let current=c.host.prepared.as_ref().unwrap();let mut document=current.document.clone();
+        let mut c=musical_control();let current=c.host.prepared.as_ref().unwrap().clone();let mut document=current.saved.score.clone();
         let root=std::env::temp_dir().join(format!("alive-shared-source-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
         let path=root.join("shared.ultra");let original=std::fs::read(&current.devices[0].path).unwrap();std::fs::write(&path,&original).unwrap();
         for t in &mut document.legacy_mut().unwrap().tracks{t.device.path=path.to_string_lossy().into_owned();}
-        c.host.prepared=Some(prepare(&document,&current.origin).unwrap());
+        c.host.prepared=Some(prepare(&current.saved.with_score(document),&current.origin).unwrap());
         let mut patch:serde_json::Value=serde_json::from_slice(&original).unwrap();patch["nodes"][0]["x"]=serde_json::json!(987);std::fs::write(&path,serde_json::to_vec(&patch).unwrap()).unwrap();
-        let before=c.host.prepared.as_ref().unwrap().document.clone();
+        let before=c.host.prepared.as_ref().unwrap().saved.score.clone();
         for i in 0..2 {let mut candidate=before.clone();let id=candidate.legacy().unwrap().tracks[i].id.clone();let replacement=capture_device(&path,&candidate).unwrap();change_device(&mut candidate,&id,"replace",None,None,Some(replacement)).unwrap();
             let error=prepare::check_sources(&candidate,&root.join("session.alive"),Some(&before)).unwrap_err();assert!(error.contains(&before.legacy().unwrap().tracks[1-i].device.instance_id),"{error}");assert!(error.contains("matching original backup"),"{error}");assert!(error.contains("preserve the changed"),"{error}");}
-        assert_eq!(c.host.prepared.as_ref().unwrap().document,before);assert!(!c.history.view().can_undo);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.score,before);assert!(!c.history.view().can_undo);
         let changed=root.join("changed.ultra");std::fs::copy(&path,&changed).unwrap();std::fs::write(&path,original).unwrap();
-        let mut recovered=before.clone();for i in 0..2{let id=recovered.legacy().unwrap().tracks[i].id.clone();let reference=capture_device(&changed,&recovered).unwrap();change_device(&mut recovered,&id,"replace",None,None,Some(reference)).unwrap();prepare(&recovered,&root.join("session.alive")).unwrap();}
+        let mut recovered=before.clone();for i in 0..2{let id=recovered.legacy().unwrap().tracks[i].id.clone();let reference=capture_device(&changed,&recovered).unwrap();change_device(&mut recovered,&id,"replace",None,None,Some(reference)).unwrap();prepare(&current.saved.with_score(recovered.clone()),&root.join("session.alive")).unwrap();}
         std::fs::remove_dir_all(root).unwrap();
     }
     #[test]
     fn delayed_retirement_preserves_draft_history_generation_and_prepared_roots(){
         let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
-        let mut control=musical_control();let mut draft=control.host.prepared.as_ref().unwrap().document.clone();draft.legacy_mut().unwrap().tracks[0].notes[0].pitch=61;
-        control.edit(draft,"Change pitch",7,0).unwrap();let document=control.draft.clone();let history=serde_json::to_value(control.history.view()).unwrap();let prepared=control.host.prepared.as_ref().unwrap().document.clone();
+        let mut control=musical_control();let mut draft=control.host.prepared.as_ref().unwrap().saved.score.clone();draft.legacy_mut().unwrap().tracks[0].notes[0].pitch=61;
+        control.edit(draft,"Change pitch",7,0).unwrap();let document=control.draft.clone();let history=serde_json::to_value(control.history.view()).unwrap();let prepared=control.host.prepared.as_ref().unwrap().saved.score.clone();
         let owner=crate::audio::tests::hold_retiring(&mut control.driver);
         assert!(control.apply_draft().unwrap_err().starts_with("retirement_pending"));
-        assert_eq!(control.draft,document);assert_eq!(serde_json::to_value(control.history.view()).unwrap(),history);assert_eq!(control.generation,7);assert_eq!(control.draft_revision,1);assert_eq!(control.host.prepared.as_ref().unwrap().document,prepared);
+        assert_eq!(control.draft,document);assert_eq!(serde_json::to_value(control.history.view()).unwrap(),history);assert_eq!(control.generation,7);assert_eq!(control.draft_revision,1);assert_eq!(control.host.prepared.as_ref().unwrap().saved.score,prepared);
         unsafe{native::alive_session_stop_v3();} // scoped Stop remains available.
         drop(owner);control.driver.stop().unwrap();
     }
     #[test]
     fn pending_history_versions_noops_baseline_redo_and_live_merge() {
-        let mut c=musical_control();let original=c.host.prepared.as_ref().unwrap().document.clone();let mut edited=original.clone();edited.legacy_mut().unwrap().tempo=130.;
+        let mut c=musical_control();let original=c.host.prepared.as_ref().unwrap().saved.score.clone();let mut edited=original.clone();edited.legacy_mut().unwrap().tempo=130.;
         c.edit(edited.clone(),"Tempo",7,0).unwrap();assert_eq!(c.draft_revision,1);
         assert!(c.edit(original.clone(),"Stale",7,0).is_err());assert!(c.edit(original.clone(),"Generation",6,1).is_err());
         assert_eq!(c.draft.as_ref().unwrap().legacy().unwrap().tempo,130.);c.edit(edited.clone(),"Same",7,1).unwrap();assert_eq!(c.draft_revision,1);
-        {let live=&mut c.host.prepared.as_mut().unwrap().document;live.legacy_mut().unwrap().tracks[0].gain=0.4;live.legacy_mut().unwrap().tracks[0].device.parameters.insert("cutoff".into(),2345.);}
+        {let live=&mut c.host.prepared.as_mut().unwrap().saved.score;live.legacy_mut().unwrap().tracks[0].gain=0.4;live.legacy_mut().unwrap().tracks[0].device.parameters.insert("cutoff".into(),2345.);}
         c.dirty=true;c.history(Direction::Undo,7,1).unwrap();assert!(c.draft.is_none());assert!(c.dirty);assert!(c.history.view().can_redo);
         c.history(Direction::Redo,7,2).unwrap();let d=c.draft.as_ref().unwrap();assert_eq!(d.legacy().unwrap().tempo,130.);assert_eq!(d.legacy().unwrap().tracks[0].gain,0.4);assert_eq!(d.legacy().unwrap().tracks[0].device.parameters["cutoff"],2345.);
         assert_eq!(c.generation,7);assert!(c.history(Direction::Redo,7,3).is_err());assert_eq!(c.draft_revision,3);
@@ -917,7 +1220,7 @@ mod tests {
     }
     #[test]
     fn edit_admission_rejects_ranges_targets_rounded_overlap_and_truncation_atomically() {
-        let mut c=musical_control();let original=c.host.prepared.as_ref().unwrap().document.clone();
+        let mut c=musical_control();let original=c.host.prepared.as_ref().unwrap().saved.score.clone();
         for mutate in [
             |s:&mut Session|s.legacy_mut().unwrap().tempo=0.,
             |s:&mut Session|s.legacy_mut().unwrap().length_beats=0.5,
@@ -933,7 +1236,7 @@ mod tests {
     }
     #[test]
     fn failed_apply_source_and_native_density_preserve_retained_history() {
-        let mut c=musical_control();let mut edited=c.host.prepared.as_ref().unwrap().document.clone();edited.legacy_mut().unwrap().tempo=130.;
+        let mut c=musical_control();let mut edited=c.host.prepared.as_ref().unwrap().saved.score.clone();edited.legacy_mut().unwrap().tempo=130.;
         c.edit(edited.clone(),"Tempo",7,0).unwrap();
         let origin=c.host.prepared.as_ref().unwrap().origin.clone();c.host.prepared.as_mut().unwrap().origin=PathBuf::from("/nonexistent/session.alive");
         assert!(c.apply_draft().is_err());assert_eq!(c.draft_revision,1);assert!(c.history.view().can_undo);assert_eq!(c.draft.as_ref().unwrap(),&edited);
@@ -944,39 +1247,74 @@ mod tests {
 
     #[test]
     fn undo_redo_merge_same_source_effect_bases_bypass_and_mixer_by_identity() {
-        let mut c=musical_control();let current=c.host.prepared.as_ref().unwrap();let mut document=current.document.clone();
+        let mut c=musical_control();let current=c.host.prepared.as_ref().unwrap().clone();let mut document=current.saved.score.clone();
         let path=Path::new(env!("CARGO_MANIFEST_DIR")).join("../examples/utility.ultra");
         for _ in 0..2 {let d=capture_device(&path,&document).unwrap();document.legacy_mut().unwrap().tracks[0].effects.push(d);}
-        c.host.prepared=Some(prepare(&document,&current.origin).unwrap());let mut edited=c.host.prepared.as_ref().unwrap().document.clone();edited.legacy_mut().unwrap().tempo=130.;
+        c.host.prepared=Some(prepare(&current.saved.with_score(document),&current.origin).unwrap());let mut edited=c.host.prepared.as_ref().unwrap().saved.score.clone();edited.legacy_mut().unwrap().tempo=130.;
         c.edit(edited,"Tempo",7,0).unwrap();
-        {let t=&mut c.host.prepared.as_mut().unwrap().document.legacy_mut().unwrap().tracks[0];t.effects[0].parameters.insert("gain".into(),0.3);t.effects[1].parameters.insert("gain".into(),0.8);t.effects[1].bypassed=true;t.gain=0.6;t.solo=true;}
+        {let t=&mut c.host.prepared.as_mut().unwrap().saved.score.legacy_mut().unwrap().tracks[0];t.effects[0].parameters.insert("gain".into(),0.3);t.effects[1].parameters.insert("gain".into(),0.8);t.effects[1].bypassed=true;t.gain=0.6;t.solo=true;}
         c.history(Direction::Undo,7,1).unwrap();c.history(Direction::Redo,7,2).unwrap();let t=&c.draft.as_ref().unwrap().legacy().unwrap().tracks[0];
         assert_eq!(t.effects[0].parameters["gain"],0.3);assert_eq!(t.effects[1].parameters["gain"],0.8);assert!(!t.effects[0].bypassed);assert!(t.effects[1].bypassed);assert_eq!(t.gain,0.6);assert!(t.solo);
     }
 
     fn workspace_control()->Control {
-        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();let project=workspaces::prospective_from_document(&p.document).unwrap();c.host.prepared=Some(prepare(&Document::WorkspacesV4(project),&p.origin).unwrap());c
+        let mut c=musical_control();let p=c.host.prepared.as_ref().unwrap();let project=workspaces::prospective_from_document(&p.saved.score).unwrap();c.host.prepared=Some(prepare(&p.saved.with_score(Document::WorkspacesV4(project)),&p.origin).unwrap());c
+    }
+    #[test]
+    fn conversion_notices_and_saves_match_the_owner_wire() {
+        const NAME:&str="session::desktop::tests::conversion_notices_and_saves_match_the_owner_wire";
+        if std::env::var("ALIVE_CONVERSION_NOTICE_CHILD").as_deref()!=Ok("1") {
+            let child=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",NAME,"--nocapture"]).env("ALIVE_CONVERSION_NOTICE_CHILD","1").env_remove("DISPLAY").env_remove("WAYLAND_DISPLAY").output().unwrap();
+            assert!(child.status.success(),"{}\n{}",String::from_utf8_lossy(&child.stdout),String::from_utf8_lossy(&child.stderr));return;
+        }
+        let root=std::env::temp_dir().join(format!("alive-conversion-wire-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
+        let mut c=musical_control();
+        for (wire,outer,clip_notice,workspace_notice) in [
+            (SaveWire::LegacyScore,"alive-session-v3","Save writes session v3","Save writes v4"),
+            (SaveWire::V5,"alive-session-v5","Save writes session v5 with a v3 score","Save writes session v5 with a v4 score")
+        ] {
+            let p=read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap();let mut saved=p.saved.clone();saved.wire=wire;
+            for track in &mut saved.score.legacy_mut().unwrap().tracks {track.notes.clear();track.automation.clear();}
+            let base=prepare(&saved,&p.origin).unwrap();let (clips,converted)=enable_clips_for_load(&c.host,base).unwrap();assert!(converted);
+            assert!(clips.saved.score.is_clips());assert!(clips.notice.as_deref().unwrap().contains(clip_notice));
+            assert!(!enable_clips_for_load(&c.host,clips.clone()).unwrap().1);
+            let clip_path=root.join(format!("{wire:?}-clips.alive"));
+            let (clip_path,_)=persistence::save_document(&clip_path,&clips.saved,&clips.origin).unwrap();
+            let file:serde_json::Value=serde_json::from_slice(&std::fs::read(clip_path).unwrap()).unwrap();assert_eq!(file["format"],outer);
+            if wire==SaveWire::V5 {assert_eq!(file["score"]["format"],"alive-session-v3");assert_eq!(file["master"]["gain"],1.);}
+            c.host.install(clips).unwrap();c.dirty=false;c.saved_wire=Some(wire);
+            c.enable_workspaces("main",c.generation,c.draft_revision).unwrap();assert!(c.dirty);
+            let candidate=c.host.prepared.as_ref().unwrap();assert!(candidate.notice.as_deref().unwrap().contains(workspace_notice));
+            let path=root.join(format!("{wire:?}-workspace.alive"));save_to_path(&mut c,&path).unwrap();assert!(!c.dirty);
+            let file:serde_json::Value=serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
+            assert_eq!(file["format"],if wire==SaveWire::V5 {"alive-session-v5"} else {"alive-session-v4"});
+            if wire==SaveWire::V5 {assert_eq!(file["score"]["format"],"alive-session-v4");assert_eq!(file["master"]["gain"],1.);}
+            save_to_path(&mut c,&path).unwrap();assert!(c.host.prepared.as_ref().unwrap().notice.as_deref().unwrap().contains(workspace_notice));
+            let again:serde_json::Value=serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();assert_eq!(again["format"],file["format"]);
+        }
+        unsafe {native::ultra_audio_stop();native::alive_session_reset();for slot in 0..16 {crate::ultra_canvas_close_document(slot);}}
+        std::fs::remove_dir_all(root).unwrap();
     }
     #[test]
     fn workspace_commands_authenticate_origin_generation_revision_and_preparation() {
-        let mut c=workspace_control();let before=c.host.prepared.as_ref().unwrap().document.clone();
+        let mut c=workspace_control();let before=c.host.prepared.as_ref().unwrap().saved.score.clone();
         let op=workspaces::WorkspaceEditV4::SourceRename{source_id:"forged".into(),name:"Forged".into()};
         for (origin,generation,revision) in [("editor",7,0),("main",6,0),("main",7,1),("main",7,0)]{assert!(c.workspace_edit(origin,op.clone(),generation,revision).is_err());}
         for (origin,generation,preparation) in [("editor",7,"0"),("main",6,"0"),("main",7,"01"),("main",7,"1"),("main",7,"0")]{assert!(c.workspace_action(origin,generation,preparation,runtime_workspaces::Action::Start{}).is_err());}
-        assert_eq!(c.host.prepared.as_ref().unwrap().document,before);assert!(c.draft.is_none());assert_eq!(c.draft_revision,0);assert!(!c.history.view().can_undo);
+        assert_eq!(c.host.prepared.as_ref().unwrap().saved.score,before);assert!(c.draft.is_none());assert_eq!(c.draft_revision,0);assert!(!c.history.view().can_undo);
     }
     #[test]
     fn workspace_history_retains_independent_ids_and_merges_current_live_values() {
         use workspaces::{WorkspaceEditV4 as E,OccurrenceV4};
-        let mut c=workspace_control();let Document::WorkspacesV4(project)=&c.host.prepared.as_ref().unwrap().document else{panic!()};
+        let mut c=workspace_control();let Document::WorkspacesV4(project)=&c.host.prepared.as_ref().unwrap().saved.score else{panic!()};
         let track=project.tracks[0].id.clone();let slot=project.tracks[0].slots[0].as_ref().unwrap().id.clone();let source=project.tracks[0].slots[0].as_ref().unwrap().source_id.clone();let instance=project.tracks[0].devices().next().unwrap().instance_id.clone();
         let affected=c.workspace_edit("main",E::SourceIndependent{occurrence:OccurrenceV4::Slot{track_id:track.clone(),slot_id:slot.clone()}},7,0).unwrap();
         assert_eq!(affected.slot_id.as_deref(),Some(slot.as_str()));assert!(affected.note_id.is_none());assert_ne!(affected.source_id.as_deref(),Some(source.as_str()));let independent=affected.source_id.unwrap();
         let accepted=c.draft.clone().unwrap();
-        {let live=&mut c.host.prepared.as_mut().unwrap().document;live.set_mixer(&track,0.37,true,false).unwrap();live.device_mut(&instance).unwrap().parameters.insert("cutoff".into(),1800.);}
+        {let live=&mut c.host.prepared.as_mut().unwrap().saved.score;live.set_mixer(&track,0.37,true,false).unwrap();live.device_mut(&instance).unwrap().parameters.insert("cutoff".into(),1800.);}
         c.history(Direction::Undo,7,1).unwrap();assert!(c.draft.is_none());assert!(c.history.view().can_redo);
-        let name=match &c.host.prepared.as_ref().unwrap().document{Document::WorkspacesV4(p)=>match &p.sources[0]{workspaces::SourceV4::Midi{name,..}=>name.clone(),_=>panic!()},_=>panic!()};
-        let p=match &c.host.prepared.as_ref().unwrap().document{Document::WorkspacesV4(p)=>p,_=>panic!()};let first=p.sources[0].id().to_owned();
+        let name=match &c.host.prepared.as_ref().unwrap().saved.score{Document::WorkspacesV4(p)=>match &p.sources[0]{workspaces::SourceV4::Midi{name,..}=>name.clone(),_=>panic!()},_=>panic!()};
+        let p=match &c.host.prepared.as_ref().unwrap().saved.score{Document::WorkspacesV4(p)=>p,_=>panic!()};let first=p.sources[0].id().to_owned();
         c.workspace_edit("main",E::SourceRename{source_id:first,name},7,2).unwrap();assert_eq!(c.draft_revision,2);assert!(c.history.view().can_redo);
         c.history(Direction::Redo,7,2).unwrap();let restored=c.draft.as_ref().unwrap();assert_eq!(Projection::from(restored),Projection::from(&accepted));assert_eq!(restored.tracks()[0].mixer(),(0.37,true,false));assert_eq!(restored.tracks()[0].instrument().unwrap().parameters["cutoff"],1800.);
         let Document::WorkspacesV4(p)=restored else{panic!()};assert_eq!(p.tracks[0].slots[0].as_ref().unwrap().source_id,independent);
@@ -984,14 +1322,14 @@ mod tests {
     #[test]
     fn workspace_source_edits_preserve_occurrence_identity_and_reject_invalid_bindings_transactionally() {
         use workspaces::WorkspaceEditV4 as E;
-        let mut c=workspace_control();let Document::WorkspacesV4(p)=&c.host.prepared.as_ref().unwrap().document else{panic!()};let source=p.sources[0].id().to_owned();let track=p.sources[0].track_id().to_owned();
+        let mut c=workspace_control();let Document::WorkspacesV4(p)=&c.host.prepared.as_ref().unwrap().saved.score else{panic!()};let source=p.sources[0].id().to_owned();let track=p.sources[0].track_id().to_owned();
         let result=c.workspace_edit("main",E::SourceRename{source_id:source.clone(),name:"Shared musical source".into()},7,0).unwrap();assert_eq!(result.track_id.as_deref(),Some(track.as_str()));assert_eq!(result.source_id.as_deref(),Some(source.as_str()));assert!(result.slot_id.is_none()&&result.placement_id.is_none());
         let before=c.draft.clone();let ids=c.history.identities();let bad=vec![Lane{instance_id:"forged-instance".into(),key:"cutoff".into(),enabled:true,points:vec![]}];
         assert!(c.workspace_edit("main",E::AutomationSet{source_id:source,lanes:bad},7,1).is_err());assert_eq!(c.draft,before);assert_eq!(c.draft_revision,1);assert_eq!(c.history.identities(),ids);
     }
     #[test]
     fn workspace_effect_roles_never_use_the_first_effect_as_an_instrument() {
-        let mut c=workspace_control();let Document::WorkspacesV4(p)=&mut c.host.prepared.as_mut().unwrap().document else{panic!()};
+        let mut c=workspace_control();let Document::WorkspacesV4(p)=&mut c.host.prepared.as_mut().unwrap().saved.score else{panic!()};
         let mut effect=p.tracks[0].devices().next().unwrap().clone();effect.instance_id="first-effect".into();p.tracks[0].chain=workspaces::ChainV4::Audio{};p.tracks[0].effects=vec![effect];p.tracks[0].slots=[None,None,None,None];let track=p.tracks[0].id.clone();p.sources.retain(|s|s.track_id()!=track);p.placements.retain(|p|p.track_id!=track);
         change_workspace_device(p,&track,"remove",Some("first-effect"),None,None).unwrap();assert!(p.tracks[0].devices().next().is_none());assert_eq!(p.tracks.len(),2);
         assert!(change_workspace_device(p,&track,"load",None,None,None).is_err());
@@ -1005,15 +1343,15 @@ mod tests {
             assert!(child.status.success(),"{}\n{}",String::from_utf8_lossy(&child.stdout),String::from_utf8_lossy(&child.stderr));return;
         }
         let mut c=musical_control();let original=c.host.prepared.as_ref().unwrap().clone();c.host.install(original.clone()).unwrap();let preparation=c.host.preparation_revision;
-        assert!(c.enable_workspaces("main",7,0).unwrap_err().contains("observed 40, limit 32"));assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.generation,7);assert_eq!(c.draft_revision,0);assert_eq!(c.host.prepared.as_ref().unwrap().document,original.document);
-        let mut quiet=original.document.clone();for t in &mut quiet.legacy_mut().unwrap().tracks{t.notes.clear();t.automation.clear();}c.host.install(prepare(&quiet,&original.origin).unwrap()).unwrap();
-        c.enable_workspaces("main",7,0).unwrap();assert_eq!(c.generation,8);let preparation=c.host.preparation_revision;let accepted=c.host.prepared.as_ref().unwrap().document.clone();
+        assert!(c.enable_workspaces("main",7,0).unwrap_err().contains("observed 40, limit 32"));assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.generation,7);assert_eq!(c.draft_revision,0);assert_eq!(c.host.prepared.as_ref().unwrap().saved.score,original.saved.score);
+        let mut quiet=original.saved.score.clone();for t in &mut quiet.legacy_mut().unwrap().tracks{t.notes.clear();t.automation.clear();}c.host.install(prepare(&original.saved.with_score(quiet),&original.origin).unwrap()).unwrap();
+        c.enable_workspaces("main",7,0).unwrap();assert_eq!(c.generation,8);let preparation=c.host.preparation_revision;let accepted=c.host.prepared.as_ref().unwrap().saved.score.clone();
         let Document::WorkspacesV4(project)=&accepted else{panic!()};
-        for (track,old) in project.tracks.iter().zip(&original.document.legacy().unwrap().tracks){let source=track.slots[0].as_ref().unwrap().source_id.clone();
+        for (track,old) in project.tracks.iter().zip(&original.saved.score.legacy().unwrap().tracks){let source=track.slots[0].as_ref().unwrap().source_id.clone();
             for n in &old.notes{c.workspace_edit("main",workspaces::WorkspaceEditV4::NoteCreate{source_id:source.clone(),beat:n.beat,duration:n.duration,pitch:n.pitch,velocity:n.velocity},8,c.draft_revision).unwrap();}
             c.workspace_edit("main",workspaces::WorkspaceEditV4::AutomationSet{source_id:source,lanes:old.automation.clone()},8,c.draft_revision).unwrap();
         }
-        let draft=c.draft.clone();let revision=c.draft_revision;let ids=c.history.identities();assert!(c.apply_draft().unwrap_err().contains("observed 40, limit 32"));assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.host.prepared.as_ref().unwrap().document,accepted);assert_eq!(c.draft,draft);assert_eq!(c.draft_revision,revision);assert_eq!(c.history.identities(),ids);assert!(c.history.view().can_undo);
+        let draft=c.draft.clone();let revision=c.draft_revision;let ids=c.history.identities();assert!(c.apply_draft().unwrap_err().contains("observed 40, limit 32"));assert_eq!(c.host.preparation_revision,preparation);assert_eq!(c.host.prepared.as_ref().unwrap().saved.score,accepted);assert_eq!(c.draft,draft);assert_eq!(c.draft_revision,revision);assert_eq!(c.history.identities(),ids);assert!(c.history.view().can_undo);
     }
 
 }
diff --git a/apps/ultra/src-tauri/src/session/history.rs b/apps/ultra/src-tauri/src/session/history.rs
index fdb0a72..0dae814 100644
--- a/apps/ultra/src-tauri/src/session/history.rs
+++ b/apps/ultra/src-tauri/src/session/history.rs
@@ -81,7 +81,7 @@ impl History {
 mod tests {
     use super::*;
     fn score() -> crate::session::Session {
-        crate::session::read(&std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().document
+        crate::session::read(&std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")).unwrap().saved.score
     }
     #[test]
     fn musical_history_is_bounded_and_redo_is_transactional() {
diff --git a/apps/ultra/src-tauri/src/session/host.rs b/apps/ultra/src-tauri/src/session/host.rs
index d5ff6fb..475b688 100644
--- a/apps/ultra/src-tauri/src/session/host.rs
+++ b/apps/ultra/src-tauri/src/session/host.rs
@@ -10,6 +10,11 @@ pub struct Host {
     owned_roots: [bool; 16],
     pub preparation_revision: u64,
 }
+pub(super) struct InstallFailure { pub message:String, pub rollback_serial:Option<u64> }
+#[cfg(test)]
+thread_local! { static TEST_FAIL_AFTER_RESET:std::cell::Cell<u32> = const { std::cell::Cell::new(0) }; }
+#[cfg(test)]
+pub(super) fn test_fail_after_reset(count:u32) { TEST_FAIL_AFTER_RESET.with(|remaining|remaining.set(count)); }
 #[derive(Serialize)]
 #[serde(rename_all = "camelCase")]
 pub struct View<'a> {
@@ -18,8 +23,15 @@ pub struct View<'a> {
     pub devices: Vec<&'a crate::canvas::device::HostManifest>,
 }
 impl Host {
+    pub(super) fn preflight_master(prepared: &PreparedSession) -> Result<(), String> {
+        Self::preflight_master_with_capability(prepared,native::master_capability().is_some())
+    }
+    pub(super) fn preflight_master_with_capability(prepared: &PreparedSession,available:bool) -> Result<(), String> {
+        prepared.saved.validate_master()?;
+        if !available && prepared.saved.master.gain != 1. { Err("Master gain is unavailable until native Master support is installed".into()) } else { Ok(()) }
+    }
     pub(super) fn configuration_workspaces(&self, prepared:&PreparedSession)->Result<(Box<native::ConfigV4>,Vec<crate::canvas::NativeGraph>),String> {
-        let (Document::WorkspacesV4(project),Schedule::Workspaces(workspace))=(&prepared.document,&prepared.schedule) else{return Err("Workspace document and schedule disagree".into())};
+        let (Document::WorkspacesV4(project),Schedule::Workspaces(workspace))=(&prepared.saved.score,&prepared.schedule) else{return Err("Workspace document and schedule disagree".into())};
         let (common,graphs)=self.configuration_common(prepared)?;
         let mut config=Box::<native::ConfigV4>::default();
         config.profile=native::V4_PROFILE_2X4;config.work_policy=native::V4_WORK_POLICY_1;
@@ -43,7 +55,7 @@ impl Host {
         Ok((config,graphs))
     }
     pub(super) fn check_schedule(prepared:&PreparedSession)->Result<(),String>{
-        match (&prepared.document,&prepared.schedule){(Document::LegacyV2(_),Schedule::Legacy)|(Document::ClipsV3(_),Schedule::Clips(_))|(Document::WorkspacesV4(_),Schedule::Workspaces(_))=>Ok(()),_=>Err("Document and prepared schedule disagree".into())}
+        match (&prepared.saved.score,&prepared.schedule){(Document::LegacyV2(_),Schedule::Legacy)|(Document::ClipsV3(_),Schedule::Clips(_))|(Document::WorkspacesV4(_),Schedule::Workspaces(_))=>Ok(()),_=>Err("Document and prepared schedule disagree".into())}
     }
     fn configuration_v3(&self,prepared:&PreparedSession)->Result<(Box<native::ConfigV3>,Vec<crate::canvas::NativeGraph>),String> {
         let profile=if prepared.tracks.len()<=2&&prepared.devices.len()<=6{native::V3_PROFILE_2X4}else{native::V3_PROFILE_8X4};
@@ -51,11 +63,11 @@ impl Host {
         if prepared.tracks.len()>limits.max_tracks as usize||prepared.devices.len()>limits.max_devices as usize{return Err("Prepared session exceeds its admitted native clip profile".into());}
         let (mut config,graphs)=self.configuration_common(prepared)?;
         config.profile=limits.profile;config.work_policy=limits.work_policy;config.preparation_revision=self.preparation_revision.checked_add(1).ok_or("Native preparation revision exhausted")?;
-        config.tempo_bpm=prepared.document.tempo();
+        config.tempo_bpm=prepared.saved.score.tempo();
         let Schedule::Clips(clips)=&prepared.schedule else{return Err("Not a clip bank".into())};config.clip_count=clips.len() as u32;
-        for (i,track) in prepared.document.tracks().into_iter().enumerate(){
+        for (i,track) in prepared.saved.score.tracks().into_iter().enumerate(){
             config.tracks[i].slots=[native::V3_NONE;4];config.tracks[i].initial_clip=native::V3_NONE;
-            let default=&prepared.document.bank(&track.id()).unwrap().default_clip_id;
+            let default=&prepared.saved.score.bank(&track.id()).unwrap().default_clip_id;
             for (index,clip) in clips.iter().enumerate().filter(|(_,c)|c.track==i){config.tracks[i].slots[clip.slot]=index as u32;if default.as_ref()==Some(&clip.id){config.tracks[i].initial_clip=index as u32;}}
         }
         for (index,clip) in clips.iter().enumerate(){config.clips[index]=native::ClipV3{track:clip.track as u32,event_begin:clip.event_begin as u32,event_count:clip.event_count as u32,lane_count:clip.lane_count,length_frames:clip.length_frames,owned_masks:clip.owned_masks};}
@@ -64,13 +76,13 @@ impl Host {
     /// Only a playable legacy candidate may fall back after stricter clip admission.
     pub fn enable_clips(&self,mut prepared:PreparedSession)->Result<PreparedSession,String> {
         self.validate(&prepared)?;
-        if prepared.document.is_clips()||prepared.document.is_workspaces(){return Ok(prepared);}
-        let attempt=(||{let mut candidate=prepared.clone();candidate.document=prepared.document.to_clips()?;let document=candidate.document.clone();prepare::compile_clips(&document,&mut candidate)?;self.admit(&candidate).map_err(|e|format!("{} (native reason {})",e.message,e.code))?;Ok::<_,String>(candidate)})();
-        match attempt {Ok(mut candidate)=>{candidate.notice=Some("Upgraded in memory; Save writes session v3".into());Ok(candidate)},Err(reason)=>{prepared.notice=Some(format!("Legacy session - clip-bank conversion unavailable: {reason}"));Ok(prepared)}}
+        if prepared.saved.score.is_clips()||prepared.saved.score.is_workspaces(){return Ok(prepared);}
+        let attempt=(||{let mut candidate=prepared.clone();candidate.saved.score=prepared.saved.score.to_clips()?;let document=candidate.saved.score.clone();prepare::compile_clips(&document,&mut candidate)?;self.admit(&candidate).map_err(|e|format!("{} (native reason {})",e.message,e.code))?;Ok::<_,String>(candidate)})();
+        match attempt {Ok(mut candidate)=>{candidate.notice=Some(match candidate.saved.wire {SaveWire::LegacyScore=>"Upgraded in memory; Save writes session v3",SaveWire::V5=>"Upgraded in memory; Save writes session v5 with a v3 score"}.into());Ok(candidate)},Err(reason)=>{prepared.notice=Some(format!("Legacy session - clip-bank conversion unavailable: {reason}"));Ok(prepared)}}
     }
     pub fn view(&self) -> Result<View<'_>, String> {
         let p = self.prepared.as_ref().ok_or("Create or open an Alive session")?;
-        Ok(View { document: &p.document, path: &p.origin, devices: if p.document.is_workspaces(){vec![]}else{p.tracks.iter().map(|t| Ok(&p.devices[t.midi_instrument()?].manifest)).collect::<Result<_,String>>()?} })
+        Ok(View { document: &p.saved.score, path: &p.origin, devices: if p.saved.score.is_workspaces(){vec![]}else{p.tracks.iter().map(|t| Ok(&p.devices[t.midi_instrument()?].manifest)).collect::<Result<_,String>>()?} })
     }
     fn configuration(&self, prepared: &PreparedSession) -> Result<(Box<native::ConfigV2>, Vec<crate::canvas::NativeGraph>),String> {
         let (common,graphs)=self.configuration_common(prepared)?;
@@ -86,11 +98,11 @@ impl Host {
         config.track_count = prepared.tracks.len() as u32;
         config.device_count = prepared.devices.len() as u32;
         config.event_count = prepared.events.len() as u32;
-        config.loop_enabled = prepared.document.loop_enabled() as u32;
+        config.loop_enabled = prepared.saved.score.loop_enabled() as u32;
         config.length_frames = prepared.length_frames;
         let mut graphs = Vec::with_capacity(prepared.devices.len());
         for (index, device) in prepared.devices.iter().enumerate() {
-            let model = &prepared.document.tracks()[device.track];
+            let model = &prepared.saved.score.tracks()[device.track];
             let reference = model.devices().find(|d| d.instance_id == device.instance_id).unwrap();
             let mut graph = device.graph.clone();
             graph.revision = self.revisions[index] + 1;
@@ -103,14 +115,14 @@ impl Host {
                 parameter_count: device.manifest.parameters.len() as u32, revision: graph.revision, bypassed: reference.bypassed as u32, ..Default::default() };
             for (slot, parameter) in device.manifest.parameters.iter().enumerate() {
                 native.parameters[slot] = native::Parameter { node: parameter.node, param: parameter.slot,
-                    automated: match &prepared.schedule {Schedule::Legacy=>match &prepared.document {Document::LegacyV2(s)=>s.tracks[device.track].automation.iter().any(|lane| lane.instance_id == device.instance_id && lane.key == parameter.key && lane.enabled),_=>false},Schedule::Clips(clips)=>clips.iter().any(|c|c.owned_masks[index]&(1<<slot)!=0),Schedule::Workspaces(w)=>w.sources.iter().any(|s|s.descriptor.owned_masks[index]&(1<<slot)!=0)} as u32,
+                    automated: match &prepared.schedule {Schedule::Legacy=>match &prepared.saved.score {Document::LegacyV2(s)=>s.tracks[device.track].automation.iter().any(|lane| lane.instance_id == device.instance_id && lane.key == parameter.key && lane.enabled),_=>false},Schedule::Clips(clips)=>clips.iter().any(|c|c.owned_masks[index]&(1<<slot)!=0),Schedule::Workspaces(w)=>w.sources.iter().any(|s|s.descriptor.owned_masks[index]&(1<<slot)!=0)} as u32,
                     base: parameter.base, minimum: parameter.min, maximum: parameter.max, reserved: 0 };
             }
             config.devices[index] = native;
             graphs.push(graph);
         }
         for (index, track) in prepared.tracks.iter().enumerate() {
-            let model = &prepared.document.tracks()[index];
+            let model = &prepared.saved.score.tracks()[index];
             let mut native = native::TrackV2 { instrument: track.midi_instrument()? as u32, effect_count: track.effects.len() as u32,
                 gain: model.mixer().0, mute: model.mixer().1 as u32, solo: model.mixer().2 as u32, ..Default::default() };
             for (slot, &device) in track.effects.iter().enumerate() { native.effects[slot] = device as u32; }
@@ -146,7 +158,7 @@ impl Host {
         for (index, graph) in graphs.iter().enumerate() {
             if unsafe { native::alive_session_validate_device_v2(&config.devices[index], graph) } == 0 {
                 let device = &prepared.devices[index];
-                let track = &prepared.document.tracks()[device.track];
+                let track = &prepared.saved.score.tracks()[device.track];
                 return Err(AdmissionError{code:native::V3_GRAPH_REJECTED,message:format!("Track '{}' instance '{}' ({}): {}", track.name(), device.instance_id, device.path.display(), native::error())});
             }
         }
@@ -158,21 +170,39 @@ impl Host {
     /// Caller must witness both CPAL closures destroyed through Driver::stop.
     /// A failed open, stream=None, or musical Stop alone is insufficient.
     /// Headless probes have no CPAL closures and stop their renderer synchronously.
-    pub fn install(&mut self, prepared: PreparedSession) -> Result<(), String> {
+    pub fn install(&mut self, prepared: PreparedSession) -> Result<u64, String> {
+        Self::preflight_master(&prepared)?;
         self.validate(&prepared)?;
+        let serials=if native::master_capability().is_some(){Some(super::native_master::reserve_pair().ok_or("Master serial exhausted")?)}else{None};
+        self.install_reserved(prepared,serials).map_err(|failure|failure.message)?;
+        Ok(serials.map_or(0,|s|s.0))
+    }
+    pub(super) fn install_reserved(&mut self,prepared:PreparedSession,serials:Option<(u64,u64)>)->Result<(),InstallFailure> {
         unsafe { native::ultra_audio_stop(); }
-        if let Err(error) = self.apply(&prepared) {
+        let mut replaced=false;
+        let result=self.apply(&prepared,&mut replaced).and_then(|()|Self::initialize_master(prepared.saved.master.gain,serials.map(|s|s.0)));
+        if let Err(error) = result {
+            if !replaced{return Err(InstallFailure{message:format!("Session apply failed; prior session retained: {error}"),rollback_serial:None});}
             if let Some(previous) = self.prepared.clone() {
-                if let Err(rollback) = self.apply(&previous) {
-                    return Err(format!("Session apply failed: {error}; prior session remains saved in memory but audio restoration failed: {rollback}"));
+                let mut rollback_replaced=false;
+                if let Err(rollback) = self.apply(&previous,&mut rollback_replaced).and_then(|()|Self::initialize_master(previous.saved.master.gain,serials.map(|s|s.1))) {
+                    return Err(InstallFailure{message:format!("Session apply failed: {error}; prior session remains saved in memory but audio restoration failed: {rollback}"),rollback_serial:None});
                 }
+                return Err(InstallFailure{message:format!("Session apply failed; prior session retained: {error}"),rollback_serial:serials.map(|s|s.1)});
             }
-            return Err(format!("Session apply failed; prior session retained: {error}"));
+            return Err(InstallFailure{message:format!("Session apply failed; prior session retained: {error}"),rollback_serial:None});
         }
         self.prepared = Some(prepared);
         Ok(())
     }
-    fn apply(&mut self, prepared: &PreparedSession) -> Result<(), String> {
+    fn initialize_master(gain:f64,serial:Option<u64>)->Result<(),String>{
+        if let Some(serial)=serial {
+            let capability=native::master_capability().ok_or("Native Master support is unavailable")?;
+            if unsafe{(capability.set)(1,gain,serial)}!=1{return Err("Native Master initialization failed".into());}
+        }
+        Ok(())
+    }
+    fn apply(&mut self, prepared: &PreparedSession, replaced:&mut bool) -> Result<(), String> {
         if self.revisions.iter().any(|r|*r==u64::MAX)||self.preparation_revision==u64::MAX{return Err("Native revision exhausted".into());}
         Self::check_schedule(prepared)?;
         let (legacy,clips,workspaces,graphs)=match &prepared.schedule {
@@ -183,6 +213,9 @@ impl Host {
         self.preparation_revision=self.preparation_revision.checked_add(1).ok_or("Native preparation revision exhausted")?;
         unsafe {
             if native::alive_session_reset() == 0 { return Err("Stop device I/O before applying a session".into()); }
+            *replaced=true;
+            #[cfg(test)]
+            if TEST_FAIL_AFTER_RESET.with(|remaining|{let count=remaining.get();if count>0{remaining.set(count-1);true}else{false}}){return Err("Injected failure after native reset".into());}
             for slot in 0..16 {
                 if self.owned_roots[slot] {
                     if crate::ultra_canvas_close_document(slot as u32) == 0 { return Err(format!("Native root {slot} could not be closed")); }
@@ -208,7 +241,7 @@ impl Host {
         prepare::binding_value(parameter, value)?;
         if unsafe { native::alive_session_base_v2(index as u32, self.revisions[index], slot as u32, value) } == 0 { return Err(native::error()); }
         parameter.base = value;
-        prepared.document.device_mut(instance_id)?.parameters.insert(key.into(), value);
+        prepared.saved.score.device_mut(instance_id)?.parameters.insert(key.into(), value);
         prepare::edit_parameter(&mut device.patch, parameter.node, &parameter.param, value);
         // Keep the prepared snapshot ready for rollback without recompiling on a knob edit.
         let node = device.graph.nodes.iter_mut().find(|node| node.id == parameter.node).unwrap();
@@ -221,12 +254,12 @@ impl Host {
         let index = prepared.devices.iter().position(|d| d.instance_id == instance_id).ok_or("Unknown instance")?;
         if prepared.devices[index].manifest.kind != crate::canvas::device::DeviceKind::AudioEffect { return Err("Only effects can be bypassed".into()); }
         if unsafe { native::alive_session_bypass_v2(index as u32, self.revisions[index], bypassed as u32) } == 0 { return Err(native::error()); }
-        prepared.document.device_mut(instance_id)?.bypassed = bypassed;
+        prepared.saved.score.device_mut(instance_id)?.bypassed = bypassed;
         Ok(())
     }
     pub fn mixer(&mut self, track: usize, gain: f64, mute: bool, solo: bool) -> Result<(), String> {
         if !gain.is_finite() || !(0. ..=2.).contains(&gain) { return Err("Track gain must be 0..2".into()); }
-        let document=&mut self.prepared.as_mut().ok_or("No session")?.document;
+        let document=&mut self.prepared.as_mut().ok_or("No session")?.saved.score;
         let id=document.tracks().get(track).ok_or("Unknown track")?.id().to_owned();
         if unsafe { native::alive_session_mixer(track as u32, gain, mute as u32, solo as u32) } == 0 { return Err(native::error()); }
         document.set_mixer(&id,gain,mute,solo)?;
@@ -249,7 +282,7 @@ fn diagnostic(prepared:&PreparedSession)->AdmissionError {
     if unsafe{native::alive_session_diagnostic_v3(&mut d)}==0{return AdmissionError{code:native::V3_BAD_FIELD,message:native_message};}
     if d.error==native::V3_GRAPH_REJECTED{return AdmissionError{code:d.error,message:format!("V3 graph policy restriction: {native_message}. The source may remain valid for legacy playback")};}
     let resource=match d.resource{native::V3_RESOURCE_EVENTS=>"events",native::V3_RESOURCE_ROOT_CLEARS=>"root clears",native::V3_RESOURCE_EVENT_SCANS=>"event scans",native::V3_RESOURCE_PARAMETER_WRITES=>"parameter writes",native::V3_RESOURCE_GUARD_STEPS=>"guard steps",_=>"native admission"};
-    let contributors=prepared.document.tracks().into_iter().enumerate().filter(|(i,_)|d.track_mask&(1<<i)!=0).map(|(i,t)|{let clips=match &prepared.schedule {Schedule::Clips(clips)=>clips.iter().enumerate().filter(|(n,c)|c.track==i&&(d.clip[i]==native::V3_NONE||*n==d.clip[i] as usize)).map(|(_,c)|c.name.as_str()).collect::<Vec<_>>().join(", "),_=>String::new()};format!("{} [{}]: {}{}",t.name(),clips,if d.contribution[i]==u32::MAX{"at least "}else{""},d.contribution[i])}).collect::<Vec<_>>().join("; ");
+    let contributors=prepared.saved.score.tracks().into_iter().enumerate().filter(|(i,_)|d.track_mask&(1<<i)!=0).map(|(i,t)|{let clips=match &prepared.schedule {Schedule::Clips(clips)=>clips.iter().enumerate().filter(|(n,c)|c.track==i&&(d.clip[i]==native::V3_NONE||*n==d.clip[i] as usize)).map(|(_,c)|c.name.as_str()).collect::<Vec<_>>().join(", "),_=>String::new()};format!("{} [{}]: {}{}",t.name(),clips,if d.contribution[i]==u32::MAX{"at least "}else{""},d.contribution[i])}).collect::<Vec<_>>().join("; ");
     let envelope=d.conservative!=0||d.frame==native::V3_NO_FRAME||d.clip.iter().enumerate().any(|(i,c)|d.track_mask&(1<<i)!=0&&*c==native::V3_NONE);
     AdmissionError{code:d.error,message:format!("{} exceeds {resource}: {}{} / {}. {contributors}. {native_message}. Use fewer simultaneous notes/points, longer very short loops, or simpler chains",if envelope{"Conservative combination envelope"}else{"Prepared bank"},if d.observed==u64::MAX{"at least "}else{""},d.observed,d.limit)}
 }
diff --git a/apps/ultra/src-tauri/src/session/master.rs b/apps/ultra/src-tauri/src/session/master.rs
new file mode 100644
index 0000000..3039772
--- /dev/null
+++ b/apps/ultra/src-tauri/src/session/master.rs
@@ -0,0 +1,22 @@
+use super::Document;
+
+#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
+#[serde(deny_unknown_fields)]
+pub struct MasterSettings { pub gain: f64 }
+
+#[derive(Clone, Copy, Debug, PartialEq, Eq)]
+pub enum SaveWire { LegacyScore, V5 }
+
+#[derive(Clone, Debug, PartialEq)]
+pub struct SavedSession { pub score: Document, pub master: MasterSettings, pub wire: SaveWire }
+
+impl SavedSession {
+    pub fn with_score(&self, score: Document) -> Self {
+        let mut saved = self.clone();
+        saved.score = score;
+        saved
+    }
+    pub fn validate_master(&self) -> Result<(), String> {
+        super::prepare::bounded(self.master.gain, 0., 4., "Master gain")
+    }
+}
diff --git a/apps/ultra/src-tauri/src/session/mod.rs b/apps/ultra/src-tauri/src/session/mod.rs
index 5c39976..4abf1b3 100644
--- a/apps/ultra/src-tauri/src/session/mod.rs
+++ b/apps/ultra/src-tauri/src/session/mod.rs
@@ -2,6 +2,8 @@
 use serde::{Deserialize, Serialize};
 use std::collections::BTreeMap;
 mod prepare;
+mod master;
+pub use master::{MasterSettings, SaveWire, SavedSession};
 pub use prepare::{prepare, PreparedSession, Schedule};
 mod persistence;
 mod history;
@@ -16,6 +18,7 @@ pub use clips::{Document, ClipBank};
 pub type Session = Document;
 pub use persistence::{read, save};
 pub mod native;
+mod native_master;
 pub mod host;
 pub mod probe;
 pub mod desktop;
diff --git a/apps/ultra/src-tauri/src/session/native.rs b/apps/ultra/src-tauri/src/session/native.rs
index 940bdbb..4ea501d 100644
--- a/apps/ultra/src-tauri/src/session/native.rs
+++ b/apps/ultra/src-tauri/src/session/native.rs
@@ -4,6 +4,44 @@ use crate::canvas::NativeGraph;
 use serde::Serialize;
 use std::ffi::{c_char, CStr};
 
+#[cfg(not(all(test, target_os="windows")))]
+pub(super) fn master_capability() -> Option<&'static super::native_master::Capability> {
+    static CAPABILITY: std::sync::OnceLock<Option<super::native_master::Capability>> = std::sync::OnceLock::new();
+    CAPABILITY.get_or_init(|| super::native_master::resolve(alive_session_state_v2 as *const () as *const std::ffi::c_void)).as_ref()
+}
+
+#[cfg(all(test, target_os="windows"))]
+pub(super) fn master_capability() -> Option<&'static super::native_master::Capability> {
+    static CAPABILITY: std::sync::OnceLock<Option<super::native_master::Capability>> = std::sync::OnceLock::new();
+    #[cfg(all(test, target_os="windows"))]
+    if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+        println!("cache: before={:?} thread={:?}",CAPABILITY.get().map(|value| value.is_some()),std::thread::current().id());
+    }
+    let result=CAPABILITY.get_or_init(|| {
+        let anchor=alive_session_state_v2 as *const () as *const std::ffi::c_void;
+        #[cfg(all(test, target_os="windows"))]
+        if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+            println!("cache: initializer_enter anchor={anchor:p} thread={:?}",std::thread::current().id());
+        }
+        let resolved=super::native_master::resolve(anchor);
+        #[cfg(all(test, target_os="windows"))]
+        if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+            println!("cache: initializer_result={}",resolved.is_some());
+        }
+        resolved
+    }).as_ref();
+    #[cfg(all(test, target_os="windows"))]
+    if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+        println!("cache: return={}",result.is_some());
+    }
+    result
+}
+
+#[cfg(all(test, target_os="windows"))]
+pub(super) fn master_test_anchor() -> *const std::ffi::c_void {
+    alive_session_state_v2 as *const () as *const std::ffi::c_void
+}
+
 #[repr(C)]
 #[derive(Clone, Copy, Default)]
 pub struct Parameter {
@@ -129,6 +167,10 @@ extern "C" {
     pub fn alive_session_configure_v2(config: *const ConfigV2) -> i32;
     pub fn alive_session_base_v2(document: u32, revision: u64, parameter: u32, value: f64) -> i32;
     pub fn alive_session_bypass_v2(document: u32, revision: u64, bypassed: u32) -> i32;
+}
+// The resolver needs the address of the linked DLL export on Windows.
+#[cfg_attr(target_os="windows", link(name="ultra_native"))]
+extern "C" {
     pub fn alive_session_state_v2(state: *mut StateV2) -> i32;
 }
 
diff --git a/apps/ultra/src-tauri/src/session/native_master.rs b/apps/ultra/src-tauri/src/session/native_master.rs
new file mode 100644
index 0000000..58a2aa1
--- /dev/null
+++ b/apps/ultra/src-tauri/src/session/native_master.rs
@@ -0,0 +1,274 @@
+//! Optional Master symbols are resolved from the image containing the linked anchor.
+use std::ffi::{c_char, c_int, c_void};
+
+#[repr(C)]
+#[derive(Clone, Copy, Default)]
+pub struct Limits { pub version:u32, pub struct_bytes:u32, pub features:u32, pub ramp_frames:u32, pub max_gain:f64 }
+#[repr(C)]
+#[derive(Clone, Copy, Default, Debug)]
+pub struct State { pub version:u32, pub struct_bytes:u32, pub clip_mask:u32, pub reserved:u32, pub target_gain:f64, pub current_gain:f64, pub peak_left:f64, pub peak_right:f64, pub applied_serial:u64, pub applied_frame:u64, pub observation_start_frame:u64, pub observation_end_frame:u64 }
+impl State { pub fn output()->Self { Self { version:1, struct_bytes:std::mem::size_of::<Self>() as u32, ..Self::default() } } }
+const _: () = { use std::mem::{size_of,align_of,offset_of};
+    assert!(size_of::<Limits>()==24 && align_of::<Limits>()==8);
+    assert!(offset_of!(Limits,version)==0 && offset_of!(Limits,struct_bytes)==4 && offset_of!(Limits,features)==8 && offset_of!(Limits,ramp_frames)==12 && offset_of!(Limits,max_gain)==16);
+    assert!(size_of::<State>()==80 && align_of::<State>()==8);
+    assert!(offset_of!(State,version)==0 && offset_of!(State,struct_bytes)==4 && offset_of!(State,clip_mask)==8 && offset_of!(State,reserved)==12 && offset_of!(State,target_gain)==16 && offset_of!(State,current_gain)==24 && offset_of!(State,peak_left)==32 && offset_of!(State,peak_right)==40 && offset_of!(State,applied_serial)==48 && offset_of!(State,applied_frame)==56 && offset_of!(State,observation_start_frame)==64 && offset_of!(State,observation_end_frame)==72);
+};
+pub type Set = unsafe extern "C" fn(u32,f64,u64)->c_int;
+pub type Reset = unsafe extern "C" fn(u32,u64)->c_int;
+pub type Snapshot = unsafe extern "C" fn(*mut c_void,*mut State)->c_int;
+type GetLimits = unsafe extern "C" fn(*mut Limits)->c_int;
+
+pub struct Capability { _module: platform::Module, pub set:Set, pub reset:Reset, pub snapshot_v2:Snapshot, pub snapshot_v3:Snapshot, pub snapshot_v4:Snapshot }
+#[derive(Default)]
+pub struct Serials(pub u64);
+impl Serials {
+    pub fn reserve_pair(&mut self)->Option<(u64,u64)> { let last=self.0.checked_add(2)?;self.0=last;Some((last-1,last)) }
+    pub fn next(&mut self)->Option<u64> { let next=self.0.checked_add(1)?;self.0=next;Some(next) }
+}
+static SERIALS: std::sync::Mutex<Serials> = std::sync::Mutex::new(Serials(0));
+pub fn reserve_pair()->Option<(u64,u64)> { SERIALS.lock().ok()?.reserve_pair() }
+pub fn next_serial()->Option<u64> { SERIALS.lock().ok()?.next() }
+#[cfg(test)]
+pub fn current_serial()->u64 { SERIALS.lock().unwrap().0 }
+#[cfg(test)]
+pub fn set_serial_for_test(value:u64) { SERIALS.lock().unwrap().0=value; }
+#[cfg(test)]
+pub fn fresh_process(test_name:&str)->bool {
+    if std::env::var_os("ALIVE_MASTER_TEST_CHILD").is_some(){return false;}
+    let output=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",test_name,"--nocapture"])
+        .env("ALIVE_MASTER_TEST_CHILD","1").output().unwrap();
+    assert!(output.status.success(),"native fixture failed:\n{}\n{}",String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));
+    true
+}
+
+#[cfg(all(test, target_os="windows"))]
+macro_rules! diagnostic {
+    ($($arg:tt)*) => {
+        #[cfg(all(test, target_os="windows"))]
+        if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+            println!($($arg)*);
+        }
+    };
+}
+
+#[cfg(not(all(test, target_os="windows")))]
+pub fn resolve(anchor: *const c_void) -> Option<Capability> {
+    unsafe {
+        let module=platform::Module::from_anchor(anchor)?;
+        let mut symbols=[std::ptr::null_mut();6];
+        let names:[&[u8];6]=[b"alive_session_master_limits\0",b"alive_session_master_set\0",b"alive_session_master_reset_clip\0",b"alive_session_master_snapshot_v2\0",b"alive_session_master_snapshot_v3\0",b"alive_session_master_snapshot_v4\0"];
+        for (slot,name) in symbols.iter_mut().zip(names) { *slot=module.symbol(name)?; }
+        let limits:GetLimits=std::mem::transmute(symbols[0]);
+        let mut info=Limits {version:1,struct_bytes:std::mem::size_of::<Limits>() as u32,..Limits::default()};
+        if limits(&mut info)!=1 || info.version!=1 || info.struct_bytes!=std::mem::size_of::<Limits>() as u32 || info.features!=7 || info.ramp_frames!=64 || info.max_gain!=4. { return None; }
+        Some(Capability {_module:module,set:std::mem::transmute(symbols[1]),reset:std::mem::transmute(symbols[2]),snapshot_v2:std::mem::transmute(symbols[3]),snapshot_v3:std::mem::transmute(symbols[4]),snapshot_v4:std::mem::transmute(symbols[5])})
+    }
+}
+
+#[cfg(all(test, target_os="windows"))]
+pub fn resolve(anchor: *const c_void) -> Option<Capability> {
+    unsafe {
+        diagnostic!("resolve: enter anchor={anchor:p} thread={:?}",std::thread::current().id());
+        let module=match platform::Module::from_anchor(anchor) { Some(module)=>module, None=>{diagnostic!("resolve: stage=anchor_module_or_export result=false");return None;} };
+        let mut symbols=[std::ptr::null_mut();6];
+        let names:[&[u8];6]=[b"alive_session_master_limits\0",b"alive_session_master_set\0",b"alive_session_master_reset_clip\0",b"alive_session_master_snapshot_v2\0",b"alive_session_master_snapshot_v3\0",b"alive_session_master_snapshot_v4\0"];
+        for (slot,name) in symbols.iter_mut().zip(names) {
+            *slot=match module.symbol(name) { Some(value)=>value, None=>{diagnostic!("resolve: stage=symbol name={} result=false",String::from_utf8_lossy(&name[..name.len()-1]));return None;} };
+        }
+        let limits:GetLimits=std::mem::transmute(symbols[0]);
+        let mut info=Limits {version:1,struct_bytes:std::mem::size_of::<Limits>() as u32,..Limits::default()};
+        let status=limits(&mut info);
+        diagnostic!("resolve: limits result={status} version={} bytes={} features={} ramp={} max_gain={}",info.version,info.struct_bytes,info.features,info.ramp_frames,info.max_gain);
+        if status!=1 || info.version!=1 || info.struct_bytes!=std::mem::size_of::<Limits>() as u32 || info.features!=7 || info.ramp_frames!=64 || info.max_gain!=4. { diagnostic!("resolve: stage=limits result=false");return None; }
+        diagnostic!("resolve: stage=ok result=true");
+        Some(Capability {_module:module,set:std::mem::transmute(symbols[1]),reset:std::mem::transmute(symbols[2]),snapshot_v2:std::mem::transmute(symbols[3]),snapshot_v3:std::mem::transmute(symbols[4]),snapshot_v4:std::mem::transmute(symbols[5])})
+    }
+}
+
+#[cfg(any(target_os="linux",target_os="macos"))]
+mod platform {
+    use super::*;
+    #[repr(C)] struct DlInfo { name:*const c_char, base:*mut c_void, symbol:*const c_char, address:*mut c_void }
+    #[cfg_attr(target_os="linux",link(name="dl"))]
+    extern "C" { fn dladdr(address:*const c_void,info:*mut DlInfo)->c_int; fn dlopen(name:*const c_char,flags:c_int)->*mut c_void; fn dlsym(handle:*mut c_void,name:*const c_char)->*mut c_void; fn dlclose(handle:*mut c_void)->c_int; }
+    const NOW:c_int=2;
+    #[cfg(target_os="linux")] const NOLOAD:c_int=4;
+    #[cfg(target_os="macos")] const NOLOAD:c_int=0x10;
+    pub struct Module { handle:usize, base:usize }
+    impl Module {
+        pub unsafe fn from_anchor(anchor:*const c_void)->Option<Self> {
+            let mut info:DlInfo=std::mem::zeroed();
+            if anchor.is_null() || dladdr(anchor,&mut info)==0 || info.name.is_null() || info.base.is_null() {return None;}
+            let handle=dlopen(info.name,NOW|NOLOAD);
+            if handle.is_null(){return None;}
+            let module=Self{handle:handle as usize,base:info.base as usize};
+            if module.symbol(b"alive_session_state_v2\0")? != anchor.cast_mut(){return None;}
+            Some(module)
+        }
+        pub unsafe fn symbol(&self,name:&[u8])->Option<*mut c_void> {
+            let address=dlsym(self.handle as *mut c_void,name.as_ptr().cast());
+            let mut info:DlInfo=std::mem::zeroed();
+            if address.is_null() || dladdr(address,&mut info)==0 || info.base as usize!=self.base {None}else{Some(address)}
+        }
+    }
+    impl Drop for Module {fn drop(&mut self){unsafe{dlclose(self.handle as *mut c_void);}}}
+}
+
+#[cfg(target_os="windows")]
+mod platform {
+    use super::*;
+    #[link(name="kernel32")]
+    extern "system" {fn GetModuleHandleExW(flags:u32,name:*const u16,handle:*mut *mut c_void)->i32;fn GetProcAddress(handle:*mut c_void,name:*const c_char)->*mut c_void;fn FreeLibrary(handle:*mut c_void)->i32;}
+    #[cfg(test)]
+    #[link(name="kernel32")]
+    extern "system" {fn GetModuleFileNameW(handle:*mut c_void,path:*mut u16,size:u32)->u32;}
+    pub struct Module {handle:usize}
+    #[cfg(not(test))]
+    impl Module {
+        pub unsafe fn from_anchor(anchor:*const c_void)->Option<Self>{
+            let mut handle=std::ptr::null_mut();
+            if anchor.is_null() || GetModuleHandleExW(4,anchor.cast(),&mut handle)==0 || handle.is_null(){return None;}
+            let module=Self{handle:handle as usize};
+            if module.symbol(b"alive_session_state_v2\0")? != anchor.cast_mut(){return None;}Some(module)
+        }
+        pub unsafe fn symbol(&self,name:&[u8])->Option<*mut c_void>{
+            let address=GetProcAddress(self.handle as *mut c_void,name.as_ptr().cast());
+            if address.is_null(){return None;}
+            let mut owner=std::ptr::null_mut();
+            if GetModuleHandleExW(4,address.cast(),&mut owner)==0 || owner.is_null(){return None;}
+            let same=owner as usize==self.handle;FreeLibrary(owner);
+            if same{Some(address)}else{None}
+        }
+    }
+    #[cfg(test)]
+    impl Module {
+        pub unsafe fn from_anchor(anchor:*const c_void)->Option<Self>{
+            let mut handle=std::ptr::null_mut();
+            if anchor.is_null() {diagnostic!("anchor: stage=null");return None;}
+            let status=GetModuleHandleExW(4,anchor.cast(),&mut handle);
+            if status==0 {let error=std::io::Error::last_os_error();diagnostic!("anchor: stage=module_lookup error={error}");return None;}
+            if handle.is_null(){diagnostic!("anchor: stage=module_null");return None;}
+            #[cfg(test)]
+            if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_some() {
+                let mut path=[0u16;32768];let len=GetModuleFileNameW(handle,path.as_mut_ptr(),path.len() as u32) as usize;
+                println!("anchor: module={handle:p} path={:?}",if len>0 && len<path.len(){String::from_utf16_lossy(&path[..len])}else{format!("unavailable: {}",std::io::Error::last_os_error())});
+            }
+            let module=Self{handle:handle as usize};
+            let export=match module.symbol(b"alive_session_state_v2\0") {Some(value)=>value,None=>{diagnostic!("anchor: stage=export_lookup_or_owner");return None;}};
+            diagnostic!("anchor: export={export:p} equal={}",export==anchor.cast_mut());
+            if export != anchor.cast_mut(){diagnostic!("anchor: stage=mismatch");return None;}Some(module)
+        }
+        pub unsafe fn symbol(&self,name:&[u8])->Option<*mut c_void>{
+            let address=GetProcAddress(self.handle as *mut c_void,name.as_ptr().cast());
+            if address.is_null(){diagnostic!("symbol: name={} stage=missing",String::from_utf8_lossy(&name[..name.len()-1]));return None;}
+            let mut owner=std::ptr::null_mut();
+            let status=GetModuleHandleExW(4,address.cast(),&mut owner);
+            if status==0 {let error=std::io::Error::last_os_error();diagnostic!("symbol: name={} address={address:p} stage=owner_lookup error={error}",String::from_utf8_lossy(&name[..name.len()-1]));return None;}
+            if owner.is_null(){diagnostic!("symbol: name={} address={address:p} stage=owner_null",String::from_utf8_lossy(&name[..name.len()-1]));return None;}
+            let same=owner as usize==self.handle;
+            diagnostic!("symbol: name={} address={address:p} owner={owner:p} same={same}",String::from_utf8_lossy(&name[..name.len()-1]));
+            FreeLibrary(owner);
+            if same{Some(address)}else{None}
+        }
+    }
+    impl Drop for Module {fn drop(&mut self){unsafe{FreeLibrary(self.handle as *mut c_void);}}}
+}
+
+#[cfg(test)]
+mod tests {
+    use super::*;
+    #[link(name="ultra_native")]
+    #[allow(clashing_extern_declarations)]
+    extern "C" { fn alive_session_state_v2(state:*mut c_void) -> c_int; }
+    #[test]
+    fn resolves_the_loaded_native_image() {
+        let anchor = alive_session_state_v2 as *const () as *const c_void;
+        assert!(resolve(std::ptr::null()).is_none());
+        assert_eq!(resolve(anchor).is_some(),std::env::var_os("ALIVE_MASTER_EXPECT_UNAVAILABLE").is_none());
+    }
+    #[cfg(target_os="windows")]
+    #[test]
+    fn production_capability_fresh_process_diagnostics() {
+        const NAME:&str="session::native_master::tests::production_capability_fresh_process_diagnostics";
+        if std::env::var_os("ALIVE_MASTER_DIAGNOSTIC_CHILD").is_none() {
+            let output=std::process::Command::new(std::env::current_exe().unwrap())
+                .args(["--exact",NAME,"--nocapture"]).env("ALIVE_MASTER_DIAGNOSTIC_CHILD","1").output().unwrap();
+            print!("{}",String::from_utf8_lossy(&output.stdout));
+            eprint!("{}",String::from_utf8_lossy(&output.stderr));
+            assert!(output.status.success(),"diagnostic child failed: {}",output.status);
+            return;
+        }
+        let expected=std::env::var_os("ALIVE_MASTER_EXPECT_UNAVAILABLE").is_none();
+        let actual=super::super::native::master_capability().is_some();
+        assert_eq!(super::super::native::master_capability().is_some(),actual,"cached capability changed");
+        println!("production capability={actual} expected={expected}");
+        unsafe { windows_diagnostics("production",super::super::native::master_test_anchor()); }
+        unsafe { windows_diagnostics("direct",alive_session_state_v2 as *const () as *const c_void); }
+        assert_eq!(actual,expected);
+    }
+    #[cfg(target_os="windows")]
+    unsafe fn windows_diagnostics(label:&str, anchor:*const c_void) {
+        #[link(name="kernel32")]
+        extern "system" {
+            fn GetModuleHandleExW(flags:u32,name:*const u16,handle:*mut *mut c_void)->i32;
+            fn GetProcAddress(handle:*mut c_void,name:*const c_char)->*mut c_void;
+            fn GetModuleFileNameW(handle:*mut c_void,path:*mut u16,size:u32)->u32;
+            fn FreeLibrary(handle:*mut c_void)->i32;
+        }
+        println!("{label}: expectation_env={:?} anchor={anchor:p}",std::env::var_os("ALIVE_MASTER_EXPECT_UNAVAILABLE"));
+        let mut module=std::ptr::null_mut();
+        if anchor.is_null() {
+            println!("{label}: stage=anchor_module reason=null_anchor direct_resolve={}",resolve(anchor).is_some());return;
+        }
+        if GetModuleHandleExW(4,anchor.cast(),&mut module)==0 || module.is_null() {
+            let error=std::io::Error::last_os_error();
+            println!("{label}: stage=anchor_module error={error} direct_resolve={}",resolve(anchor).is_some());return;
+        }
+        let mut path=[0u16;32768];let len=GetModuleFileNameW(module,path.as_mut_ptr(),path.len() as u32) as usize;
+        println!("{label}: module={module:p} path={:?}",if len>0 && len<path.len(){String::from_utf16_lossy(&path[..len])}else{format!("unavailable: {}",std::io::Error::last_os_error())});
+        let anchor_export=GetProcAddress(module,b"alive_session_state_v2\0".as_ptr().cast());
+        println!("{label}: anchor_export={anchor_export:p}");
+        let mut stage="ok";
+        if anchor_export.is_null(){stage="anchor_export_missing";}
+        else {
+            let mut owner=std::ptr::null_mut();
+            if GetModuleHandleExW(4,anchor_export.cast(),&mut owner)==0 || owner.is_null(){stage="anchor_export_owner";}
+            else {if owner!=module {stage="anchor_export_other_module";} FreeLibrary(owner);}
+            if stage=="ok" && anchor_export!=anchor.cast_mut(){stage="anchor_mismatch";}
+        }
+        let names:[&[u8];6]=[b"alive_session_master_limits\0",b"alive_session_master_set\0",b"alive_session_master_reset_clip\0",b"alive_session_master_snapshot_v2\0",b"alive_session_master_snapshot_v3\0",b"alive_session_master_snapshot_v4\0"];
+        let mut limits_address=std::ptr::null_mut();
+        if stage=="ok" {
+            for (i,name) in names.iter().enumerate() {
+                let address=GetProcAddress(module,name.as_ptr().cast());
+                let mut owner=std::ptr::null_mut();
+                let owner_ok=!address.is_null() && GetModuleHandleExW(4,address.cast(),&mut owner)!=0 && !owner.is_null();
+                println!("{label}: symbol={} address={address:p} owner={owner:p}",String::from_utf8_lossy(&name[..name.len()-1]));
+                if address.is_null(){stage="symbol_missing";break;}
+                if !owner_ok {stage="symbol_owner";break;}
+                let same=owner==module;FreeLibrary(owner);
+                if !same {stage="symbol_other_module";break;}
+                if i==0 {limits_address=address;}
+            }
+        }
+        if stage=="ok" {
+            let limits:GetLimits=std::mem::transmute(limits_address);
+            let mut info=Limits{version:1,struct_bytes:std::mem::size_of::<Limits>() as u32,..Limits::default()};
+            let result=limits(&mut info);
+            println!("{label}: limits result={result} version={} bytes={} features={} ramp={} max_gain={}",info.version,info.struct_bytes,info.features,info.ramp_frames,info.max_gain);
+            if result!=1 || info.version!=1 || info.struct_bytes!=std::mem::size_of::<Limits>() as u32 || info.features!=7 || info.ramp_frames!=64 || info.max_gain!=4. {stage="limits";}
+        }
+        println!("{label}: stage={stage} direct_resolve={}",resolve(anchor).is_some());
+        FreeLibrary(module);
+    }
+    #[test]
+    fn reserves_a_pair_without_wrap_or_reuse() {
+        let mut serials=Serials(u64::MAX-2);
+        assert_eq!(serials.reserve_pair(),Some((u64::MAX-1,u64::MAX)));
+        assert_eq!(serials.next(),None);
+        let mut short=Serials(u64::MAX-1);
+        assert_eq!(short.reserve_pair(),None);
+        assert_eq!(short.0,u64::MAX-1);
+    }
+}
diff --git a/apps/ultra/src-tauri/src/session/persistence.rs b/apps/ultra/src-tauri/src/session/persistence.rs
index a84b152..b7cb2c2 100644
--- a/apps/ultra/src-tauri/src/session/persistence.rs
+++ b/apps/ultra/src-tauri/src/session/persistence.rs
@@ -7,14 +7,15 @@ pub fn read(path: &Path) -> Result<PreparedSession, String> {
     let path = fs::canonicalize(path).map_err(|e| format!("Cannot open session {}: {e}", path.display()))?;
     let file = fs::File::open(&path).map_err(|e| format!("Cannot read session: {e}"))?;
     if !file.metadata().map_err(|e| e.to_string())?.is_file() { return Err("Choose an Alive session file".into()); }
-    let mut text = String::new();
-    file.take(MAX_BYTES + 1).read_to_string(&mut text).map_err(|e| format!("Cannot read session as UTF-8: {e}"))?;
-    if text.len() as u64 > MAX_BYTES { return Err("Session exceeds the 1 MiB limit".into()); }
+    let mut bytes = Vec::new();
+    file.take(MAX_BYTES + 1).read_to_end(&mut bytes).map_err(|e| format!("Cannot read session: {e}"))?;
+    if bytes.len() as u64 > MAX_BYTES { return Err("Session exceeds the 1 MiB limit".into()); }
+    let text = String::from_utf8(bytes).map_err(|e| format!("Cannot read session as UTF-8: {e}"))?;
     let session = decode(&text, &path)?;
     prepare(&session, &path)
 }
-pub fn save(path: &Path, session: &Session, origin: &Path) -> Result<PathBuf, String> { save_document(path,session,origin).map(|(path,_)|path) }
-pub(super) fn save_document(path: &Path, session: &Session, origin: &Path) -> Result<(PathBuf,Session), String> {
+pub fn save(path: &Path, session: &SavedSession, origin: &Path) -> Result<PathBuf, String> { save_document(path,session,origin).map(|(path,_)|path) }
+pub(super) fn save_document(path: &Path, session: &SavedSession, origin: &Path) -> Result<(PathBuf,SavedSession), String> {
     let prepared = prepare(session, origin)?;
     let mut path = path.to_path_buf();
     if path.extension().is_none() { path.set_extension("alive"); }
@@ -28,14 +29,12 @@ pub(super) fn save_document(path: &Path, session: &Session, origin: &Path) -> Re
     // A session symlink may resolve to a different folder than the chosen name.
     let parent = path.parent().ok_or("Choose a session file name")?;
     if prepared.devices.iter().any(|device| device.path == path) { return Err("A session cannot replace its Ultra device file".into()); }
-    let mut document = prepared.document;
+    let mut saved = prepared.saved;
     // Preserve resolved identities when Save As moves a session to another folder.
     for device in &prepared.devices {
-        document.device_mut(&device.instance_id)?.path = relative_path(parent, &device.path).to_str().ok_or("Device path cannot be represented as UTF-8")?.to_owned();
+        saved.score.device_mut(&device.instance_id)?.path = relative_path(parent, &device.path).to_str().ok_or("Device path cannot be represented as UTF-8")?.to_owned();
     }
-    let mut bytes = serde_json::to_vec_pretty(&document).map_err(|e| e.to_string())?;
-    bytes.push(b'\n');
-    if bytes.len() as u64 > MAX_BYTES { return Err("Session exceeds the 1 MiB limit".into()); }
+    let bytes = serialize_saved(&saved)?;
     let temporary = parent.join(format!(".alive-save-{}-{}.tmp", std::process::id(), NEXT_TEMP.fetch_add(1, Ordering::Relaxed)));
     let result = (|| -> std::io::Result<()> {
         let mut file = OpenOptions::new().write(true).create_new(true).open(&temporary)?;
@@ -48,7 +47,21 @@ pub(super) fn save_document(path: &Path, session: &Session, origin: &Path) -> Re
         let _ = fs::remove_file(&temporary);
         return Err(format!("Session was not saved: {error}"));
     }
-    Ok((path,document))
+    Ok((path,saved))
+}
+
+pub(super) fn serialize_saved(saved: &SavedSession) -> Result<Vec<u8>, String> {
+    saved.validate_master()?;
+    #[derive(serde::Serialize)]
+    struct Envelope<'a> { format: &'static str, score: &'a Document, master: &'a MasterSettings }
+    let mut bytes = match saved.wire {
+        SaveWire::LegacyScore if saved.master.gain == 1. => serde_json::to_vec_pretty(&saved.score),
+        SaveWire::LegacyScore => return Err("Non-unity Master requires Alive session v5".into()),
+        SaveWire::V5 => serde_json::to_vec_pretty(&Envelope {format:"alive-session-v5",score:&saved.score,master:&saved.master}),
+    }.map_err(|e| e.to_string())?;
+    bytes.push(b'\n');
+    if bytes.len() as u64 > MAX_BYTES { return Err("Session exceeds the 1 MiB limit".into()); }
+    Ok(bytes)
 }
 
 fn relative_path(base: &Path, target: &Path) -> PathBuf {
@@ -74,14 +87,34 @@ struct ReferenceV1 { path: String, id: String, version: u32, parameters: std::co
 #[derive(serde::Deserialize)]
 #[serde(deny_unknown_fields)]
 struct LaneV1 { key: String, enabled: bool, points: Vec<Point> }
-pub(super) fn decode(text: &str, origin: &Path) -> Result<Session, String> {
+#[derive(serde::Deserialize)]
+struct FormatHeader { format: String }
+pub(super) fn decode(text: &str, origin: &Path) -> Result<SavedSession, String> {
+    if text.len() as u64 > MAX_BYTES { return Err("Session exceeds the 1 MiB limit".into()); }
+    clips::reject_duplicates(text)?;
+    let header: FormatHeader = serde_json::from_str(text).map_err(|e| format!("Invalid Alive session JSON: {e}"))?;
+    if header.format == "alive-session-v5" {
+        #[derive(serde::Deserialize)]
+        #[serde(deny_unknown_fields)]
+        struct Envelope { format: String, score: Box<serde_json::value::RawValue>, master: MasterSettings }
+        let envelope: Envelope = serde_json::from_str(text).map_err(|e| format!("Invalid Alive v5 session JSON: {e}"))?;
+        if envelope.format != "alive-session-v5" { return Err("Unsupported Alive session format".into()); }
+        let score = decode_score(envelope.score.get(), origin, false)?;
+        let saved = SavedSession { score, master: envelope.master, wire: SaveWire::V5 };
+        saved.validate_master()?;
+        Ok(saved)
+    } else {
+        Ok(SavedSession {score:decode_score(text,origin,true)?,master:MasterSettings{gain:1.},wire:SaveWire::LegacyScore})
+    }
+}
+fn decode_score(text: &str, origin: &Path, allow_v1: bool) -> Result<Session, String> {
     use sha2::{Digest, Sha256};
-    let value: serde_json::Value = serde_json::from_str(text).map_err(|e| format!("Invalid Alive session JSON: {e}"))?;
-    match value["format"].as_str() {
-        Some("alive-session-v4") => workspaces::decode(text).map(Document::WorkspacesV4),
-        Some("alive-session-v3") => super::clips::decode_v3(text),
-        Some("alive-session-v2") => serde_json::from_str::<LegacySession>(text).map(Document::LegacyV2).map_err(|e| format!("Invalid Alive session JSON: {e}")),
-        Some("alive-session-v1") => {
+    let header: FormatHeader = serde_json::from_str(text).map_err(|e| format!("Invalid Alive session JSON: {e}"))?;
+    match header.format.as_str() {
+        "alive-session-v4" => workspaces::decode(text).map(Document::WorkspacesV4),
+        "alive-session-v3" => super::clips::decode_v3(text),
+        "alive-session-v2" => serde_json::from_str::<LegacySession>(text).map(Document::LegacyV2).map_err(|e| format!("Invalid Alive session JSON: {e}")),
+        "alive-session-v1" if allow_v1 => {
             let old: SessionV1 = serde_json::from_str(text).map_err(|e| format!("Invalid Alive v1 session JSON: {e}"))?;
             let _ = old.format;
             if old.tracks.len() > 16 { return Err("Session exceeds sixteen native roots".into()); }
diff --git a/apps/ultra/src-tauri/src/session/prepare.rs b/apps/ultra/src-tauri/src/session/prepare.rs
index 612ee09..854e325 100644
--- a/apps/ultra/src-tauri/src/session/prepare.rs
+++ b/apps/ultra/src-tauri/src/session/prepare.rs
@@ -28,7 +28,7 @@ pub enum Schedule { Legacy, Clips(Vec<PreparedClip>), Workspaces(super::prepare_
 #[derive(Clone, Debug)]
 pub struct PreparedSession {
     pub origin: PathBuf,
-    pub document: Session,
+    pub saved: SavedSession,
     pub tracks: Vec<PreparedTrack>,
     pub devices: Vec<PreparedDevice>,
     pub events: Vec<FrameEvent>,
@@ -46,22 +46,24 @@ pub(super) fn text(value: &str, limit: usize, label: &str) -> Result<(), String>
     } else { Ok(()) }
 }
 
-pub fn prepare(session: &Session, path: &Path) -> Result<PreparedSession, String> {
-    if let Document::WorkspacesV4(project)=session {return super::prepare_workspaces::prepare(project,path);}
+pub fn prepare(saved: &SavedSession, path: &Path) -> Result<PreparedSession, String> {
+    saved.validate_master()?;
+    let session = &saved.score;
+    if let Document::WorkspacesV4(project)=session {return super::prepare_workspaces::prepare(saved,project,path);}
     if session.is_clips() {
         session.validate_clips()?;
         let mut common=session.legacy()?.clone();common.format="alive-session-v2".into();
         let limits=native::clip_capacity()?;
-        let mut prepared=prepare_common(&common,path,limits.max_tracks as usize,limits.max_devices as usize)?;
+        let mut prepared=prepare_common(saved,&common,path,limits.max_tracks as usize,limits.max_devices as usize)?;
         let mut document=session.clone();
-        for (target,source) in document.legacy_mut()?.tracks.iter_mut().zip(&prepared.document.legacy()?.tracks) {
+        for (target,source) in document.legacy_mut()?.tracks.iter_mut().zip(&prepared.saved.score.legacy()?.tracks) {
             for (a,b) in target.devices_mut().zip(source.devices()) {a.parameters=b.parameters.clone();}
         }
-        prepared.document=document;compile_clips(session,&mut prepared)?;return Ok(prepared);
+        prepared.saved.score=document;compile_clips(session,&mut prepared)?;return Ok(prepared);
     }
-    prepare_common(session.legacy()?,path,2,6)
+    prepare_common(saved,session.legacy()?,path,2,6)
 }
-fn prepare_common(session:&LegacySession,path:&Path,max_tracks:usize,max_devices:usize)->Result<PreparedSession,String> {
+fn prepare_common(saved:&SavedSession,session:&LegacySession,path:&Path,max_tracks:usize,max_devices:usize)->Result<PreparedSession,String> {
     if session.format != "alive-session-v2" { return Err("Unsupported Alive session format; expected alive-session-v2".into()); }
     text(&session.title, 128, "Session title")?;
     bounded(session.tempo, 30., 240., "Tempo")?;
@@ -84,10 +86,10 @@ fn prepare_common(session:&LegacySession,path:&Path,max_tracks:usize,max_devices
     let frames_per_beat = 48_000. * 60. / session.tempo;
     let frame = |beat: f64| (beat * frames_per_beat).round() as u64;
     let length_frames = frame(session.length_beats);
-    let mut result = PreparedSession { origin: path.to_path_buf(), document: Document::LegacyV2(session.clone()), tracks: vec![], devices: vec![], events: vec![], length_frames, schedule:Schedule::Legacy, notice:None };
+    let mut result = PreparedSession { origin: path.to_path_buf(), saved: saved.with_score(Document::LegacyV2(session.clone())), tracks: vec![], devices: vec![], events: vec![], length_frames, schedule:Schedule::Legacy, notice:None };
     let mut references: Vec<_> = session.tracks.iter().enumerate().flat_map(|(track, t)| t.devices().enumerate().map(move |(position, d)| (track, position, d))).collect();
     references.sort_by_key(|(_, _, d)| &d.instance_id);
-    check_sources(&result.document,path,None)?;
+    check_sources(&result.saved.score,path,None)?;
     for (track, position, reference) in references {
         let context = |e| format!("Track '{}' instance '{}' ({}): {e}", session.tracks[track].name, reference.instance_id, reference.path);
         let device = prepare_device(reference, path, track).map_err(context)?;
@@ -97,7 +99,7 @@ fn prepare_common(session:&LegacySession,path:&Path,max_tracks:usize,max_devices
         result.devices.push(device);
     }
     compile_music(session, &mut result, false)?;
-    for track in &mut result.document.legacy_mut()?.tracks {
+    for track in &mut result.saved.score.legacy_mut()?.tracks {
         for reference in track.devices_mut() {
             let device = result.devices.iter().find(|d| d.instance_id == reference.instance_id).unwrap();
             reference.parameters = device.manifest.parameters.iter().map(|p| (p.key.clone(), p.base)).collect();
diff --git a/apps/ultra/src-tauri/src/session/prepare_workspaces.rs b/apps/ultra/src-tauri/src/session/prepare_workspaces.rs
index 3bf8db7..a7c0cb1 100644
--- a/apps/ultra/src-tauri/src/session/prepare_workspaces.rs
+++ b/apps/ultra/src-tauri/src/session/prepare_workspaces.rs
@@ -11,7 +11,7 @@ pub struct PreparedPlacement {pub id:String,pub descriptor:native::PlacementV4}
 #[derive(Clone, Debug)]
 pub struct PreparedWorkspaces {pub sources:Vec<PreparedSource>,pub slots:Vec<PreparedSlot>,pub placements:Vec<PreparedPlacement>}
 
-pub(super) fn prepare(project:&ProjectV4,path:&Path)->Result<PreparedSession,String> {
+pub(super) fn prepare(saved:&SavedSession,project:&ProjectV4,path:&Path)->Result<PreparedSession,String> {
     project.validate()?;
     midi_only(project)?;
     // Storage bounds are an early rejection only. Host admission proves all work.
@@ -22,12 +22,12 @@ pub(super) fn prepare(project:&ProjectV4,path:&Path)->Result<PreparedSession,Str
     super::prepare::check_sources(&document,path,None)?;
     let mut references:Vec<_>=project.tracks.iter().enumerate().flat_map(|(track,t)|t.devices().enumerate().map(move |(position,d)|(track,position,d))).collect();
     references.sort_by_key(|(_,_,d)|&d.instance_id);
-    let mut prepared=PreparedSession{origin:path.to_owned(),document,tracks:vec![],devices:vec![],events:vec![],length_frames:frame_at(project.length_beats,project.tempo)?,schedule:Schedule::Workspaces(PreparedWorkspaces{sources:vec![],slots:vec![],placements:vec![]}),notice:None};
+    let mut prepared=PreparedSession{origin:path.to_owned(),saved:saved.with_score(document),tracks:vec![],devices:vec![],events:vec![],length_frames:frame_at(project.length_beats,project.tempo)?,schedule:Schedule::Workspaces(PreparedWorkspaces{sources:vec![],slots:vec![],placements:vec![]}),notice:None};
     for (track,position,reference) in references {
         let device=super::prepare::prepare_device(reference,path,track).map_err(|e|format!("Track '{}' instance '{}': {e}",project.tracks[track].name,reference.instance_id))?;
         let expected=if position==0 {crate::canvas::device::DeviceKind::Instrument}else{crate::canvas::device::DeviceKind::AudioEffect};
         if device.manifest.kind!=expected || (position==0&&reference.bypassed) {return Err(format!("Track '{}' instance '{}' has incompatible instrument/effect role",project.tracks[track].name,reference.instance_id));}
-        prepared.document.device_mut(&reference.instance_id)?.parameters=device.manifest.parameters.iter().map(|p|(p.key.clone(),p.base)).collect();
+        prepared.saved.score.device_mut(&reference.instance_id)?.parameters=device.manifest.parameters.iter().map(|p|(p.key.clone(),p.base)).collect();
         prepared.devices.push(device);
     }
     compile(project,&mut prepared)?;
diff --git a/apps/ultra/src-tauri/src/session/probe.rs b/apps/ultra/src-tauri/src/session/probe.rs
index 7245069..f8f7de4 100644
--- a/apps/ultra/src-tauri/src/session/probe.rs
+++ b/apps/ultra/src-tauri/src/session/probe.rs
@@ -42,7 +42,7 @@ fn digest(wave: &[f32]) -> String {
 }
 fn saved_device_boundaries(host: &mut Host, source: &super::PreparedSession, output: &Path) -> Result<Value, String> {
     let offsets = [0u64, 1, 31, 63, 64, 127];
-    let mut document = source.document.clone();
+    let mut document = source.saved.score.clone();
     document.legacy_mut()?.tempo = 120.; document.legacy_mut()?.length_beats = 1.; document.legacy_mut()?.loop_enabled = true;
     for (track, model) in document.legacy_mut()?.tracks.iter_mut().enumerate() {
         model.gain = 0.7; model.mute = false; model.solo = false;
@@ -58,7 +58,7 @@ fn saved_device_boundaries(host: &mut Host, source: &super::PreparedSession, out
             }).collect(),
         }).collect();
     }
-    let prepared = prepare(&document, &source.origin)?;
+    let prepared = prepare(&source.saved.with_score(document), &source.origin)?;
     unsafe { native::ultra_audio_stop(); }
     host.install(prepared.clone())?; start()?;
     let mut baseline = Vec::with_capacity(1024);
@@ -120,15 +120,15 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
             notes:vec![Note { beat:0., duration:1. / 24000., pitch:60, velocity:127 }], automation:vec![], gain:1., mute:false, solo:false }] };
     let origin = output.join("chain.alive");
     let document = super::Document::LegacyV2(document);
-    let saved = save(&origin,&document,&origin)?;
+    let saved = save(&origin,&source.saved.with_score(document.clone()),&origin)?;
     let prepared = read(&saved)?;
     unsafe { native::ultra_audio_stop(); }
     host.install(prepared.clone())?; start()?;
     let wet = render(256,&[1])?;
     require(wet[2] > 0., "Saved lowpass did not ring after the impulse")?;
-    let mut dry_document = prepared.document.clone(); dry_document.legacy_mut()?.tracks[0].effects[1].bypassed = true;
+    let mut dry_document = prepared.saved.score.clone(); dry_document.legacy_mut()?.tracks[0].effects[1].bypassed = true;
     unsafe { native::ultra_audio_stop(); }
-    host.install(prepare(&dry_document,&saved)?)?; start()?;
+    host.install(prepare(&prepared.saved.with_score(dry_document),&saved)?)?; start()?;
     let dry = render(256,&[31,1,63,127])?;
     require(dry[0] > 0. && dry[2..].iter().all(|&s| s == 0.),"Saved bypass did not emit the exact dry impulse")?;
     unsafe { native::ultra_audio_stop(); }
@@ -143,11 +143,11 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
 
     let mut ordered = document.clone();
     ordered.legacy_mut()?.tracks[0].automation.push(Lane { instance_id:"probe-utility".into(),key:"gain".into(),enabled:true,points:vec![Point { beat:1. / 24000.,value:0. }] });
-    let forward = prepare(&ordered,&saved)?;
+    let forward = prepare(&prepared.saved.with_score(ordered.clone()),&saved)?;
     unsafe { native::ultra_audio_stop(); } host.install(forward.clone())?; start()?;
     let ringing = render(128,&[31,63,1])?;
     ordered.legacy_mut()?.tracks[0].effects.reverse();
-    let reverse = prepare(&ordered,&saved)?;
+    let reverse = prepare(&prepared.saved.with_score(ordered.clone()),&saved)?;
     let target = |p: &super::PreparedSession| p.events.iter().find(|e| e.kind == 1).map(|e| p.devices[e.device as usize].instance_id.clone());
     require(target(&forward) == target(&reverse) && target(&reverse).as_deref() == Some("probe-utility"),"Reorder changed automation ownership")?;
     unsafe { native::ultra_audio_stop(); } host.install(reverse)?; start()?;
@@ -157,10 +157,10 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
     unsafe { native::ultra_audio_stop(); } host.install(prepared.clone())?; start()?;
     render(1,&[1])?;
     let before = native::state()?;
-    let previous = host.prepared.as_ref().unwrap().document.clone();
+    let previous = host.prepared.as_ref().unwrap().saved.score.clone();
     let mut invalid = prepared.clone(); invalid.devices[0].graph.node_count = 0;
     require(host.install(invalid).is_err(),"Invalid prospective graph unexpectedly installed")?;
-    require(host.prepared.as_ref().unwrap().document == previous,"Rejected candidate changed saved model")?;
+    require(host.prepared.as_ref().unwrap().saved.score == previous,"Rejected candidate changed saved model")?;
     let continued = render(1,&[1])?;
     require(continued == wet[2..4] && native::state()?.position == before.position+1,"Rejected candidate interrupted the active native session")?;
     let stale = native::state()?.devices[0];
@@ -168,15 +168,15 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
     for _ in 0..64 { host.base("probe-utility","gain",0.4)?; }
     require(host.base("probe-utility","gain",0.3).is_err(),"Saturated base queue did not reject")?;
     require(host.bypass("probe-filter",true).is_err(),"Saturated bypass queue did not reject")?;
-    let model = &host.prepared.as_ref().unwrap().document;
+    let model = &host.prepared.as_ref().unwrap().saved.score;
     require(model.legacy()?.tracks[0].effects[0].parameters["gain"] == 0.4 && !model.legacy()?.tracks[0].effects[1].bypassed,"Rejected live value leaked into saved state")?;
     unsafe { native::alive_session_stop(); }
     require(render(64,&[31,1,32])?.iter().all(|&s| s==0.) && native::state()?.playing==0,"Stop failed under saturated chain command queue")?;
     unsafe { native::ultra_audio_stop(); } host.install(prepared.clone())?;
     require(unsafe { native::alive_session_bypass_v2(stale.document,stale.revision,1) } == 0,"Reinstallation accepted a stale root handle")?;
-    let saved = save(&output.join("chain-reopened.alive"),&host.prepared.as_ref().unwrap().document,&saved)?;
+    let saved = save(&output.join("chain-reopened.alive"),&host.prepared.as_ref().unwrap().saved,&saved)?;
     let reopened = read(&saved)?;
-    require(reopened.document.legacy()?.tracks[0].effects.len()==2,"Reopen lost saved effects")?;
+    require(reopened.saved.score.legacy()?.tracks[0].effects.len()==2,"Reopen lost saved effects")?;
     host.install(reopened)?; start()?;
     require(render(256,&[127,1,64])? == wet,"Reopened saved chain changed audio")?;
     let mut two = document.clone();
@@ -185,7 +185,7 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
     other.effects[0].parameters.insert("gain".into(),0.5);
     other.effects[1].parameters.insert("cutoff".into(),700.);
     two.legacy_mut()?.tracks.push(other);
-    let six = prepare(&two,&saved)?;
+    let six = prepare(&prepared.saved.with_score(two.clone()),&saved)?;
     unsafe { native::ultra_audio_stop(); } host.install(six.clone())?; start()?;
     let combined = render(128,&[31,1,64])?;
     let state = native::state()?;
@@ -193,7 +193,7 @@ fn saved_chain_proof(host: &mut Host, source: &super::PreparedSession, output: &
     let other_filter = six.devices.iter().position(|d| d.instance_id=="probe-filter-other").unwrap();
     require(state.devices[first_filter].base[0]==2400. && state.devices[other_filter].base[0]==700.,"Identical source effects shared base state")?;
     let mut only_other = two.clone(); only_other.legacy_mut()?.tracks[0].mute = true;
-    unsafe { native::ultra_audio_stop(); } host.install(prepare(&only_other,&saved)?)?; start()?;
+    unsafe { native::ultra_audio_stop(); } host.install(prepare(&prepared.saved.with_score(only_other),&saved)?)?; start()?;
     let independent = render(128,&[1,127])?;
     require(combined.iter().zip(wet.iter().zip(&independent)).all(|(sum,(a,b))| (sum-a-b).abs()<1e-7),"Identical source effects shared filter tails or mixed a root twice")?;
     require(independent[2..].iter().zip(&wet[2..]).any(|(a,b)| a != b),"Distinct filter instances unexpectedly shared their tail")?;
@@ -212,7 +212,7 @@ pub fn run(path: &Path, output: &Path) -> Result<Value, String> {
     let _shutdown = Shutdown;
     let prepared = read(path)?;
     require(prepared.tracks.len() == 2, "The session proof requires two saved device references")?;
-    require(prepared.document.legacy()?.loop_enabled, "The session proof requires an enabled loop")?;
+    require(prepared.saved.score.legacy()?.loop_enabled, "The session proof requires an enabled loop")?;
     let mut host = Host::default();
     host.install(prepared.clone())?;
     start()?;
@@ -242,8 +242,8 @@ pub fn run(path: &Path, output: &Path) -> Result<Value, String> {
     let cutoff = prepared.devices[prepared.tracks[0].midi_instrument()?].manifest.parameters.iter().position(|p| p.key == "cutoff").ok_or("Proof requires cutoff binding")?;
     let level = prepared.devices[prepared.tracks[0].midi_instrument()?].manifest.parameters.iter().position(|p| p.key == "level").ok_or("Proof requires level binding")?;
     let before = native::state()?;
-    host.base(&prepared.document.legacy()?.tracks[0].device.instance_id, "cutoff", 1711.)?;
-    host.base(&prepared.document.legacy()?.tracks[0].device.instance_id, "level", 72.)?;
+    host.base(&prepared.saved.score.legacy()?.tracks[0].device.instance_id, "cutoff", 1711.)?;
+    host.base(&prepared.saved.score.legacy()?.tracks[0].device.instance_id, "level", 72.)?;
     render(1, &[1])?;
     let owned = native::state()?;
     require(owned.devices[prepared.tracks[0].midi_instrument()?].base[cutoff] == 1711. && owned.devices[prepared.tracks[0].midi_instrument()?].effective[cutoff] == before.devices[prepared.tracks[0].midi_instrument()?].effective[cutoff]
@@ -274,11 +274,11 @@ pub fn run(path: &Path, output: &Path) -> Result<Value, String> {
         && sought.tracks.iter().all(|t| t.active_voices == 0), "Seek retained pre-seek notes or used the wrong frame/generation")?;
 
     let view = host.view()?;
-    let saved = save(&output.join("reopened.alive"), view.document, view.path)?;
+    let saved = save(&output.join("reopened.alive"), &host.prepared.as_ref().unwrap().saved, view.path)?;
     let reopened = read(&saved)?;
-    require(reopened.document.legacy()?.tracks[0].device.parameters["cutoff"] == 1711.
-        && reopened.document.legacy()?.tracks[0].device.parameters["level"] == 72.
-        && reopened.document.legacy()?.tracks[1].notes == prepared.document.legacy()?.tracks[1].notes, "Session reopen lost state")?;
+    require(reopened.saved.score.legacy()?.tracks[0].device.parameters["cutoff"] == 1711.
+        && reopened.saved.score.legacy()?.tracks[0].device.parameters["level"] == 72.
+        && reopened.saved.score.legacy()?.tracks[1].notes == prepared.saved.score.legacy()?.tracks[1].notes, "Session reopen lost state")?;
     unsafe { native::ultra_audio_stop(); }
     host.install(reopened)?;
     start()?;
@@ -286,7 +286,7 @@ pub fn run(path: &Path, output: &Path) -> Result<Value, String> {
     require(reopened_energy > 1e-9, "Reopened session did not play")?;
     let mut single = host.view()?.document.clone();
     single.legacy_mut()?.tracks.truncate(1);
-    let one = prepare(&single, &saved)?;
+    let one = prepare(&host.prepared.as_ref().unwrap().saved.with_score(single), &saved)?;
     unsafe { native::ultra_audio_stop(); }
     host.install(one)?;
     start()?;
diff --git a/apps/ultra/src-tauri/src/session/runtime.rs b/apps/ultra/src-tauri/src/session/runtime.rs
index 9be9221..d8eca81 100644
--- a/apps/ultra/src-tauri/src/session/runtime.rs
+++ b/apps/ultra/src-tauri/src/session/runtime.rs
@@ -44,7 +44,7 @@ pub struct View {pub tracks:Vec<Track>,pub requests:Vec<RequestResult>,pub reque
 #[serde(rename_all="camelCase")]
 pub struct PreparedClip {track_id:String,clip_id:String,name:String,slot:usize,length_frames:String}
 #[derive(Default)]
-pub struct Runtime {revision:u64,serial:u64,requests:Vec<RequestResult>,pub workspace:super::runtime_workspaces::Runtime}
+pub struct Runtime {revision:u64,serial:u64,requests:Vec<RequestResult>,pub workspace:super::runtime_workspaces::Runtime,pub master_observation:Option<super::native_master::State>}
 fn status(value:u32)->&'static str{match value{n::V3_QUEUED=>"queued",n::V3_PENDING=>"pending",n::V3_APPLIED=>"applied",n::V3_REJECTED=>"rejected",n::V3_SUPERSEDED=>"superseded",n::V3_CANCELED=>"canceled",n::V3_MIXED=>"mixed",_=>"unavailable"}}
 fn frame(value:u64)->Option<String>{(value!=n::V3_NO_FRAME).then(||value.to_string())}
 impl Runtime {
@@ -55,15 +55,20 @@ impl Runtime {
     pub fn poll(&mut self,host:&Host)->Result<(serde_json::Value,Option<serde_json::Value>),String>{
         let p=host.prepared.as_ref().ok_or("No session")?;
         super::host::Host::check_schedule(p)?;
-        if p.document.is_workspaces(){return self.workspace.poll(host);}
-        if !p.document.is_clips(){return Ok((serde_json::to_value(n::state()?).map_err(|e|e.to_string())?,None));}
-        let mut raw=Box::<n::StateV3>::default();if unsafe{n::alive_session_state_v3(&mut *raw)}==0{return Err("Session state is temporarily unavailable".into());}
+        if p.saved.score.is_workspaces(){let result=self.workspace.poll(host)?;self.master_observation=self.workspace.master_observation;return Ok(result);}
+        if !p.saved.score.is_clips(){
+            let raw=if let Some(capability)=n::master_capability(){let mut raw=n::StateV2::default();let mut master=super::native_master::State::output();if unsafe{(capability.snapshot_v2)((&mut raw as *mut n::StateV2).cast(),&mut master)}!=1{return Err("Session state is temporarily unavailable".into());}self.master_observation=Some(master);raw}else{self.master_observation=None;n::state()?};
+            return Ok((serde_json::to_value(raw).map_err(|e|e.to_string())?,None));
+        }
+        let mut raw=Box::<n::StateV3>::default();
+        if let Some(capability)=n::master_capability(){let mut master=super::native_master::State::output();if unsafe{(capability.snapshot_v3)((&mut *raw as *mut n::StateV3).cast(),&mut master)}!=1{return Err("Session state is temporarily unavailable".into());}self.master_observation=Some(master);}
+        else {self.master_observation=None;if unsafe{n::alive_session_state_v3(&mut *raw)}==0{return Err("Session state is temporarily unavailable".into());}}
         if raw.preparation_revision!=host.preparation_revision{return Err("Native preparation publication is temporarily unavailable".into());}
         if self.revision!=host.preparation_revision{self.requests.clear();self.revision=host.preparation_revision;}
         self.reconcile(&raw);
         let Schedule::Clips(clips)=&p.schedule else{return Err("Missing prepared bank".into())};
         let clip_id=|index:u32|clips.get(index as usize).map(|c|c.id.clone());
-        let tracks=p.document.tracks().into_iter().enumerate().map(|(i,t)|{let r=&raw.tracks[i];Track{track_id:t.id().to_owned(),active_clip_id:clip_id(r.active_clip),phase:r.phase.to_string(),epoch:r.track_epoch.to_string(),pending_action:match r.pending_action{n::V3_LAUNCH=>Some("launch".into()),n::V3_TRACK_STOP=>Some("stop".into()),_=>None},pending_clip_id:clip_id(r.pending_clip),pending_serial:(r.pending_serial!=0).then(||r.pending_serial.to_string()),pending_frame:frame(r.pending_frame)}}).collect();
+        let tracks=p.saved.score.tracks().into_iter().enumerate().map(|(i,t)|{let r=&raw.tracks[i];Track{track_id:t.id().to_owned(),active_clip_id:clip_id(r.active_clip),phase:r.phase.to_string(),epoch:r.track_epoch.to_string(),pending_action:match r.pending_action{n::V3_LAUNCH=>Some("launch".into()),n::V3_TRACK_STOP=>Some("stop".into()),_=>None},pending_clip_id:clip_id(r.pending_clip),pending_serial:(r.pending_serial!=0).then(||r.pending_serial.to_string()),pending_frame:frame(r.pending_frame)}}).collect();
         let devices=raw.devices[..p.devices.len()].iter().map(|d|serde_json::json!({"document":d.document,"bypassed":d.bypassed,"parameterCount":d.parameter_count,"revision":d.revision.to_string(),"base":d.base,"effective":d.effective,"owned":d.owned})).collect::<Vec<_>>();
         let state=serde_json::json!({"playing":raw.playing,"configured":raw.configured,"absoluteFrame":raw.absolute_frame.to_string(),"position":raw.position.to_string(),"generation":raw.generation.to_string(),"rejected":raw.rejected.to_string(),"peakLeft":raw.peak_left,"peakRight":raw.peak_right,"tracks":raw.tracks[..p.tracks.len()].iter().map(|t|t.mixer).collect::<Vec<_>>(),"devices":devices});
         Ok((state,Some(serde_json::to_value(View{tracks,requests:self.requests.clone(),requested_stop_epoch:raw.requested_stop_epoch.to_string(),applied_stop_epoch:raw.applied_stop_epoch.to_string()}).map_err(|e|e.to_string())?)))
@@ -90,7 +95,7 @@ impl Runtime {
         self.poll(host)?;
         let p=host.prepared.as_ref().ok_or("No session")?;
         let Schedule::Clips(clips)=&p.schedule else{return Err("Enable the clip bank first".into())};
-        let members=p.document.tracks().into_iter().enumerate().filter(|(i,_)|request.track_mask&(1<<i)!=0).map(|(i,t)|{
+        let members=p.saved.score.tracks().into_iter().enumerate().filter(|(i,_)|request.track_mask&(1<<i)!=0).map(|(i,t)|{
             let action=request.tracks[i];
             Member{track_index:i,track_id:t.id().to_owned(),clip_id:if action.action==n::V3_LAUNCH{clips.iter().find(|c|c.track==i&&c.slot==action.slot as usize).map(|c|c.id.clone())}else{None},
                 action:if action.action==n::V3_LAUNCH{"launch"}else{"stop"}.into(),status:"queued".into()}
@@ -118,7 +123,7 @@ fn scene_request(p:&super::PreparedSession,slot:usize)->Result<n::RequestV3,Stri
     for t in 0..p.tracks.len(){request.tracks[t]=if clips.iter().any(|c|c.track==t&&c.slot==slot){n::TrackActionV3{action:n::V3_LAUNCH,slot:slot as u32}}else{n::TrackActionV3{action:n::V3_TRACK_STOP,slot:n::V3_NONE}};}
     Ok(request)
 }
-pub fn prepared(host:&Host)->Vec<PreparedClip>{let Some(p)=&host.prepared else{return vec![]};match &p.schedule{Schedule::Legacy|Schedule::Workspaces(_)=>vec![],Schedule::Clips(clips)=>clips.iter().map(|c|PreparedClip{track_id:p.document.tracks()[c.track].id().to_owned(),clip_id:c.id.clone(),name:c.name.clone(),slot:c.slot,length_frames:c.length_frames.to_string()}).collect()}}
+pub fn prepared(host:&Host)->Vec<PreparedClip>{let Some(p)=&host.prepared else{return vec![]};match &p.schedule{Schedule::Legacy|Schedule::Workspaces(_)=>vec![],Schedule::Clips(clips)=>clips.iter().map(|c|PreparedClip{track_id:p.saved.score.tracks()[c.track].id().to_owned(),clip_id:c.id.clone(),name:c.name.clone(),slot:c.slot,length_frames:c.length_frames.to_string()}).collect()}}
 
 #[cfg(test)]
 mod tests {
@@ -154,9 +159,9 @@ mod tests {
     #[test]
     fn scene_mapper_uses_immutable_prepared_slots_and_empty_members_stop(){
         let path=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive");
-        let old=super::super::read(&path).unwrap();let mut doc=old.document.to_clips().unwrap();
+        let old=super::super::read(&path).unwrap();let mut doc=old.saved.score.to_clips().unwrap();
         let track=doc.legacy().unwrap().tracks[1].id.clone();let bank=doc.bank_mut(&track).unwrap();bank.slots[0]=None;bank.default_clip_id=None;
-        let prepared=super::super::prepare(&doc,&path).unwrap();
+        let prepared=super::super::prepare(&old.saved.with_score(doc),&path).unwrap();
         let r=scene_request(&prepared,0).unwrap();assert_eq!(r.track_mask,3);assert_eq!(r.kind,n::V3_TRACK_ACTIONS);
         assert_eq!((r.tracks[0].action,r.tracks[0].slot),(n::V3_LAUNCH,0));
         assert_eq!((r.tracks[1].action,r.tracks[1].slot),(n::V3_TRACK_STOP,n::V3_NONE));
diff --git a/apps/ultra/src-tauri/src/session/runtime_workspaces.rs b/apps/ultra/src-tauri/src/session/runtime_workspaces.rs
index 3a81bd1..ef1a6ec 100644
--- a/apps/ultra/src-tauri/src/session/runtime_workspaces.rs
+++ b/apps/ultra/src-tauri/src/session/runtime_workspaces.rs
@@ -22,7 +22,7 @@ pub struct Track {pub track_id:String,pub authority:Option<String>,pub active_sl
 #[serde(rename_all="camelCase")]
 pub struct View {pub tracks:Vec<Track>,pub requests:Vec<RequestResult>,pub requested_stop_epoch:String,pub applied_stop_epoch:String}
 #[derive(Default)]
-pub struct Runtime {revision:u64,requests:Vec<RequestResult>}
+pub struct Runtime {revision:u64,requests:Vec<RequestResult>,pub master_observation:Option<super::native_master::State>}
 fn frame(value:u64)->Option<String>{(value!=n::V4_NO_FRAME).then(||value.to_string())}
 fn status(value:u32)->&'static str{match value{n::V4_QUEUED=>"queued",n::V4_PENDING=>"pending",n::V4_APPLIED=>"applied",n::V4_REJECTED=>"rejected",n::V4_SUPERSEDED=>"superseded",n::V4_CANCELED=>"canceled",n::V4_MIXED=>"mixed",_=>"unavailable"}}
 fn workspace(p:&PreparedSession)->Result<&PreparedWorkspaces,String>{Host::check_schedule(p)?;match &p.schedule {Schedule::Workspaces(w)=>Ok(w),_=>Err("Enable MIDI workspaces first".into())}}
@@ -42,7 +42,9 @@ impl Runtime {
     }
     pub fn poll(&mut self,host:&Host)->Result<(serde_json::Value,Option<serde_json::Value>),String>{
         let p=host.prepared.as_ref().ok_or("No session")?;let w=workspace(p)?;
-        let mut raw=Box::<n::StateV4>::default();if unsafe{n::alive_session_state_v4(&mut *raw)}==0{return Err("Workspace state is temporarily unavailable".into());}
+        let mut raw=Box::<n::StateV4>::default();
+        if let Some(capability)=n::master_capability(){let mut master=super::native_master::State::output();if unsafe{(capability.snapshot_v4)((&mut *raw as *mut n::StateV4).cast(),&mut master)}!=1{return Err("Workspace state is temporarily unavailable".into());}self.master_observation=Some(master);}
+        else {self.master_observation=None;if unsafe{n::alive_session_state_v4(&mut *raw)}==0{return Err("Workspace state is temporarily unavailable".into());}}
         if raw.preparation_revision!=host.preparation_revision{return Err("Native workspace preparation publication is temporarily unavailable".into());}
         if self.revision!=host.preparation_revision {self.requests.clear();self.revision=host.preparation_revision;}
         self.reconcile(&raw);
@@ -63,7 +65,7 @@ impl Runtime {
     }
 }
 fn observations(p:&PreparedSession,w:&PreparedWorkspaces,raw:&n::StateV4)->Result<Vec<Track>,String>{
-    p.document.tracks().into_iter().enumerate().map(|(index,t)|{
+    p.saved.score.tracks().into_iter().enumerate().map(|(index,t)|{
         let r=&raw.tracks[index];
         let authority=match r.authority {n::V4_ARRANGEMENT_AUTHORITY=>"arrangement",n::V4_SESSION_AUTHORITY=>"session",_=>return Err("Invalid native workspace authority".into())};
         let source=if r.active_source==n::V4_NONE{None}else{Some(w.sources.get(r.active_source as usize).filter(|s|s.descriptor.track==index as u32).ok_or("Unmapped native workspace source")?.id.clone())};
@@ -74,12 +76,12 @@ fn observations(p:&PreparedSession,w:&PreparedWorkspaces,raw:&n::StateV4)->Resul
     }).collect()
 }
 fn request(p:&PreparedSession,action:Action)->Result<(n::RequestV4,RequestResult),String>{
-    let w=workspace(p)?;let tracks=p.document.tracks();
+    let w=workspace(p)?;let tracks=p.saved.score.tracks();
     let index=|id:&str|tracks.iter().position(|t|t.id()==id).ok_or_else(||format!("Unknown prepared track '{id}'"));
     let mut r=n::RequestV4::default();let mut result=RequestResult::default();
     match action {
         Action::Start{}=>{r.kind=n::V4_START;result.kind="start".into();},
-        Action::Seek{beat}=>{if !beat.is_finite()||beat<0.||beat>=p.document.length_beats(){return Err("Seek beat must be within the prepared song".into());}r.kind=n::V4_SEEK;r.position=super::workspaces::frame_at(beat,p.document.tempo())?;result.kind="seek".into();},
+        Action::Seek{beat}=>{if !beat.is_finite()||beat<0.||beat>=p.saved.score.length_beats(){return Err("Seek beat must be within the prepared song".into());}r.kind=n::V4_SEEK;r.position=super::workspaces::frame_at(beat,p.saved.score.tempo())?;result.kind="seek".into();},
         Action::Launch{track_id,slot_id}=>{let i=index(&track_id)?;let slot=w.slots.iter().find(|s|s.descriptor.track==i as u32&&s.id==slot_id).ok_or("Apply while stopped to launch this draft-only slot")?;r.kind=n::V4_TRACK_ACTIONS;r.track_mask=1<<i;r.tracks[i]=n::TrackActionV4{action:n::V4_LAUNCH,slot:slot.slot as u32};result.kind="launch".into();result.track_id=Some(track_id);result.slot_id=Some(slot_id);result.source_id=Some(w.sources[slot.descriptor.source as usize].id.clone());},
         Action::Stop{track_id}=>{let i=index(&track_id)?;r.kind=n::V4_TRACK_ACTIONS;r.track_mask=1<<i;r.tracks[i]=n::TrackActionV4{action:n::V4_TRACK_STOP,slot:n::V4_NONE};result.kind="stop".into();result.track_id=Some(track_id);},
         Action::Return{track_ids}=>{if track_ids.is_empty()||track_ids.len()>tracks.len(){return Err("Return requires one or more unique prepared track IDs".into());}r.kind=n::V4_TRACK_ACTIONS;result.kind="return".into();for id in track_ids{let i=index(&id)?;if r.track_mask&(1<<i)!=0{return Err("Duplicate Return track ID".into());}r.track_mask|=1<<i;r.tracks[i]=n::TrackActionV4{action:n::V4_RETURN,slot:n::V4_NONE};}},
@@ -90,7 +92,7 @@ fn request(p:&PreparedSession,action:Action)->Result<(n::RequestV4,RequestResult
 }
 
 pub fn prepared(host:&Host)->Result<Option<serde_json::Value>,String>{
-    let p=host.prepared.as_ref().ok_or("No session")?;if !p.document.is_workspaces(){return Ok(None);}let w=workspace(p)?;let tracks=p.document.tracks();
+    let p=host.prepared.as_ref().ok_or("No session")?;if !p.saved.score.is_workspaces(){return Ok(None);}let w=workspace(p)?;let tracks=p.saved.score.tracks();
     Ok(Some(serde_json::json!({"preparationRevision":host.preparation_revision.to_string(),
         "sources":w.sources.iter().map(|s|serde_json::json!({"trackId":tracks[s.descriptor.track as usize].id(),"sourceId":s.id,"kind":"midi","name":s.name,"lengthFrames":s.descriptor.length_frames.to_string()})).collect::<Vec<_>>(),
         "slots":w.slots.iter().map(|s|serde_json::json!({"trackId":tracks[s.descriptor.track as usize].id(),"slotId":s.id,"slot":s.slot,"sourceId":w.sources[s.descriptor.source as usize].id,"name":s.name,"sourceOffsetFrames":s.descriptor.source_offset.to_string(),"loopEnabled":s.descriptor.loop_enabled!=0})).collect::<Vec<_>>(),
@@ -103,8 +105,8 @@ mod tests {
     fn prepared()->PreparedSession {
         let path=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive");
         let old=super::super::read(&path).unwrap();
-        let project=super::super::workspaces::prospective_from_document(&old.document).unwrap();
-        super::super::prepare(&super::super::Document::WorkspacesV4(project),&path).unwrap()
+        let project=super::super::workspaces::prospective_from_document(&old.saved.score).unwrap();
+        super::super::prepare(&old.saved.with_score(super::super::Document::WorkspacesV4(project)),&path).unwrap()
     }
     #[test]
     fn gaps_and_session_silence_keep_null_sources_and_pending_return_is_not_predicted(){
@@ -119,7 +121,7 @@ mod tests {
     }
     #[test]
     fn return_and_launch_use_prepared_identities_and_reject_draft_or_foreign_slots(){
-        let p=prepared();let w=workspace(&p).unwrap();let tracks=p.document.tracks();
+        let p=prepared();let w=workspace(&p).unwrap();let tracks=p.saved.score.tracks();
         let (raw,result)=request(&p,Action::Return{track_ids:tracks.iter().map(|t|t.id().into()).collect()}).unwrap();assert_eq!(raw.track_mask,3);assert_eq!(result.kind,"return");assert!(result.track_id.is_none());assert!(result.members.iter().all(|m|m.authority=="arrangement"));
         assert!(request(&p,Action::Return{track_ids:vec![tracks[0].id().into();2]}).is_err());
         assert!(request(&p,Action::Launch{track_id:tracks[0].id().into(),slot_id:"draft-only".into()}).is_err());
@@ -128,7 +130,7 @@ mod tests {
     }
     #[test]
     fn receipt_reconciliation_matches_revision_and_preserves_terminal_members(){
-        let p=prepared();let (_,mut result)=request(&p,Action::Return{track_ids:p.document.tracks().iter().map(|t|t.id().into()).collect()}).unwrap();result.preparation_revision="9".into();result.request_serial=u64::MAX.to_string();result.status="pending".into();result.members[0].status="applied".into();result.members[1].status="pending".into();
+        let p=prepared();let (_,mut result)=request(&p,Action::Return{track_ids:p.saved.score.tracks().iter().map(|t|t.id().into()).collect()}).unwrap();result.preparation_revision="9".into();result.request_serial=u64::MAX.to_string();result.status="pending".into();result.members[0].status="applied".into();result.members[1].status="pending".into();
         let mut runtime=Runtime{requests:vec![result],..Default::default()};let mut raw=n::StateV4::default();raw.last_consumed_request=u64::MAX;raw.receipts[0]=n::ReceiptV4{preparation_revision:8,request_serial:u64::MAX,status:n::V4_APPLIED,applied_mask:3,..Default::default()};
         runtime.reconcile(&raw);assert_eq!(runtime.requests[0].status,"unavailable");assert_eq!(runtime.requests[0].members[0].status,"applied");assert_eq!(runtime.requests[0].members[1].status,"unavailable");
         raw.receipts[0].preparation_revision=9;runtime.reconcile(&raw);assert_eq!(runtime.requests[0].status,"applied");assert!(runtime.requests[0].members.iter().all(|m|m.status=="applied"));
diff --git a/apps/ultra/src-tauri/src/session/tests.rs b/apps/ultra/src-tauri/src/session/tests.rs
index 6232d44..8c6dab0 100644
--- a/apps/ultra/src-tauri/src/session/tests.rs
+++ b/apps/ultra/src-tauri/src/session/tests.rs
@@ -28,18 +28,203 @@ fn native_v3_layout_matches_fixed_c_interface() {
 }
 use std::path::Path;
 
+fn test_saved(score: Session) -> SavedSession {
+    SavedSession { score, master: MasterSettings { gain: 1. }, wire: SaveWire::LegacyScore }
+}
+fn prepare_score_fixture(score: &Session, path: &Path) -> Result<PreparedSession, String> {
+    super::prepare(&test_saved(score.clone()), path)
+}
+fn save_score_fixture(path: &Path, score: &Session, origin: &Path) -> Result<std::path::PathBuf, String> {
+    super::save(path, &test_saved(score.clone()), origin)
+}
+
 fn example_path() -> std::path::PathBuf {
     Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive")
 }
 fn example() -> Session {
-    read(&example_path()).unwrap().document
+    read(&example_path()).unwrap().saved.score
+}
+
+#[test]
+fn bare_legacy_parameter_maps_reject_escaped_duplicate_keys() {
+    let text = std::fs::read_to_string(example_path()).unwrap();
+    let duplicate = text.replacen("\"attack\": 10,", "\"attack\": 10, \"\\u0061ttack\": 11,", 1);
+    assert_ne!(text, duplicate);
+    assert!(persistence::decode(&duplicate, &example_path()).is_err());
+    let v2=serde_json::to_string_pretty(&example()).unwrap();
+    let duplicate=v2.replacen("\"attack\":", "\"attack\": 10, \"\\u0061ttack\":", 1);
+    assert_ne!(v2,duplicate);
+    assert!(persistence::decode(&duplicate,&example_path()).is_err());
+}
+
+#[test]
+fn v5_envelope_accepts_a_valid_score_and_master() {
+    let score = serde_json::to_string(&example()).unwrap();
+    let text = format!(r#"{{"format":"alive-session-v5","score":{score},"master":{{"gain":0.5}}}}"#);
+    assert!(persistence::decode(&text, &example_path()).is_ok());
+}
+
+fn master_fixture(name: &str) -> std::path::PathBuf {
+    Path::new(env!("CARGO_MANIFEST_DIR")).join("../../../docs/contracts/alive-master-v1-fixtures").join(name)
+}
+
+#[test]
+fn master_contract_raw_fixtures_decode_strictly() {
+    for (name, gain) in [("v5-v2.json",1.),("v5-v3.json",1.),("v5-v4.json",1.),
+        ("v5-v3-eight.json",1.),("gain-0.json",0.),("gain-0.5.json",0.5),
+        ("gain-1.json",1.),("gain-4.json",4.)] {
+        let path=master_fixture(name);
+        let saved=persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).unwrap();
+        assert_eq!(saved.master.gain,gain,"{name}");
+        assert_eq!(saved.wire,SaveWire::V5,"{name}");
+        if name=="v5-v3-eight.json" {assert_eq!(saved.score.tracks().len(),8);}
+    }
+    for name in ["legacy-v1.json","legacy-v2.json","legacy-v3.json","legacy-v4.json"] {
+        let path=master_fixture(name);
+        let saved=persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).unwrap();
+        assert_eq!(saved.master.gain,1.,"{name}");assert_eq!(saved.wire,SaveWire::LegacyScore,"{name}");
+    }
+    for name in ["invalid-duplicate-outer-master.json","invalid-duplicate-parameter-v4.json",
+        "invalid-duplicate-parameter-v3.json","invalid-duplicate-parameter-v2.json","invalid-nonfinite.json",
+        "invalid-malformed.json","invalid-trailing.json","invalid-duplicate-score.json",
+        "invalid-duplicate-master.json","invalid-duplicate-outer.json","invalid-over.json",
+        "invalid-negative.json","invalid-string.json","invalid-unknown.json","invalid-missing.json",
+        "invalid-nested-v5.json","invalid-nested-v1.json"] {
+        let path=master_fixture(name);
+        assert!(persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).is_err(),"{name}");
+    }
+}
+
+#[test]
+fn master_decode_enforces_complete_file_limit() {
+    let path=master_fixture("v5-v2.json");let mut text=std::fs::read_to_string(&path).unwrap();
+    text.push_str(&" ".repeat(1_048_576-text.len()));
+    assert!(persistence::decode(&text,&path).is_ok());
+    text.push(' ');assert!(persistence::decode(&text,&path).unwrap_err().contains("1 MiB"));
+}
+
+#[test]
+fn master_read_checks_byte_limit_before_utf8_decoding() {
+    let path=std::env::temp_dir().join(format!("alive-master-invalid-utf8-{}.alive",std::process::id()));
+    let mut bytes=vec![b' ';1_048_576];bytes.push(0xc3);
+    std::fs::write(&path,bytes).unwrap();
+    let error=read(&path).unwrap_err();std::fs::remove_file(path).unwrap();
+    assert!(error.contains("1 MiB"),"{error}");
+}
+
+#[test]
+fn master_serialization_limit_includes_final_newline() {
+    let mut saved=test_saved(example());saved.wire=SaveWire::V5;
+    saved.score.legacy_mut().unwrap().title.clear();
+    let base=persistence::serialize_saved(&saved).unwrap().len();
+    saved.score.legacy_mut().unwrap().title="x".repeat(1_048_576-base);
+    let bytes=persistence::serialize_saved(&saved).unwrap();
+    assert_eq!(bytes.len(),1_048_576);assert_eq!(bytes.last(),Some(&b'\n'));
+    saved.score.legacy_mut().unwrap().title.push('x');
+    assert!(persistence::serialize_saved(&saved).unwrap_err().contains("1 MiB"));
+}
+
+#[test]
+fn master_roundtrip_rebases_and_preserves_complete_wrapper() {
+    let origin=master_fixture("v5-v3.json");
+    let mut source=persistence::decode(&std::fs::read_to_string(&origin).unwrap(),&origin).unwrap();source.master.gain=0.5;
+    let root=std::env::temp_dir().join(format!("alive-master-save-{}",std::process::id()));
+    std::fs::create_dir_all(&root).unwrap();
+    let (path,saved)=persistence::save_document(&root.join("moved.alive"),&source,&origin).unwrap();
+    let reopened=persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).unwrap();
+    assert_eq!(reopened,saved);assert_eq!(saved.master,source.master);assert_eq!(saved.wire,SaveWire::V5);
+    assert_eq!(prepare::prepare_device(saved.score.tracks()[0].instrument().unwrap(),&path,0).unwrap().path,
+        prepare::prepare_device(source.score.tracks()[0].instrument().unwrap(),&origin,0).unwrap().path);
+    std::fs::remove_dir_all(root).unwrap();
+}
+
+#[test]
+fn master_roundtrips_every_score_variant_including_eight_tracks() {
+    let root=std::env::temp_dir().join(format!("alive-master-variants-{}",std::process::id()));
+    std::fs::create_dir_all(&root).unwrap();
+    for name in ["v5-v2.json","v5-v3.json","v5-v4.json","v5-v3-eight.json"] {
+        let origin=master_fixture(name);let mut saved=persistence::decode(&std::fs::read_to_string(&origin).unwrap(),&origin).unwrap();
+        saved.master.gain=4.;let path=root.join(name);
+        let (path,rebased)=persistence::save_document(&path,&saved,&origin).unwrap();
+        let reopened=persistence::decode(&std::fs::read_to_string(&path).unwrap(),&path).unwrap();
+        assert_eq!(reopened,rebased,"{name}");assert_eq!(reopened.score.tracks().len(),saved.score.tracks().len());
+    }
+    std::fs::remove_dir_all(root).unwrap();
+}
+
+#[test]
+fn master_preflight_accepts_nonunity_with_native_capability() {
+    let mut candidate=read(&example_path()).unwrap();
+    candidate.saved.master.gain=0.5;
+    assert!(native::master_capability().is_some());
+    assert!(host::Host::preflight_master(&candidate).is_ok());
+}
+
+#[test]
+fn master_host_install_publishes_saved_gain_before_audio() {
+    if native_master::fresh_process("session::tests::master_host_install_publishes_saved_gain_before_audio"){return;}
+    let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+    let mut candidate=read(&example_path()).unwrap();candidate.saved.master.gain=0.5;
+    let mut host=host::Host::default();host.install(candidate).unwrap();
+    let capability=native::master_capability().unwrap();let mut score=native::StateV2::default();
+    let mut master=native_master::State::output();
+    assert_eq!(unsafe{(capability.snapshot_v2)((&mut score as *mut native::StateV2).cast(),&mut master)},1);
+    assert_eq!(master.current_gain,0.5);assert_eq!(master.target_gain,0.5);assert_ne!(master.applied_serial,0);
+    assert_eq!(master.applied_frame,score.absolute_frame);
+    unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+}
+
+#[test]
+fn master_old_library_unity_install_and_nonunity_preflight() {
+    if std::env::var_os("ALIVE_MASTER_EXPECT_UNAVAILABLE").is_none(){return;}
+    if native_master::fresh_process("session::tests::master_old_library_unity_install_and_nonunity_preflight"){return;}
+    let _native_guard=crate::tests::NATIVE_FFI_TEST_LOCK.lock().unwrap();
+    assert!(native::master_capability().is_none());
+    let candidate=read(&example_path()).unwrap();let mut host=host::Host::default();
+    assert_eq!(host.install(candidate.clone()).unwrap(),0);assert_eq!(native::state().unwrap().configured,1);
+    let mut nonunity=candidate;nonunity.saved.master.gain=0.5;
+    let revision=host.preparation_revision;
+    assert!(host.install(nonunity).unwrap_err().contains("Master gain"));assert_eq!(host.preparation_revision,revision);
+    unsafe{native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
+}
+
+#[test]
+fn master_nonunity_host_install_refuses_before_native_replacement() {
+    let original=read(&example_path()).unwrap();
+    let mut candidate=original.clone();candidate.saved.master.gain=0.5;candidate.saved.wire=SaveWire::V5;
+    let mut host=host::Host::default();host.prepared=Some(original.clone());
+    let revision=host.preparation_revision;
+    assert!(host::Host::preflight_master_with_capability(&candidate,false).unwrap_err().contains("Master gain"));
+    assert_eq!(host.preparation_revision,revision);
+    assert_eq!(host.prepared.unwrap().saved,original.saved);
+}
+
+#[test]
+fn master_wire_save_and_failure_preserve_the_owner() {
+    let prepared=read(&example_path()).unwrap();
+    let root=std::env::temp_dir().join(format!("alive-master-wire-{}",std::process::id()));
+    std::fs::create_dir_all(&root).unwrap();
+    let old=prepared.saved.clone();
+    let (path,saved)=persistence::save_document(&root.join("old.alive"),&old,&prepared.origin).unwrap();
+    assert_eq!(saved.wire,SaveWire::LegacyScore);
+    assert_ne!(serde_json::from_str::<serde_json::Value>(&std::fs::read_to_string(&path).unwrap()).unwrap()["format"],"alive-session-v5");
+    let mut v5=old.clone();v5.wire=SaveWire::V5;
+    let (path,saved)=persistence::save_document(&root.join("new.alive"),&v5,&prepared.origin).unwrap();
+    assert_eq!(saved.wire,SaveWire::V5);
+    assert_eq!(persistence::decode(&std::fs::read_to_string(path).unwrap(),&root.join("new.alive")).unwrap().wire,SaveWire::V5);
+    let before=v5.clone();let mut invalid=v5.clone();invalid.master.gain=f64::NAN;
+    assert!(persistence::save_document(&root.join("invalid.alive"),&invalid,&prepared.origin).is_err());
+    let blocked=root.join("directory.alive");std::fs::create_dir(&blocked).unwrap();
+    assert!(persistence::save_document(&blocked,&v5,&prepared.origin).is_err());
+    assert_eq!(v5,before);assert!(blocked.is_dir());
+    std::fs::remove_dir_all(root).unwrap();
 }
 
 #[test]
 fn active_v4_decode_roundtrip_preserves_sources_and_occurrences() {
     let project = workspaces::prospective_from_document(&example()).unwrap();
     let text = workspaces::encode(&project).unwrap();
-    let document = persistence::decode(&text, &example_path()).unwrap();
+    let document = persistence::decode(&text, &example_path()).unwrap().score;
     assert_eq!(serde_json::to_value(&document).unwrap(), serde_json::to_value(&project).unwrap());
     let duplicate = text.replacen("\"tempo\":", "\"tempo\": 120, \"tempo\":", 1);
     assert!(persistence::decode(&duplicate, &example_path()).unwrap_err().contains("Duplicate"));
@@ -52,10 +237,10 @@ fn active_v4_preparation_compiles_shared_sources_once() {
     let mut shared = project.tracks[0].slots[0].clone().unwrap();
     shared.id = "shared-second-slot".into();
     project.tracks[0].slots[1] = Some(shared);
-    let base = prepare(&example(), &example_path()).unwrap();
-    let prepared = prepare(&Document::WorkspacesV4(project.clone()), &example_path()).unwrap();
+    let base = prepare_score_fixture(&example(), &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&Document::WorkspacesV4(project.clone()), &example_path()).unwrap();
     assert_eq!(prepared.events.len(), base.events.len());
-    assert_eq!(prepared.document, Document::WorkspacesV4(project));
+    assert_eq!(prepared.saved.score, Document::WorkspacesV4(project));
     assert_eq!(prepared.tracks.len(), 2);
     assert_eq!(prepared.devices.len(), 2);
     let mut ordered=prepared.events.clone();
@@ -70,7 +255,7 @@ fn active_v4_preparation_rejects_audio_before_reading_dependencies() {
     let mut project = workspaces::prospective_from_document(&example()).unwrap();
     project.sources.clear();project.placements.clear();
     for track in &mut project.tracks {track.chain=workspaces::ChainV4::Audio{};track.effects.clear();track.slots=[None,None,None,None];}
-    let error=prepare(&Document::WorkspacesV4(project), &example_path()).unwrap_err();
+    let error=prepare_score_fixture(&Document::WorkspacesV4(project), &example_path()).unwrap_err();
     assert!(error.contains("Audio sources are unavailable"),"{error}");
 }
 
@@ -116,7 +301,7 @@ fn v3_eight_track_host_roundtrip_and_mixer() {
         return;
     }
     let document = capacity_document();
-    let prepared = prepare(&document, &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&document, &example_path()).unwrap();
     assert_eq!((prepared.tracks.len(), prepared.devices.len(), prepared.events.len()), (8, 16, 32));
     let mut host = host::Host::default();
     host.install(prepared).unwrap();
@@ -139,16 +324,16 @@ fn v3_eight_track_host_roundtrip_and_mixer() {
     assert!(left[..31].iter().all(|sample| sample.is_finite()));
     let folder = std::env::temp_dir().join(format!("alive-capacity-host-{}", std::process::id()));
     std::fs::create_dir_all(&folder).unwrap();
-    let saved = save(&folder.join("eight.alive"), &host.prepared.as_ref().unwrap().document, &example_path()).unwrap();
+    let saved = super::save(&folder.join("eight.alive"), &host.prepared.as_ref().unwrap().saved, &example_path()).unwrap();
     let reopened = read(&saved).unwrap();
-    assert_eq!(reopened.document.legacy().unwrap().tracks[7].id, "capacity-track-7");
-    assert!(reopened.document.legacy().unwrap().tracks[3].mute && reopened.document.legacy().unwrap().tracks[7].solo);
-    assert_eq!(reopened.document.banks(), host.prepared.as_ref().unwrap().document.banks());
+    assert_eq!(reopened.saved.score.legacy().unwrap().tracks[7].id, "capacity-track-7");
+    assert!(reopened.saved.score.legacy().unwrap().tracks[3].mute && reopened.saved.score.legacy().unwrap().tracks[7].solo);
+    assert_eq!(reopened.saved.score.banks(), host.prepared.as_ref().unwrap().saved.score.banks());
     let mut excess = document.clone();
     let mut extra = excess.legacy().unwrap().tracks[0].effects[0].clone(); extra.instance_id = "seventeenth-root".into();
     excess.legacy_mut().unwrap().tracks[4].effects.push(extra);
     for track in &mut excess.legacy_mut().unwrap().tracks { for device in track.devices_mut() { device.path = "/missing-capacity-dependency.ultra".into(); } }
-    assert!(prepare(&excess, &example_path()).unwrap_err().contains("sixteen native roots"));
+    assert!(prepare_score_fixture(&excess, &example_path()).unwrap_err().contains("sixteen native roots"));
     unsafe { native::alive_session_stop_v3(); native::ultra_audio_stop(); native::alive_session_reset();
              for slot in 0..16 { crate::ultra_canvas_close_document(slot); } }
     std::fs::remove_dir_all(folder).unwrap();
@@ -167,7 +352,7 @@ fn v3_strict_wire_migration_and_roundtrip_preserve_score_identity() {
     assert_eq!(wire["tracks"][0]["slots"][0]["notes"][0]["id"], "note-b81cb31228756f6d8c9d9d538eceec38");
     assert_eq!(clips, legacy.to_clips().unwrap());
     let encoded = serde_json::to_string(&clips).unwrap();
-    assert_eq!(persistence::decode(&encoded, &example_path()).unwrap(), clips);
+    assert_eq!(persistence::decode(&encoded, &example_path()).unwrap().score, clips);
     for field in ["defaultClipId", "slots"] {
         let mut bad = wire.clone(); bad["tracks"][0].as_object_mut().unwrap().remove(field);
         assert!(persistence::decode(&bad.to_string(), &example_path()).is_err());
@@ -190,12 +375,12 @@ fn v3_compiles_independent_clip_ranges_and_empty_lane_ownership() {
     for n in &mut copied.notes{n.id=format!("copy-{}",n.id);}
     for lane in &mut copied.automation{lane.points.clear();}
     bank.slots[2]=Some(copied);bank.default_clip_id=None;
-    let prepared=prepare(&document,&example_path()).unwrap();
+    let prepared=prepare_score_fixture(&document,&example_path()).unwrap();
     let Schedule::Clips(clips)=&prepared.schedule else {panic!("expected clips")};
     assert_eq!(clips.len(),3);assert_eq!(clips[1].slot,2);assert_eq!(clips[1].id,"copy");
     assert_eq!(clips[1].length_frames,768000);assert!(clips[1].owned_masks.iter().any(|m|*m!=0));
     assert_eq!(clips[1].event_begin,clips[0].event_begin+clips[0].event_count);
-    assert_eq!(prepared.document,document);
+    assert_eq!(prepared.saved.score,document);
 }
 
 #[test]
@@ -218,9 +403,9 @@ fn v3_strict_ids_disabled_aggregate_and_source_free_range_rejections(){
 fn v3_save_as_preserves_bank_ids_beats_defaults_and_source_hashes(){
     let mut document=example().to_clips().unwrap();let id=document.legacy().unwrap().tracks[0].id.clone();document.bank_mut(&id).unwrap().slots[0].as_mut().unwrap().notes[0].beat=0.03125;document.legacy_mut().unwrap().tracks[0].gain=0.43;
     let folder=std::env::temp_dir().join(format!("alive-v3-roundtrip-{}",std::process::id()));std::fs::create_dir_all(folder.join("nested")).unwrap();
-    let (path,saved)=persistence::save_document(&folder.join("nested/session.alive"),&document,&example_path()).unwrap();let reopened=read(&path).unwrap();
-    assert!(reopened.document.is_clips());assert_eq!(saved.banks(),document.banks());assert_eq!(reopened.document.banks(),document.banks());
-    assert_eq!(saved.legacy().unwrap().tracks[0].device.source_sha256,document.legacy().unwrap().tracks[0].device.source_sha256);assert_eq!(saved.legacy().unwrap().tracks[0].device.parameters,document.legacy().unwrap().tracks[0].device.parameters);assert_eq!(saved.legacy().unwrap().tracks[0].gain,0.43);
+    let (path,saved)=persistence::save_document(&folder.join("nested/session.alive"),&test_saved(document.clone()),&example_path()).unwrap();let reopened=read(&path).unwrap();
+    assert!(reopened.saved.score.is_clips());assert_eq!(saved.score.banks(),document.banks());assert_eq!(reopened.saved.score.banks(),document.banks());
+    assert_eq!(saved.score.legacy().unwrap().tracks[0].device.source_sha256,document.legacy().unwrap().tracks[0].device.source_sha256);assert_eq!(saved.score.legacy().unwrap().tracks[0].device.parameters,document.legacy().unwrap().tracks[0].device.parameters);assert_eq!(saved.score.legacy().unwrap().tracks[0].gain,0.43);
     std::fs::remove_dir_all(folder).unwrap();
 }
 
@@ -230,7 +415,7 @@ fn saved_session_resolves_two_real_independent_device_references() {
     assert_eq!(session.legacy().unwrap().tracks.len(), 2);
     assert_ne!(session.legacy().unwrap().tracks[0].id, session.legacy().unwrap().tracks[1].id);
     assert_eq!(session.legacy().unwrap().tracks[0].device.path, session.legacy().unwrap().tracks[1].device.path);
-    let prepared = prepare(&session, &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&session, &example_path()).unwrap();
     assert_eq!(prepared.devices[prepared.tracks[0].midi_instrument().unwrap()].manifest.id, "org.alive.subtractive");
     assert_ne!(prepared.devices[prepared.tracks[0].midi_instrument().unwrap()].manifest.parameters.last().unwrap().base,
         prepared.devices[prepared.tracks[1].midi_instrument().unwrap()].manifest.parameters.last().unwrap().base);
@@ -243,14 +428,14 @@ fn session_v1_rejects_effects_with_an_explicit_chain_runtime_error() {
     reference.path="../../ultra/examples/utility.ultra".into();reference.id="org.alive.utility".into();reference.version=2;
     reference.parameters.clear();
     reference.source_sha256 = prepare::fingerprint(&crate::documents::read_patch(&example_path().parent().unwrap().join(&reference.path)).unwrap().patch.unwrap()).unwrap();
-    let error=prepare(&session,&example_path()).unwrap_err();
+    let error=prepare_score_fixture(&session,&example_path()).unwrap_err();
     assert!(error.contains("instruments only")&&error.contains("chain runtime")&&error.contains("Pulse"),"{error}");
 }
 
 #[test]
 fn session_v1_accepts_version_two_instruments_and_checks_declared_version() {
     let mut session=example();
-    let original=prepare(&session,&example_path()).unwrap();
+    let original=prepare_score_fixture(&session,&example_path()).unwrap();
     let mut patch=original.devices[original.tracks[0].midi_instrument().unwrap()].patch.clone();
     let device=&mut patch["device"];device["version"]=serde_json::json!(2);device["kind"]=serde_json::json!("instrument");
     device["midi"]=serde_json::json!({"input":device["midi"].clone(),"output":null});
@@ -259,9 +444,9 @@ fn session_v1_accepts_version_two_instruments_and_checks_declared_version() {
     std::fs::write(&path,serde_json::to_vec(&patch).unwrap()).unwrap();
     session.legacy_mut().unwrap().tracks[0].device.path=path.to_string_lossy().into_owned();session.legacy_mut().unwrap().tracks[0].device.version=2;
     session.legacy_mut().unwrap().tracks[0].device.source_sha256 = prepare::fingerprint(&patch).unwrap();
-    assert!(prepare(&session,&example_path()).is_ok());
+    assert!(prepare_score_fixture(&session,&example_path()).is_ok());
     session.legacy_mut().unwrap().tracks[0].device.version=1;
-    assert!(prepare(&session,&example_path()).unwrap_err().contains("version mismatch"));
+    assert!(prepare_score_fixture(&session,&example_path()).unwrap_err().contains("version mismatch"));
     std::fs::remove_file(path).unwrap();
 }
 
@@ -276,7 +461,7 @@ fn frame_conversion_orders_off_automation_on_and_preserves_required_offsets() {
         Note { beat: 64. / 24000., duration: 64. / 24000., pitch: 60, velocity: 90 }];
     track.automation = vec![Lane { instance_id: track.device.instance_id.clone(), key: "cutoff".into(), enabled: true,
         points: [0, 1, 31, 63, 64, 127].iter().map(|&frame| Point { beat: frame as f64 / 24000., value: 1000. }).collect() }];
-    let prepared = prepare(&session, &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&session, &example_path()).unwrap();
     let offsets: Vec<_> = prepared.events.iter().filter(|e| e.kind == 1).map(|e| e.frame).collect();
     assert_eq!(offsets, [0, 1, 31, 63, 64, 127]);
     assert_eq!(prepared.events.iter().filter(|e| e.frame == 64).map(|e| e.kind).collect::<Vec<_>>(), [0, 1, 2]);
@@ -288,17 +473,17 @@ fn frame_collision_voice_release_ambiguity_and_loop_seam_overload_are_rejected()
     let mut session = example();
     let duplicate = session.legacy().unwrap().tracks[0].notes[0].clone();
     session.legacy_mut().unwrap().tracks[0].notes.push(duplicate);
-    assert!(prepare(&session, &example_path()).unwrap_err().contains("Overlapping"));
+    assert!(prepare_score_fixture(&session, &example_path()).unwrap_err().contains("Overlapping"));
     let mut session = example();
     session.legacy_mut().unwrap().tracks[0].automation[0].points[1].beat = 0.00000001;
-    assert!(prepare(&session, &example_path()).unwrap_err().contains("distinct audio frames"));
+    assert!(prepare_score_fixture(&session, &example_path()).unwrap_err().contains("distinct audio frames"));
     let mut session = example();
     session.legacy_mut().unwrap().tempo = 240.;
     session.legacy_mut().unwrap().length_beats = 1. / 64.; // 188 frames, repeated six times per callback.
     session.legacy_mut().unwrap().tracks.truncate(1);
     session.legacy_mut().unwrap().tracks[0].automation.clear();
     session.legacy_mut().unwrap().tracks[0].notes = (0..8).map(|pitch| Note { beat: 0., duration: 0.005, pitch: 60 + pitch, velocity: 100 }).collect();
-    assert!(prepare(&session, &example_path()).unwrap_err().contains("overload"));
+    assert!(prepare_score_fixture(&session, &example_path()).unwrap_err().contains("overload"));
 }
 
 #[test]
@@ -310,7 +495,7 @@ fn session_roundtrip_preserves_notes_automation_and_mixer() {
     session.legacy_mut().unwrap().tracks[0].notes[0].duration = 0.375;
     let encoded = serde_json::to_vec(&session).unwrap();
     assert_eq!(serde_json::from_slice::<Session>(&encoded).unwrap(), session);
-    assert!(prepare(&session, &example_path()).is_ok());
+    assert!(prepare_score_fixture(&session, &example_path()).is_ok());
 }
 
 #[test]
@@ -318,12 +503,12 @@ fn missing_and_incompatible_devices_identify_track_and_preserve_input() {
     let mut missing = example();
     missing.legacy_mut().unwrap().tracks[1].device.path = "missing.ultra".into();
     let before = missing.clone();
-    let error = prepare(&missing, &example_path()).unwrap_err();
+    let error = prepare_score_fixture(&missing, &example_path()).unwrap_err();
     assert!(error.contains("Harmony") && error.contains("missing.ultra"), "{error}");
     assert_eq!(missing, before);
     let mut incompatible = example();
     incompatible.legacy_mut().unwrap().tracks[0].device.version = 2;
-    let error = prepare(&incompatible, &example_path()).unwrap_err();
+    let error = prepare_score_fixture(&incompatible, &example_path()).unwrap_err();
     assert!(error.contains("Pulse") && error.contains("version"), "{error}");
 }
 
@@ -339,7 +524,7 @@ fn rejects_invalid_schedule_and_parameter_binding_before_admission() {
     ] {
         let mut session = example();
         mutate(&mut session);
-        assert!(prepare(&session, &example_path()).is_err());
+        assert!(prepare_score_fixture(&session, &example_path()).is_err());
     }
 }
 
@@ -351,16 +536,16 @@ fn save_as_rebases_references_and_failed_save_retains_file() {
     let mut session = example();
     session.legacy_mut().unwrap().tracks[0].gain = 0.432;
     session.legacy_mut().unwrap().tracks[1].device.parameters.insert("cutoff".into(), 1999.);
-    save(&path, &session, &example_path()).unwrap();
+    save_score_fixture(&path, &session, &example_path()).unwrap();
     let loaded = read(&path).unwrap();
-    assert_eq!(loaded.document.legacy().unwrap().tracks[0].gain, 0.432);
-    assert_eq!(loaded.document.legacy().unwrap().tracks[1].device.parameters["cutoff"], 1999.);
-    assert_eq!(loaded.document.legacy().unwrap().tracks[0].notes, session.legacy().unwrap().tracks[0].notes);
-    assert_eq!(loaded.document.legacy().unwrap().tracks[1].automation, session.legacy().unwrap().tracks[1].automation);
-    assert_eq!(loaded.devices[loaded.tracks[0].midi_instrument().unwrap()].path, { let p = prepare(&session, &example_path()).unwrap(); p.devices[p.tracks[0].midi_instrument().unwrap()].path.clone() });
+    assert_eq!(loaded.saved.score.legacy().unwrap().tracks[0].gain, 0.432);
+    assert_eq!(loaded.saved.score.legacy().unwrap().tracks[1].device.parameters["cutoff"], 1999.);
+    assert_eq!(loaded.saved.score.legacy().unwrap().tracks[0].notes, session.legacy().unwrap().tracks[0].notes);
+    assert_eq!(loaded.saved.score.legacy().unwrap().tracks[1].automation, session.legacy().unwrap().tracks[1].automation);
+    assert_eq!(loaded.devices[loaded.tracks[0].midi_instrument().unwrap()].path, { let p = prepare_score_fixture(&session, &example_path()).unwrap(); p.devices[p.tracks[0].midi_instrument().unwrap()].path.clone() });
     let previous = std::fs::read(&path).unwrap();
     session.legacy_mut().unwrap().tracks[0].device.path = "missing.ultra".into();
-    assert!(save(&path, &session, &example_path()).is_err());
+    assert!(save_score_fixture(&path, &session, &example_path()).is_err());
     assert_eq!(std::fs::read(&path).unwrap(), previous);
     assert!(read(&path).is_ok());
     std::fs::remove_dir_all(folder).unwrap();
@@ -369,10 +554,10 @@ fn save_as_rebases_references_and_failed_save_retains_file() {
 #[test]
 fn save_cannot_replace_source_device_or_accept_oversized_file() {
     let session = example();
-    let prepared = prepare(&session, &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&session, &example_path()).unwrap();
     let source = &prepared.devices[prepared.tracks[0].midi_instrument().unwrap()].path;
     let original = std::fs::read(source).unwrap();
-    assert!(save(source, &session, &example_path()).is_err());
+    assert!(save_score_fixture(source, &session, &example_path()).is_err());
     assert_eq!(std::fs::read(source).unwrap(), original);
     let oversized = std::env::temp_dir().join(format!("alive-oversized-{}.alive", std::process::id()));
     std::fs::write(&oversized, vec![b' '; 1024 * 1024 + 1]).unwrap();
@@ -388,10 +573,10 @@ fn saving_through_a_session_symlink_keeps_dependency_paths_relative_to_target()
     let target_folder = folder.join("deep/target");
     std::fs::create_dir_all(&target_folder).unwrap();
     let target = target_folder.join("target.alive");
-    save(&target, &example(), &example_path()).unwrap();
+    save_score_fixture(&target, &example(), &example_path()).unwrap();
     let link = folder.join("linked.alive");
     symlink(&target, &link).unwrap();
-    save(&link, &example(), &example_path()).unwrap();
+    save_score_fixture(&link, &example(), &example_path()).unwrap();
     assert!(read(&target).is_ok(), "Saving through a link rebased devices against the link's folder");
     assert!(link.is_symlink());
     std::fs::remove_dir_all(folder).unwrap();
@@ -446,14 +631,14 @@ fn v3_scene_is_one_native_queue_entry_with_prepared_member_identities() {
         assert!(child.status.success(),"{}\n{}",String::from_utf8_lossy(&child.stdout),String::from_utf8_lossy(&child.stderr));return;
     }
     let mut host=host::Host::default();let p=host.enable_clips(read(&example_path()).unwrap()).unwrap();host.install(p).unwrap();
-    let before=serde_json::to_value(&host.prepared.as_ref().unwrap().document).unwrap();
+    let before=serde_json::to_value(&host.prepared.as_ref().unwrap().saved.score).unwrap();
     let mut runtime=runtime::Runtime::default();assert_eq!(unsafe{native::ultra_external_start()},1);
     for _ in 0..63 {assert_eq!(unsafe{native::alive_session_mixer(0,1.,0,0)},1);}
     let scene=runtime.scene(&host,0).unwrap();assert_eq!(scene.status,"queued");assert_eq!(scene.request_serial,"1");
     assert_eq!(scene.track_mask,3);assert_eq!(scene.scene_slot,Some(0));assert_eq!(scene.members.len(),2);
     for (index,member) in scene.members.iter().enumerate(){
-        let track=&host.prepared.as_ref().unwrap().document.legacy().unwrap().tracks[index];
-        assert_eq!(member.track_id,track.id);assert_eq!(member.clip_id,host.prepared.as_ref().unwrap().document.bank(&track.id).unwrap().default_clip_id);
+        let track=&host.prepared.as_ref().unwrap().saved.score.legacy().unwrap().tracks[index];
+        assert_eq!(member.track_id,track.id);assert_eq!(member.clip_id,host.prepared.as_ref().unwrap().saved.score.bank(&track.id).unwrap().default_clip_id);
         assert_eq!(member.action,"launch");assert_eq!(member.status,"queued");
     }
     let refused=runtime.scene(&host,3).unwrap();assert_eq!(refused.status,"rejected");assert_eq!(refused.reason,7);assert_eq!(refused.rejected_mask,3);
@@ -463,7 +648,7 @@ fn v3_scene_is_one_native_queue_entry_with_prepared_member_identities() {
     let empty=runtime.scene(&host,3).unwrap();assert_eq!(empty.members.iter().map(|m|m.action.as_str()).collect::<Vec<_>>(),vec!["stop","stop"]);
     assert_eq!(unsafe{native::ultra_external_render(64,left.as_mut_ptr(),right.as_mut_ptr())},1);
     let (_,view)=runtime.poll(&host).unwrap();let view=view.unwrap();let requests=view["requests"].as_array().unwrap();assert_eq!(requests.last().unwrap()["appliedMask"],3);
-    assert_eq!(serde_json::to_value(&host.prepared.as_ref().unwrap().document).unwrap(),before);
+    assert_eq!(serde_json::to_value(&host.prepared.as_ref().unwrap().saved.score).unwrap(),before);
     unsafe{native::ultra_audio_stop();native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}
 }
 
@@ -474,8 +659,8 @@ fn v3_native_host_defaults_requests_and_graph_fallback_are_real() {
         let child=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",NAME,"--nocapture"]).env("ALIVE_V3_HOST_CHILD","1").env_remove("DISPLAY").env_remove("WAYLAND_DISPLAY").output().unwrap();
         assert!(child.status.success(),"{}\n{}",String::from_utf8_lossy(&child.stdout),String::from_utf8_lossy(&child.stderr));return;
     }
-    let mut host=host::Host::default();let upgraded=host.enable_clips(read(&example_path()).unwrap()).unwrap();assert!(upgraded.document.is_clips(),"{:?}",upgraded.notice);
-    let default=upgraded.document.bank(&upgraded.document.legacy().unwrap().tracks[0].id).unwrap().default_clip_id.clone();host.install(upgraded).unwrap();
+    let mut host=host::Host::default();let upgraded=host.enable_clips(read(&example_path()).unwrap()).unwrap();assert!(upgraded.saved.score.is_clips(),"{:?}",upgraded.notice);
+    let default=upgraded.saved.score.bank(&upgraded.saved.score.legacy().unwrap().tracks[0].id).unwrap().default_clip_id.clone();host.install(upgraded).unwrap();
     let mut raw=native::StateV3::default();assert_eq!(unsafe{native::alive_session_state_v3(&mut raw)},1);assert_eq!(raw.playing,0);assert_eq!(raw.tracks[0].active_clip,0);assert_eq!(raw.tracks[0].phase,0);assert!(default.is_some());
     let mut runtime=runtime::Runtime::default();let mut request=native::RequestV3::default();request.kind=native::V3_START;
     assert_eq!(unsafe{native::ultra_external_start()},1);let receipt=runtime.request(&host,request,None,None).unwrap();assert_eq!(receipt.status,"queued");
@@ -488,15 +673,15 @@ fn v3_native_host_defaults_requests_and_graph_fallback_are_real() {
     for preset in patch["device"]["presets"].as_array_mut().unwrap(){preset["values"]["demo"]=serde_json::json!(0);}
     let path=folder.join("toggle-binding.ultra");std::fs::write(&path,serde_json::to_vec(&patch).unwrap()).unwrap();
     old.legacy_mut().unwrap().tracks[0].device.path=path.to_string_lossy().into_owned();old.legacy_mut().unwrap().tracks[0].device.source_sha256=prepare::fingerprint(&patch).unwrap();
-    let candidate=prepare(&old,&example_path()).unwrap();host.validate(&candidate).unwrap();
-    let mut explicit=candidate.clone();explicit.document=explicit.document.to_clips().unwrap();let doc=explicit.document.clone();prepare::compile_clips(&doc,&mut explicit).unwrap();
+    let candidate=prepare_score_fixture(&old,&example_path()).unwrap();host.validate(&candidate).unwrap();
+    let mut explicit=candidate.clone();explicit.saved.score=explicit.saved.score.to_clips().unwrap();let doc=explicit.saved.score.clone();prepare::compile_clips(&doc,&mut explicit).unwrap();
     assert_eq!(host.admit(&explicit).err().unwrap().code,native::V3_GRAPH_REJECTED);assert!(host.enable_clips(explicit).is_err());
-    let retained=host.enable_clips(candidate).unwrap();assert!(!retained.document.is_clips());assert!(retained.notice.as_ref().unwrap().contains("graph policy"));assert_eq!(retained.document.legacy().unwrap().tracks[0].notes,old.legacy().unwrap().tracks[0].notes);
+    let retained=host.enable_clips(candidate).unwrap();assert!(!retained.saved.score.is_clips());assert!(retained.notice.as_ref().unwrap().contains("graph policy"));assert_eq!(retained.saved.score.legacy().unwrap().tracks[0].notes,old.legacy().unwrap().tracks[0].notes);
     let mut dense=example();dense.legacy_mut().unwrap().tempo=120.;dense.legacy_mut().unwrap().length_beats=4.;
     for (i,t) in dense.legacy_mut().unwrap().tracks.iter_mut().enumerate(){t.automation.clear();t.notes=(40..60).map(|pitch|Note{beat:i as f64,duration:0.01,pitch,velocity:80}).collect();}
-    let density=host.enable_clips(prepare(&dense,&example_path()).unwrap()).unwrap();assert!(!density.document.is_clips(),"Expected conservative phase combination refusal");assert_eq!(density.document.legacy().unwrap().tracks[1].notes,dense.legacy().unwrap().tracks[1].notes);assert!(density.notice.as_ref().unwrap().contains("Conservative"));
+    let density=host.enable_clips(prepare_score_fixture(&dense,&example_path()).unwrap()).unwrap();assert!(!density.saved.score.is_clips(),"Expected conservative phase combination refusal");assert_eq!(density.saved.score.legacy().unwrap().tracks[1].notes,dense.legacy().unwrap().tracks[1].notes);assert!(density.notice.as_ref().unwrap().contains("Conservative"));
     host.install(retained).unwrap();assert_eq!(unsafe{native::ultra_external_start()},1);assert_eq!(unsafe{native::alive_session_start()},1);assert_eq!(unsafe{native::ultra_external_render(512,left.as_mut_ptr(),right.as_mut_ptr())},1);assert_eq!(native::state().unwrap().playing,1);
-    let p=host.prepared.as_ref().unwrap();let saved=save(&folder.join("retained.alive"),&p.document,&p.origin).unwrap();assert!(!read(&saved).unwrap().document.is_clips());
+    let p=host.prepared.as_ref().unwrap();let saved=super::save(&folder.join("retained.alive"),&p.saved,&p.origin).unwrap();assert!(!read(&saved).unwrap().saved.score.is_clips());
     unsafe{native::alive_session_stop();native::ultra_audio_stop();native::alive_session_reset();for slot in 0..16{crate::ultra_canvas_close_document(slot);}}std::fs::remove_dir_all(folder).unwrap();
 }
 
@@ -504,7 +689,7 @@ fn v3_native_host_defaults_requests_and_graph_fallback_are_real() {
 fn legacy_read_returns_canonical_v2_with_stable_instance_targets() {
     let first = read(&example_path()).unwrap();
     let second = read(&example_path()).unwrap();
-    let wire = serde_json::to_value(&first.document).unwrap();
+    let wire = serde_json::to_value(&first.saved.score).unwrap();
     assert_eq!(wire["format"], "alive-session-v2");
     assert_eq!(wire["tracks"][0]["effects"], serde_json::json!([]));
     let id = wire["tracks"][0]["device"]["instanceId"].as_str().unwrap();
@@ -512,7 +697,7 @@ fn legacy_read_returns_canonical_v2_with_stable_instance_targets() {
     assert_eq!(id.len(), 39);
     assert_eq!(wire["tracks"][0]["automation"][0]["instanceId"], id);
     assert_eq!(wire["tracks"][0]["device"]["sourceSha256"].as_str().unwrap().len(), 64);
-    assert_eq!(first.document, second.document);
+    assert_eq!(first.saved.score, second.saved.score);
 }
 
 #[test]
@@ -565,18 +750,18 @@ fn saved_effect_order_and_automation_resolve_by_instance_not_chain_index() {
     session.legacy_mut().unwrap().tracks[0].effects[1].parameters.insert("gain".into(), 0.8);
     session.legacy_mut().unwrap().tracks[0].effects[1].bypassed = true;
     session.legacy_mut().unwrap().tracks[0].automation.push(Lane { instance_id: "effect-z".into(), key: "gain".into(), enabled: true, points: vec![Point { beat: 0., value: 0.5 }] });
-    let first = prepare(&session, &example_path()).unwrap();
+    let first = prepare_score_fixture(&session, &example_path()).unwrap();
     let z = first.devices.iter().position(|d| d.instance_id == "effect-z").unwrap();
     assert_eq!(first.tracks[0].effects[0], z);
     assert_eq!(first.devices[z].manifest.parameters[0].base, 0.2);
     assert!(first.events.iter().any(|e| e.device == z as u32 && e.kind == 1 && e.value == 0.5));
     session.legacy_mut().unwrap().tracks[0].effects.reverse();
-    let second = prepare(&session, &example_path()).unwrap();
+    let second = prepare_score_fixture(&session, &example_path()).unwrap();
     assert_eq!(second.tracks[0].effects[1], z);
     assert_eq!(first.events.iter().map(|e| (e.frame,e.device,e.target,e.value)).collect::<Vec<_>>(), second.events.iter().map(|e| (e.frame,e.device,e.target,e.value)).collect::<Vec<_>>());
     let cross = session.legacy().unwrap().tracks[0].automation.last().unwrap().clone();
     session.legacy_mut().unwrap().tracks[1].automation.push(cross);
-    assert!(prepare(&session, &example_path()).unwrap_err().contains("cross-track"));
+    assert!(prepare_score_fixture(&session, &example_path()).unwrap_err().contains("cross-track"));
 }
 
 #[test]
@@ -591,8 +776,8 @@ fn hashes_cover_original_json_before_instance_bases_and_formatting_is_irrelevant
     std::fs::write(&path, serde_json::to_vec(&source).unwrap()).unwrap();
     session.legacy_mut().unwrap().tracks[0].device.path = path.to_string_lossy().into();
     session.legacy_mut().unwrap().tracks[0].device.parameters.insert("cutoff".into(), 1337.);
-    let prepared = prepare(&session, &example_path()).unwrap();
-    let saved = save(&folder.join("saved.alive"), &prepared.document, &example_path()).unwrap();
+    let prepared = prepare_score_fixture(&session, &example_path()).unwrap();
+    let saved = super::save(&folder.join("saved.alive"), &prepared.saved, &example_path()).unwrap();
     std::fs::write(&path, serde_json::to_vec_pretty(&source).unwrap()).unwrap();
     assert!(read(&saved).is_ok());
     let mut changed = source; changed["nodes"][0]["x"] = serde_json::json!(12345);
@@ -611,16 +796,16 @@ fn save_as_relocates_every_effect_and_cannot_overwrite_any_dependency() {
     session.legacy_mut().unwrap().tracks[0].effects = vec![effect("utility", "utility.ultra"),effect("filter", "stereo-lowpass.ultra")];
     let folder = std::env::temp_dir().join(format!("alive-chain-save-{}",std::process::id()));
     std::fs::create_dir_all(&folder).unwrap();
-    let path = save(&folder.join("chain.alive"), &session, &example_path()).unwrap();
+    let path = save_score_fixture(&folder.join("chain.alive"), &session, &example_path()).unwrap();
     let loaded = read(&path).unwrap();
     assert_eq!(loaded.devices.len(),4);
-    assert_eq!(loaded.document.legacy().unwrap().tracks[0].effects.iter().map(|d| (&d.instance_id,&d.source_sha256,d.bypassed)).collect::<Vec<_>>(),session.legacy().unwrap().tracks[0].effects.iter().map(|d| (&d.instance_id,&d.source_sha256,d.bypassed)).collect::<Vec<_>>());
-    for device in &loaded.devices { assert!(device.path.exists()); assert!(save(&device.path,&loaded.document,&path).is_err()); }
+    assert_eq!(loaded.saved.score.legacy().unwrap().tracks[0].effects.iter().map(|d| (&d.instance_id,&d.source_sha256,d.bypassed)).collect::<Vec<_>>(),session.legacy().unwrap().tracks[0].effects.iter().map(|d| (&d.instance_id,&d.source_sha256,d.bypassed)).collect::<Vec<_>>());
+    for device in &loaded.devices { assert!(device.path.exists()); assert!(super::save(&device.path,&loaded.saved,&path).is_err()); }
     let json_dependency=folder.join("effect-source.json");
     let source=std::fs::read(&session.legacy().unwrap().tracks[0].effects[0].path).unwrap();
     std::fs::write(&json_dependency,&source).unwrap();
     session.legacy_mut().unwrap().tracks[0].effects[0].path=json_dependency.to_string_lossy().into();
-    assert!(save(&json_dependency,&session,&example_path()).unwrap_err().contains("cannot replace"));
+    assert!(save_score_fixture(&json_dependency,&session,&example_path()).unwrap_err().contains("cannot replace"));
     assert_eq!(std::fs::read(&json_dependency).unwrap(),source);
     std::fs::remove_dir_all(folder).unwrap();
 }
@@ -630,9 +815,9 @@ fn global_root_and_chain_bounds_reject_before_dependency_reads() {
     let mut session=example();
     let mut reference=session.legacy().unwrap().tracks[0].device.clone();reference.path="must-not-be-read.ultra".into();
     session.legacy_mut().unwrap().tracks[0].effects=(0..15).map(|i| {let mut d=reference.clone();d.instance_id=format!("effect-{i}");d}).collect();
-    assert!(prepare(&session,&example_path()).unwrap_err().contains("sixteen"));
+    assert!(prepare_score_fixture(&session,&example_path()).unwrap_err().contains("sixteen"));
     session.legacy_mut().unwrap().tracks[0].effects.truncate(3);
-    assert!(prepare(&session,&example_path()).unwrap_err().contains("two effects"));
+    assert!(prepare_score_fixture(&session,&example_path()).unwrap_err().contains("two effects"));
     // Future eight-instrument/nine-effect input still hits the global root budget
     // before track-profile rejection, dependency reads or fixed-array indexing.
     let mut future=example(); future.legacy_mut().unwrap().tracks=(0..8).map(|i| {
@@ -641,7 +826,7 @@ fn global_root_and_chain_bounds_reject_before_dependency_reads() {
         let mut effect=track.device.clone();effect.instance_id=format!("effect-{i}");track.effects=vec![effect];track
     }).collect();
     let mut ninth=future.legacy().unwrap().tracks[0].effects[0].clone();ninth.instance_id="ninth-effect".into();future.legacy_mut().unwrap().tracks[0].effects.push(ninth);
-    assert!(prepare(&future,&example_path()).unwrap_err().contains("sixteen"));
+    assert!(prepare_score_fixture(&future,&example_path()).unwrap_err().contains("sixteen"));
 }
 
 #[test]
@@ -651,7 +836,7 @@ fn stable_parameter_keys_survive_explicit_source_manifest_reordering() {
     filter.parameters.insert("cutoff".into(),777.);
     session.legacy_mut().unwrap().tracks[0].effects.push(filter.clone());
     session.legacy_mut().unwrap().tracks[0].automation.push(Lane {instance_id:"filter".into(),key:"cutoff".into(),enabled:true,points:vec![Point {beat:0.,value:1234.}]});
-    let first=prepare(&session,&example_path()).unwrap();
+    let first=prepare_score_fixture(&session,&example_path()).unwrap();
     let before=first.events.iter().find(|e| e.kind==1&&first.devices[e.device as usize].instance_id=="filter").unwrap();
     let mut patch=crate::documents::read_patch(Path::new(&filter.path)).unwrap().patch.unwrap();
     patch["device"]["parameters"].as_array_mut().unwrap().reverse();
@@ -660,12 +845,12 @@ fn stable_parameter_keys_survive_explicit_source_manifest_reordering() {
     session.legacy_mut().unwrap().tracks[0].effects[0].path=path.to_string_lossy().into();
     // Explicit replacement captures the new authored source, preserving key targets.
     session.legacy_mut().unwrap().tracks[0].effects[0].source_sha256=prepare::fingerprint(&patch).unwrap();
-    let second=prepare(&session,&example_path()).unwrap();
+    let second=prepare_score_fixture(&session,&example_path()).unwrap();
     let after=second.events.iter().find(|e| e.kind==1&&second.devices[e.device as usize].instance_id=="filter").unwrap();
     assert_ne!(before.target,after.target);
     assert_eq!(second.devices[after.device as usize].manifest.parameters[after.target as usize].key,"cutoff");
     assert_eq!(after.value,1234.);
-    assert_eq!(second.document.legacy().unwrap().tracks[0].effects[0].parameters["cutoff"],777.);
+    assert_eq!(second.saved.score.legacy().unwrap().tracks[0].effects[0].parameters["cutoff"],777.);
     std::fs::remove_file(path).unwrap();
 }
 
@@ -690,16 +875,16 @@ fn v4_native_host_admits_complete_candidate_and_preserves_old_on_refusal() {
         let child=std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",NAME,"--nocapture"]).env("ALIVE_WORKSPACE_HOST_CHILD","1").env_remove("DISPLAY").env_remove("WAYLAND_DISPLAY").output().unwrap();
         assert!(child.status.success(),"{}\n{}",String::from_utf8_lossy(&child.stdout),String::from_utf8_lossy(&child.stderr));return;
     }
-    let mut host=host::Host::default();host.install(prepare(&example().to_clips().unwrap(),&example_path()).unwrap()).unwrap();
+    let mut host=host::Host::default();host.install(prepare_score_fixture(&example().to_clips().unwrap(),&example_path()).unwrap()).unwrap();
     let mut runtime=runtime::Runtime::default();
     assert_eq!(unsafe{native::ultra_external_start()},1);
     let legacy=runtime.request(&host,native::RequestV3{kind:native::V3_START,..Default::default()},None,None).unwrap();assert_eq!(legacy.status,"queued");
     let mut first_left=[0f32;1];let mut first_right=[0f32;1];assert_eq!(unsafe{native::ultra_external_render(1,first_left.as_mut_ptr(),first_right.as_mut_ptr())},1);
     unsafe{native::alive_session_stop();native::ultra_audio_stop();}
-    let original=host.prepared.as_ref().unwrap().document.clone();
-    let original_candidate=prepare(&Document::WorkspacesV4(workspaces::prospective_from_document(&original).unwrap()),&example_path()).unwrap();
+    let original=host.prepared.as_ref().unwrap().saved.score.clone();
+    let original_candidate=prepare_score_fixture(&Document::WorkspacesV4(workspaces::prospective_from_document(&original).unwrap()),&example_path()).unwrap();
     assert!(host.validate(&original_candidate).unwrap_err().contains("observed 40, limit 32"));
-    assert_eq!(host.prepared.as_ref().unwrap().document,original);
+    assert_eq!(host.prepared.as_ref().unwrap().saved.score,original);
     let mut authored=example();
     for (index,track) in authored.legacy_mut().unwrap().tracks.iter_mut().enumerate(){
         track.notes.clear();track.automation.clear();
@@ -713,7 +898,7 @@ fn v4_native_host_admits_complete_candidate_and_preserves_old_on_refusal() {
         Lane{instance_id:instrument,key:"level".into(),enabled:true,points:vec![Point{beat:0.,value:70.},Point{beat:4.,value:90.}]},
     ]);
     let project=workspaces::prospective_from_document(&authored).unwrap();
-    let candidate=prepare(&Document::WorkspacesV4(project.clone()),&example_path()).unwrap();
+    let candidate=prepare_score_fixture(&Document::WorkspacesV4(project.clone()),&example_path()).unwrap();
     host.validate(&candidate).unwrap();host.install(candidate).unwrap();
     assert!(host.view().unwrap().devices.is_empty());
     assert_eq!(unsafe{native::ultra_external_start()},1);
@@ -728,17 +913,17 @@ fn v4_native_host_admits_complete_candidate_and_preserves_old_on_refusal() {
     let returned=runtime.workspace_request(&host,runtime_workspaces::Action::Return{track_ids:project.tracks.iter().map(|t|t.id.clone()).collect()}).unwrap();assert_eq!(returned.kind,"return");assert!(returned.track_id.is_none());
     for _ in 0..110 {assert_eq!(unsafe{native::ultra_external_render(1024,left.as_mut_ptr(),right.as_mut_ptr())},1);}
     let view=runtime.poll(&host).unwrap().1.unwrap();assert_eq!(view["tracks"][0]["authority"],"arrangement");assert!(view["tracks"][0]["activeSlotId"].is_null());
-    let before=host.prepared.as_ref().unwrap().document.clone();let revision=host.preparation_revision;
+    let before=host.prepared.as_ref().unwrap().saved.score.clone();let revision=host.preparation_revision;
     let mut larger=project.clone();let mut third=larger.tracks[0].clone();third.id="extra-track".into();third.slots=[None,None,None,None];third.effects.clear();if let workspaces::ChainV4::Midi{instrument}=&mut third.chain{instrument.instance_id="extra-instrument".into();}larger.tracks.push(third);
-    assert!(prepare(&Document::WorkspacesV4(larger),&example_path()).unwrap_err().contains("Profile 2"));assert_eq!(host.preparation_revision,revision);assert_eq!(host.prepared.as_ref().unwrap().document,before);
+    assert!(prepare_score_fixture(&Document::WorkspacesV4(larger),&example_path()).unwrap_err().contains("Profile 2"));assert_eq!(host.preparation_revision,revision);assert_eq!(host.prepared.as_ref().unwrap().saved.score,before);
     assert_eq!(unsafe{native::ultra_external_render(31,left.as_mut_ptr(),right.as_mut_ptr())},1);assert_eq!(runtime.poll(&host).unwrap().0["playing"],1);
     let epoch=unsafe{native::alive_session_stop_v4()};assert!(epoch>0);assert_eq!(unsafe{native::ultra_external_render(1,left.as_mut_ptr(),right.as_mut_ptr())},1);assert_eq!(runtime.poll(&host).unwrap().0["playing"],0);
     unsafe{native::ultra_audio_stop();}
     let root=std::env::temp_dir().join(format!("alive-v4-save-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
-    let saved=save(&root.join("project.alive"),&before,&example_path()).unwrap();let reopened=read(&saved).unwrap();assert!(reopened.document.is_workspaces());host.install(reopened).unwrap();
+    let saved=save_score_fixture(&root.join("project.alive"),&before,&example_path()).unwrap();let reopened=read(&saved).unwrap();assert!(reopened.saved.score.is_workspaces());host.install(reopened).unwrap();
     let (_,view)=runtime.poll(&host).unwrap();assert_eq!(view.unwrap()["tracks"][0]["authority"],"arrangement");
-    if let Ok(output)=std::env::var("ALIVE_WORKSPACE_FIXTURE_OUT") {let output=std::path::PathBuf::from(output);std::fs::create_dir_all(&output).unwrap();save(&output.join("admitted-chord-progression-v3.alive"),&authored.to_clips().unwrap(),&example_path()).unwrap();save(&output.join("admitted-chord-progression-v4.alive"),&before,&example_path()).unwrap();}
-    host.install(prepare(&authored.to_clips().unwrap(),&example_path()).unwrap()).unwrap();
+    if let Ok(output)=std::env::var("ALIVE_WORKSPACE_FIXTURE_OUT") {let output=std::path::PathBuf::from(output);std::fs::create_dir_all(&output).unwrap();save_score_fixture(&output.join("admitted-chord-progression-v3.alive"),&authored.to_clips().unwrap(),&example_path()).unwrap();save_score_fixture(&output.join("admitted-chord-progression-v4.alive"),&before,&example_path()).unwrap();}
+    host.install(prepare_score_fixture(&authored.to_clips().unwrap(),&example_path()).unwrap()).unwrap();
     assert_eq!(unsafe{native::ultra_external_start()},1);
     let resumed=runtime.request(&host,native::RequestV3{kind:native::V3_START,..Default::default()},None,None).unwrap();assert_eq!(resumed.status,"queued");assert!(runtime::decimal(&resumed.request_serial).unwrap()>runtime::decimal(&returned.request_serial).unwrap());
     assert_eq!(unsafe{native::ultra_external_render(31,left.as_mut_ptr(),right.as_mut_ptr())},1);assert_eq!(runtime.poll(&host).unwrap().0["playing"],1);unsafe{native::ultra_audio_stop();}
@@ -753,7 +938,7 @@ fn v4_nested_duplicates_and_invalid_prepared_dependencies_are_transactional(){
     for case in ["missing","changed","role"] {
         let mut candidate=project.clone();let workspaces::ChainV4::Midi{instrument}=&mut candidate.tracks[0].chain else{unreachable!()};
         match case {"missing"=>instrument.path="/missing-workspace-instrument.ultra".into(),"changed"=>instrument.source_sha256="0".repeat(64),"role"=>{let id=instrument.instance_id.clone();*instrument=effect(&id,"utility.ultra");},_=>unreachable!()}
-        let document=Document::WorkspacesV4(candidate);let before=document.clone();let error=prepare(&document,&example_path()).unwrap_err();assert!(error.contains("Pulse")||error.contains("role"),"{case}: {error}");assert_eq!(document,before);
+        let document=Document::WorkspacesV4(candidate);let before=document.clone();let error=prepare_score_fixture(&document,&example_path()).unwrap_err();assert!(error.contains("Pulse")||error.contains("role"),"{case}: {error}");assert_eq!(document,before);
     }
 }
 
@@ -764,10 +949,10 @@ fn v4_source_compiler_checks_disabled_bindings_and_placement_endpoint_arithmetic
         let mut candidate=project.clone();let instance=candidate.tracks[0].devices().next().unwrap().instance_id.clone();
         let workspaces::SourceV4::Midi{automation,..}=&mut candidate.sources[0] else{unreachable!()};
         *automation=vec![Lane{instance_id:instance,key:key.into(),enabled:false,points:vec![Point{beat:0.,value}]}];
-        assert!(prepare(&Document::WorkspacesV4(candidate),&example_path()).is_err(),"{key}");
+        assert!(prepare_score_fixture(&Document::WorkspacesV4(candidate),&example_path()).is_err(),"{key}");
     }
     let mut candidate=project;candidate.tempo=137.;candidate.placements[0].start=0.03;candidate.placements[0].duration=0.03;
-    let prepared=prepare(&Document::WorkspacesV4(candidate.clone()),&example_path()).unwrap();let Schedule::Workspaces(w)=prepared.schedule else{unreachable!()};
+    let prepared=prepare_score_fixture(&Document::WorkspacesV4(candidate.clone()),&example_path()).unwrap();let Schedule::Workspaces(w)=prepared.schedule else{unreachable!()};
     let p=w.placements.iter().find(|p|p.id==candidate.placements[0].id).unwrap();
     assert_eq!(p.descriptor.duration_frames,workspaces::frame_at(0.06,137.).unwrap()-workspaces::frame_at(0.03,137.).unwrap());
 }
diff --git a/apps/ultra/src-tauri/src/session/workspace_edits.rs b/apps/ultra/src-tauri/src/session/workspace_edits.rs
index c5c1255..3ccfc6b 100644
--- a/apps/ultra/src-tauri/src/session/workspace_edits.rs
+++ b/apps/ultra/src-tauri/src/session/workspace_edits.rs
@@ -38,7 +38,7 @@ mod tests {
     #[test]
     fn command_primary_ids_follow_the_operation_not_sorted_invalidation(){
         let path=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../alive/examples/two-instruments.alive");
-        let document=super::super::read(&path).unwrap().document;
+        let document=super::super::read(&path).unwrap().saved.score;
         let original=prospective_from_document(&document).unwrap();let track=original.tracks[0].id.clone();let slot=original.tracks[0].slots[0].as_ref().unwrap().clone();let source=slot.source_id.clone();let placement=original.placements[0].id.clone();
         for operation in [
             WorkspaceEditV4::SlotDuplicate{track_id:track.clone(),slot_id:slot.id.clone(),destination_slot:1},
diff --git a/apps/ultra/src-tauri/src/session/workspaces.rs b/apps/ultra/src-tauri/src/session/workspaces.rs
index 1c07553..5b2fc37 100644
--- a/apps/ultra/src-tauri/src/session/workspaces.rs
+++ b/apps/ultra/src-tauri/src/session/workspaces.rs
@@ -917,6 +917,7 @@ pub fn prospective_from_legacy_text(
     origin: &std::path::Path,
 ) -> Result<ProjectV4, String> {
     check_size(text.len())?;
+    super::clips::reject_duplicates(text)?;
     // This header only selects the full decoder; it never replaces wire validation.
     #[derive(Deserialize)]
     struct Format {
@@ -926,8 +927,10 @@ pub fn prospective_from_legacy_text(
         serde_json::from_str(text).map_err(|e| format!("Invalid Alive session JSON: {e}"))?;
     let document = if format.format == "alive-session-v3" {
         super::clips::decode_v3_candidate(text)?
+    } else if format.format == "alive-session-v1" || format.format == "alive-session-v2" {
+        super::persistence::decode(text, origin)?.score
     } else {
-        super::persistence::decode(text, origin)?
+        return Err("Expected a bare legacy score for workspace conversion".into());
     };
     prospective_from_document(&document)
 }
diff --git a/apps/ultra/src-tauri/src/session/workspaces_tests.rs b/apps/ultra/src-tauri/src/session/workspaces_tests.rs
index 9f0fc49..fe36884 100644
--- a/apps/ultra/src-tauri/src/session/workspaces_tests.rs
+++ b/apps/ultra/src-tauri/src/session/workspaces_tests.rs
@@ -343,14 +343,14 @@ fn legacy_prospective_conversion_preserves_input_and_rejects_held_voice_excess()
     let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
         .join("../../alive/examples/two-instruments.alive");
     let text = std::fs::read_to_string(&path).unwrap();
-    let old = super::super::persistence::decode(&text, &path).unwrap();
+    let old = super::super::persistence::decode(&text, &path).unwrap().score;
     let before = old.clone();
     let a = prospective_from_document(&old).unwrap();
     let b = prospective_from_document(&old.to_clips().unwrap()).unwrap();
     assert_eq!(a, b);
     assert_eq!(old, before);
     assert_eq!(prospective_from_legacy_text(&text, &path).unwrap(), a);
-    assert_eq!(super::super::persistence::decode(&encode(&a).unwrap(), &path).unwrap(), Document::WorkspacesV4(a.clone()));
+    assert_eq!(super::super::persistence::decode(&encode(&a).unwrap(), &path).unwrap().score, Document::WorkspacesV4(a.clone()));
     let mut invalid = old.clone();
     invalid.legacy_mut().unwrap().tracks[0].notes = (0..5)
         .map(|i| super::super::Note {
@@ -867,7 +867,7 @@ fn prospective_conversion_survives_unavailable_or_smaller_native_v3_admission()
             }
             "v2-text" => {
                 let text = serde_json::to_string(&legacy_v2_tracks(4)).unwrap();
-                let decoded = super::super::persistence::decode(&text, &path).unwrap();
+                let decoded = super::super::persistence::decode(&text, &path).unwrap().score;
                 assert!(!decoded.is_clips());
                 prospective_from_legacy_text(&text, &path).unwrap()
             }
diff --git a/apps/ultra/tests/alive_session_capacity.cpp b/apps/ultra/tests/alive_session_capacity.cpp
index e4b890d..2eec97d 100644
--- a/apps/ultra/tests/alive_session_capacity.cpp
+++ b/apps/ultra/tests/alive_session_capacity.cpp
@@ -394,6 +394,7 @@ void scene_timing(unsigned tracks, unsigned devices, unsigned count) {
     });
 }
 void timing(unsigned tracks, unsigned devices, unsigned count, bool scenes = false) {
+  uint64_t master_serial=0;
   if (!scenes) for (bool extended : {false, true}) {
     for (auto music : {Music::Sustain, Music::EmptyShort, Music::PopulatedShort, Music::Dense}) {
       Fixture f(tracks, devices, music, extended);
@@ -417,6 +418,9 @@ void timing(unsigned tracks, unsigned devices, unsigned count, bool scenes = fal
           assert(alive_session_mixer(i % tracks, .125, 0, 0));
           request(f, 2, 32767);
         });
+        measure("master_burst64", f, frames, count, [&](unsigned i) {
+          for(unsigned j=0;j<64;++j)assert(alive_session_master_set(1,(i+j)%2?0.5:4.,++master_serial)==ALIVE_MASTER_OK);
+        }, []{AliveSessionStateV3 score{};score.version=3;score.struct_bytes=sizeof score;AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);});
       }
       if (music == Music::Dense) {
         measure(extended ? "extended_full_queue_stop" : "saved_full_queue_stop", f, 64, count, [&](unsigned) {
diff --git a/apps/ultra/tests/alive_session_master_partial_library_test.sh b/apps/ultra/tests/alive_session_master_partial_library_test.sh
new file mode 100644
index 0000000..b332986
--- /dev/null
+++ b/apps/ultra/tests/alive_session_master_partial_library_test.sh
@@ -0,0 +1,24 @@
+#!/usr/bin/env bash
+set -euo pipefail
+ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
+TEST_BINARY=$(realpath "$1")
+OUT=$2
+mkdir "$OUT"
+cat > "$OUT/exports.map" <<'EOF'
+{
+  global: *;
+  local: alive_session_master_set; alive_session_master_reset_clip;
+         alive_session_master_snapshot_v2; alive_session_master_snapshot_v3;
+         alive_session_master_snapshot_v4;
+};
+EOF
+c++ -std=c++17 -O2 -fPIC -shared -pthread "$ROOT/apps/ultra/src-tauri/native/backend.cpp" \
+  "$ROOT/apps/ultra/build/core/libultra_core_bundle.a" -ldl -lrt \
+  -Wl,-soname,libultra_native.so -Wl,--version-script="$OUT/exports.map" -o "$OUT/libultra_native.so"
+nm -D --defined-only "$OUT/libultra_native.so" > "$OUT/exports.txt"
+rg -q ' alive_session_master_limits$' "$OUT/exports.txt"
+if rg -q ' alive_session_master_set$' "$OUT/exports.txt"; then exit 1; fi
+ALIVE_MASTER_EXPECT_UNAVAILABLE=1 LD_LIBRARY_PATH="$OUT" "$TEST_BINARY" \
+  --exact session::tests::master_old_library_unity_install_and_nonunity_preflight
+ALIVE_MASTER_EXPECT_UNAVAILABLE=1 LD_LIBRARY_PATH="$OUT" "$TEST_BINARY" \
+  --exact session::desktop::tests::master_old_library_snapshot_exposes_no_observation
diff --git a/apps/ultra/tests/alive_session_master_resolver_test.sh b/apps/ultra/tests/alive_session_master_resolver_test.sh
new file mode 100644
index 0000000..febe0b1
--- /dev/null
+++ b/apps/ultra/tests/alive_session_master_resolver_test.sh
@@ -0,0 +1,37 @@
+#!/usr/bin/env bash
+set -euo pipefail
+ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
+BUILD="$ROOT/apps/ultra/build"
+TMP=$(mktemp -d)
+trap 'rm -rf "$TMP"' EXIT
+mkdir -p "$TMP/old" "$TMP/partial" "$TMP/collision"
+cat > "$TMP/anchor.c" <<'EOF'
+int alive_session_state_v2(void *out) { (void)out; return 0; }
+EOF
+cat > "$TMP/partial.c" <<'EOF'
+int alive_session_master_limits(void *out) { (void)out; __builtin_trap(); }
+EOF
+cat > "$TMP/dependency.c" <<'EOF'
+int alive_session_master_limits(void *out) { (void)out; __builtin_trap(); }
+int alive_session_master_set(void) { return 1; }
+int alive_session_master_reset_clip(void) { return 1; }
+int alive_session_master_snapshot_v2(void) { return 1; }
+int alive_session_master_snapshot_v3(void) { return 1; }
+int alive_session_master_snapshot_v4(void) { return 1; }
+EOF
+cc -shared -fPIC "$TMP/anchor.c" -o "$TMP/old/libultra_native.so"
+cc -shared -fPIC "$TMP/anchor.c" "$TMP/partial.c" -o "$TMP/partial/libultra_native.so"
+cc -shared -fPIC "$TMP/dependency.c" -o "$TMP/collision/libcollision.so"
+cc -shared -fPIC "$TMP/anchor.c" -L"$TMP/collision" -Wl,--no-as-needed -lcollision \
+  -Wl,-rpath,'$ORIGIN' -o "$TMP/collision/libultra_native.so"
+rustc --edition=2021 --test "$ROOT/apps/ultra/src-tauri/src/session/native_master.rs" \
+  -L "native=$TMP/old" -C "link-arg=-Wl,-rpath,$BUILD" -o "$TMP/resolver"
+# Linking to the full library can satisfy Rust runtime symbols from that image,
+# making the test executable fail before it can inspect an older library.
+readelf --dyn-syms --wide "$TMP/resolver" > "$TMP/symbols"
+awk '$7 == "UND" && $8 ~ /^(_ZN|_R)/ { print "Unexpected Rust symbol dependency: " $8 > "/dev/stderr"; bad=1 } END { exit bad }' "$TMP/symbols"
+LD_LIBRARY_PATH="$BUILD" "$TMP/resolver" --exact tests::resolves_the_loaded_native_image
+for fixture in old partial collision; do
+  ALIVE_MASTER_EXPECT_UNAVAILABLE=1 LD_LIBRARY_PATH="$TMP/$fixture" \
+    "$TMP/resolver" --exact tests::resolves_the_loaded_native_image
+done
diff --git a/apps/ultra/tests/alive_session_master_test.cpp b/apps/ultra/tests/alive_session_master_test.cpp
new file mode 100644
index 0000000..ad10530
--- /dev/null
+++ b/apps/ultra/tests/alive_session_master_test.cpp
@@ -0,0 +1,196 @@
+#include "../src-tauri/native/alive_session.h"
+#include "../src-tauri/native/backend.h"
+#include "../../../docs/contracts/alive-master-v1.h"
+#include <cassert>
+#include <dlfcn.h>
+#include <initializer_list>
+#include <atomic>
+#include <algorithm>
+#include <thread>
+#include <limits>
+#include <cstring>
+#include <cmath>
+
+int main() {
+  Dl_info anchor_info{};
+  auto anchor=reinterpret_cast<void*>(&alive_session_error);
+  assert(dladdr(anchor,&anchor_info));
+  void* library = dlopen(anchor_info.dli_fname, RTLD_NOW | RTLD_NOLOAD);
+  assert(library);
+  assert(dlsym(library,"alive_session_error")==anchor);
+  for(const char* symbol:{"alive_session_master_limits","alive_session_master_set","alive_session_master_reset_clip","alive_session_master_snapshot_v2","alive_session_master_snapshot_v3","alive_session_master_snapshot_v4"}){
+    auto address=dlsym(library,symbol);Dl_info info{};
+    assert(address && dladdr(address,&info) && info.dli_fbase==anchor_info.dli_fbase);
+  }
+  using Limits = int (*)(AliveMasterLimitsV1*);
+  auto limits = reinterpret_cast<Limits>(dlsym(library, "alive_session_master_limits"));
+  assert(limits && "native Master limits must be exported");
+  AliveMasterLimitsV1 out{ALIVE_MASTER_V1, sizeof(out), 0, 0, 0};
+  assert(limits(&out) == ALIVE_MASTER_OK);
+  assert(out.features == 7 && out.ramp_frames == 64 && out.max_gain == 4);
+  AliveMasterLimitsV1 invalid{2, sizeof(invalid), 42, 43, 44};
+  assert(limits(&invalid) == ALIVE_MASTER_UNSUPPORTED);
+  assert(invalid.version == 2 && invalid.features == 42 && invalid.ramp_frames == 43 && invalid.max_gain == 44);
+  assert(limits(nullptr) == ALIVE_MASTER_INVALID);
+  using Set = int (*)(uint32_t, double, uint64_t);
+  using Reset = int (*)(uint32_t, uint64_t);
+  using Snapshot = int (*)(AliveSessionStateV2*, AliveMasterStateV1*);
+  auto set = reinterpret_cast<Set>(dlsym(library, "alive_session_master_set"));
+  auto reset = reinterpret_cast<Reset>(dlsym(library, "alive_session_master_reset_clip"));
+  auto snapshot = reinterpret_cast<Snapshot>(dlsym(library, "alive_session_master_snapshot_v2"));
+  assert(set && reset && snapshot && "native Master commands and combined snapshot must be exported");
+  assert(set(1, 0.5, 1) == ALIVE_MASTER_UNCONFIGURED);
+  UltraCanvasGraph graph{}; graph.revision=100; graph.node_count=5; graph.edge_count=5;
+  const unsigned kinds[]={60,65,12,13,14};
+  for(unsigned i=0;i<5;++i){graph.nodes[i].id=i+1;graph.nodes[i].kind=kinds[i];}
+  graph.nodes[0].p0=4;graph.nodes[2].p0=127;
+  graph.edges[0]={1,1,2,0};graph.edges[1]={2,0,3,0};graph.edges[2]={3,0,4,0};graph.edges[3]={3,0,4,1};graph.edges[4]={4,0,5,0};
+  assert(ultra_canvas_install_document(0,&graph));
+  AliveSessionConfig config{};config.version=1;config.track_count=1;config.length_frames=256;
+  auto& track=config.tracks[0];track.document=0;track.note_node=1;track.revision=graph.revision;track.output_channels=2;track.output_layout=2;track.gain=1;
+  track.parameter_count=1;track.parameters[0]={3,0,1,0,127,0,127};
+  config.events[0]={0,0,ALIVE_SESSION_NOTE_ON,60,0,127};config.event_count=1;
+  auto unrelated=graph;unrelated.revision=101;assert(ultra_canvas_install_document(1,&unrelated));
+  assert(!alive_session_configure(&config));assert(ultra_canvas_close_document(1));
+  assert(alive_session_configure(&config));
+  assert(set(1, 0.5, 1) == ALIVE_MASTER_OK);
+  AliveSessionStateV2 score{};score.version=2;score.struct_bytes=sizeof(score);
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof(master);
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.target_gain==0.5 && master.current_gain==0.5 && master.applied_serial==1);
+  assert(master.applied_frame==score.absolute_frame && master.observation_start_frame==score.absolute_frame && master.observation_end_frame==score.absolute_frame);
+  auto score_before=score;auto master_before=master;
+  master.version=2;assert(snapshot(&score,&master)==ALIVE_MASTER_UNSUPPORTED);
+  assert(score.absolute_frame==score_before.absolute_frame && master.version==2 && master.applied_serial==master_before.applied_serial);
+  master=master_before;
+  assert(ultra_external_start());assert(alive_session_start());
+  float left[512]{},right[512]{};assert(ultra_external_render(1,left,right));assert(left[0]==0.125f && right[0]==0.125f);
+  assert(set(1,1.,2)==ALIVE_MASTER_OK);assert(ultra_external_render(64,left,right));
+  for(unsigned i=0;i<64;++i){const float expected=float(.25*(.5+.5*double(i+1)/64));assert(left[i]==expected&&right[i]==expected);}
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.target_gain==1. && master.current_gain==1. && master.applied_serial==2);
+  assert(master.applied_frame+64==score.absolute_frame && master.observation_end_frame==score.absolute_frame);
+  assert(set(1,0.,3)==ALIVE_MASTER_OK);assert(ultra_external_render(17,left,right));
+  for(unsigned i=0;i<17;++i){const float expected=float(.25*(1.-double(i+1)/64));assert(left[i]==expected&&right[i]==expected);}
+  assert(set(1,1.,4)==ALIVE_MASTER_OK);assert(ultra_external_render(64,left,right));
+  const double interrupted=1.-17./64.;
+  for(unsigned i=0;i<64;++i){const float expected=float(.25*(interrupted+(1.-interrupted)*double(i+1)/64));assert(left[i]==expected&&right[i]==expected);}
+  assert(set(1,-1.,3)==ALIVE_MASTER_INVALID && set(1,5.,3)==ALIVE_MASTER_INVALID && set(1,1.,0)==ALIVE_MASTER_INVALID);
+  assert(set(1,std::numeric_limits<double>::quiet_NaN(),3)==ALIVE_MASTER_INVALID);
+  assert(set(1,std::numeric_limits<double>::infinity(),3)==ALIVE_MASTER_INVALID);
+  auto unchanged=master;master.reserved=1;
+  assert(snapshot(&score,&master)==ALIVE_MASTER_INVALID && master.reserved==1 && master.applied_serial==unchanged.applied_serial);
+  master.reserved=0;
+  for(unsigned i=0;i<64;++i)assert(set(1,0.5,5+i)==ALIVE_MASTER_OK);
+  assert(reset(1,69)==ALIVE_MASTER_FULL);
+  alive_session_stop();assert(ultra_external_render(1,left,right));
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && !score.playing && master.applied_serial==68);
+  assert(reset(1,70)==ALIVE_MASTER_OK);assert(ultra_external_render(1,left,right));
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.applied_serial==70 && master.clip_mask==0);
+  ultra_audio_stop();assert(alive_session_reset());
+  assert(alive_session_configure(&config));assert(set(1,0.7,100)==ALIVE_MASTER_OK);
+  assert(ultra_external_start());assert(alive_session_start());assert(set(1,0.1,101)==ALIVE_MASTER_OK);
+  assert(ultra_external_render(64,left,right));assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.current_gain==0.7+(0.1-0.7));assert(left[63]==float(.25*(0.7+(0.1-0.7))));assert(ultra_external_render(1,left,right));
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.current_gain==0.1);
+  assert(left[0]==float(.25*0.1));
+  ultra_audio_stop();assert(alive_session_reset());
+  config.length_frames=2048;
+  uint64_t partition_serial=10000;
+  for(unsigned partition:{1u,31u,32u,63u,64u,65u,127u,128u,256u,512u}){
+    assert(alive_session_configure(&config));assert(set(1,0.5,++partition_serial)==ALIVE_MASTER_OK);
+    assert(ultra_external_start());assert(alive_session_start());assert(ultra_external_render(1,left,right));
+    assert(left[0]==0.125f && right[0]==0.125f);assert(set(1,1.,++partition_serial)==ALIVE_MASTER_OK);
+    unsigned largest=0;
+    for(unsigned at=0;at<512;){const unsigned n=std::min(partition,512-at);largest=std::max(largest,n);assert(ultra_external_render(n,left,right));
+      for(unsigned i=0;i<n;++i){const unsigned frame=at+i;const double gain=frame<64?.5+.5*double(frame+1)/64:1.;const float expected=float(.25*gain);assert(left[i]==expected&&right[i]==expected);}at+=n;
+    }
+    assert(largest==partition);
+    ultra_audio_stop();assert(alive_session_reset());
+    assert(alive_session_configure(&config));assert(set(1,0.7,++partition_serial)==ALIVE_MASTER_OK);
+    assert(ultra_external_start());assert(alive_session_start());assert(set(1,0.1,++partition_serial)==ALIVE_MASTER_OK);
+    for(unsigned at=0;at<64;){const unsigned n=std::min(partition,64-at);assert(ultra_external_render(n,left,right));at+=n;}
+    assert(snapshot(&score,&master)==ALIVE_MASTER_OK);const double last=0.7+(0.1-0.7);assert(master.current_gain==last);
+    assert(set(1,0.7,++partition_serial)==ALIVE_MASTER_OK);assert(ultra_external_render(1,left,right));
+    assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.current_gain==last+(0.7-last)/64.);
+    ultra_audio_stop();assert(alive_session_reset());
+  }
+  assert(ultra_canvas_close_document(0));
+  graph.revision=101;assert(ultra_canvas_install_document(0,&graph));
+  track.revision=101;config.track_count=2;config.tracks[1]=track;
+  graph.revision=102;assert(ultra_canvas_install_document(1,&graph));
+  config.tracks[1].document=1;config.tracks[1].revision=102;
+  config.events[1]={0,1,ALIVE_SESSION_NOTE_ON,60,0,127};config.event_count=2;
+  assert(alive_session_configure(&config));assert(set(1,2.,71)==ALIVE_MASTER_OK);
+  assert(ultra_external_start());assert(alive_session_start());assert(ultra_external_render(1,left,right));
+  assert(left[0]==1.f && right[0]==1.f);assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.clip_mask==0);
+  assert(set(1,4.,72)==ALIVE_MASTER_OK);assert(ultra_external_render(64,left,right));
+  assert(left[63]==2.f && right[63]==2.f);assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.clip_mask==3 && master.peak_left==2. && master.peak_right==2.);
+  assert(reset(1,73)==ALIVE_MASTER_OK);assert(ultra_external_render(1,left,right));
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.clip_mask==3 && master.applied_serial==73);
+  assert(set(1,0.5,74)==ALIVE_MASTER_OK);assert(reset(1,75)==ALIVE_MASTER_OK);assert(set(1,0.75,76)==ALIVE_MASTER_OK);
+  const auto stopped_frame=score.absolute_frame;ultra_audio_stop();
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && master.applied_serial==76 && master.current_gain==0.75 && master.clip_mask==0);
+  assert(set(1,0.25,77)==ALIVE_MASTER_OK);assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.applied_serial==77 && master.current_gain==0.25 && master.target_gain==0.25 && master.applied_frame==stopped_frame);
+  assert(master.clip_mask==0 && master.peak_left==0 && master.peak_right==0 && master.observation_end_frame==stopped_frame);
+  assert(alive_session_reset());assert(ultra_canvas_close_document(0));assert(ultra_canvas_close_document(1));
+  graph.revision=103;assert(ultra_canvas_install_document(0,&graph));
+  config.track_count=1;config.event_count=1;track.revision=103;
+  assert(alive_session_configure(&config));assert(set(1,0.5,72)==ALIVE_MASTER_OK);
+  assert(alive_session_mixer(0,0.5,0,0));assert(ultra_external_start());
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK);const auto rejected_base=score.rejected;
+  std::atomic<bool> done{false};std::atomic<unsigned> reads{0};
+  std::thread reader([&]{while(!done.load(std::memory_order_acquire)){
+    AliveSessionStateV2 s{};s.version=2;s.struct_bytes=sizeof s;
+    AliveMasterStateV1 m{};m.version=1;m.struct_bytes=sizeof m;
+    const int result=snapshot(&s,&m);assert(result==ALIVE_MASTER_OK||result==ALIVE_MASTER_BUSY);
+    if(result==ALIVE_MASTER_OK){assert(s.tracks[0].gain==m.target_gain);assert(m.applied_frame==m.observation_start_frame && m.observation_end_frame==s.absolute_frame);
+      const auto completed=m.applied_serial==72?0:(m.applied_serial-72)/63;
+      assert(s.rejected>=rejected_base+completed && s.rejected<=rejected_base+5000);++reads;}
+  }});
+  for(unsigned i=0;i<5000;++i){const double value=i%2?0.25:0.75;
+    for(unsigned j=0;j<63;++j)assert(set(1,value,73+uint64_t(i)*63+j)==ALIVE_MASTER_OK);
+    assert(alive_session_mixer(0,value,0,0));assert(!alive_session_mixer(0,value,0,0));assert(ultra_external_render(1,left,right));
+  }
+  done.store(true,std::memory_order_release);reader.join();assert(reads>0);
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK && score.rejected==rejected_base+5000);
+  ultra_audio_stop();assert(alive_session_reset());assert(ultra_canvas_close_document(0));
+  UltraCanvasGraph asymmetric{};asymmetric.revision=104;asymmetric.node_count=4;asymmetric.edge_count=2;
+  asymmetric.nodes[0].id=1;asymmetric.nodes[0].kind=60;asymmetric.nodes[0].p0=4;
+  asymmetric.nodes[1].id=2;asymmetric.nodes[1].kind=38;std::strcpy(asymmetric.nodes[1].text,"0.25");
+  asymmetric.nodes[2].id=3;asymmetric.nodes[2].kind=38;std::strcpy(asymmetric.nodes[2].text,"0.5");
+  asymmetric.nodes[3].id=4;asymmetric.nodes[3].kind=49;std::strcpy(asymmetric.nodes[3].text,"1 2");
+  asymmetric.edges[0]={2,0,4,0};asymmetric.edges[1]={3,0,4,1};
+  assert(ultra_canvas_install_document(0,&asymmetric));config.track_count=1;config.event_count=0;track.revision=104;track.parameter_count=0;
+  assert(alive_session_configure(&config));assert(set(1,4.,400000)==ALIVE_MASTER_OK);
+  assert(ultra_external_start());assert(alive_session_start());assert(ultra_external_render(1,left,right));
+  assert(left[0]==1.f&&right[0]==2.f);assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.peak_left==1.&&master.peak_right==2.&&master.clip_mask==2);
+  ultra_audio_stop();assert(alive_session_reset());assert(ultra_canvas_close_document(0));
+  UltraCanvasGraph overload{};overload.revision=105;overload.node_count=11;overload.edge_count=10;
+  overload.nodes[0].id=1;overload.nodes[0].kind=60;overload.nodes[0].p0=4;
+  overload.nodes[1].id=2;overload.nodes[1].kind=38;std::strcpy(overload.nodes[1].text,"100000");
+  for(unsigned i=2;i<10;++i){overload.nodes[i].id=i+1;overload.nodes[i].kind=41;overload.nodes[i].p0=100000;overload.edges[i-2]={i,0,i+1,0};}
+  overload.nodes[10].id=11;overload.nodes[10].kind=49;std::strcpy(overload.nodes[10].text,"1 2");
+  overload.edges[8]={10,0,11,0};overload.edges[9]={10,0,11,1};
+  assert(ultra_canvas_install_document(0,&overload));config.track_count=1;config.event_count=0;track.revision=105;track.parameter_count=0;
+  assert(alive_session_configure(&config));assert(set(1,4.,400001)==ALIVE_MASTER_OK);
+  assert(ultra_external_start());assert(alive_session_start());left[0]=right[0]=99.f;
+  assert(!ultra_external_render(1,left,right));assert(left[0]==0.f&&right[0]==0.f);
+  assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(std::isfinite(master.peak_left)&&std::isfinite(master.peak_right));
+  assert(master.observation_start_frame==master.observation_end_frame && master.peak_left==0. && master.peak_right==0. && master.clip_mask==3);
+  assert(std::isfinite(score.tracks[0].peak_left)&&std::isfinite(score.tracks[0].peak_right));
+  ultra_audio_stop();assert(alive_session_reset());assert(ultra_canvas_close_document(0));
+  overload.revision=106;overload.nodes[1].kind=44;overload.nodes[1].p0=24000;overload.nodes[1].p1=0.000001;overload.nodes[1].text[0]=0;
+  assert(ultra_canvas_install_document(0,&overload));track.revision=106;assert(alive_session_configure(&config));
+  assert(set(1,4.,400002)==ALIVE_MASTER_OK);assert(ultra_external_start());assert(alive_session_start());
+  left[0]=right[0]=left[1]=right[1]=99.f;assert(!ultra_external_render(2,left,right));
+  assert(left[0]==0.f&&right[0]==0.f&&left[1]==0.f&&right[1]==0.f);assert(snapshot(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.observation_end_frame==master.observation_start_frame+1);
+  assert(master.peak_left>1.&&master.peak_left<std::numeric_limits<float>::max()&&master.peak_right==master.peak_left&&master.clip_mask==3);
+  ultra_audio_stop();assert(alive_session_reset());assert(ultra_canvas_close_document(0));
+  assert(dlclose(library) == 0);
+}
diff --git a/apps/ultra/tests/alive_session_test.cpp b/apps/ultra/tests/alive_session_test.cpp
index aa6ad98..1e1d28e 100644
--- a/apps/ultra/tests/alive_session_test.cpp
+++ b/apps/ultra/tests/alive_session_test.cpp
@@ -10,6 +10,7 @@
 #include <cstdio>
 #include <cstring>
 #include <memory>
+#include <thread>
 #include <vector>
 
 namespace {
@@ -141,6 +142,34 @@ void stop_snapshot_preserves_later_commands(){
  }
  interleaved_session=nullptr;
 }
+void invalid_track_sample_does_not_poison_meter(){
+ auto workspace=std::make_unique<ultra::CanvasWorkspace>();auto session=std::make_unique<ultra::AliveSession>();
+ const auto graph=instrument();ultra::CanvasPlan plan{};assert(ultra::compile_canvas(graph,plan));
+ auto discard=[](alive::Event){return true;};assert(workspace->install(0,plan,0,discard));
+ AliveSessionConfig config{};config.version=1;config.track_count=1;config.length_frames=256;
+ auto& track=config.tracks[0];track.document=0;track.revision=graph.revision;track.note_node=1;track.output_channels=2;track.output_layout=2;track.gain=1;
+ assert(session->configure(config,*workspace));assert(session->start());session->begin(*workspace);
+ const auto out=session->mix(0,{std::numeric_limits<double>::infinity(),2.});assert(std::isinf(out[0])&&out[1]==2.);
+ session->publish(*workspace);AliveSessionState observed{};assert(session->snapshot(observed));
+ assert(observed.tracks[0].peak_left==0.&&observed.tracks[0].peak_right==2.);
+}
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+std::atomic<bool> publication_entered{false},publication_release{false};
+void hold_publication()noexcept{publication_entered.store(true);while(!publication_release.load())std::this_thread::yield();}
+void master_snapshot_busy_is_bounded_and_does_not_write(){
+ auto workspace=std::make_unique<ultra::CanvasWorkspace>();auto session=std::make_unique<ultra::AliveSession>();
+ const auto graph=instrument();ultra::CanvasPlan plan{};assert(ultra::compile_canvas(graph,plan));
+ auto discard=[](alive::Event){return true;};assert(workspace->install(0,plan,0,discard));
+ AliveSessionConfig config{};config.version=1;config.track_count=1;config.length_frames=256;
+ auto& track=config.tracks[0];track.document=0;track.revision=graph.revision;track.note_node=1;track.output_channels=2;track.output_layout=2;track.gain=1;
+ assert(session->configure(config,*workspace));publication_entered=false;publication_release=false;ultra::alive_session_test_publication=hold_publication;
+ std::thread writer([&]{session->publish(*workspace);});while(!publication_entered.load())std::this_thread::yield();
+ AliveSessionStateV2 score{};score.version=2;score.struct_bytes=sizeof score;score.absolute_frame=123;
+ AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;master.applied_serial=456;
+ assert(session->master_snapshot(score,master)==ALIVE_MASTER_BUSY);assert(score.absolute_frame==123&&master.applied_serial==456);
+ publication_release=true;writer.join();ultra::alive_session_test_publication=nullptr;
+}
+#endif
 void chase_disable_remove(){
  auto c=prepare();add(c,31,0,1,0,64);add(c,31,0,2,60,127);
  assert(alive_session_configure(&c));assert(ultra_external_start());assert(alive_session_seek(10));assert(alive_session_start());render(1);
@@ -164,4 +193,8 @@ void measured_paths(){
  }
 }
 }
-int main(){const auto expected=score({1});assert(score({32,64,127,1024})==expected);ownership_and_stop();isolation_loop_mixer();admission();shared_frame_and_sustain();live_base_preserves_structural_constraints();stop_snapshot_preserves_later_commands();chase_disable_remove();measured_paths();ultra_audio_stop();assert(alive_session_reset());std::puts("PASS: Alive exact frames, partitions, ownership, overload Stop, seek, loop, isolation, mono join, mixer and callback guard");}
+int main(){const auto expected=score({1});assert(score({32,64,127,1024})==expected);ownership_and_stop();isolation_loop_mixer();admission();shared_frame_and_sustain();live_base_preserves_structural_constraints();stop_snapshot_preserves_later_commands();invalid_track_sample_does_not_poison_meter();
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+master_snapshot_busy_is_bounded_and_does_not_write();
+#endif
+chase_disable_remove();measured_paths();ultra_audio_stop();assert(alive_session_reset());std::puts("PASS: Alive exact frames, partitions, ownership, overload Stop, seek, loop, isolation, mono join, mixer and callback guard");}
diff --git a/apps/ultra/tests/alive_session_v2_test.cpp b/apps/ultra/tests/alive_session_v2_test.cpp
index a7475c7..d60d751 100644
--- a/apps/ultra/tests/alive_session_v2_test.cpp
+++ b/apps/ultra/tests/alive_session_v2_test.cpp
@@ -72,6 +72,36 @@ void add(AliveSessionConfigV2& c,uint64_t frame,unsigned track,unsigned kind,uns
 void impulse(AliveSessionConfigV2& c,unsigned track=0){add(c,0,track,2,c.tracks[track].instrument,60,127);add(c,1,track,0,c.tracks[track].instrument,60,0);}
 void render(unsigned n){callback_guard::begin();const int ok=ultra_external_render(n,left.data(),right.data());callback_guard::end();assert(ok);}
 AliveSessionStateV2 state(){AliveSessionStateV2 s{};s.version=2;s.struct_bytes=sizeof s;assert(alive_session_state_v2(&s));return s;}
+void assert_score_unchanged(AliveSessionStateV2 before, AliveSessionStateV2 after) {
+  // The rejection counter is sampled independently of the published score.
+  before.rejected=after.rejected=0;
+  assert(std::memcmp(&before,&after,sizeof before)==0);
+}
+void master_rejection_freshness_v2() {
+  auto c=prepare();assert(alive_session_configure_v2(&c));
+  AliveSessionStateV2 score{};score.version=2;score.struct_bytes=sizeof score;
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+  assert(alive_session_master_snapshot_v2(&score,&master)==ALIVE_MASTER_OK);
+  auto before=score;auto legacy_before=state();auto master_before=master;const auto base=score.rejected;
+  assert(!alive_session_validate_prepared_v2(&c,nullptr,0));
+  auto legacy_after=state();assert(legacy_after.rejected==base+1);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v2(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+  assert(alive_session_master_set(1,0.5,987654)==ALIVE_MASTER_OK);
+  assert(alive_session_master_snapshot_v2(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  before=score;legacy_before=state();master_before=master;
+  assert(!alive_session_validate_prepared_v2(&c,nullptr,0));
+  legacy_after=state();assert(legacy_after.rejected==base+2);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v2(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+2);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+}
 void start(const AliveSessionConfigV2& c){const int configured=alive_session_configure_v2(&c);if(!configured)std::fprintf(stderr,"v2 configure: %s (tracks=%u devices=%u events=%u)\n",alive_session_error(),c.track_count,c.device_count,c.event_count);assert(configured);assert(ultra_external_start());assert(alive_session_start());}
 std::vector<float> ordered(bool reverse,const std::vector<unsigned>& partitions){
  auto c=prepare(1,reverse);c.devices[0].parameters[0].automated=1;impulse(c);add(c,1,0,1,0,0,0);start(c);
@@ -213,4 +243,4 @@ void measured_six_device_paths(){
  std::printf("six-device dense 1024-frame callback mean_us=%.3f; six-device seek+one-frame mean_us=%.3f (wall clock, no deadline claim)\n",dense,reset);
 }
 }
-int main(){initial_snapshot();order_and_partitions();bypass_and_warm_state();endpoint_sum_and_short_chains();additional_input_readers();ownership_and_isolation();hard_resets();admission();legacy_admission_policy();measured_six_device_paths();cleanup();std::puts("PASS: v2 ordered chains, exact bypass/warm state, partitions, ownership, resets, admission, overload and callback guard");}
+int main(){initial_snapshot();master_rejection_freshness_v2();order_and_partitions();bypass_and_warm_state();endpoint_sum_and_short_chains();additional_input_readers();ownership_and_isolation();hard_resets();admission();legacy_admission_policy();measured_six_device_paths();cleanup();std::puts("PASS: v2 ordered chains, exact bypass/warm state, partitions, ownership, resets, admission, overload and callback guard");}
diff --git a/apps/ultra/tests/alive_session_v3_measure.cpp b/apps/ultra/tests/alive_session_v3_measure.cpp
index afe8f0b..1706999 100644
--- a/apps/ultra/tests/alive_session_v3_measure.cpp
+++ b/apps/ultra/tests/alive_session_v3_measure.cpp
@@ -299,6 +299,11 @@ template <class Before> void measure(const char *name, unsigned frames, unsigned
     const auto previews = ultra::alive_session_test_preview_reads;
     const auto begin = std::chrono::steady_clock::now();
     render(frames);
+    if(std::strstr(name,"master_burst64")){
+      AliveSessionStateV3 score{};score.version=3;score.struct_bytes=sizeof score;
+      AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+      assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+    }
     const auto end = std::chrono::steady_clock::now();
     times.push_back(std::chrono::duration<double, std::micro>(end - begin).count());
     assert(!state().fault);
@@ -421,8 +426,13 @@ int main(int argc, char **argv) {
   }
   for (bool maximal : {false, true}) {
     auto c = fixture(maximal, 48000, true);
+    uint64_t master_serial=0;
     for (unsigned frames : {1u, 31u, 64u, 128u, 256u, 512u, 1024u})
       measure(maximal ? "max_graph_sustain" : "saved_graph_sustain", frames, 1200, [](unsigned) {});
+    for (unsigned frames : {1u, 31u, 64u, 128u, 256u, 512u, 1024u})
+      measure(maximal ? "max_master_burst64" : "saved_master_burst64", frames, 1200, [&](unsigned i) {
+        for(unsigned j=0;j<64;++j)assert(alive_session_master_set(1,(i+j)%2?0.5:4.,++master_serial)==ALIVE_MASTER_OK);
+      });
     c = fixture(maximal, 188, false);
     for (unsigned frames : {64u, 256u, 1024u})
       measure(maximal ? "max_short_empty" : "saved_short_empty", frames, 1200, [](unsigned) {});
diff --git a/apps/ultra/tests/alive_session_v3_test.cpp b/apps/ultra/tests/alive_session_v3_test.cpp
index c671030..771b721 100644
--- a/apps/ultra/tests/alive_session_v3_test.cpp
+++ b/apps/ultra/tests/alive_session_v3_test.cpp
@@ -6,6 +6,7 @@
 #include <cstdio>
 #include <cstring>
 #include <vector>
+#include <thread>
 
 static_assert(ultra::session_bits::count(0) == 0);
 static_assert(ultra::session_bits::count(0xffffffffu) == 32);
@@ -19,6 +20,10 @@ namespace {
 uint64_t revision = 40000, preparation = 0, serial = 0;
 std::array<float, 1024> left{}, right{};
 std::array<UltraCanvasGraph, 16> graphs{};
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+std::atomic<bool> master_publication_entered{false},master_publication_release{false};
+void hold_master_publication()noexcept{master_publication_entered=true;while(!master_publication_release.load())std::this_thread::yield();}
+#endif
 void cleanup() {
   ultra_audio_stop();
   assert(alive_session_reset());
@@ -286,6 +291,73 @@ void configure_stopped(AliveSessionConfigV3 &c) {
   assert(alive_session_configure_v3(&c));
   assert(ultra_external_start());
 }
+void assert_score_unchanged(AliveSessionStateV3 before, AliveSessionStateV3 after) {
+  // The rejection counter is sampled independently of the published score.
+  before.rejected=after.rejected=0;
+  assert(std::memcmp(&before,&after,sizeof before)==0);
+}
+void master_rejection_freshness_v3() {
+  auto c=prepare();finalize(c);assert(alive_session_configure_v3(&c));
+  AliveSessionStateV3 score{};score.version=3;score.struct_bytes=sizeof score;
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  auto before=score;auto legacy_before=state();auto master_before=master;const auto base=score.rejected;
+  assert(!alive_session_validate_prepared_v3(&c,nullptr,0));
+  auto legacy_after=state();assert(legacy_after.rejected==base+1);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+  assert(alive_session_master_set(1,0.5,987654)==ALIVE_MASTER_OK);
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  before=score;legacy_before=state();master_before=master;
+  assert(!alive_session_validate_prepared_v3(&c,nullptr,0));
+  legacy_after=state();assert(legacy_after.rejected==base+2);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+2);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+}
+void master_v3_fifo_and_publication() {
+  auto c=prepare();finalize(c);assert(alive_session_configure_v3(&c));
+  assert(alive_session_master_set(1,0.5,1)==ALIVE_MASTER_OK);
+  AliveSessionStateV3 score{};score.version=3;score.struct_bytes=sizeof score;
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.current_gain==0.5&&master.applied_serial==1&&master.applied_frame==score.absolute_frame);
+  assert(ultra_external_start());
+  assert(alive_session_master_set(1,1.,2)==ALIVE_MASTER_OK);
+  assert(alive_session_master_reset_clip(1,3)==ALIVE_MASTER_OK);render(64);
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK);
+  assert(!score.playing&&master.current_gain==1.&&master.applied_serial==3);
+  assert(master.applied_frame+64==score.absolute_frame);
+  const auto rejected_base=score.rejected;
+  std::atomic<bool> done{false};std::atomic<unsigned> reads{0};
+  std::thread reader([&]{while(!done.load()){
+    AliveSessionStateV3 s{};s.version=3;s.struct_bytes=sizeof s;AliveMasterStateV1 m{};m.version=1;m.struct_bytes=sizeof m;
+    const int result=alive_session_master_snapshot_v3(&s,&m);assert(result==ALIVE_MASTER_OK||result==ALIVE_MASTER_BUSY);
+    if(result==ALIVE_MASTER_OK){assert(s.tracks[0].mixer.gain==m.target_gain);assert(m.applied_frame==m.observation_start_frame && m.observation_end_frame==s.absolute_frame);
+      const auto completed=m.applied_serial==3?0:(m.applied_serial-3)/63;assert(s.rejected>=rejected_base+completed && s.rejected<=rejected_base+2000);++reads;}
+  }});
+  for(unsigned i=0;i<2000;++i){const double value=i%2?0.25:0.75;
+    for(unsigned j=0;j<63;++j)assert(alive_session_master_set(1,value,4+uint64_t(i)*63+j)==ALIVE_MASTER_OK);
+    assert(alive_session_mixer(0,value,0,0));assert(!alive_session_mixer(0,value,0,0));render(1);}
+  done=true;reader.join();assert(reads>0);
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_OK && score.rejected==rejected_base+2000);
+  AliveSessionStateV2 wrong{};wrong.version=2;wrong.struct_bytes=sizeof wrong;wrong.absolute_frame=123;
+  master.applied_serial=456;assert(alive_session_master_snapshot_v2(&wrong,&master)==ALIVE_MASTER_UNSUPPORTED);
+  assert(wrong.absolute_frame==123&&master.applied_serial==456);
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+  master_publication_entered=false;master_publication_release=false;ultra::alive_session_test_publication=hold_master_publication;
+  std::thread writer([]{render(1);});while(!master_publication_entered.load())std::this_thread::yield();
+  score.absolute_frame=123;master.applied_serial=456;
+  assert(alive_session_master_snapshot_v3(&score,&master)==ALIVE_MASTER_BUSY);assert(score.absolute_frame==123&&master.applied_serial==456);
+  master_publication_release=true;writer.join();ultra::alive_session_test_publication=nullptr;
+#endif
+}
 AliveSessionReceiptV3 scene(unsigned mask, unsigned slot = 1, unsigned stops = 0,
                              bool accepted = true) {
   AliveSessionRequestV3 r{};
@@ -1219,6 +1291,8 @@ int main(int argc, char **argv) {
   }
 #endif
   admission();
+  master_rejection_freshness_v3();
+  master_v3_fifo_and_publication();
   assert(playback({1}) == playback({31, 63, 64, 127, 1024, 1}));
   transitions();
   scene_member_receipts();
diff --git a/apps/ultra/tests/alive_session_v4_measure.cpp b/apps/ultra/tests/alive_session_v4_measure.cpp
index 7f57db9..a069f2e 100644
--- a/apps/ultra/tests/alive_session_v4_measure.cpp
+++ b/apps/ultra/tests/alive_session_v4_measure.cpp
@@ -16,6 +16,7 @@ using Charge = std::array<uint64_t, 6>;
 std::array<float, 1024> left{}, right{};
 std::array<Charge, 4> charged{};
 uint64_t serial = 1000000, dispatched = 0;
+uint64_t master_serial = 0;
 std::array<uint64_t, 2> probes{};
 const Charge *synthetic_charge = nullptr;
 volatile uint64_t sink = 0;
@@ -256,6 +257,10 @@ void matrix(unsigned count) {
         const std::string label = std::string(extended ? "extended_" : "saved_") + shape;
         for (unsigned n : {1u,31u,64u,128u,256u,512u,1024u})
           measure(label.c_str(), f, n, count, [](unsigned){}, []{});
+        for (unsigned n : {1u,31u,64u,128u,256u,512u,1024u})
+          measure("master_burst64", f, n, count, [&](unsigned i){
+            for(unsigned j=0;j<64;++j)assert(alive_session_master_set(1,(i+j)%2?0.5:4.,++master_serial)==ALIVE_MASTER_OK);
+          }, []{AliveSessionStateV4 score{};score.version=4;score.struct_bytes=sizeof score;AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);});
       }
     }
     Fixture controls(profile, profile == 1 ? 3 : 10, true, "arrangement");
diff --git a/apps/ultra/tests/alive_session_v4_test.cpp b/apps/ultra/tests/alive_session_v4_test.cpp
index 5e94976..56698f1 100644
--- a/apps/ultra/tests/alive_session_v4_test.cpp
+++ b/apps/ultra/tests/alive_session_v4_test.cpp
@@ -6,6 +6,7 @@
 #include <cstdio>
 #include <cstring>
 #include <vector>
+#include <thread>
 namespace {
 struct Dispatch {
   uint64_t frame;
@@ -25,6 +26,10 @@ void trace_placement(unsigned, uint64_t amount) noexcept { placement_steps += am
 
 uint64_t preparation = 0, serial = 0, revision = 90000;
 std::array<float, 1024> left{}, right{};
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+std::atomic<bool> master_publication_entered{false},master_publication_release{false};
+void hold_master_publication()noexcept{master_publication_entered=true;while(!master_publication_release.load())std::this_thread::yield();}
+#endif
 AliveSessionConfigV4 prepare(unsigned effects = 0) {
   ultra_audio_stop();
   assert(alive_session_reset());
@@ -87,6 +92,72 @@ void render(unsigned frames) {
   callback_guard::end();
   assert(ok);
 }
+void assert_score_unchanged(AliveSessionStateV4 before, AliveSessionStateV4 after) {
+  // The rejection counter is sampled independently of the published score.
+  before.rejected=after.rejected=0;
+  assert(std::memcmp(&before,&after,sizeof before)==0);
+}
+void master_rejection_freshness_v4() {
+  auto c=prepare();assert(alive_session_configure_v4(&c,nullptr,0));
+  AliveSessionStateV4 score{};score.version=4;score.struct_bytes=sizeof score;
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  auto before=score;auto legacy_before=state();auto master_before=master;const auto base=score.rejected;
+  assert(!alive_session_validate_prepared_v4(&c,nullptr,0,nullptr,0));
+  auto legacy_after=state();assert(legacy_after.rejected==base+1);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+  assert(alive_session_master_set(1,0.5,987654)==ALIVE_MASTER_OK);
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+1);
+  before=score;legacy_before=state();master_before=master;
+  assert(!alive_session_validate_prepared_v4(&c,nullptr,0,nullptr,0));
+  legacy_after=state();assert(legacy_after.rejected==base+2);
+  assert_score_unchanged(legacy_before,legacy_after);
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  assert(score.rejected==base+2);
+  assert_score_unchanged(before,score);
+  assert(std::memcmp(&master,&master_before,sizeof master)==0);
+}
+void master_v4_fifo_and_publication() {
+  auto c=prepare();assert(alive_session_configure_v4(&c,nullptr,0));
+  assert(alive_session_master_set(1,0.5,1)==ALIVE_MASTER_OK);
+  AliveSessionStateV4 score{};score.version=4;score.struct_bytes=sizeof score;
+  AliveMasterStateV1 master{};master.version=1;master.struct_bytes=sizeof master;
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  assert(master.current_gain==0.5&&master.applied_serial==1&&master.applied_frame==score.absolute_frame);
+  assert(ultra_external_start());assert(alive_session_master_set(1,1.,2)==ALIVE_MASTER_OK);
+  assert(alive_session_master_reset_clip(1,3)==ALIVE_MASTER_OK);render(64);
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK);
+  assert(!score.playing&&master.current_gain==1.&&master.applied_serial==3);
+  assert(master.applied_frame+64==score.absolute_frame);
+  const auto rejected_base=score.rejected;
+  std::atomic<bool> done{false};std::atomic<unsigned> reads{0};
+  std::thread reader([&]{while(!done.load()){
+    AliveSessionStateV4 s{};s.version=4;s.struct_bytes=sizeof s;AliveMasterStateV1 m{};m.version=1;m.struct_bytes=sizeof m;
+    const int result=alive_session_master_snapshot_v4(&s,&m);assert(result==ALIVE_MASTER_OK||result==ALIVE_MASTER_BUSY);
+    if(result==ALIVE_MASTER_OK){assert(s.tracks[0].mixer.gain==m.target_gain);assert(m.applied_frame==m.observation_start_frame && m.observation_end_frame==s.absolute_frame);
+      const auto completed=m.applied_serial==3?0:(m.applied_serial-3)/63;assert(s.rejected>=rejected_base+completed && s.rejected<=rejected_base+2000);++reads;}
+  }});
+  for(unsigned i=0;i<2000;++i){const double value=i%2?0.25:0.75;
+    for(unsigned j=0;j<63;++j)assert(alive_session_master_set(1,value,4+uint64_t(i)*63+j)==ALIVE_MASTER_OK);
+    assert(alive_session_mixer(0,value,0,0));assert(!alive_session_mixer(0,value,0,0));render(1);}
+  done=true;reader.join();assert(reads>0);
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_OK && score.rejected==rejected_base+2000);
+  AliveSessionStateV3 wrong{};wrong.version=3;wrong.struct_bytes=sizeof wrong;wrong.absolute_frame=123;
+  master.applied_serial=456;assert(alive_session_master_snapshot_v3(&wrong,&master)==ALIVE_MASTER_UNSUPPORTED);
+  assert(wrong.absolute_frame==123&&master.applied_serial==456);
+#ifdef ULTRA_ALIVE_SESSION_TEST_TRACE
+  master_publication_entered=false;master_publication_release=false;ultra::alive_session_test_publication=hold_master_publication;
+  std::thread writer([]{render(1);});while(!master_publication_entered.load())std::this_thread::yield();
+  score.absolute_frame=123;master.applied_serial=456;
+  assert(alive_session_master_snapshot_v4(&score,&master)==ALIVE_MASTER_BUSY);assert(score.absolute_frame==123&&master.applied_serial==456);
+  master_publication_release=true;writer.join();ultra::alive_session_test_publication=nullptr;
+#endif
+}
 AliveSessionReceiptV4 request(unsigned kind = ALIVE_SESSION_V4_START, bool expected = true) {
   AliveSessionRequestV4 r{};
   r.version = 4;
@@ -461,6 +532,8 @@ int main(int argc, char **argv) {
     return 0;
   }
 
+  master_rejection_freshness_v4();
+  master_v4_fifo_and_publication();
   for (unsigned profile : {1u, 2u}) {
     AliveSessionLimitsV4 limits{};
     limits.version = 4;
diff --git a/apps/ultra/tests/alive_workspace_navigation.py b/apps/ultra/tests/alive_workspace_navigation.py
index 8422293..ff2ed9f 100644
--- a/apps/ultra/tests/alive_workspace_navigation.py
+++ b/apps/ultra/tests/alive_workspace_navigation.py
@@ -42,7 +42,7 @@ def install(ui, windows, select_device, activate_disclosure, observe_replace=Non
             'Set Saved Default', 'Clear Saved Default',
             'Selected clip piano roll', 'Selected note velocity', 'Add note')
         track_action = re.fullmatch(r'(?:Open (.+) editor|Replace (.+) device|Remove (.+) track)', name)
-        surface = (name == 'Alive audio settings' or device or clip or track_action or
+        surface = (name in ('Alive audio settings', 'Prepare / Apply') or device or clip or track_action or
                    re.fullmatch(r'(?:Pulse|Harmony|Track \d+) (?:gain|mute|solo)', name))
         if not surface:
             return
diff --git a/apps/ultra/tests/check_alive_arrangement.py b/apps/ultra/tests/check_alive_arrangement.py
index 57cb0ba..8a9547c 100644
--- a/apps/ultra/tests/check_alive_arrangement.py
+++ b/apps/ultra/tests/check_alive_arrangement.py
@@ -10,7 +10,9 @@ import json
 import os
 from pathlib import Path
 import subprocess
+import sys
 import time
+from desktop_process_helpers import process_identity, assert_same_identity, stop_recorder, cleanup_independently
 
 import check_alive_desktop as alive
 import check_alive_session_ui as presentation
@@ -79,7 +81,7 @@ def save(name, apply=False):
         alive.wait_value('Session status', lambda s: 'prepared and applied' in s)
     path = ui.output / name
     alive.choose_file('Save session as', 'Save Alive Session', path)
-    result = json.loads(path.read_text())
+    result = alive.file_score(json.loads(path.read_text()))
     record('saved', path=str(path))
     return path, result
 
@@ -119,8 +121,9 @@ def run():
     ui.wait_for('MIDI source')
     arrangement()
     capture_window(1440, 900, 'native-example-1440x900.png')
-    record('loaded', executable=str(Path(f'/proc/{ui.pid}/exe').resolve()),
-           native_mappings=[line for line in Path(f'/proc/{ui.pid}/maps').read_text().splitlines() if 'libultra_native' in line])
+    initial_identity = process_identity(ui.pid)
+    assert initial_identity['executable_path'] == os.environ['ULTRA_TEST_ALIVE_BINARY']
+    record('loaded', process_identity=initial_identity)
     video_log = (ui.output/'interaction-video.log').open('w')
     video = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'x11grab', '-video_size', '1440x900', '-framerate', '12', '-i', os.environ['DISPLAY'], '-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '24', '-pix_fmt', 'yuv420p', str(ui.output/'arrangement-interaction.mp4')], stdout=video_log, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)
     tick, header = rect('Seek to beat 8'), rect('Select Pulse Arrangement track')
@@ -146,7 +149,7 @@ def run():
     assert alive.value('Placement start') == '9.5'
     assert alive.value('Placement duration') == '2.5'
     assert alive.value('Placement source offset') == '0.5'
-    video.communicate(b'q\n', timeout=10)
+    stop_recorder(video)
     assert video.returncode == 0
     video = None
     record('native create, note, place, move, right resize, fixed-end left trim', placement_id=first, video='arrangement-interaction.mp4', video_scope='UI interaction only; no audio or exact timing proof')
@@ -197,7 +200,7 @@ def run():
     record('complete candidate refused without changing preparation or clearing pending history', refusal=refusal, native_generation=before_generation, prepared_placement=before_prepared)
     # A nonzero loop start adds a conservative prefix boundary. Explicitly trim
     # these occurrences into the brace; never change source music or policy.
-    initial = json.loads((ui.output/'initial.alive').read_text())
+    initial = alive.file_score(json.loads((ui.output/'initial.alive').read_text()))
     for original in initial['placements']:
         ui.click('Select placement '+original['id'])
         alive.numeric('Placement duration', 6)
@@ -312,6 +315,9 @@ def run():
     windows.scope = 'Alive'
     windows.focus('Alive')
     ui.wait_for('MIDI source')
+    restarted_identity = process_identity(ui.pid)
+    record('restart identity', process_identity=restarted_identity)
+    assert_same_identity(initial_identity, restarted_identity)
     assert alive.value('Transport playing') == 'false'
     assert alive.value('Transport position') == '0.000 beats'
     assert observed(1, 'authority', lambda s: s == 'arrangement') == 'arrangement'
@@ -339,19 +345,26 @@ if __name__ == '__main__':
     try:
         run()
     except Exception as error:
-        record('failure', error=repr(error))
-        alive.screenshot('arrangement-failure.png')
+        cleanup_independently([lambda: record('failure', error=repr(error)),
+                               lambda: alive.screenshot('arrangement-failure.png')])
         raise
     finally:
-        if video is not None and video.poll() is None:
-            video.communicate(b'q\n', timeout=10)
-        if capture is not None:
+        had_failure = sys.exc_info()[0] is not None
+        def finish_audio():
             report['interrupted_audio'] = alive.finish_capture(capture)
             record('capture finalized after interrupted journey')
-        if restart is not None and restart.poll() is None:
+        def finish_restart():
             restart.terminate()
             try:
                 restart.wait(timeout=5)
             except subprocess.TimeoutExpired:
                 restart.kill()
                 restart.wait()
+        actions = []
+        if video is not None: actions.append(lambda: stop_recorder(video))
+        if capture is not None: actions.append(finish_audio)
+        if restart is not None and restart.poll() is None: actions.append(finish_restart)
+        errors = cleanup_independently(actions)
+        if errors:
+            print('Arrangement cleanup errors:', errors, file=sys.stderr, flush=True)
+            if not had_failure: raise RuntimeError(f'Arrangement cleanup errors: {errors}')
diff --git a/apps/ultra/tests/check_alive_capacity.py b/apps/ultra/tests/check_alive_capacity.py
index 027db4d..77e7d80 100644
--- a/apps/ultra/tests/check_alive_capacity.py
+++ b/apps/ultra/tests/check_alive_capacity.py
@@ -106,7 +106,7 @@ try:
     saved = ui.output / 'capacity-saved.alive'
     disclosure('Audio details', False)
     alive.choose_file('Save session as', 'Save Alive Session', saved)
-    record = json.loads(saved.read_text())
+    record = alive.file_score(json.loads(saved.read_text()))
     assert len(record['tracks']) == 8 and sum(1 + len(t['effects']) for t in record['tracks']) == 16
     assert record['tracks'][0]['effects'][0]['parameters']['gain'] == .65
     assert record['tracks'][0]['device']['parameters']['cutoff'] == 1777
diff --git a/apps/ultra/tests/check_alive_chooser_diagnostics.py b/apps/ultra/tests/check_alive_chooser_diagnostics.py
index 166a30f..c325aa6 100644
--- a/apps/ultra/tests/check_alive_chooser_diagnostics.py
+++ b/apps/ultra/tests/check_alive_chooser_diagnostics.py
@@ -133,7 +133,14 @@ def run():
     alive.choose_file('Replace Pulse device', 'Load Ultra Device', alive.DEVICE)
     before = next(row for row in alive.native_inputs if row['action'] == 'chooser input before')
     queued = next(row for row in alive.native_inputs if row['action'] == 'chooser input queued')
+    pre_focus = next(row for row in alive.native_inputs if row['action'] == 'chooser input pre-focus')
+    settled = next(row for row in alive.native_inputs if row['action'] == 'chooser input settled')
     assert before['name'] == queued['name'] == 'Replace Pulse device'
+    assert pre_focus['name'] == settled['name'] == before['name']
+    assert all(len(row['current_rect']) == 4 for row in (pre_focus, before, queued, settled))
+    assert before['showing'] and before['visible']
+    hit = before['planned_accessible_hit']
+    assert hit['status'] == 'complete' and hit['path'][-1]['name'] == before['name']
     assert before['rect'] == queued['rect'] and before['point'] == queued['point']
     assert any(window['title'] == alive.MAIN and window['pid'] == [alive.ui.pid]
                for window in before['windows'])
diff --git a/apps/ultra/tests/check_alive_clips.py b/apps/ultra/tests/check_alive_clips.py
index e1a9aa4..14b8b5d 100644
--- a/apps/ultra/tests/check_alive_clips.py
+++ b/apps/ultra/tests/check_alive_clips.py
@@ -49,7 +49,7 @@ def editor_exists():
 def saved(name):
     path = ui.output / name
     alive.choose_file('Save session as', 'Save Alive Session', path)
-    return path, json.loads(path.read_text())
+    return path, alive.file_score(json.loads(path.read_text()))
 
 
 def launch_at_observable_phase(name):
@@ -73,6 +73,7 @@ def run():
     ui.click('New session')
     windows.focus('Unsaved Alive Session'); ui.click('Discard'); windows.focus(alive.MAIN)
     initial_path, initial = saved('initial-v3.alive')
+    assert json.loads(initial_path.read_text())['format'] == 'alive-session-v5'
     assert initial['format'] == 'alive-session-v3'
     shared = ui.output / 'shared-utility.ultra'
     original = Path('apps/ultra/examples/utility.ultra').read_bytes()
diff --git a/apps/ultra/tests/check_alive_desktop.py b/apps/ultra/tests/check_alive_desktop.py
index 3c288eb..1416d31 100644
--- a/apps/ultra/tests/check_alive_desktop.py
+++ b/apps/ultra/tests/check_alive_desktop.py
@@ -19,11 +19,15 @@ import subprocess
 import time
 from stream_measurement import Recorder, ProcessSampler, ProcessGroups, JsonLines, PlayingIntervals
 from desktop_timing import TimingProbe
+from desktop_sustained import DesktopSustained
+from desktop_checkpoint import playing_dwell, project_pilot, qualify_epochs
+from desktop_process_helpers import process_identity
 
 import check_canvas_desktop as ui
 import check_documents_desktop as windows
 from gi.repository import Atspi, GLib
 from alive_workspace_navigation import install as install_workspace_navigation
+from chooser_observation import find_web_ancestor, planned_hit_path
 
 prepare_workspace_control = install_workspace_navigation(
     ui, windows, select_device=lambda name: select_device_click(name),
@@ -44,6 +48,7 @@ resource_groups = None
 resource_writer = None
 playing = PlayingIntervals()
 control_action = 0
+sustained_driver = None
 
 
 def checkpoint(event, control=''):
@@ -75,6 +80,10 @@ def select_clip(track):
     ui.click(name)
 
 
+def file_score(session):
+    return session['score'] if session.get('format') == 'alive-session-v5' else session
+
+
 def score(track):
     return track['slots'][0] if 'slots' in track else track
 
@@ -279,27 +288,46 @@ def native_window_record(window):
     return row
 
 
-def observe_replace_input(phase, name, rect):
+def observe_replace_input(phase, name, rect, control):
     """Observe the original input batch; never retry, refocus or move its target."""
     started = time.monotonic()
     row = {'action': 'chooser input ' + phase, 'monotonic': started, 'name': name,
-           'scope': windows.scope, 'rect': [rect.x, rect.y, rect.width, rect.height],
-           'point': [rect.x + rect.width // 2, rect.y + rect.height // 2]}
+           'scope': windows.scope}
+    if phase == 'queued':
+        row.update(motions=1, presses=1, releases=1)
+    if phase == 'before':
+        row['planned_accessible_hit'] = {'status': 'unknown', 'reason': 'observation_unavailable', 'path': []}
+    if rect is not None:
+        row.update(rect=[rect.x, rect.y, rect.width, rect.height],
+                   point=[rect.x + rect.width // 2, rect.y + rect.height // 2])
     try:
+        current = Atspi.Component.get_extents(control, Atspi.CoordType.SCREEN)
+        row['current_rect'] = [current.x, current.y, current.width, current.height]
+        states = control.get_state_set()
+        row['showing'] = states.contains(Atspi.StateType.SHOWING)
+        row['visible'] = states.contains(Atspi.StateType.VISIBLE)
         if phase == 'before':
             with native_observation_errors() as errors:
                 row['x_errors'] = errors
                 row['hit_path'] = native_hit_path(*row['point'])
             row['windows'] = [native_window_record(window) for window in row['hit_path']]
-        else:
-            # Reached only after the original three XTest assertions and flush.
-            row.update(motions=1, presses=1, releases=1)
+            web, ancestry = find_web_ancestor(control)
+            row['web_ancestor'] = ancestry
+            if web is None:
+                row['planned_accessible_hit'] = {'status': 'unknown', 'reason': 'web_ancestor_unavailable', 'path': []}
+            else:
+                row['planned_accessible_hit'] = planned_hit_path(
+                    web, lambda node: Atspi.Component.get_accessible_at_point(
+                        node, *row['point'], Atspi.CoordType.SCREEN))
     except Exception as error:
         row['observation_error'] = repr(error)
     row['observation_seconds'] = time.monotonic() - started
     native_inputs.append(row)
-    if phase == 'queued':
-        (ui.output / 'native-inputs.json').write_text(json.dumps(native_inputs, indent=2))
+    if phase in ('queued', 'settled'):
+        try:
+            (ui.output / 'native-inputs.json').write_text(json.dumps(native_inputs, indent=2))
+        except Exception as error:
+            print('Chooser input observation error:', repr(error), flush=True)
 
 
 def isolate_editor_observation(observe):
@@ -321,7 +349,7 @@ def isolate_editor_observation(observe):
 
 
 @isolate_editor_observation
-def observe_editor_input(phase, name, rect):
+def observe_editor_input(phase, name, rect, control=None):
     """Buffer one original activation's receipts without changing its input."""
     global editor_observation
     if phase == 'before':
@@ -439,11 +467,16 @@ def native_control_click(name, kind, record=None):
 
 
 def reorder_click(name):
+    if sustained_driver is not None:
+        return sustained_driver.observer.action(name, lambda: native_control_click(name, 'reorder'))
     return native_control_click(name, 'reorder')
 
 
 def select_device_click(name):
-    result = native_control_click(name, 'device selection')
+    if sustained_driver is not None:
+        result = sustained_driver.observer.action(name, lambda: native_control_click(name, 'device selection'))
+    else:
+        result = native_control_click(name, 'device selection')
     time.sleep(.15)  # Keep the original selector click's post-input allowance.
     return result
 
@@ -582,6 +615,8 @@ def start_capture(name):
     process = Recorder(path, [
         'pw-cat', '--record', *raw, '--rate=48000', '--format=f32', '--channels=2',
         '--target=0', '--properties={ node.name = Alive-Session-Capture }', '-'])
+    if sustained_driver is not None:
+        sustained_driver.capture = (process, path)
     for _ in range(50):
         if 'Alive-Session-Capture:input_FL' in subprocess.check_output(['pw-link', '-i'], text=True):
             break
@@ -593,8 +628,17 @@ def start_capture(name):
 
 
 def finish_capture(capture):
-    with timing.phase('capture-finalize ' + capture[1].name) if timing else nullcontext():
-        return measured_finish_capture(capture)
+    if sustained_driver is not None:
+        sustained_driver.finishing_capture = True
+    try:
+        with timing.phase('capture-finalize ' + capture[1].name) if timing else nullcontext():
+            result = measured_finish_capture(capture)
+    finally:
+        if sustained_driver is not None:
+            sustained_driver.finishing_capture = False
+    if sustained_driver is not None:
+        sustained_driver.capture = None
+    return result
 
 
 def measured_finish_capture(capture):
@@ -627,7 +671,8 @@ def process_sample():
     groups = resource_groups.sample()
     result = {**groups['app'], 'sampler_capture_overhead': groups['sampler_capture_overhead'],
               'private_audio_server': groups['private_audio_server']}
-    resource_writer.write(result)
+    with sustained_driver.lock if sustained_driver is not None else nullcontext():
+        resource_writer.write(result)
     return result
 
 
@@ -719,6 +764,48 @@ def close_effect_editor():
     raise AssertionError('Effect editor Close did not destroy its native window')
 
 
+def apply_input_geometry():
+    control = ui.wait_for('Prepare / Apply')
+    rect = Atspi.Component.get_extents(control, Atspi.CoordType.SCREEN)
+    point = (rect.x + rect.width // 2, rect.y + rect.height // 2)
+    frame = next(f for f in windows.app_frames() if f.get_name().removeprefix('* ') == MAIN)
+    node = frame
+    path = []
+    for _ in range(32):
+        path.append({'name': node.get_name(), 'role': node.get_role_name()})
+        child = Atspi.Component.get_accessible_at_point(node, *point, Atspi.CoordType.SCREEN)
+        if child is None or child == node: break
+        node = child
+    web = next(item for item in ui.walk(frame) if item.get_role_name() == 'document web')
+    web_path = []
+    for _ in range(32):
+        web_path.append({'name': web.get_name(), 'role': web.get_role_name()})
+        child = Atspi.Component.get_accessible_at_point(web, *point, Atspi.CoordType.SCREEN)
+        if child is None or child == web: break
+        web = child
+    panel = ui.wait_for('Audio details')
+    panel_rect = Atspi.Component.get_extents(panel, Atspi.CoordType.SCREEN)
+    expanded = panel.get_state_set().contains(Atspi.StateType.EXPANDED)
+    root = ui.Gdk.get_default_root_window()
+    overlap = [max(rect.x, panel_rect.x), max(rect.y, panel_rect.y),
+               min(rect.x + rect.width, panel_rect.x + panel_rect.width),
+               min(rect.y + rect.height, panel_rect.y + panel_rect.height)]
+    summary_covers_point = (expanded and overlap[0] <= point[0] < overlap[2] and
+                            overlap[1] <= point[1] < overlap[3])
+    return {'rect': [rect.x, rect.y, rect.width, rect.height], 'point': point,
+            'screen': [root.get_width(), root.get_height()],
+            'showing': control.get_state_set().contains(Atspi.StateType.SHOWING),
+            'enabled': control.get_state_set().contains(Atspi.StateType.ENABLED),
+            'audio_details_expanded': expanded,
+            'audio_details_rect': [panel_rect.x, panel_rect.y, panel_rect.width, panel_rect.height],
+            'audio_summary_overlap_edges': overlap if expanded else None,
+            'audio_summary_covers_point': summary_covers_point,
+            'accessible_hit_path': path,
+            'web_hit_path': web_path,
+            'native_hit_path': native_hit_path(*point),
+            'frames': [{'name': f.get_name(), 'showing': f.get_state_set().contains(Atspi.StateType.SHOWING)} for f in windows.app_frames()]}
+
+
 def piano_history_with_effect_editor():
     # The effect editor stays alive while the main window edits pending music.
     windows.focus(MAIN)
@@ -726,12 +813,17 @@ def piano_history_with_effect_editor():
     ui.click('Selected clip piano roll')
     px, py = ui.control_point('Selected clip piano roll', (32 + 2 / 8 * 608) / 640,
                               (21 + 5.5 * 191 / 39) / 218)
-    for _ in range(2):
-        ui.t.XTestFakeMotionEvent(ui.display, 0, px, py, 0)
-        ui.t.XTestFakeButtonEvent(ui.display, 1, 1, 0)
-        ui.t.XTestFakeButtonEvent(ui.display, 1, 0, 0)
-        ui.x.XFlush(ui.display)
-        time.sleep(.07)
+    def double_click_note():
+        for _ in range(2):
+            ui.t.XTestFakeMotionEvent(ui.display, 0, px, py, 0)
+            ui.t.XTestFakeButtonEvent(ui.display, 1, 1, 0)
+            ui.t.XTestFakeButtonEvent(ui.display, 1, 0, 0)
+            ui.x.XFlush(ui.display)
+            time.sleep(.07)
+    if sustained_driver is not None:
+        sustained_driver.observer.action('piano note double click', double_click_note)
+    else:
+        double_click_note()
     time.sleep(.3)
     assert value('Note 13 pitch') == '80'
     Atspi.Component.grab_focus(ui.wait_for('Selected clip piano roll'))
@@ -750,10 +842,39 @@ def piano_history_with_effect_editor():
     windows.focus(MAIN)
     ui.click('Audio details')  # Expose transport diagnostics before asserting Stop.
     transport('stop')
-    ui.click('Prepare / Apply'); time.sleep(.4)
+    receipt = {'before_navigation': apply_input_geometry()}
+    screenshot('before-apply.png')
+    trace_path = ui.output / 'app.log'
+    trace_offset = trace_path.stat().st_size
+    if os.environ.get('ULTRA_TEST_APPLY_OCCLUDED') == '1':
+        px, py = receipt['before_navigation']['point']
+        assert ui.t.XTestFakeMotionEvent(ui.display, 0, px, py, 0)
+        assert ui.t.XTestFakeButtonEvent(ui.display, 1, 1, 0)
+        assert ui.t.XTestFakeButtonEvent(ui.display, 1, 0, 0)
+        ui.x.XFlush(ui.display)
+        receipt['queued'] = True
+    else:
+        prepare_workspace_control('Prepare / Apply')
+        receipt['after_navigation'] = apply_input_geometry()
+        ui.click('Prepare / Apply')
+        receipt['queued'] = True
+    deadline = time.monotonic() + (0.7 if os.environ.get('ULTRA_TEST_APPLY_OCCLUDED') == '1' else 5)
+    while True:
+        receipt['trace'] = trace_path.read_bytes()[trace_offset:].decode(errors='replace').splitlines()
+        if (any('ALIVE_TRACE editor_destroyed' in line for line in receipt['trace']) and
+                any('ALIVE_TRACE apply_end' in line for line in receipt['trace'])) or time.monotonic() >= deadline:
+            break
+        time.sleep(.1)
+    receipt['after_frames'] = [{'name': f.get_name(), 'showing': f.get_state_set().contains(Atspi.StateType.SHOWING)} for f in windows.app_frames()]
+    receipt['audio_details_after_click_expanded'] = ui.wait_for('Audio details').get_state_set().contains(Atspi.StateType.EXPANDED)
+    (ui.output / 'apply-receipt.json').write_text(json.dumps(receipt, indent=2))
     assert not any(frame.get_name() == 'Pulse - Ultra Hosted Editor' and
                    frame.get_state_set().contains(Atspi.StateType.SHOWING)
                    for frame in windows.app_frames()), 'Apply must close the old editor generation'
+    assert any('ALIVE_TRACE apply_begin' in line for line in receipt['trace']), 'Apply IPC must begin'
+    assert any('ALIVE_TRACE apply_end result=ok' in line for line in receipt['trace']), 'Apply IPC must complete'
+    assert any('ALIVE_TRACE editor_close' in line for line in receipt['trace']), 'Apply must request stale editor close'
+    assert any('ALIVE_TRACE editor_destroyed' in line for line in receipt['trace']), 'Apply must destroy stale editor'
     assert not ui.wait_for('Undo pending edit').get_state_set().contains(Atspi.StateType.ENABLED)
     assert value('Note 13 pitch') == '81'
     ui.click('Edit selected device in Ultra')
@@ -911,7 +1032,7 @@ def check_audio_settings():
             'stop_audio_terminated_notes': True, 'restart_kept_transport_stopped': True}
 
 
-def run():
+def _run():
     windows.focus(MAIN)
     ui.wait_for('Start transport')
     entrypoints = check_separate_apps()
@@ -954,7 +1075,7 @@ def run():
     time.sleep(.5)
     before_reorder = ui.output / 'before-reorder.alive'
     choose_file('Save session as', 'Save Alive Session', before_reorder)
-    chain['prepared_instances'] = [d['instanceId'] for d in json.loads(before_reorder.read_text())['tracks'][0]['effects']]
+    chain['prepared_instances'] = [d['instanceId'] for d in file_score(json.loads(before_reorder.read_text()))['tracks'][0]['effects']]
     reorder_click('Move Pulse Stereo Utility effect 1 later')
     ui.wait_for('Select Pulse Stereo Utility effect 2')
     reorder_click('Move Pulse Stereo Utility effect 2 earlier')
@@ -984,7 +1105,7 @@ def run():
     assert ui.wait_for('Redo pending edit').get_state_set().contains(Atspi.StateType.ENABLED)
     deadline = time.monotonic() + 5
     while time.monotonic() < deadline:
-        saved = json.loads(source.read_text())
+        saved = file_score(json.loads(source.read_text()))
         if saved['tempo'] == 116 and saved['tracks'][0]['device']['parameters'].get('cutoff') == 1333:
             break
         time.sleep(.1)
@@ -1021,7 +1142,7 @@ def run():
     # Prospective dependency failure must keep the active session and clock running.
     bad = ui.output / 'missing-device.alive'
     broken = json.loads(source.read_text())
-    broken['tracks'][0]['device']['path'] = 'missing-device.ultra'
+    file_score(broken)['tracks'][0]['device']['path'] = 'missing-device.ultra'
     bad.write_text(json.dumps(broken))
     before = int(value('Absolute frame'))
     ui.click('Audio details')
@@ -1052,10 +1173,14 @@ def run():
     # *playing* duration. Paused time is excluded conservatively from the receipt.
     required = float(os.environ.get('ALIVE_ENDURANCE_SECONDS', '0'))
     sustained, samples, cycles, played = None, [], 0, 0.
+    pilot_growth = None
     if required:
+        playing_baseline = sustained_driver.playing.seconds if sustained_driver is not None else 0.
         capture = start_capture('endurance')
         time.sleep(3)
         samples.append(process_sample())
+        if sustained_driver is not None:
+            cycle_begin = sustained_driver.growth(capture[1])
         while played < required:
             started = time.monotonic()
             frame_before = int(value('Absolute frame'))
@@ -1065,15 +1190,22 @@ def run():
             ui.click('Seek transport')
             if cycles % 4 == 0:
                 editor_edit(800 + cycles % 5 * 100)
-            playing.observe(time.monotonic(), value('Transport playing') == 'true', int(value('Absolute frame')), control_action)
-            segment_end = time.monotonic() + min(8, max(0, required - played))
+            if sustained_driver is not None:
+                wait_value('Transport playing', lambda s: s == 'true')
+                sustained_driver.observe()
+            else:
+                playing.observe(time.monotonic(), value('Transport playing') == 'true', int(value('Absolute frame')), control_action)
+            segment_end = time.monotonic() + playing_dwell(required, played)
             while time.monotonic() < segment_end:
                 time.sleep(min(1, max(0, segment_end-time.monotonic())))
-                playing.observe(time.monotonic(), value('Transport playing') == 'true', int(value('Absolute frame')), control_action)
+                if sustained_driver is not None:
+                    sustained_driver.observe()
+                else:
+                    playing.observe(time.monotonic(), value('Transport playing') == 'true', int(value('Absolute frame')), control_action)
                 samples.append(process_sample())
             wait_value('Transport playing', lambda s: s == 'true')
             assert int(value('Absolute frame')) > frame_before, 'Audio frame clock stopped advancing'
-            played = playing.seconds
+            played = sustained_driver.playing.seconds - playing_baseline if sustained_driver is not None else playing.seconds
             # Retained stream epochs survive Apply; capture each boundary as well.
             log(f'endurance cycle {cycles + 1} before Stop/possible Apply')
             transport('stop')
@@ -1088,7 +1220,14 @@ def run():
                 samples.append(process_sample()); log(f'endurance cycle {cycles}, playing seconds {played:.3f}')
             (ui.output / 'endurance-progress.json').write_text(json.dumps({'playing_seconds': played, 'cycles': cycles, 'required': required}, indent=2))
         samples.append(process_sample())
+        if sustained_driver is not None:
+            cycle_end = sustained_driver.growth(capture[1])
+            played = cycle_end['playing_seconds'] - playing_baseline
         sustained = finish_capture(capture)
+        if sustained_driver is not None:
+            capture_end = sustained_driver.growth(capture[1])
+            pilot_growth = {'cycle_begin': cycle_begin, 'cycle_end': cycle_end,
+                            'capture_end': capture_end}
         assert sustained['seconds'] >= required and sustained['peak'] > 1e-4
     with timing.phase('final-diagnostics') if timing else nullcontext():
         final = detail()
@@ -1152,21 +1291,71 @@ def run():
     ui.click('Audio details')
     wait_value('Transport playing', lambda s: s == 'true')
     report['pending_draft_quit_cancel_retained_edits_and_playback'] = True
-    checkpoint('final-quit-entry')
-    ui.click('Quit Alive')
-    windows.focus('Unsaved Alive Session')
-    ui.click('Discard')
-    deadline = time.monotonic() + 8
-    while time.monotonic() < deadline:
+    if sustained_driver is not None:
+        transport('stop')
+        ui.click('Audio details')
+        ui.click('Alive audio settings')
+        ui.click('Audio details')
+        ui.click('Stop Alive audio to edit settings')
+        wait_value('Transport playing', lambda s: s == 'false')
+        sustained_driver.retired()
         try:
-            state = Path(f'/proc/{ui.pid}/stat').read_text().split(') ', 1)[1].split()[0]
-            if state == 'Z':
+            epoch_rows = [row for line in sustained_driver.epoch_log.path.read_text().splitlines()
+                          if 'epoch_id' in (row := json.loads(line))]
+            qualification = qualify_epochs(epoch_rows)
+        except Exception as error:
+            (ui.output / 'sustained-epoch-qualification.json').write_text(json.dumps({'qualified': False, 'error': repr(error)}, indent=2))
+            raise
+        (ui.output / 'sustained-epoch-qualification.json').write_text(json.dumps(qualification, indent=2))
+        assert qualification['qualified'], qualification
+        report['epoch_qualification'] = qualification
+        ui.click('Close audio settings')
+        sustained_driver.stop_sampling()
+    checkpoint('final-quit-entry')
+    def terminal_quit():
+        ui.click('Quit Alive')
+        windows.focus('Unsaved Alive Session')
+        ui.click('Discard')
+        deadline = time.monotonic() + 8
+        while time.monotonic() < deadline:
+            try:
+                state = Path(f'/proc/{ui.pid}/stat').read_text().split(') ', 1)[1].split()[0]
+                if state == 'Z':
+                    break
+            except FileNotFoundError:
                 break
-        except FileNotFoundError:
-            break
-        time.sleep(.1)
+            time.sleep(.1)
+        else:
+            raise AssertionError('Alive Quit did not exit after Discard')
+    if sustained_driver is not None:
+        # After retirement the process is intentionally allowed to disappear.
+        time.sleep = sustained_driver.raw_sleep
+        for name, original in sustained_driver.originals.items():
+            setattr(ui, name, original)
+        sustained_driver.terminal.quit(terminal_quit)
+        report['stream_measurement'] = sustained_driver.manifest()
+        report['stream_measurement']['process_identity'] = sustained_driver.identity
+        final_growth = sustained_driver.growth(ui.output / 'endurance.f32')
+        begin, end, finished = (pilot_growth[k] for k in ('cycle_begin', 'cycle_end', 'capture_end'))
+        wall = sustained['supervision']['wall_seconds']
+        report['pilot_growth'] = {**pilot_growth, 'final': final_growth,
+                                  'cycles': cycles, 'playing_seconds': played,
+                                  'capture_reason': sustained['supervision']['reason'],
+                                  'projection_uncertainty': 'linear cycle growth; future pauses and per-action variability are not bounded'}
+        report['projection_1800'] = project_pilot(
+            playing_seconds=played, capture_wall_seconds=wall,
+            cycle_playing_seconds=end['playing_seconds'] - begin['playing_seconds'],
+            collector_wall_seconds=report['stream_measurement']['wall_seconds'],
+            audio_bytes=finished['audio_bytes'], metadata_bytes=final_growth['metadata_bytes'],
+            epoch_attempts=final_growth['epoch_attempts'],
+            fixed_wall_seconds=max(0, wall - (end['monotonic'] - begin['monotonic'])),
+            fixed_collector_wall_seconds=max(0, report['stream_measurement']['wall_seconds'] - (end['monotonic'] - begin['monotonic'])),
+            fixed_audio_bytes=begin['audio_bytes'] + finished['audio_bytes'] - end['audio_bytes'],
+            fixed_metadata_bytes=begin['metadata_bytes'] + final_growth['metadata_bytes'] - end['metadata_bytes'],
+            fixed_epoch_attempts=begin['epoch_attempts'] + final_growth['epoch_attempts'] - end['epoch_attempts'],
+            target_seconds=1800, variability=.1, minimum_headroom_fraction=.05)
     else:
-        raise AssertionError('Alive Quit did not exit after Discard')
+        terminal_quit()
     report['quit_discard_exited'] = True
     checkpoint('final-quit-exit')
     (ui.output / 'native-session-report.json').write_text(json.dumps(report, indent=2))
@@ -1175,6 +1364,27 @@ def run():
     checkpoint('journey-complete')
 
 
+def run():
+    global sustained_driver
+    if not float(os.environ.get('ALIVE_ENDURANCE_SECONDS', '0')):
+        return _run()
+    sustained_driver = DesktopSustained(ui, windows, Atspi, GLib)
+    with sustained_driver.measure.owned(sustained_driver.cleanup, sustained_driver.health):
+        windows.focus(MAIN)
+        ui.wait_for('Start transport')
+        sustained_driver.identity = process_identity(ui.pid)
+        details = ui.wait_for('Audio details')
+        if not details.get_state_set().contains(Atspi.StateType.EXPANDED):
+            ui.click('Audio details')
+        measurements = ui.wait_for('Stream measurements')
+        if not measurements.get_state_set().contains(Atspi.StateType.EXPANDED):
+            ui.click('Stream measurements')
+        sustained_driver.observe()
+        ui.click('Audio details')
+        sustained_driver.install()
+        return _run()
+
+
 if __name__ == '__main__':
     timing = TimingProbe(ui.output)
     ui.wait_for = timing.wrap('wait_for', ui.wait_for)
diff --git a/apps/ultra/tests/check_alive_editor_diagnostics.py b/apps/ultra/tests/check_alive_editor_diagnostics.py
index b5c4d5d..0572f72 100644
--- a/apps/ultra/tests/check_alive_editor_diagnostics.py
+++ b/apps/ultra/tests/check_alive_editor_diagnostics.py
@@ -28,6 +28,9 @@ def check_unavailable_observations():
         assert len(alive.editor_observation_failures) == 3
         assert all(row['unavailable'] and len(row['error']) <= 512
                    for row in alive.editor_observation_failures)
+        assert [(row['observer'], row['error_type']) for row in alive.editor_observation_failures] == [
+            ('observe_editor_input', 'AttributeError'), ('observe_editor_window', 'KeyError'),
+            ('observe_editor_input', 'AttributeError')], alive.editor_observation_failures
         # A broken fallback collector must not escape the observation boundary.
         alive.editor_observation_failures = None
         alive.editor_observation = None
@@ -119,10 +122,12 @@ def run():
                and window['pid'] == [ui.pid] for window in result['root_windows']), result
     assert all(row['observation_seconds'] >= 0 for row in rows)
     # Repeated diagnostics are bounded without sending another activation.
+    failures_before = list(alive.editor_observation_failures)
     alive.observe_editor_input('before', before['name'], alive.Atspi.Component.get_extents(
         ui.wait_for(before['name']), alive.Atspi.CoordType.SCREEN))
     alive.observe_editor_window(True)
     assert [row for row in alive.native_inputs if row['action'].startswith('editor ')] == rows
+    assert alive.editor_observation_failures == failures_before
     alive.transport('stop')
     ui.click('Quit Alive')
     windows.focus('Unsaved Alive Session'); ui.click('Discard')
diff --git a/apps/ultra/tests/check_alive_master.py b/apps/ultra/tests/check_alive_master.py
new file mode 100644
index 0000000..cbce825
--- /dev/null
+++ b/apps/ultra/tests/check_alive_master.py
@@ -0,0 +1,185 @@
+#!/usr/bin/env python3
+"""Native cross-view Master, musical history and process-restart journey."""
+import json
+import os
+from pathlib import Path
+import subprocess
+import sys
+import time
+
+import check_alive_desktop as alive
+import check_alive_arrangement as arrangement
+from desktop_process_helpers import process_identity, assert_same_identity, cleanup_independently
+from gi.repository import Atspi
+
+ui, windows = alive.ui, alive.windows
+report = {'kind': 'native Tauri on private software PipeWire', 'physical_audio': False, 'actions': []}
+restart = capture = restart_log = None
+
+
+def record(action, **fields):
+    report['actions'].append({'action': action, 'monotonic': time.monotonic(), **fields})
+    (ui.output / 'master-report.json').write_text(json.dumps(report, indent=2))
+
+
+def capture_view(view, width, height):
+    arrangement.capture_window(width, height, f'master-{view}-{width}x{height}.png')
+    for name in ('Master gain fader', 'Master gain', 'Stop transport'):
+        rect = Atspi.Component.get_extents(ui.wait_for(name), Atspi.CoordType.SCREEN)
+        assert (rect.width > 0 and rect.height > 0 and rect.x >= 0 and rect.y >= 0 and
+                rect.x + rect.width <= width and rect.y + rect.height <= height), (name, rect)
+    if view == 'session':
+        for track in ('Pulse', 'Harmony'):
+            for slot in range(1, 5):
+                name = f'Select {track} slot {slot}'
+                rect = Atspi.Component.get_extents(ui.wait_for(name), Atspi.CoordType.SCREEN)
+                assert (rect.width > 0 and rect.height > 0 and rect.x >= 0 and rect.y >= 0 and
+                        rect.x + rect.width <= width and rect.y + rect.height <= height), (name, rect)
+        for scene in range(1, 5):
+            name = f'Launch scene {scene}'
+            rect = Atspi.Component.get_extents(ui.wait_for(name), Atspi.CoordType.SCREEN)
+            assert (rect.width > 0 and rect.height > 0 and rect.x >= 0 and rect.y >= 0 and
+                    rect.x + rect.width <= width and rect.y + rect.height <= height), (name, rect)
+    record('viewport', view=view, width=width, height=height)
+
+
+def run():
+    global restart, capture, restart_log
+    windows.focus(alive.MAIN)
+    ui.wait_for('Start transport')
+    initial = process_identity(ui.pid)
+    assert initial['executable_path'] == os.environ['ULTRA_TEST_ALIVE_BINARY']
+    record('initial artifact identity', identity=initial)
+    alive.check_audio_settings()
+    alive.choose_file('Replace Pulse device', 'Load Ultra Device', alive.DEVICE)
+    alive.choose_file('Replace Harmony device', 'Load Ultra Device', alive.DEVICE)
+    arrangement.expanded('Audio details', False)
+    alive.select_clip('Harmony')
+    alive.prepare_workspace_control('Select Harmony Subtractive instrument')
+    ui.click('Select Harmony Subtractive instrument')
+    sibling_cutoff = float(alive.value('Cutoff base'))
+    alive.select_clip('Pulse')
+    alive.prepare_workspace_control('Select Pulse Subtractive instrument')
+    ui.click('Select Pulse Subtractive instrument')
+    alive.select_clip('Pulse')
+    alive.numeric('Note 1 duration', .75)
+    alive.numeric('Note 1 velocity', 83)
+    for label, initial_value, second in [('Cutoff', 900, 3400), ('Level', 62, 78)]:
+        ui.click(f'{label} automation enabled')
+        ui.click(f'Add {label} point')
+        alive.numeric(f'{label} point 1 value', initial_value)
+        ui.click(f'Add {label} point')
+        alive.numeric(f'{label} point 2 beat', 4)
+        alive.numeric(f'{label} point 2 value', second)
+    ui.click('Prepare / Apply')
+    time.sleep(.5)
+    arrangement.expanded('Audio details')
+    capture = alive.start_capture('master-before-restart')
+    alive.transport('start')
+    alive.numeric('Master gain', .5)
+    alive.wait_value('Master output status', lambda s: 'Saved target -6.0 dB' in s and 'applied -6.0 dB' in s)
+    alive.numeric('Pulse gain', .55)
+    ui.click('Harmony mute'); ui.click('Harmony mute')
+    ui.click('Pulse solo'); ui.click('Pulse solo')
+    alive.editor_edit(1333)
+    alive.editor_edit(1333)
+    assert float(alive.value('Cutoff base')) == 1333
+    arrangement.expanded('Audio details', False)
+    alive.numeric('Note 1 pitch', 61)
+    ui.click('Undo pending edit')
+    assert alive.value('Note 1 pitch') == '60'
+    assert float(alive.value('Master gain')) == .5
+    ui.click('Redo pending edit')
+    assert alive.value('Note 1 pitch') == '61'
+    assert float(alive.value('Master gain')) == .5
+    for width, height in ((1440, 900), (1280, 800)):
+        capture_view('session', width, height)
+    arrangement.arrangement()
+    for width, height in ((1440, 900), (1280, 800)):
+        capture_view('arrangement', width, height)
+    assert float(alive.value('Master gain')) == .5
+    arrangement.session()
+    alive.transport('stop')
+    ui.click('Prepare / Apply')
+    alive.wait_value('Session status', lambda s: 'prepared and applied' in s)
+    report['first_audio'] = alive.finish_capture(capture)
+    capture = None
+    assert report['first_audio']['peak'] > .0001
+    path = ui.output / 'master-roundtrip.alive'
+    alive.choose_file('Save session as', 'Save Alive Session', path)
+    saved = json.loads(path.read_text())
+    assert saved['format'] == 'alive-session-v5' and saved['master']['gain'] == .5
+    score = alive.file_score(saved)
+    assert score['format'] == 'alive-session-v4'
+    pulse = score['tracks'][0]['chain']['instrument']
+    harmony = score['tracks'][1]['chain']['instrument']
+    assert pulse['parameters']['cutoff'] == 1333
+    assert harmony['parameters']['cutoff'] == sibling_cutoff
+    assert score['tracks'][0]['gain'] == .55
+    source_id = score['tracks'][0]['slots'][0]['sourceId']
+    source = next(item for item in score['sources'] if item['id'] == source_id)
+    assert source['notes'][0]['pitch'] == 61
+    assert pulse['instanceId'] != harmony['instanceId']
+    ui.click('Quit Alive')
+    arrangement.exited(ui.pid)
+    record('saved v5 and actual quit', identity=initial)
+    env = os.environ.copy(); env.pop('LD_LIBRARY_PATH', None)
+    restart_log = (ui.output / 'master-restarted-app.log').open('w')
+    restart = subprocess.Popen([os.environ['ULTRA_TEST_ALIVE_BINARY'], str(path)], env=env, stdout=restart_log, stderr=subprocess.STDOUT)
+    ui.pid = restart.pid
+    windows.scope = 'Alive'
+    windows.focus('Alive')
+    ui.wait_for('Start transport')
+    reopened_identity = process_identity(ui.pid)
+    assert_same_identity(initial, reopened_identity)
+    assert alive.value('Transport playing') == 'false'
+    assert float(alive.value('Master gain')) == .5
+    assert float(alive.value('Pulse gain')) == .55
+    alive.select_clip('Pulse')
+    assert alive.value('Note 1 pitch') == '61'
+    assert not ui.wait_for('Undo pending edit').get_state_set().contains(Atspi.StateType.ENABLED)
+    assert not ui.wait_for('Redo pending edit').get_state_set().contains(Atspi.StateType.ENABLED)
+    reopened_path = ui.output / 'master-reopened.alive'
+    alive.choose_file('Save session as', 'Save Alive Session', reopened_path)
+    assert json.loads(reopened_path.read_text()) == saved
+    capture = alive.start_capture('master-reopened-playback')
+    alive.transport('start'); time.sleep(2)
+    alive.transport('stop')
+    report['reopened_audio'] = alive.finish_capture(capture)
+    capture = None
+    assert report['reopened_audio']['peak'] > .0001
+    ui.click('Quit Alive')
+    restart.wait(timeout=8)
+    assert restart.returncode == 0
+    record('same executable and module, reopened owner and replay', identity=reopened_identity, complete=True)
+
+
+if __name__ == '__main__':
+    try:
+        run()
+    except BaseException as error:
+        failures = cleanup_independently([lambda: record('failure', error=repr(error)),
+                                          lambda: alive.screenshot('master-failure.png')])
+        if failures:
+            print('Master failure evidence errors:', failures, file=sys.stderr, flush=True)
+        raise
+    finally:
+        failed = sys.exc_info()[0] is not None
+        actions = []
+        if capture is not None:
+            actions.append(lambda: alive.finish_capture(capture))
+        if restart is not None and restart.poll() is None:
+            def stop_restart():
+                restart.terminate()
+                try: restart.wait(timeout=5)
+                except subprocess.TimeoutExpired:
+                    restart.kill(); restart.wait()
+            actions.append(stop_restart)
+        if restart_log is not None:
+            actions.append(restart_log.close)
+        errors = cleanup_independently(actions)
+        if errors:
+            if failed:
+                print('Master cleanup errors:', errors, file=sys.stderr, flush=True)
+            else:
+                raise RuntimeError(f'Master cleanup errors: {errors}')
diff --git a/apps/ultra/tests/check_alive_native_input.py b/apps/ultra/tests/check_alive_native_input.py
index 7042ea3..5368b02 100644
--- a/apps/ultra/tests/check_alive_native_input.py
+++ b/apps/ultra/tests/check_alive_native_input.py
@@ -18,7 +18,7 @@ windows = alive.windows
 def save_chain(name):
     path = ui.output / name
     alive.choose_file('Save session as', 'Save Alive Session', path)
-    return json.loads(path.read_text())['tracks'][0]['effects']
+    return alive.file_score(json.loads(path.read_text()))['tracks'][0]['effects']
 
 
 def run():
diff --git a/apps/ultra/tests/check_alive_packaged.py b/apps/ultra/tests/check_alive_packaged.py
index 44f3de6..2b04459 100644
--- a/apps/ultra/tests/check_alive_packaged.py
+++ b/apps/ultra/tests/check_alive_packaged.py
@@ -18,7 +18,7 @@ def run():
     windows.focus('Alive')
     ui.wait_for('Packaged First Light - Alive')
     document = json.loads(source.read_text())
-    document['title'] = 'Packaged New Session'
+    alive.file_score(document)['title'] = 'Packaged New Session'
     source.write_text(json.dumps(document, indent=2) + '\n')
     ui.click('New session')
     ui.wait_for('* Packaged New Session - Alive')
diff --git a/apps/ultra/tests/check_alive_scene_modes.py b/apps/ultra/tests/check_alive_scene_modes.py
index bf18e35..fe90866 100644
--- a/apps/ultra/tests/check_alive_scene_modes.py
+++ b/apps/ultra/tests/check_alive_scene_modes.py
@@ -22,12 +22,13 @@ def run():
     windows.focus(alive.MAIN)
     current = ui.output / 'initial-v3.alive'
     alive.choose_file('Save session as', 'Save Alive Session', current)
-    fresh = json.loads(current.read_text())
+    envelope = json.loads(current.read_text())
+    fresh = alive.file_score(envelope)
     assert fresh['format'] == 'alive-session-v3'
     fresh['title'] = 'Fresh scene identities'
     fresh['tracks'][0]['slots'][0]['name'] = 'Fresh scene clip'
     fresh_path = ui.output / 'fresh-v3.alive'
-    fresh_path.write_text(json.dumps(fresh, indent=2))
+    fresh_path.write_text(json.dumps(envelope, indent=2))
 
     # Same playable legacy / conservative clip-density refusal as the Rust regression.
     legacy = json.loads(Path('apps/alive/examples/two-instruments.alive').read_text())
diff --git a/apps/ultra/tests/check_alive_scenes.py b/apps/ultra/tests/check_alive_scenes.py
index 9ec1920..5739210 100644
--- a/apps/ultra/tests/check_alive_scenes.py
+++ b/apps/ultra/tests/check_alive_scenes.py
@@ -135,7 +135,7 @@ try:
     saved = ui.output / 'scenes-saved.alive'
     disclosure('Audio details', False)
     alive.choose_file('Save session as', 'Save Alive Session', saved)
-    record = json.loads(saved.read_text())
+    record = alive.file_score(json.loads(saved.read_text()))
     assert len(record['tracks']) == 8 and sum(1 + len(t['effects']) for t in record['tracks']) == 16
     assert record['tracks'][0]['effects'][0]['parameters']['gain'] == .65
     assert record['tracks'][0]['device']['parameters']['cutoff'] == 1777
diff --git a/apps/ultra/tests/check_canvas_desktop.py b/apps/ultra/tests/check_canvas_desktop.py
index 167f58b..871dfd2 100644
--- a/apps/ultra/tests/check_canvas_desktop.py
+++ b/apps/ultra/tests/check_canvas_desktop.py
@@ -103,18 +103,22 @@ def click(name, observer=None):
         image = Gdk.pixbuf_get_from_window(root, 0, 0, root.get_width(), root.get_height())
         image.savev(str(output/'native-action-failure.png'), 'png', [], [])
         raise AssertionError(name + ' is disabled')
+    if observer is not None:
+        observer('pre-focus', name, None, control)
     Atspi.Component.grab_focus(control)
     rect = Atspi.Component.get_extents(control, Atspi.CoordType.SCREEN)
     assert rect.width > 0 and rect.height > 0, name
     if observer is not None:
-        observer('before', name, rect)
+        observer('before', name, rect, control)
     assert t.XTestFakeMotionEvent(display, 0, rect.x+rect.width//2, rect.y+rect.height//2, 0)
     assert t.XTestFakeButtonEvent(display, 1, 1, 0)
     assert t.XTestFakeButtonEvent(display, 1, 0, 0)
     x.XFlush(display)
     if observer is not None:
-        observer('queued', name, rect)
+        observer('queued', name, rect, control)
     time.sleep(.15)
+    if observer is not None:
+        observer('settled', name, rect, control)
 
 
 def text(name, value):
@@ -543,6 +547,18 @@ def print_popup_scenario():
 
 
 
+def slider_help_targets(converted):
+    nodes, edges = converted['nodes'], converted['edges']
+    comments = [node for node in nodes if node['type'] == 'comment']
+    executable = [node for node in nodes if node['type'] != 'comment']
+    assert len(nodes) == 21 and len(comments) == 5 and len(executable) == 16 and len(edges) == 10
+    slider, number = executable[3], executable[8]
+    assert slider['type'] == 'slider' and number['type'] == 'number_int'
+    assert any(edge['from'] == slider['id'] and edge['outlet'] == 0 and
+               edge['to'] == number['id'] and edge['inlet'] == 0 for edge in edges)
+    return slider['id'], number['id']
+
+
 def run():
     try:
         wait_for('Start audio')
@@ -570,16 +586,17 @@ def run():
 
         # Real X input checks WebKit pointer capture and the native apply boundary.
         wiring = {'version': 1, 'profile': 'ultra-canvas-v1', 'nodes': [
-            {'id': 1, 'type': 'add', 'x': 80, 'y': 80, 'params': {'rhs': 0}},
+            {'id': 1, 'type': 'add', 'x': 80, 'y': 80, 'params': {'rhs': 0, 'numericmode': 0}},
             {'id': 2, 'type': 'number', 'x': 300, 'y': 240, 'params': {'value': 0}},
         ], 'edges': []}
         import_json()
         text('Patch JSON', json.dumps(wiring))
         click('Import JSON')
-        source = '+ 1, Outlet 0: Sum (control)'
+        source = '+ 1, Outlet 0: sum (control)'
         target = 'number.legacy 2, Inlet 0: Value (control)'
         drag_port(source, target, y_offset=9)
         connected = export()
+        print('WIRING-NODES', json.dumps({'imported': wiring['nodes'], 'after_drag': connected['nodes']}), flush=True)
         assert connected['edges'] == [{'from': 1, 'outlet': 0, 'to': 2, 'inlet': 0}], 'Native cord drag failed'
         assert connected['nodes'] == wiring['nodes'], 'Wiring moved the objects'
         keys('Control_L', 'z')
@@ -684,17 +701,25 @@ def run():
             click('Allow partial import with the listed omissions and behavior differences')
             click('Import supported portion')
             converted = export()
-            assert len(converted['nodes']) == 16 and len(converted['edges']) == 10
+            comment_count = sum(node['type'] == 'comment' for node in converted['nodes'])
+            print('SLIDER-HELP-COUNTS', json.dumps({'nodes': len(converted['nodes']),
+                  'comments': comment_count, 'executable': len(converted['nodes']) - comment_count,
+                  'edges': len(converted['edges'])}), flush=True)
+            slider_id, number_id = slider_help_targets(converted)
             Atspi.Component.grab_focus(wait_for('Editable patch canvas'))
             keys('Control_L', 'e')
-            drag_control('slider value, object 4', (.1, .5), (.75, .5))
-            first = numeric_value('number value, object 9')
+            drag_control(f'slider value, object {slider_id}', (.1, .5), (.75, .5))
+            first = numeric_value(f'number value, object {number_id}')
             assert 80 < first < 110, 'Imported installed slider branch did not run through Tauri'
-            drag_control('slider value, object 4', (.75, .5), (.2, .5))
-            second = numeric_value('number value, object 9')
+            drag_control(f'slider value, object {slider_id}', (.75, .5), (.2, .5))
+            second = numeric_value(f'number value, object {number_id}')
             assert 15 < second < 40, 'Imported installed slider branch did not update'
             imported_help = {'tested': True, 'source': str(max_help), 'partial': True,
-                             'selected_tab': 'basic', 'imported_nodes': 16, 'imported_edges': 10,
+                             'selected_tab': 'basic', 'imported_nodes': len(converted['nodes']),
+                             'imported_comments': comment_count,
+                             'imported_executable_nodes': len(converted['nodes']) - comment_count,
+                             'imported_edges': len(converted['edges']),
+                             'slider_id': slider_id, 'number_id': number_id,
                              'native_downstream_values': [first, second],
                              'whole_help_executed': False}
             (output/'imported-slider.ultra.json').write_text(json.dumps(converted, indent=2)+'\n')
diff --git a/apps/ultra/tests/check_canvas_desktop.sh b/apps/ultra/tests/check_canvas_desktop.sh
index 89625b2..71ff39b 100644
--- a/apps/ultra/tests/check_canvas_desktop.sh
+++ b/apps/ultra/tests/check_canvas_desktop.sh
@@ -2,6 +2,8 @@
 # Actual canvas UI + Rust CPAL, private display, bus and software audio server.
 set -euo pipefail
 ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
+source "$ROOT/apps/ultra/tests/desktop_launch_config.sh"
+ultra_screen_size=$(desktop_screen_size)
 if [[ ${ULTRA_TEST_PRIVATE_SESSION:-} != 1 ]]; then
   if [[ ${1:-} == --software-audio ]]; then shift; fi
   for tool in dbus-run-session xvfb-run Xvfb python3 pipewire wireplumber pw-cat pw-link; do
@@ -64,7 +66,7 @@ if [[ ${ULTRA_TEST_PRIVATE_SESSION:-} != 1 ]]; then
     sleep .3
     kill -0 "$ultra_policy_pid"
   env -u WAYLAND_DISPLAY dbus-run-session -- xvfb-run -a \
-    -s '-screen 0 1280x840x24 -nolisten tcp' bash "$0"
+    -s "-screen 0 ${ultra_screen_size}x24 -nolisten tcp" bash "$0"
   exit
 fi
 if [[ ${DISPLAY:-} != :[0-9]* || -n ${WAYLAND_DISPLAY:-} || -z ${XAUTHORITY:-} ]]; then
@@ -104,6 +106,10 @@ export AT_SPI_BUS_ADDRESS
 "${ULTRA_TEST_REGISTRY_BIN:-/usr/lib/at-spi2-registryd}" >"$ULTRA_TEST_OUTPUT_DIR/registry.log" 2>&1 &
 ultra_registry_pid=$!
 cd "$ROOT"
+if [[ ${ULTRA_TEST_ALIVE:-0} == 1 && -n ${ULTRA_TEST_ALIVE_BINARY:-} ]]; then
+  export ULTRA_TEST_STARTUP_ULTRA_BINARY
+  ULTRA_TEST_STARTUP_ULTRA_BINARY=$(desktop_startup_binary "$ULTRA_TEST_ALIVE_BINARY")
+fi
 python3 "$ROOT/apps/ultra/tests/check_document_startup.py"
 if [[ ${ULTRA_TEST_STARTUP_ONLY:-0} == 1 ]]; then exit; fi
 if [[ ${ULTRA_TEST_PINCH_ONLY:-0} == 1 ]]; then
@@ -127,23 +133,16 @@ fi
 ultra_launch_arguments=("$ultra_initial_patch")
 ultra_launch_binary="$ROOT/apps/ultra/src-tauri/target/release/ultra"
 if [[ ${ULTRA_TEST_ALIVE:-0} == 1 ]]; then
+  export ALIVE_TRACE_COMMANDS=1
   ultra_initial_session="$ULTRA_TEST_OUTPUT_DIR/initial.alive"
-  python3 - "${ULTRA_TEST_ALIVE_SESSION:-$ROOT/apps/alive/examples/two-instruments.alive}" "$ultra_initial_session" <<'PY'
-import json, sys
-from pathlib import Path
-source, target = map(Path, sys.argv[1:])
-session = json.loads(source.read_text())
-for track in session['tracks']:
-    instrument = track.get('device') or track.get('chain', {}).get('instrument')
-    for device in ([instrument] if instrument else []) + track.get('effects', []):
-        device['path'] = str((source.parent / device['path']).resolve(strict=True))
-target.write_text(json.dumps(session, indent=2) + '\n')
-PY
+  python3 "$ROOT/apps/ultra/tests/stage_alive_session.py" "${ULTRA_TEST_ALIVE_SESSION:-$ROOT/apps/alive/examples/two-instruments.alive}" "$ultra_initial_session"
   ultra_launch_arguments=("$ultra_initial_session")
   ultra_launch_binary="${ULTRA_TEST_ALIVE_BINARY:-$ROOT/apps/ultra/src-tauri/target/release/alive}"
+  ultra_launch_binary=$(desktop_alive_binary "$ultra_launch_binary")
+  export ULTRA_TEST_ALIVE_BINARY="$ultra_launch_binary"
   if [[ ${ULTRA_TEST_ALIVE_DEFAULT:-0} == 1 ]]; then ultra_launch_arguments=(); fi
 fi
-if [[ -n ${ULTRA_TEST_ALIVE_BINARY:-} ]]; then
+if [[ ${ULTRA_TEST_ALIVE:-0} == 1 ]]; then
   env -u LD_LIBRARY_PATH "$ultra_launch_binary" "${ultra_launch_arguments[@]}" >"$ULTRA_TEST_OUTPUT_DIR/app.log" 2>&1 &
 else
   LD_LIBRARY_PATH="$ROOT/apps/ultra/src-tauri/target/release${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" \
diff --git a/apps/ultra/tests/check_document_startup.py b/apps/ultra/tests/check_document_startup.py
index e13362b..d51bddd 100644
--- a/apps/ultra/tests/check_document_startup.py
+++ b/apps/ultra/tests/check_document_startup.py
@@ -10,7 +10,7 @@ import time
 assert os.environ.get('ULTRA_TEST_PRIVATE_SESSION') == '1'
 assert os.environ.get('XAUTHORITY') and not os.environ.get('WAYLAND_DISPLAY')
 
-binary = Path('apps/ultra/src-tauri/target/release/ultra').resolve()
+binary = Path(os.environ.get('ULTRA_TEST_STARTUP_ULTRA_BINARY', 'apps/ultra/src-tauri/target/release/ultra')).resolve()
 output = Path(os.environ['ULTRA_TEST_OUTPUT_DIR'])
 assert (binary.parent / 'libultra_native.so').is_file(), 'Build the adjacent native library first'
 env = {**os.environ, 'LD_LIBRARY_PATH': os.pathsep.join(filter(None,
diff --git a/apps/ultra/tests/check_instrument_desktop.py b/apps/ultra/tests/check_instrument_desktop.py
index 0cbdd2d..fe2fb66 100644
--- a/apps/ultra/tests/check_instrument_desktop.py
+++ b/apps/ultra/tests/check_instrument_desktop.py
@@ -154,7 +154,7 @@ def run():
     assert len(authored['edges']) == len(edges), authored['edges']
     screenshot('authored-canvas.png')
     ui.click('Perform instrument')
-    ui.click('Package instrument')
+    ui.click('Package device')
     ui.wait_for('Cutoff value')
     numeric('Cutoff', 1200); numeric('Attack', 35)
     ui.text('New preset name', 'Warm'); ui.click('Store preset')
diff --git a/apps/ultra/tests/check_ultra_drafts.py b/apps/ultra/tests/check_ultra_drafts.py
new file mode 100644
index 0000000..c607e6a
--- /dev/null
+++ b/apps/ultra/tests/check_ultra_drafts.py
@@ -0,0 +1,332 @@
+#!/usr/bin/env python3
+"""Focused-draft native scenarios; run only under the private desktop harness."""
+import ctypes as C
+import json
+import os
+from pathlib import Path
+import re
+import time
+
+import check_canvas_desktop as ui
+import check_documents_desktop as documents
+from gi.repository import Atspi
+
+output = ui.output
+path = output / 'initial.ultra'
+root_title = path.name + ' - Ultra'
+trace = output / 'app.log'
+
+
+def wait_until(predicate, message):
+    for _ in range(120):
+        value = predicate()
+        if value:
+            return value
+        time.sleep(.1)
+    raise AssertionError(message)
+
+
+def records():
+    lines = trace.read_text(errors='replace').splitlines()
+    return [dict(re.findall(r'(event|owner|revision|scope|depth|token|code)=([\w]+)', line))
+            for line in lines if line.startswith('ultra-document-trace ')]
+
+
+def value(number, digits):
+    control = ui.wait_for(f'number.legacy value, object {number}')
+    assert Atspi.Component.grab_focus(control)
+    ui.keys('Control_L', 'a')
+    for digit in digits:
+        ui.keys(digit)
+    observed=Atspi.Text.get_text(control,0,-1)
+    assert observed==digits, f'focused number {number} displays {observed!r}, expected {digits!r}'
+
+
+def root():
+    documents.focus(root_title)
+    ui.wait_for('Editable patch canvas')
+
+
+def save_and_wait(expected):
+    ui.keys('Control_L', 's')
+    wait_until(lambda: json.loads(path.read_text())['nodes'][0]['params']['value'] == expected,
+               f'disk root value did not become {expected}')
+
+
+def cancel_picker():
+    def cancel_button():
+        for frame in documents.app_frames():
+            if frame.get_role_name() not in ('file chooser', 'dialog'):
+                continue
+            for element in ui.walk(frame):
+                if element.get_name() in ('Cancel', '_Cancel') and 'Action' in element.get_interfaces():
+                    return element
+        return None
+    assert Atspi.Action.do_action(wait_until(cancel_button, 'Save As picker did not open'), 0)
+
+
+def run_save_as():
+    root();ui.keys('Control_L', 'e');value(1, '42')
+    ui.keys('Control_L', 'Shift_L', 's')
+    wait_until(lambda: any(record.get('event') == 'save_begin' and record.get('code') == '1' for record in records()), 'Save As did not start')
+    cancel_picker()
+    wait_until(lambda: any(record.get('event') == 'save_cancel' for record in records()), 'Save As did not cancel')
+    assert json.loads(path.read_text())['nodes'][0]['params']['value'] == 10
+    root();save_and_wait(42)
+    entries = records();commits = [entry for entry in entries if entry.get('event') == 'commit' and entry.get('code') == '1']
+    assert len(commits) == 1, commits
+    assert int(commits[0]['revision']) == int(commits[0]['token']) + 1, commits
+    (output / 'focused-save-as.json').write_text(json.dumps({'records': entries, 'saved': json.loads(path.read_text())}, indent=2) + '\n')
+    print('PASS focused Save As cancellation and subsequent Save', flush=True)
+
+
+def double_click(name):
+    control = ui.wait_for(name);rect = Atspi.Component.get_extents(control, Atspi.CoordType.SCREEN)
+    assert ui.t.XTestFakeMotionEvent(ui.display, 0, rect.x + rect.width // 2, rect.y + rect.height // 2, 0)
+    for _ in range(2):
+        assert ui.t.XTestFakeButtonEvent(ui.display, 1, 1, 0)
+        assert ui.t.XTestFakeButtonEvent(ui.display, 1, 0, 0)
+        ui.x.XFlush(ui.display);time.sleep(.07)
+
+
+def titles():
+    return [frame.get_name().removeprefix('* ') for frame in documents.app_frames()]
+
+
+def request_os_close(title):
+    class Data(C.Union):
+        _fields_=[('bytes',C.c_char*20),('longs',C.c_long*5)]
+    class Client(C.Structure):
+        _fields_=[('type',C.c_int),('serial',C.c_ulong),('send_event',C.c_int),('display',C.c_void_p),
+                  ('window',C.c_ulong),('message_type',C.c_ulong),('format',C.c_int),('data',Data)]
+    class Event(C.Union):
+        _fields_=[('client',Client),('padding',C.c_long*24)]
+    documents.focus(title);focused,revert=C.c_ulong(),C.c_int()
+    ui.x.XGetInputFocus(ui.display,C.byref(focused),C.byref(revert))
+    ui.x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];ui.x.XInternAtom.restype=C.c_ulong
+    ui.x.XSendEvent.argtypes=[C.c_void_p,C.c_ulong,C.c_int,C.c_long,C.POINTER(Event)]
+    event=Event();event.client.type=33;event.client.display=ui.display;event.client.window=focused.value
+    event.client.message_type=ui.x.XInternAtom(ui.display,b'WM_PROTOCOLS',0);event.client.format=32
+    event.client.data.longs[0]=ui.x.XInternAtom(ui.display,b'WM_DELETE_WINDOW',0)
+    assert ui.x.XSendEvent(ui.display,focused.value,0,0,C.byref(event));ui.x.XFlush(ui.display)
+
+
+def run_child():
+    root();double_click('Select or drag p object 3')
+    child = wait_until(lambda: next((title for title in titles() if 'boundary' in title and title != root_title), None), 'child window did not open')
+    documents.focus(child);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L', 'e');value(13, '73')
+    documents.native_menu('Close Window')
+    wait_until(lambda: child not in titles(), 'child did not close')
+    entries = records();commits = [entry for entry in entries if entry.get('event') == 'commit' and entry.get('code') == '1']
+    assert len(commits) == 1 and int(commits[0]['revision']) == int(commits[0]['token']) + 1, commits
+    ack = [entry for entry in entries if entry.get('event') == 'close_ack' and entry.get('code') == '1']
+    assert ack and int(ack[-1]['revision']) == int(commits[0]['revision']), entries
+    assert entries.index(commits[0]) < entries.index(ack[-1]), entries
+    root();ui.keys('Control_L', 's')
+    def saved():
+        patch = json.loads(path.read_text())
+        child_node = next(node for node in patch['nodes'] if node['id'] == 3)
+        return patch if child_node['patcher']['nodes'][0]['params']['value'] == 73 else None
+    patch = wait_until(saved, 'child value not saved into owner')
+    (output / 'focused-child-close.json').write_text(json.dumps({'records': records(), 'saved': patch}, indent=2) + '\n')
+    print('PASS focused child close flush, owner revision and Save', flush=True)
+
+
+def run_linked():
+    root();double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not open')
+    documents.focus(child);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','e');value(13,'73')
+    root();assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','e');value(1,'42');ui.keys('Control_L','s')
+    def saved():
+        patch=json.loads(path.read_text());nodes=patch['nodes'];child_node=next(node for node in nodes if node['id']==3)
+        return patch if nodes[0]['params']['value']==42 and child_node['patcher']['nodes'][0]['params']['value']==73 else None
+    patch=wait_until(saved,'linked edits did not both reach disk')
+    entries=records();commits=[entry for entry in entries if entry.get('event')=='commit' and entry.get('code')=='1']
+    assert len(commits)==2,entries
+    assert [int(entry['revision']) for entry in commits]==[1,2],entries
+    assert {entry['scope'] for entry in commits}=={'0','3'},entries
+    assert all(int(entry['revision'])==int(entry['token'])+1 for entry in commits),entries
+    assert next(entry for entry in entries if entry.get('event')=='save_done')['revision']=='2',entries
+    (output/'focused-linked.json').write_text(json.dumps({'records':entries,'saved':patch},indent=2)+'\n')
+    print('PASS linked root and child edits retain both revisions in saved owner',flush=True)
+
+
+def run_peer_invalid(reverse=False,save_as=False):
+    root();double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not open')
+    draft_title,save_title,number=(root_title,child,1) if reverse else (child,root_title,13)
+    documents.focus(draft_title);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','e');control=ui.wait_for(f'number.legacy value, object {number}');assert Atspi.Component.grab_focus(control)
+    ui.keys('Control_L','a');ui.keys('BackSpace')
+    assert Atspi.Text.get_text(control,0,-1)=='', 'peer draft was not empty'
+    documents.focus(save_title);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','Shift_L','s') if save_as else ui.keys('Control_L','s')
+    wait_until(lambda:any(entry.get('event') in ('save_begin','save_refused') for entry in records()),'Save result not observed')
+    entries=records();assert not any(entry.get('event')=='save_begin' for entry in entries),entries
+    documents.focus(draft_title);assert Atspi.Text.get_text(ui.wait_for(f'number.legacy value, object {number}'),0,-1)==''
+    assert json.loads(path.read_text())['nodes'][1]['patcher']['nodes'][0]['params']['value']==10
+    (output/'peer-invalid.json').write_text(json.dumps({'records':entries},indent=2)+'\n')
+    print('PASS root Save refuses a parked invalid child draft',flush=True)
+
+
+def run_peer_valid(reverse=False):
+    root();double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not open')
+    draft_title,save_title,number,digits=(root_title,child,1,'42') if reverse else (child,root_title,13,'73')
+    documents.focus(draft_title);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','e');value(number,digits)
+    documents.focus(save_title);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'));ui.keys('Control_L','s')
+    def saved():
+        patch=json.loads(path.read_text());node=patch['nodes'][0] if reverse else patch['nodes'][1]['patcher']['nodes'][0]
+        return patch if node['params']['value']==int(digits) else None
+    patch=wait_until(saved,'linked valid draft did not reach disk');entries=records()
+    commits=[entry for entry in entries if entry.get('event')=='commit' and entry.get('code')=='1']
+    assert len(commits)==1 and commits[0]['revision']=='1',entries
+    acks=[entry for entry in entries if entry.get('event')=='save_ack' and entry.get('code')=='1']
+    assert {entry['scope'] for entry in acks}=={'0','3'},entries
+    begin=next(entry for entry in entries if entry.get('event')=='save_begin')
+    assert begin['revision']=='1' and entries.index(commits[0])<entries.index(begin),entries
+    assert all(entries.index(ack)<entries.index(begin) for ack in acks),entries
+    (output/'peer-valid.json').write_text(json.dumps({'records':entries,'saved':patch},indent=2)+'\n')
+    print('PASS linked valid edit admitted once before Save snapshot',flush=True)
+
+
+def run_overlapping_saves():
+    root();double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not open')
+    root();ui.keys('Control_L','e');value(1,'42');ui.keys('Control_L','Shift_L','s')
+    wait_until(lambda:any(entry.get('event')=='save_begin' and entry.get('code')=='1' for entry in records()),'Save As did not start')
+    documents.focus(child);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'));ui.keys('Control_L','s')
+    ui.wait_for('A Save is already in progress for this patch',text_content=True)
+    assert len([entry for entry in records() if entry.get('event')=='save_begin'])==1,records()
+    cancel_picker();wait_until(lambda:any(entry.get('event')=='save_cancel' for entry in records()),'Save As did not cancel')
+    documents.focus(child);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'));ui.keys('Control_L','s')
+    wait_until(lambda:json.loads(path.read_text())['nodes'][0]['params']['value']==42,'retry Save did not write owner')
+    entries=records();assert len([entry for entry in entries if entry.get('event')=='save_begin'])==2,entries
+    (output/'overlapping-saves.json').write_text(json.dumps({'records':entries,'saved':json.loads(path.read_text())},indent=2)+'\n')
+    print('PASS same-owner concurrent Save refused until picker cancellation',flush=True)
+
+
+def run_picker_edit():
+    root();double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not open')
+    root();ui.keys('Control_L','e');value(1,'42');ui.keys('Control_L','Shift_L','s')
+    wait_until(lambda:any(entry.get('event')=='save_begin' and entry.get('code')=='1' for entry in records()),'Save As did not start')
+    documents.focus(child);assert Atspi.Component.grab_focus(ui.wait_for('Editable patch canvas'))
+    ui.keys('Control_L','e');value(13,'73');ui.keys('Return')
+    wait_until(lambda:any(entry.get('event')=='commit' and entry.get('revision')=='2' for entry in records()),'child edit did not commit while picker open')
+    destination=output/'picker-snapshot.ultra';documents.focus('Save Ultra Patch')
+    for _ in range(20):
+        try:
+            documents.scoped_find('Native filename entry');break
+        except StopIteration:
+            ui.keys('slash')
+    ui.text('Native filename entry',str(destination.resolve()));ui.keys('Return')
+    patch=wait_until(lambda:json.loads(destination.read_text()) if destination.exists() else None,'Save As did not write snapshot')
+    assert patch['nodes'][0]['params']['value']==42 and patch['nodes'][1]['patcher']['nodes'][0]['params']['value']==10,patch
+    wait_until(lambda:any(frame.get_name().startswith('* ') and destination.name in frame.get_name() for frame in documents.app_frames()),'newer edit did not remain dirty')
+    renamed=wait_until(lambda:next((title for title in titles() if 'boundary' in title and destination.name in title),None),'child title did not follow Save As')
+    documents.focus(renamed);assert Atspi.Text.get_text(ui.wait_for('number.legacy value, object 13'),0,-1)=='73'
+    entries=records();assert next(entry for entry in entries if entry.get('event')=='save_begin')['revision']=='1',entries
+    assert next(entry for entry in entries if entry.get('event')=='save_done')['revision']=='2',entries
+    (output/'picker-edit.json').write_text(json.dumps({'records':entries,'saved':patch,'child':73,'dirty':True},indent=2)+'\n')
+    print('PASS edit during Save As keeps newer owner dirty',flush=True)
+
+
+def run_quit():
+    root();ui.click('File');ui.wait_for('Quit Ultra');ui.keys('Escape')
+    root();ui.keys('Control_L', 'e');value(1, '42');ui.keys('Control_L', 'q')
+    documents.focus('Unsaved Patch');ui.click('Cancel');root()
+    assert json.loads(path.read_text())['nodes'][0]['params']['value'] == 10
+    ui.keys('Control_L', 'q');documents.focus('Unsaved Patch');ui.click('Save')
+    wait_until(lambda: json.loads(path.read_text())['nodes'][0]['params']['value'] == 42, 'Quit Save did not persist focused draft')
+    entries=records();commits=[entry for entry in entries if entry.get('event')=='commit' and entry.get('code')=='1']
+    assert len(commits)==1 and int(commits[0]['revision'])==int(commits[0]['token'])+1, entries
+    assert any(entry.get('event')=='quit_prepare' for entry in entries),entries
+    acks=[entry for entry in entries if entry.get('event')=='close_ack' and entry.get('code')=='1']
+    assert acks and int(acks[0]['revision'])==int(commits[0]['revision']),entries
+    assert entries.index(commits[0])<entries.index(acks[0]),entries
+    def exited():
+        status=Path(f'/proc/{ui.pid}/status')
+        return not status.exists() or '\nState:\tZ' in status.read_text()
+    wait_until(exited,'Quit did not exit the application')
+    (output/'focused-quit.json').write_text(json.dumps({'records':entries,'saved':json.loads(path.read_text())},indent=2)+'\n')
+    print('PASS focused Quit Cancel followed by Save',flush=True)
+
+
+def run_quit_discard():
+    root();ui.keys('Control_L','e');value(1,'42');ui.keys('Control_L','q')
+    documents.focus('Unsaved Patch');ui.click('Discard')
+    def exited():
+        status=Path(f'/proc/{ui.pid}/status')
+        return not status.exists() or '\nState:\tZ' in status.read_text()
+    wait_until(exited,'Quit Discard did not exit the application')
+    saved=json.loads(path.read_text());assert saved['nodes'][0]['params']['value']==10
+    entries=records();commits=[entry for entry in entries if entry.get('event')=='commit' and entry.get('code')=='1']
+    assert len(commits)==1 and int(commits[0]['revision'])==int(commits[0]['token'])+1,entries
+    assert any(entry.get('event')=='close_ack' and entry.get('revision')==commits[0]['revision'] for entry in entries),entries
+    (output/'focused-quit-discard.json').write_text(json.dumps({'records':entries,'saved':saved},indent=2)+'\n')
+    print('PASS focused Quit Discard leaves disk unchanged',flush=True)
+
+
+def run_close(discard=False):
+    root();ui.keys('Control_L','e');value(1,'42');documents.native_menu('Close Window')
+    documents.focus('Unsaved Patch')
+    if not discard:
+        ui.click('Cancel');root();assert json.loads(path.read_text())['nodes'][0]['params']['value']==10
+        documents.native_menu('Close Window');documents.focus('Unsaved Patch')
+    ui.click('Discard' if discard else 'Save')
+    wait_until(lambda:root_title not in titles(),'owner did not close')
+    saved=json.loads(path.read_text());assert saved['nodes'][0]['params']['value']==(10 if discard else 42)
+    entries=records();commits=[entry for entry in entries if entry.get('event')=='commit' and entry.get('code')=='1']
+    acks=[entry for entry in entries if entry.get('event')=='close_ack' and entry.get('code')=='1']
+    assert len(commits)==1 and int(commits[0]['revision'])==int(commits[0]['token'])+1,entries
+    assert acks and acks[0]['revision']==commits[0]['revision'] and entries.index(commits[0])<entries.index(acks[0]),entries
+    (output/'focused-close.json').write_text(json.dumps({'records':entries,'saved':saved},indent=2)+'\n')
+    print('PASS focused close '+('Discard' if discard else 'Cancel followed by Save'),flush=True)
+
+
+def run_reopen():
+    root();assert Atspi.Text.get_text(ui.wait_for('number.legacy value, object 1'),0,-1)=='42'
+    double_click('Select or drag p object 3')
+    child=wait_until(lambda:next((title for title in titles() if 'boundary' in title and title!=root_title),None),'child window did not reopen')
+    documents.focus(child)
+    assert Atspi.Text.get_text(ui.wait_for('number.legacy value, object 13'),0,-1)=='73'
+    (output/'focused-reopen.json').write_text(json.dumps({'root':42,'child':73},indent=2)+'\n')
+    print('PASS restarted owner and child display saved values',flush=True)
+
+
+def run_os_close(invalid=False):
+    root();ui.keys('Control_L','e')
+    if invalid:
+        control=ui.wait_for('number.legacy value, object 1');assert Atspi.Component.grab_focus(control)
+        ui.keys('Control_L','a');ui.keys('BackSpace');assert Atspi.Text.get_text(control,0,-1)==''
+    else:value(1,'42')
+    request_os_close(root_title)
+    if invalid:
+        wait_until(lambda:any(item.get('event')=='close_ack' and item.get('code')=='0' for item in records()),'invalid OS close not rejected')
+        assert root_title in titles();root();assert Atspi.Text.get_text(ui.wait_for('number.legacy value, object 1'),0,-1)==''
+        assert json.loads(path.read_text())['nodes'][0]['params']['value']==10
+    else:
+        documents.focus('Unsaved Patch');ui.click('Save');wait_until(lambda:root_title not in titles(),'OS close did not finish')
+        assert json.loads(path.read_text())['nodes'][0]['params']['value']==42
+        entries=records();commit=next(item for item in entries if item.get('event')=='commit' and item.get('code')=='1')
+        ack=next(item for item in entries if item.get('event')=='close_ack' and item.get('code')=='1')
+        assert commit['revision']==ack['revision']=='1' and entries.index(commit)<entries.index(ack),entries
+    (output/'focused-os-close.json').write_text(json.dumps({'invalid':invalid,'records':records(),'saved':json.loads(path.read_text())},indent=2)+'\n')
+    print('PASS focused X11 WM_DELETE_WINDOW '+('invalid refusal' if invalid else 'Save'),flush=True)
+
+
+if __name__ == '__main__':
+    scenario = os.environ['ULTRA_DRAFT_CASE']
+    try:
+        {'save-as': run_save_as, 'child': run_child, 'linked': run_linked, 'peer-invalid':run_peer_invalid,
+         'peer-invalid-as':lambda:run_peer_invalid(save_as=True), 'peer-invalid-reverse':lambda:run_peer_invalid(reverse=True), 'quit': run_quit,
+         'peer-valid':run_peer_valid, 'peer-valid-reverse':lambda:run_peer_valid(True), 'overlap-saves':run_overlapping_saves, 'picker-edit':run_picker_edit,
+         'quit-discard': run_quit_discard, 'close': run_close, 'close-discard': lambda:run_close(True), 'reopen':run_reopen,
+         'os-close':run_os_close, 'os-close-invalid':lambda:run_os_close(True)}[scenario]()
+    finally:
+        ui.x.XCloseDisplay(ui.display)
diff --git a/apps/ultra/tests/chooser_observation.py b/apps/ultra/tests/chooser_observation.py
new file mode 100644
index 0000000..70d2327
--- /dev/null
+++ b/apps/ultra/tests/chooser_observation.py
@@ -0,0 +1,40 @@
+"""Bound chooser observations between synchronous accessibility calls.
+
+An individual external accessibility call can still block beyond the time budget.
+"""
+import time
+
+
+def find_web_ancestor(node, max_nodes=32, seconds=.15, clock=time.monotonic):
+    deadline = clock() + seconds
+    count = 0
+    try:
+        while node is not None and count < max_nodes:
+            if clock() >= deadline:
+                return None, {'status': 'truncated', 'reason': 'time_limit', 'nodes': count}
+            count += 1
+            if node.get_role_name() == 'document web':
+                return node, {'status': 'complete', 'nodes': count}
+            node = node.get_parent()
+        if node is None:
+            return None, {'status': 'unavailable', 'reason': 'no_web_ancestor', 'nodes': count}
+        return None, {'status': 'truncated', 'reason': 'node_limit', 'nodes': count}
+    except Exception as error:
+        return None, {'status': 'unavailable', 'error_type': type(error).__name__, 'nodes': count}
+
+
+def planned_hit_path(node, child_at_point, max_nodes=32, seconds=.15, clock=time.monotonic):
+    deadline = clock() + seconds
+    path = []
+    try:
+        while node is not None and len(path) < max_nodes:
+            if clock() >= deadline:
+                return {'status': 'truncated', 'reason': 'time_limit', 'path': path}
+            path.append({'name': (node.get_name() or '')[:256], 'role': node.get_role_name()})
+            child = child_at_point(node)
+            if child is None or child == node:
+                return {'status': 'complete', 'path': path}
+            node = child
+        return {'status': 'truncated', 'reason': 'node_limit', 'path': path}
+    except Exception as error:
+        return {'status': 'unavailable', 'error_type': type(error).__name__, 'path': path}
diff --git a/apps/ultra/tests/ci/alive-chain.spec.mjs b/apps/ultra/tests/ci/alive-chain.spec.mjs
index 080dd04..bec42a3 100644
--- a/apps/ultra/tests/ci/alive-chain.spec.mjs
+++ b/apps/ultra/tests/ci/alive-chain.spec.mjs
@@ -19,7 +19,7 @@ async function openSession(page,longNames=false,clipBank=false,trackCount=2,work
     document.tracks[0].effects.push({instanceId,id:device.id,path:`${file}.ultra`,parameters:{},bypassed:false});
     deviceInstances[instanceId]={track:0,index:runtime.length,manifest};runtime.push({effective:manifest.parameters.map(p=>p.base),owned:manifest.parameters.map(()=>0)});
   }
-  const snapshot={generation:1,draftRevision:0,capabilities:{maxTracks:8,maxDevices:16,atomicTrackActions:true},history:{canUndo:false,canRedo:false},document,deviceInstances,dirty:false,draft:null,state:{playing:0,position:0,absoluteFrame:0,rejected:0,generation:1,peakLeft:0,peakRight:0,devices:runtime,tracks:document.tracks.map(()=>({peakLeft:0,peakRight:0,activeVoices:0}))},audio:{config:{host:'default',device:'default',sample_rate:48000},observed_buffer_frames:0,callbacks:0,stream_errors:0,failed:false,message:'Browser fixture'}};
+  const snapshot={master:{gain:1,acceptedSerial:'1',available:true,unavailableReason:null,observationStale:false,observation:{targetGain:1,currentGain:1,peakLeft:.2,peakRight:1.2,clipMask:2,appliedSerial:'1',appliedFrame:'64',observationStartFrame:'0',observationEndFrame:'64'}},generation:1,draftRevision:0,capabilities:{maxTracks:8,maxDevices:16,atomicTrackActions:true},history:{canUndo:false,canRedo:false},document,deviceInstances,dirty:false,draft:null,state:{playing:0,position:0,absoluteFrame:0,rejected:0,generation:1,peakLeft:0,peakRight:0,devices:runtime,tracks:document.tracks.map(()=>({peakLeft:0,peakRight:0,activeVoices:0}))},audio:{config:{host:'default',device:'default',sample_rate:48000},observed_buffer_frames:0,callbacks:0,stream_errors:0,failed:false,message:'Browser fixture'}};
   if(clipBank){
     document.format='alive-session-v3';snapshot.mode='clipsV3';snapshot.preparationRevision='9007199254740993';snapshot.snapshotSequence='1';snapshot.preparedClips=[];
     document.tracks.forEach(t=>{const c={id:`clip-${t.id}`,name:'Clip 1',lengthBeats:8,notes:t.notes.map((n,i)=>({...n,id:`note-${t.id}-${i}`})),automation:t.automation};t.slots=[c,null,null,null];t.defaultClipId=c.id;delete t.notes;delete t.automation;snapshot.preparedClips.push({trackId:t.id,clipId:c.id,name:c.name,slot:0,lengthFrames:'205714'});});
@@ -54,6 +54,7 @@ async function openSession(page,longNames=false,clipBank=false,trackCount=2,work
         else throw Error('Unsupported fixture edit '+op.kind);
         undo.push(structuredClone(snapshot.draft??snapshot.document));redo.length=0;snapshot.draft=draft;snapshot.draftRevision++;snapshot.history={canUndo:true,canRedo:false};return{snapshot:structuredClone(snapshot),affected};
       }
+      if(name==='alive_master'||name==='alive_master_reset_clip'){window.calls.push({name,args});if(window.masterGate)return window.masterGate(name,args);if(args.generation!==snapshot.generation)throw {code:'STALE_GENERATION',message:'stale generation'};const serial=String(BigInt(snapshot.master.acceptedSerial)+1n);snapshot.master.acceptedSerial=serial;snapshot.master.observation.appliedSerial=serial;if(name==='alive_master'){snapshot.master.gain=args.gain;snapshot.master.observation.targetGain=args.gain;snapshot.master.observation.currentGain=args.gain;return {generation:args.generation,acceptedGain:args.gain,acceptedSerial:serial,changed:true};}snapshot.master.observation.clipMask=0;return {generation:args.generation,acceptedSerial:serial};}
       if(name==='alive_mixer'){window.calls.push({name,args});for(const document of [snapshot.document,snapshot.draft])if(document)Object.assign(document.tracks[args.track],{gain:args.gain,mute:args.mute,solo:args.solo});snapshot.dirty=true;return;}
       if(name==='alive_clip_edit'){window.calls.push({name,args});const op=args.operation;if(op.kind!=='create')throw Error('Fixture supports create only');snapshot.draft??=structuredClone(snapshot.document);const track=snapshot.draft.tracks.find(t=>t.id===op.trackId);if(track.slots[op.slot])throw Error('Slot already occupied');track.slots[op.slot]={id:`new-${track.id}-${op.slot}`,name:'New clip',lengthBeats:8,notes:[],automation:[]};snapshot.draftRevision++;snapshot.history={canUndo:true,canRedo:false};return{snapshot:structuredClone(snapshot),affected:{trackId:track.id,slot:op.slot}};}
       return previous(name,args);
@@ -110,12 +111,33 @@ test('vertical gain fader sends one bounded change and reflects external snapsho
 for(const size of [{width:1440,height:900},{width:1280,height:800}])test(`two fixed track columns leave blank stage and expose piano roll at ${size.width}x${size.height}`,async({page},testInfo)=>{
   await page.setViewportSize(size);await openSession(page,false,true);
   const geometry=await page.evaluate(()=>{const rect=e=>e.getBoundingClientRect().toJSON();return{track:[...document.querySelectorAll('.track')].map(rect),mixerControls:[...document.querySelectorAll('.mixer-toggle,.track-inspector')].map(rect),session:rect(document.querySelector('#session-workspace')),piano:rect(document.querySelector('#piano-roll')),detail:rect(document.querySelector('#detail-content')),scene:rect(document.querySelector('.scene-column'))};});
-  for(const track of geometry.track)expect(track.width).toBe(146);expect(geometry.scene.x-(geometry.track[1].x+geometry.track[1].width)).toBeGreaterThan(300);
+  for(const track of geometry.track)expect(track.width).toBe(128);expect(geometry.scene.x-(geometry.track[1].x+geometry.track[1].width)).toBeGreaterThan(300);
   for(const control of geometry.mixerControls)expect(control.bottom).toBeLessThanOrEqual(geometry.session.bottom);
   expect(geometry.piano.y).toBeLessThan(geometry.detail.y+65);expect(Math.min(geometry.piano.bottom,geometry.detail.bottom)-geometry.piano.y).toBeGreaterThan(150);
   await page.screenshot({path:testInfo.outputPath(`two-tracks-${size.width}x${size.height}.png`)});
 });
 
+for(const size of [{width:1440,height:900},{width:1280,height:800}])for(const fixture of [{name:'v4 two-track',count:2,v4:true},{name:'v3 eight-track',count:8,v4:false}])test(`expanded inspector preserves shared mixer baseline in ${fixture.name} at ${size.width}x${size.height}`,async({page},testInfo)=>{
+  await page.setViewportSize(size);await openSession(page,false,true,fixture.count,fixture.v4);
+  const tracks=page.locator('.track'),inspector=tracks.first().locator('.track-inspector'),summary=inspector.locator('summary');
+  const geometry=()=>tracks.evaluateAll(elements=>elements.slice(0,2).map(track=>{
+    const box=selector=>{const r=track.querySelector(selector).getBoundingClientRect();return {top:r.top,bottom:r.bottom};};
+    return {fader:box('.gain-fader'),mute:box('.mixer-toggle:first-child'),solo:box('.mixer-toggle:last-child')};
+  }));
+  const before=await geometry();await summary.focus();await summary.press('Enter');await expect(inspector).toHaveAttribute('open','');
+  const after=await geometry();await page.screenshot({path:testInfo.outputPath(`expanded-${fixture.name.replaceAll(' ','-')}-${size.width}x${size.height}.png`)});
+  for(const control of ['fader','mute','solo'])for(const edge of ['top','bottom']){
+    expect(Math.abs(before[0][control][edge]-before[1][control][edge]),`collapsed ${control} ${edge}`).toBeLessThanOrEqual(2);
+    expect(Math.abs(after[0][control][edge]-after[1][control][edge]),`expanded ${control} ${edge}`).toBeLessThanOrEqual(2);
+    expect(Math.abs(after[0][control][edge]-before[0][control][edge]),`stable ${control} ${edge}`).toBeLessThanOrEqual(2);
+  }
+  for(const name of ['Open Pulse editor','Replace Pulse device','Remove Pulse track']){
+    const action=page.getByRole('button',{name,exact:true});await expect(action).toBeVisible();await action.focus();await expect(action).toBeFocused();await action.click({trial:true});
+  }
+  await page.locator('#stop').click({trial:true});await page.locator('#master-session').getByLabel('Master gain fader').click({trial:true});
+  expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(size.width);
+});
+
 test('Add note queued behind track removal never edits the surviving track',async({page})=>{
   const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.setViewportSize({width:1100,height:800});await openSession(page);
   await page.locator('.track-inspector summary').first().click();
@@ -298,14 +320,19 @@ async function openArrangement(page,size){
   await page.locator('#view-arrangement').click();await expect(page.getByRole('button',{name:'Select placement p-0',exact:true})).toBeVisible();
 }
 const workspaceEdits=page=>page.evaluate(()=>window.calls.filter(c=>c.name==='alive_workspace_edit'));
-async function dragTimeline(page,locator,from,to,{cancel=false,hide=false}={}){
-  const box=await locator.boundingBox();await page.mouse.move(box.x+from[0],box.y+from[1]);await page.mouse.down();await page.mouse.move(box.x+to[0],box.y+to[1],{steps:6});
+async function dragTimeline(page,locator,from,to,{cancel=false,hide=false,box=null}={}){
+  box??=await locator.boundingBox();await page.mouse.move(box.x+from[0],box.y+from[1]);await page.mouse.down();await page.mouse.move(box.x+to[0],box.y+to[1],{steps:6});
   if(cancel)await page.keyboard.press('Escape');if(hide)await page.locator('#view-session').click();await page.mouse.up();
 }
+async function dragBlankLaneRange(page,lane){
+  const box=await page.evaluate(()=>{const element=document.querySelector('.timeline-lane'),rect=element?.getBoundingClientRect();return rect&&rect.width&&rect.height?{x:rect.x,y:rect.y}:null;});
+  expect(box).not.toBeNull();await dragTimeline(page,lane,[384,35],[480,35],{box});
+}
 for(const size of [{width:1440,height:900},{width:1280,height:800}]){
   test(`Arrangement pointer edits, cancellation and local view controls at ${size.width}`,async({page})=>{
     await openArrangement(page,size);const p=page.getByRole('button',{name:'Select placement p-0',exact:true});
-    const box=await p.boundingBox();await page.mouse.move(box.x+30,box.y+12);await page.mouse.down();await page.mouse.move(box.x+126,box.y+12,{steps:5});expect(await workspaceEdits(page)).toHaveLength(0);await page.mouse.up();
+    // Read the current placement and its geometry together; timeline redraws replace its nodes.
+    const box=await page.evaluate(()=>{const element=document.querySelector('[data-placement-id="p-0"]'),rect=element?.getBoundingClientRect();return rect&&rect.width&&rect.height?{x:rect.x,y:rect.y}:null;});expect(box).not.toBeNull();await page.mouse.move(box.x+30,box.y+12);await page.mouse.down();await page.mouse.move(box.x+126,box.y+12,{steps:5});expect(await workspaceEdits(page)).toHaveLength(0);await page.mouse.up();
     await expect(page.getByLabel('Placement start',{exact:true})).toHaveValue('2');expect(await workspaceEdits(page)).toHaveLength(1);
     await dragTimeline(page,p,[30,12],[78,12],{cancel:true});expect(await workspaceEdits(page)).toHaveLength(1);await expect(page.getByLabel('Placement start',{exact:true})).toHaveValue('2');
     await dragTimeline(page,p.locator('.timeline-edge.right'),[3,15],[51,15]);await expect(page.getByLabel('Placement duration',{exact:true})).toHaveValue('5');
@@ -326,11 +353,22 @@ for(const size of [{width:1440,height:900},{width:1280,height:800}]){
   });
 }
 test('Arrangement creates separate source and occurrence history and cancels stale gestures and brace previews',async({page})=>{
-  await openArrangement(page,{width:1280,height:800});const lane=page.locator('.timeline-lane').first();await dragTimeline(page,lane,[384,35],[480,35]);await page.getByRole('button',{name:'Create MIDI source',exact:true}).click();await expect(page.getByLabel('MIDI source',{exact:true})).toHaveValue('new-source-1');await page.getByRole('button',{name:'Place source in range',exact:true}).click();expect((await workspaceEdits(page)).map(c=>c.args.operation.kind)).toEqual(['sourceCreateMidi','placementCreate']);
+  await openArrangement(page,{width:1280,height:800});const lane=page.locator('.timeline-lane').first();await dragBlankLaneRange(page,lane);await page.getByRole('button',{name:'Create MIDI source',exact:true}).click();await expect(page.getByLabel('MIDI source',{exact:true})).toHaveValue('new-source-1');await page.getByRole('button',{name:'Place source in range',exact:true}).click();expect((await workspaceEdits(page)).map(c=>c.args.operation.kind)).toEqual(['sourceCreateMidi','placementCreate']);
   const p=page.getByRole('button',{name:'Select placement new-placement-2',exact:true});const b=await p.boundingBox();await page.mouse.move(b.x+30,b.y+15);await page.mouse.down();await page.mouse.move(b.x+78,b.y+15);const polls=await page.evaluate(()=>{window.sessionSnapshot.draftRevision++;return window.calls.filter(c=>c.name==='alive_current').length;});await expect.poll(()=>page.evaluate(()=>window.calls.filter(c=>c.name==='alive_current').length)).toBeGreaterThan(polls+1);await page.mouse.up();expect(await workspaceEdits(page)).toHaveLength(2);
   await dragTimeline(page,page.locator('.timeline-brace .right'),[3,8],[-93,8],{cancel:true});expect(await workspaceEdits(page)).toHaveLength(2);
   await dragTimeline(page,page.locator('.timeline-brace .right'),[3,8],[-93,8]);await expect(page.getByLabel('Song loop end',{exact:true})).toHaveValue('6');expect((await workspaceEdits(page)).at(-1).args.operation.kind).toBe('transportRange');
 });
+test('Arrangement blank-lane drag selects the range after a timeline redraw',async({page})=>{
+  await openArrangement(page,{width:1280,height:800});const lane=page.locator('.timeline-lane').first();
+  const redraw=async()=>{await page.getByRole('button',{name:'Zoom timeline in',exact:true}).click();await page.getByRole('button',{name:'Zoom timeline out',exact:true}).click();};
+  await page.evaluate(()=>{window.previousLane=document.querySelector('.timeline-lane');});await redraw();
+  expect(await page.evaluate(()=>!window.previousLane.isConnected&&window.previousLane!==document.querySelector('.timeline-lane'))).toBe(true);
+  // A handle-based geometry read must survive an actual redraw at its resolution boundary.
+  const withElement=lane._withElement.bind(lane);lane._withElement=(task,options)=>withElement(async handle=>{await redraw();return task(handle);},options);
+  await dragBlankLaneRange(page,lane);await expect(page.locator('#timeline-range')).toHaveText('Range 8 - 10 beats');
+  await page.getByRole('button',{name:'Create MIDI source',exact:true}).click();await expect(page.getByLabel('MIDI source',{exact:true})).toHaveValue('new-source-1');
+  expect((await workspaceEdits(page)).map(c=>c.args.operation.kind)).toEqual(['sourceCreateMidi']);
+});
 for(const size of [{width:1440,height:900},{width:1280,height:800}])test(`Arrangement eight-track scrolling, long names and expanded detail stay bounded at ${size.width}`,async({page})=>{
   await page.setViewportSize(size);await openSession(page,true,true,8,true);await page.evaluate(()=>{const s=window.sessionSnapshot;s.document.lengthBeats=128;s.document.tracks[0].name='Long track name '.repeat(8);s.document.placements=[{id:'long',trackId:s.document.tracks[0].id,sourceId:s.document.sources[0].id,start:0,duration:4,sourceOffset:{kind:'beats',value:0},loopEnabled:true}];s.document.sources[0].name='Long MIDI source name '.repeat(5);s.draftRevision++;});
   await page.locator('#view-arrangement').click();await page.getByRole('button',{name:'Select placement long',exact:true}).click();await page.getByRole('separator',{name:'Resize detail area'}).focus();await page.keyboard.press('End');
@@ -353,3 +391,115 @@ for(const size of [{width:1440,height:900},{width:1280,height:800}])test(`Arrang
   expect(await page.evaluate(()=>window.calls.find(c=>c.name==='alive_mixer').args)).toMatchObject({track:0,gain:.713});await expect(page.locator('#arrangement-workspace')).toBeVisible();
   await page.locator('#view-session').click();await expect(page.getByLabel('Pulse gain',{exact:true})).toHaveValue('0.713');
 });
+
+for(const size of [{width:1440,height:900},{width:1280,height:800}])for(const profile of ['v4','v3'])test(`Master and compact workspace geometry ${profile} ${size.width}`,async({page},testInfo)=>{
+  await page.setViewportSize(size);await openSession(page,false,true,profile==='v4'?2:8,profile==='v4');
+  const geometry=await page.evaluate(()=>{const box=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};return {chrome:box(document.querySelector('.workspace-tools')).bottom, browser:box(document.querySelector('#workspace-browser')),header:box(document.querySelector('.track-name')),slots:[...document.querySelectorAll('.track:first-child .clip-slot')].map(box),scenes:[...document.querySelectorAll('.scene-row')].map(box),master:box(document.querySelector('.scene-column')),masterMixer:box(document.querySelector('#master-session .master-controls')),masterRail:box(document.querySelector('#master-session .master-fader')),masterMeter:box(document.querySelector('#master-session .master-bars')),trackRail:box(document.querySelector('.track .gain-fader')),trackMeter:box(document.querySelector('.track .vertical-meter')),trackMixer:box(document.querySelector('.track-mixer')),workspace:box(document.querySelector('#session-workspace')),stop:box(document.querySelector('#stop')),scrollWidth:document.documentElement.scrollWidth,innerWidth:innerWidth};});
+  expect(geometry.chrome).toBeLessThanOrEqual(80);expect(geometry.browser.width).toBe(220);expect(geometry.header.height).toBe(28);expect(geometry.master.width).toBe(128);expect(geometry.masterMixer.y).toBe(geometry.trackMixer.y);expect(geometry.masterMixer.bottom).toBe(geometry.trackMixer.bottom);expect(Math.abs(geometry.masterRail.y-geometry.trackRail.y)).toBeLessThanOrEqual(2);expect(Math.abs(geometry.masterRail.bottom-geometry.trackRail.bottom)).toBeLessThanOrEqual(2);expect(Math.abs(geometry.masterMeter.y-geometry.trackMeter.y)).toBeLessThanOrEqual(2);expect(Math.abs(geometry.masterMeter.bottom-geometry.trackMeter.bottom)).toBeLessThanOrEqual(3);expect(geometry.slots).toHaveLength(4);expect(geometry.scenes).toHaveLength(4);
+  for(let i=0;i<4;i++){expect(geometry.slots[i].height).toBe(24);expect(geometry.scenes[i].y).toBe(geometry.slots[i].y);}expect(geometry.scrollWidth).toBe(geometry.innerWidth);expect(geometry.stop.right).toBeLessThan(size.width);
+  for(const x of [0,99999]){await page.locator('#session-workspace').evaluate((e,x)=>e.scrollLeft=x,x);await expect(page.locator('#master-select-session')).toBeInViewport();}
+  await page.locator('#session-workspace').evaluate(e=>e.scrollLeft=0);await page.mouse.move(500,10);await page.waitForTimeout(700);await page.screenshot({path:testInfo.outputPath(`master-session-${profile}-${size.width}.png`)});
+  if(profile==='v4'){await page.locator('#view-arrangement').click();const pos=await page.evaluate(()=>{const lane=document.querySelector('.timeline-lane').getBoundingClientRect(),header=document.querySelector('.timeline-header').getBoundingClientRect(),master=document.querySelector('#master-arrangement-lane').getBoundingClientRect();return {laneRight:lane.right,headerLeft:header.left,headerRight:header.right,viewportRight:document.querySelector('#timeline-scroll').getBoundingClientRect().right,masterY:master.y};});expect(pos.headerLeft).toBeGreaterThanOrEqual(pos.laneRight-1);expect(Math.abs(pos.headerRight-pos.viewportRight)).toBeLessThanOrEqual(1);expect(pos.masterY).toBeGreaterThan(0);await page.mouse.move(500,10);await page.waitForTimeout(700);await page.screenshot({path:testInfo.outputPath(`master-arrangement-${size.width}.png`)});}
+});
+
+test('both Master views share native gain, interval peaks, overload reset and local selection',async({page})=>{
+  await page.setViewportSize({width:1440,height:900});await openSession(page,false,true,2,true);
+  const session=page.locator('#master-session'),arrangement=page.locator('#master-arrangement');
+  await expect(session.getByLabel('Master left peak')).toHaveText('L 0.200');await expect(session.getByLabel('Master right peak')).toHaveText('R 1.200 !');
+  const calls=()=>page.evaluate(()=>window.calls.filter(c=>c.name!=='alive_current'));
+  await page.locator('#master-select-session').click();await expect(page.locator('#master-detail')).toBeVisible();expect(await calls()).toEqual([]);
+  const number=session.getByLabel('Master gain',{exact:true});await number.fill('0');await number.press('Tab');await expect(session.getByLabel('Master gain decibels')).toHaveText('-inf');await expect.poll(async()=>(await calls()).filter(c=>c.name==='alive_master').length).toBe(1);
+  await session.getByRole('button',{name:'Reset Master gain to unity'}).click();await expect.poll(async()=>Number(await number.inputValue())).toBe(1);
+  await session.getByRole('button',{name:'Reset Master digital overload'}).click();await expect(session.getByLabel('Master right peak')).toHaveText('R 1.200');
+  await page.locator('#view-arrangement').click();await expect(arrangement.getByLabel('Master gain decibels')).toHaveText('0.0 dB');await expect(arrangement.getByLabel('Master left peak')).toHaveText('L 0.200');
+  const fader=arrangement.getByLabel('Master gain fader');await fader.focus();await fader.press('ArrowUp');await expect.poll(async()=>(await calls()).filter(c=>c.name==='alive_master').length).toBe(3);
+  const sends=await calls();expect(sends.filter(c=>c.name==='alive_master').map(c=>c.args.gain)).toEqual([0,1,1.01]);expect(sends.filter(c=>c.name==='alive_master_reset_clip')).toHaveLength(1);
+});
+
+test('vertical Session faders respond to real upward and downward pointer drags',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,false,true,2,true);
+  for(const [label,container] of [['Pulse gain fader',page.locator('#session-workspace')],['Master gain fader',page.locator('#master-session')]]){
+    const fader=container.getByLabel(label,{exact:true}),box=await fader.boundingBox();expect(box.height).toBeGreaterThan(45);
+    await page.mouse.move(box.x+box.width/2,box.y+box.height*.8);await page.mouse.down();await page.mouse.move(box.x+box.width/2,box.y+box.height*.2,{steps:8});await page.mouse.up();const high=Number(await fader.inputValue());
+    await page.mouse.move(box.x+box.width/2,box.y+box.height*.2);await page.mouse.down();await page.mouse.move(box.x+box.width/2,box.y+box.height*.8,{steps:8});await page.mouse.up();const low=Number(await fader.inputValue());expect(high).toBeGreaterThan(low);
+  }
+});
+
+test('Master pressure retains the final intent and reports reset refusal without claiming it saved',async({page})=>{
+  await page.setViewportSize({width:1440,height:900});await openSession(page,false,true,2,true);
+  await page.evaluate(()=>{window.masterPending=[];window.masterGate=(name,args)=>new Promise((resolve,reject)=>window.masterPending.push({name,args,resolve,reject}));});
+  const root=page.locator('#master-session'),number=root.getByLabel('Master gain',{exact:true}),reset=root.getByRole('button',{name:'Reset Master digital overload'}),status=root.getByLabel('Master output status');
+  await number.fill('0.2');await number.press('Tab');await expect(status).toContainText('pending intent');await expect(status).toContainText('Saved target 0.0 dB');
+  await reset.click();await number.fill('0.8');await number.press('Tab');await reset.click();await expect(status).toContainText('already pending');
+  expect(await page.evaluate(()=>window.masterPending.map(p=>p.name))).toEqual(['alive_master']);
+  await page.evaluate(()=>window.masterPending[0].resolve({generation:1,acceptedGain:.2,acceptedSerial:'2',changed:true}));await expect.poll(()=>page.evaluate(()=>window.masterPending.length)).toBe(2);
+  expect(await page.evaluate(()=>window.masterPending[1].name)).toBe('alive_master_reset_clip');await page.evaluate(()=>window.masterPending[1].resolve({generation:1,acceptedSerial:'3'}));await expect.poll(()=>page.evaluate(()=>window.masterPending.length)).toBe(3);
+  expect(await page.evaluate(()=>window.masterPending[2].args.gain)).toBe(.8);await page.evaluate(()=>window.masterPending[2].resolve({generation:1,acceptedGain:.8,acceptedSerial:'4',changed:true}));await expect(status).toContainText('admitted');
+  await page.evaluate(()=>{const m=window.sessionSnapshot.master;m.gain=.8;m.acceptedSerial='4';m.observation.appliedSerial='4';m.observation.currentGain=.8;m.observation.targetGain=.8;});await expect(status).toContainText('applied -1.9 dB');
+});
+
+test('Master unavailable and stale observations remain explicit',async({page})=>{
+  await openSession(page,false,true,2,true);const root=page.locator('#master-session'),status=root.getByLabel('Master output status');
+  await page.evaluate(()=>{const m=window.sessionSnapshot.master;m.observationStale=true;m.observation.observationStartFrame=m.observation.observationEndFrame;});await expect(status).toContainText('stale observation');await expect(status).toContainText('empty interval');
+  await page.evaluate(()=>{const m=window.sessionSnapshot.master;m.available=false;m.unavailableReason='Library lacks Master';m.observation=null;m.acceptedSerial='0';});await expect(status).toContainText('Library lacks Master');await expect(root.getByLabel('Master gain fader')).toBeDisabled();await expect(root.getByLabel('Master left peak')).toHaveText('L unavailable');
+});
+
+test('Master selection parks unfinished clip text and caret without a native edit',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,false,true,2,true);
+  const input=page.getByLabel('Clip name',{exact:true});await input.fill('Unfinished clip');await input.evaluate(e=>e.setSelectionRange(3,7));
+  await page.locator('#master-select-session').click();await expect(page.locator('#master-detail')).toBeVisible();await page.getByRole('button',{name:'Select Pulse slot 1',exact:true}).click();
+  await expect(input).toHaveValue('Unfinished clip');expect(await input.evaluate(e=>[e.selectionStart,e.selectionEnd])).toEqual([3,7]);expect(await page.evaluate(()=>window.calls.filter(c=>c.name!=='alive_current'))).toEqual([]);
+});
+
+test('browser and column widths resize locally and Master selection preserves device binding',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,true,true,2,true);
+  await page.locator('#detail-devices').click();const parameter=page.getByLabel('Cutoff base',{exact:true});await parameter.fill('1777');
+  await page.locator('#master-select-session').click();await expect(page.locator('#master-select-session')).toHaveAttribute('aria-pressed','true');await expect(page.locator('#master-detail')).toBeVisible();
+  const separator=page.getByRole('separator',{name:'Resize browser'});await separator.focus();await page.keyboard.press('End');await expect(separator).toHaveAttribute('aria-valuenow','280');expect(await page.locator('#workspace-browser').evaluate(e=>e.getBoundingClientRect().width)).toBe(280);
+  await separator.press('Home');expect(await page.locator('#workspace-browser').evaluate(e=>e.getBoundingClientRect().width)).toBe(180);
+  await page.locator('#track-width').fill('180');expect(await page.locator('.track').first().evaluate(e=>e.getBoundingClientRect().width)).toBe(180);
+  await page.getByRole('button',{name:'Select Pulse track',exact:true}).click();await expect(page.locator('#device-detail')).toBeVisible();await expect(parameter).toHaveValue('1777');
+  expect(await page.evaluate(()=>window.calls.filter(c=>c.name!=='alive_current'))).toEqual([]);
+});
+
+test('Master numeric validation and double-click unity use the same admission path',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,false,true,2,true);
+  const root=page.locator('#master-session'),number=root.getByLabel('Master gain',{exact:true}),fader=root.getByLabel('Master gain fader');
+  await number.fill('5');await number.press('Tab');await expect(page.getByRole('status',{name:'Session status'})).toContainText('between 0 and 4');expect(await page.evaluate(()=>window.calls.filter(c=>c.name==='alive_master'))).toHaveLength(0);
+  await number.fill('0.25');await number.press('Tab');await expect(root.getByLabel('Master gain decibels')).toHaveText('-12.0 dB');
+  await fader.dblclick();await expect.poll(()=>page.evaluate(()=>window.calls.filter(c=>c.name==='alive_master').at(-1)?.args.gain)).toBe(1);await expect(root.getByLabel('Master gain decibels')).toHaveText('0.0 dB');
+});
+
+test('Arrangement Master aligns with right track controls and source fields have visible context',async({page})=>{
+  await page.setViewportSize({width:1440,height:900});await openSession(page,false,true,2,true);await page.locator('#view-arrangement').click();
+  const boxes=await page.evaluate(()=>{const rect=e=>e.getBoundingClientRect();const header=rect(document.querySelector('.timeline-header')),master=rect(document.querySelector('#master-arrangement-lane .master-heading')),controls=rect(document.querySelector('#master-arrangement'));return {headerLeft:header.left,masterLeft:master.left,controlsRight:controls.right,workspaceRight:rect(document.querySelector('#arrangement-workspace')).right};});
+  expect(boxes.masterLeft).toBeGreaterThan(boxes.headerLeft-250);expect(Math.abs(boxes.controlsRight-boxes.workspaceRight)).toBeLessThanOrEqual(1);
+  const detail=page.locator('#clip-controls');await expect(detail.getByText('Clip name',{exact:true})).toBeVisible();await expect(detail.getByText('Source length',{exact:true})).toBeVisible();await expect(detail.getByText('Offset',{exact:true})).toBeVisible();await expect(detail.getByText('beats',{exact:true}).first()).toBeVisible();
+});
+
+test('returning from Master to the same Arrangement occurrence retains parked text',async({page})=>{
+  await openArrangement(page,{width:1440,height:900});const placement=page.getByRole('button',{name:'Select placement p-0',exact:true});await placement.click();
+  const name=page.getByLabel('MIDI source name',{exact:true});await name.fill('Unfinished source');await name.evaluate(e=>e.setSelectionRange(3,7));
+  await page.locator('#master-select-arrangement').click();await placement.click();await expect(name).toHaveValue('Unfinished source');expect(await name.evaluate(e=>[e.selectionStart,e.selectionEnd])).toEqual([3,7]);expect(await workspaceEdits(page)).toHaveLength(0);
+});
+
+test('generation change visibly cancels a pending Master intent and ignores its late receipt',async({page})=>{
+  await openSession(page,false,true,2,true);await page.evaluate(()=>{window.masterGate=(name,args)=>new Promise(resolve=>{window.finishMaster=resolve;});});
+  const root=page.locator('#master-session'),number=root.getByLabel('Master gain',{exact:true}),notice=page.getByRole('status',{name:'Session status'});
+  await number.fill('0.3');await number.press('Tab');await expect(notice).toContainText('pending');
+  await page.evaluate(()=>{window.sessionSnapshot.generation=2;window.sessionSnapshot.snapshotSequence='2';});await expect(notice).toContainText('canceled');
+  await page.evaluate(()=>window.finishMaster({generation:1,acceptedGain:.3,acceptedSerial:'2',changed:true}));await expect(root.getByLabel('Master gain decibels')).toHaveText('0.0 dB');await expect(notice).toContainText('canceled');
+});
+
+test('Arrangement Master markings and meter remain separate in the right-hand control group',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,false,true,2,true);await page.locator('#view-arrangement').click();
+  const boxes=await page.evaluate(()=>{const rect=e=>e.getBoundingClientRect();const root=document.querySelector('#master-arrangement');return {marks:rect(root.querySelector('.master-marks')).toJSON(),markLabel:rect(root.querySelector('.master-marks span:first-child')).toJSON(),meter:rect(root.querySelector('.master-bars')).toJSON(),root:rect(root).toJSON(),button:rect(root.querySelector('.master-actions button:last-child')).toJSON()};});
+  expect(boxes.marks.right).toBeLessThanOrEqual(boxes.meter.left);expect(boxes.markLabel.right).toBeLessThanOrEqual(boxes.meter.left);expect(boxes.meter.right).toBeLessThanOrEqual(boxes.root.right);expect(boxes.button.right).toBeLessThanOrEqual(boxes.root.right);
+});
+
+test('pointer-derived track gain remains readable in both mixer and Arrangement detail',async({page})=>{
+  await page.setViewportSize({width:1280,height:800});await openSession(page,false,true,2,true);
+  const slider=page.getByLabel('Pulse gain fader',{exact:true}),number=page.getByLabel('Pulse gain',{exact:true});const box=await slider.boundingBox();await page.mouse.move(box.x+box.width/2,box.y+box.height*.77);await page.mouse.down();await page.mouse.move(box.x+box.width/2,box.y+box.height*.68);await page.mouse.up();await page.locator('#view-arrangement').click();
+  const gain=page.getByLabel('Pulse Arrangement gain',{exact:true}),text=await gain.inputValue(),actual=await page.evaluate(()=>window.sessionSnapshot.document.tracks[0].gain);expect(text.length).toBeLessThanOrEqual(5);expect(Math.abs(Number(text)-actual)).toBeLessThanOrEqual(.0005);
+  await page.locator('#view-session').click();const shown=await number.inputValue();expect(shown.length).toBeLessThanOrEqual(5);expect(Math.abs(Number(shown)-actual)).toBeLessThanOrEqual(.0005);
+});
diff --git a/apps/ultra/tests/ci/canvas-documents.spec.mjs b/apps/ultra/tests/ci/canvas-documents.spec.mjs
index 5a564e4..68be84d 100644
--- a/apps/ultra/tests/ci/canvas-documents.spec.mjs
+++ b/apps/ultra/tests/ci/canvas-documents.spec.mjs
@@ -60,3 +60,35 @@ test('Enter opens File and activates Save As while F2 still edits a selected can
   await expect(page.locator('#object-entry')).toBeHidden();
   await page.locator('#workspace').focus();await page.keyboard.press('F2');await expect(page.locator('#object-entry')).toBeVisible();
 });
+
+test('Ctrl+S commits a focused number before saving its owner',async({page})=>{
+  await page.addInitScript(()=>{
+    let patch={version:1,profile:'ultra-canvas-v1',nodes:[{id:1,type:'number',x:40,y:40,params:{value:10}}],edges:[]},revision=1;
+    const descriptor=()=>({shared:true,id:1,label:'owner',ownerLabel:'owner',title:'Number.ultra',kind:'patch',viewPath:[],patch:structuredClone(patch),authoringRevision:revision,runtimeRevision:1,dirty:false});
+    window.documentCalls=[];
+    window.__TAURI__={core:{invoke:async(name,args={})=>{
+      window.documentCalls.push({name,args});
+      if(name==='document_current')return descriptor();
+      if(name==='document_commit'){patch=structuredClone(args.patch);revision++;return{accepted:true,document:descriptor()};}
+      if(name==='document_save')return descriptor();
+      if(name==='canvas_status')return{revision:1,active:true,nodes:[],console:[]};
+      if(name==='audio_status')return{running:false};
+      if(name==='audio_devices')return{config:{host:'default',device:'default',sample_rate:48000,buffer_frames:null},hosts:[],devices:[],notice:'Audio is off.'};
+      return true;
+    }},event:{listen:async()=>()=>{}},webviewWindow:{getCurrentWebviewWindow:()=>({label:'owner'})},webview:{getCurrentWebview:()=>({onDragDropEvent:async()=>()=>{}})}};
+  });
+  await page.goto('/canvas.html');await expect(page.locator('#document-title')).toHaveText('Number.ultra');
+  await page.locator('#lock-patch').click();
+  const input=page.locator('[data-node="1"] [data-parameter="value"]');await input.click();await input.fill('42');await input.press('Control+s');
+  await expect.poll(()=>page.evaluate(()=>window.documentCalls.filter(call=>call.name==='document_save').length)).toBe(1);
+  const calls=await page.evaluate(()=>window.documentCalls);
+  expect(calls.filter(call=>call.name==='document_commit')).toHaveLength(1);
+  expect(calls.find(call=>call.name==='document_save').args.patch.nodes[0].params.value).toBe(42);
+  expect(calls.findIndex(call=>call.name==='document_commit')).toBeLessThan(calls.findIndex(call=>call.name==='document_save'));
+  await input.fill('');await input.evaluate(element=>element.blur());
+  await page.locator('#document-save').evaluate(element=>{element.focus();element.click();});
+  await expect.poll(()=>page.locator('#notice').textContent()).toContain('invalid focused edit');
+  expect(await page.evaluate(()=>window.documentCalls.filter(call=>call.name==='document_save').length)).toBe(1);
+  await expect(input).toHaveValue('');await input.focus();await input.press('Escape');await input.press('Control+s');
+  await expect.poll(()=>page.evaluate(()=>window.documentCalls.filter(call=>call.name==='document_save').length)).toBe(2);
+});
diff --git a/apps/ultra/tests/ci/check-native.sh b/apps/ultra/tests/ci/check-native.sh
index 2736887..c6a999e 100644
--- a/apps/ultra/tests/ci/check-native.sh
+++ b/apps/ultra/tests/ci/check-native.sh
@@ -13,6 +13,11 @@ trap 'rm -rf "$TEST_DIR"' EXIT
 python3 apps/ultra/tests/check_backend.py
 python3 apps/ultra/tests/check_sequence.py
 python3 apps/ultra/tests/check_canvas.py
+c++ -std=c++17 -O2 -Wall -Wextra -Werror -pthread -Iapps/ultra/src-tauri/native \
+  apps/ultra/tests/alive_session_master_test.cpp -L"$NATIVE_BUILD" -lultra_native \
+  -Wl,-rpath,"$NATIVE_BUILD" -ldl -o "$TEST_DIR/alive-master-test"
+"$TEST_DIR/alive-master-test"
+bash apps/ultra/tests/alive_session_master_resolver_test.sh
 for test in external_audio document_runtime document_audio signal_audio canvas_numeric_ui_backend canvas_message_ui_backend canvas_print_popup_backend; do
   c++ -std=c++20 -O2 -Wall -Wextra -Werror "apps/ultra/tests/${test}_test.cpp" \
     -L"$NATIVE_BUILD" -lultra_native -Wl,-rpath,"$NATIVE_BUILD" \
diff --git a/apps/ultra/tests/desktop_checkpoint.py b/apps/ultra/tests/desktop_checkpoint.py
new file mode 100644
index 0000000..472520c
--- /dev/null
+++ b/apps/ultra/tests/desktop_checkpoint.py
@@ -0,0 +1,161 @@
+"""Terminal lifecycle and bounded pilot projection for the desktop journey."""
+import math
+from stream_measurement import MAX_AUDIO, MAX_METADATA, MAX_WALL, PlayingIntervals
+
+
+def playing_dwell(required, played):
+    return min(180, max(0, required - played))
+
+
+def qualify_epochs(epochs):
+    fields = ('native_render_failures', 'invalid_callback_shape', 'cpal_error_total',
+              'cpal_xrun_reports', 'cpal_non_xrun_reports', 'over_buffer_budget_count')
+    if not epochs:
+        raise ValueError('no completed epochs')
+    totals = dict.fromkeys(fields, 0)
+    results = []
+    for epoch in epochs:
+        counts = {}
+        for name in fields:
+            value = epoch['metrics'].get(name)
+            if not isinstance(value, str) or not value.isascii() or not value.isdecimal() or len(value) > 20 or int(value) > (1 << 64) - 1:
+                raise ValueError(f'invalid epoch counter {name}')
+            counts[name] = int(value)
+            totals[name] += counts[name]
+        if counts['cpal_error_total'] != counts['cpal_xrun_reports'] + counts['cpal_non_xrun_reports']:
+            raise ValueError('inconsistent typed CPAL counters')
+        results.append({'epoch_id': epoch['epoch_id'], **counts})
+    return {'qualified': not any(totals[name] for name in fields[:-1]),
+            'epochs': results, 'totals': totals,
+            'physical_underruns': None, 'budget_scope': 'processing budget exceedances, not underruns'}
+
+
+class AuditedPlayingIntervals(PlayingIntervals):
+    def __init__(self, writer):
+        super().__init__()
+        self.writer = writer
+
+    def observe(self, now, running, frames, action, rate=48000):
+        previous, before = self.last, self.seconds
+        result = super().observe(now, running, frames, action, rate)
+        self.writer.write({'monotonic': now, 'running': running, 'frame': frames,
+                           'action': action, 'rate': rate,
+                           'previous_monotonic': previous[0] if previous else None,
+                           'previous_running': previous[1] if previous else None,
+                           'previous_frame': previous[2] if previous else None,
+                           'previous_action': previous[3] if previous else None,
+                           'elapsed_seconds': now - previous[0] if previous else None,
+                           'credited_seconds': self.seconds - before})
+        return result
+
+
+class DesktopCheckpoint:
+    def __init__(self):
+        self.retired = False
+        self.complete = False
+
+    def retire(self, operation):
+        if self.retired or self.complete:
+            raise RuntimeError('retirement already completed')
+        result = operation()
+        self.retired = True
+        return result
+
+    def quit(self, operation):
+        if not self.retired or self.complete:
+            raise RuntimeError('retirement required before terminal quit')
+        result = operation()
+        self.complete = True
+        return result
+
+
+def project_pilot(*, playing_seconds, capture_wall_seconds, audio_bytes,
+                  metadata_bytes, epoch_attempts, fixed_wall_seconds,
+                  fixed_audio_bytes, fixed_metadata_bytes, fixed_epoch_attempts,
+                  target_seconds, cycle_playing_seconds=None, collector_wall_seconds=None,
+                  fixed_collector_wall_seconds=None, variability=0, minimum_headroom_fraction=0):
+    if cycle_playing_seconds is None: cycle_playing_seconds = playing_seconds
+    if collector_wall_seconds is None: collector_wall_seconds = capture_wall_seconds
+    if fixed_collector_wall_seconds is None: fixed_collector_wall_seconds = fixed_wall_seconds
+    values = (playing_seconds, capture_wall_seconds, audio_bytes, metadata_bytes,
+              epoch_attempts, fixed_wall_seconds, fixed_audio_bytes,
+              fixed_metadata_bytes, fixed_epoch_attempts, target_seconds, cycle_playing_seconds,
+              collector_wall_seconds, fixed_collector_wall_seconds, variability, minimum_headroom_fraction)
+    if (any(not math.isfinite(v) or v < 0 for v in values) or not playing_seconds or
+            not target_seconds or not cycle_playing_seconds or cycle_playing_seconds > playing_seconds or
+            minimum_headroom_fraction >= 1):
+        raise ValueError('pilot quantities must be finite and nonnegative with positive playing and target')
+    totals = (capture_wall_seconds, collector_wall_seconds, audio_bytes, metadata_bytes, epoch_attempts)
+    fixed = (fixed_wall_seconds, fixed_collector_wall_seconds, fixed_audio_bytes, fixed_metadata_bytes, fixed_epoch_attempts)
+    if any(f > t for f, t in zip(fixed, totals)):
+        raise ValueError('fixed overhead exceeds pilot total')
+    fixed_playing = playing_seconds - cycle_playing_seconds
+    scale = max(0, target_seconds - fixed_playing) / cycle_playing_seconds
+    names = ('wall_seconds', 'collector_wall_seconds', 'audio_bytes', 'metadata_bytes', 'epoch_attempts')
+    result = {name: f + (total - f) * scale * (1 + variability) for name, total, f in zip(names, totals, fixed)}
+    for name in ('audio_bytes', 'metadata_bytes', 'epoch_attempts'):
+        result[name] = math.ceil(result[name])
+    limits = dict(zip(names, (MAX_WALL, MAX_WALL, MAX_AUDIO, MAX_METADATA, 256)))
+    result['limits'] = limits
+    result['headroom'] = {name: limits[name] - result[name] for name in names}
+    result['headroom_fraction'] = {name: result['headroom'][name] / limits[name] for name in names}
+    result['exceeded_limits'] = [name for name in names if result[name] > limits[name]]
+    result['below_required_headroom'] = [name for name in names if result['headroom_fraction'][name] < minimum_headroom_fraction]
+    result['within_limits'] = not result['exceeded_limits'] and not result['below_required_headroom']
+    result['fixed_playing_seconds'] = fixed_playing
+    result['cycle_playing_seconds'] = cycle_playing_seconds
+    result['variability_fraction'] = variability
+    result['minimum_headroom_fraction'] = minimum_headroom_fraction
+    return result
+
+
+class DrivingObserver:
+    """Observe on the calling thread, bracketing controls and long waits."""
+    def __init__(self, measure, read, clock, sleep):
+        self.measure, self.read, self.clock, self.raw_sleep = measure, read, clock, sleep
+        self.reading = False
+        self.action_depth = 0
+        self.last_observation = None
+
+    def observe(self):
+        if self.reading:
+            return None
+        self.reading = True
+        try:
+            return self.measure.observe(self.read)
+        finally:
+            self.last_observation = self.clock()
+            self.reading = False
+
+    def action(self, name, operation):
+        outer = self.action_depth == 0
+        if outer:
+            self.observe()
+        failures, result = [], None
+        self.action_depth += 1
+        try:
+            with self.measure.action(name):
+                result = operation()
+        except BaseException as error:
+            failures.append(error)
+        finally:
+            self.action_depth -= 1
+        if outer:
+            try:
+                self.observe()
+            except BaseException as error:
+                failures.append(error)
+        if len(failures) == 1:
+            raise failures[0]
+        if failures:
+            raise BaseExceptionGroup('action and observation failures', failures)
+        return result
+
+    def sleep(self, seconds):
+        deadline = self.clock() + seconds
+        while True:
+            remaining = deadline - self.clock()
+            if remaining <= 0:
+                break
+            self.raw_sleep(min(1, remaining))
+            self.observe()
diff --git a/apps/ultra/tests/desktop_launch_config.sh b/apps/ultra/tests/desktop_launch_config.sh
new file mode 100644
index 0000000..7eee0bc
--- /dev/null
+++ b/apps/ultra/tests/desktop_launch_config.sh
@@ -0,0 +1,20 @@
+# Shared launch configuration for the isolated desktop harness.
+desktop_screen_size() {
+  local size=${ULTRA_TEST_SCREEN_SIZE-1280x840} width height
+  if [[ ! $size =~ ^([0-9]{1,4})x([0-9]{1,4})$ ]]; then
+    echo 'Invalid ULTRA_TEST_SCREEN_SIZE; expected WIDTHxHEIGHT within 1280x840 to 3840x2160.' >&2
+    return 2
+  fi
+  width=$((10#${BASH_REMATCH[1]})) height=$((10#${BASH_REMATCH[2]}))
+  if (( width < 1280 || width > 3840 || height < 840 || height > 2160 )); then
+    echo 'ULTRA_TEST_SCREEN_SIZE must be within 1280x840 to 3840x2160.' >&2
+    return 2
+  fi
+  printf '%dx%d\n' "$width" "$height"
+}
+desktop_alive_binary() { realpath -e -- "$1"; }
+desktop_startup_binary() {
+  local alive
+  alive=$(desktop_alive_binary "$1") || return
+  realpath -e -- "$(dirname "$alive")/ultra"
+}
diff --git a/apps/ultra/tests/desktop_process_helpers.py b/apps/ultra/tests/desktop_process_helpers.py
new file mode 100644
index 0000000..46d1e9b
--- /dev/null
+++ b/apps/ultra/tests/desktop_process_helpers.py
@@ -0,0 +1,62 @@
+"""Process identity and independent cleanup for private desktop journeys."""
+import hashlib
+from pathlib import Path
+import subprocess
+
+
+def file_identity(path):
+    stat = path.stat()
+    with path.open('rb') as file:
+        digest = hashlib.file_digest(file, 'sha256').hexdigest()
+    return {'device': stat.st_dev, 'inode': stat.st_ino, 'sha256': digest}
+
+
+def process_identity(pid, library_name='libultra_native'):
+    proc = Path('/proc') / str(pid)
+    executable = proc / 'exe'
+    result = {'executable_path': str(executable.resolve()), 'executable': file_identity(executable), 'libraries': []}
+    seen = set()
+    for line in (proc / 'maps').read_text().splitlines():
+        parts = line.split(maxsplit=5)
+        if len(parts) != 6 or library_name not in parts[5]:
+            continue
+        path = Path(parts[5])
+        device = tuple(int(part, 16) for part in parts[3].split(':'))
+        inode = int(parts[4])
+        key = (device, inode)
+        if key in seen:
+            continue
+        seen.add(key)
+        identity = file_identity(path)
+        if identity['inode'] != inode:
+            raise AssertionError(f'mapped library changed while process is running: {path}')
+        result['libraries'].append({'path': str(path), 'mapping_device': device, 'mapping_inode': inode, **identity})
+    if not result['libraries']:
+        raise AssertionError(f'no mapped library matching {library_name}')
+    result['libraries'].sort(key=lambda item: item['path'])
+    return result
+
+
+def assert_same_identity(first, second):
+    assert first == second, f'launch/restart identity differs: {first!r} != {second!r}'
+
+
+def stop_recorder(process, timeout=10):
+    if process.poll() is not None:
+        return
+    try:
+        process.communicate(b'q\n', timeout=timeout)
+    except subprocess.TimeoutExpired:
+        process.kill()
+        process.communicate()
+        raise RuntimeError('recorder did not stop and was killed')
+
+
+def cleanup_independently(actions):
+    errors = []
+    for action in actions:
+        try:
+            action()
+        except Exception as error:
+            errors.append(repr(error))
+    return errors
diff --git a/apps/ultra/tests/desktop_sustained.py b/apps/ultra/tests/desktop_sustained.py
new file mode 100644
index 0000000..82ef4cf
--- /dev/null
+++ b/apps/ultra/tests/desktop_sustained.py
@@ -0,0 +1,206 @@
+"""Driving-thread epoch observation and owned sampling for the desktop journey."""
+import json
+import os
+from pathlib import Path
+import threading
+import time
+
+from desktop_checkpoint import AuditedPlayingIntervals, DesktopCheckpoint, DrivingObserver
+from stream_measurement import EpochCollector, JsonLines, MAX_WALL, ProcessGroups, ProcessSampler
+from sustained_measurement import ProcessDisappeared, SustainedMeasurement
+
+
+class LockedJsonLines:
+    def __init__(self, path, lock):
+        self.writer, self.lock = JsonLines(path), lock
+        self.path = self.writer.path
+
+    def write(self, value):
+        with self.lock:
+            self.writer.write(value)
+
+    def manifest(self):
+        with self.lock:
+            return self.writer.manifest()
+
+
+class DesktopSustained:
+    def __init__(self, ui, windows, atspi, glib):
+        self.ui, self.windows, self.atspi, self.glib = ui, windows, atspi, glib
+        self.lock = threading.RLock()
+        self.stop = threading.Event()
+        self.errors = []
+        self.start = time.monotonic()
+        self.raw_sleep = time.sleep
+        self.epoch_log = LockedJsonLines(ui.output / 'sustained-epochs.jsonl', self.lock)
+        self.gap_log = LockedJsonLines(ui.output / 'sustained-gaps.jsonl', self.lock)
+        self.action_log = LockedJsonLines(ui.output / 'sustained-actions.jsonl', self.lock)
+        self.resource_log = LockedJsonLines(ui.output / 'sustained-resources.jsonl', self.lock)
+        self.playing_log = LockedJsonLines(ui.output / 'sustained-playing.jsonl', self.lock)
+        self.epochs = EpochCollector(self.epoch_log)
+        self.playing = AuditedPlayingIntervals(self.playing_log)
+        self.measure = SustainedMeasurement(self.epochs, self.playing, self.gap_log, self.action_log, time.monotonic)
+        self.observer = DrivingObserver(self.measure, self.read, time.monotonic, self.raw_sleep)
+        self.terminal = DesktopCheckpoint()
+        self.thread = None
+        self.originals = {}
+        self.capture = None
+        self.finishing_capture = False
+        self.last = None
+        self.references = {}
+
+    def accessible(self, name):
+        item = self.references.get(name)
+        if item is not None:
+            try:
+                if (hasattr(self.atspi, 'StateType') and
+                        item.get_state_set().contains(self.atspi.StateType.DEFUNCT)):
+                    self.references.pop(name, None)
+                else:
+                    text = self.atspi.Text.get_text(item, 0, -1)
+                    if text:
+                        return text
+                    self.references.pop(name, None)
+            except self.glib.Error:
+                self.references.pop(name, None)
+        for frame in self.windows.app_frames():
+            try:
+                for item in self.ui.walk(frame):
+                    if item.get_name() == name and 'Text' in item.get_interfaces():
+                        if (hasattr(self.atspi, 'StateType') and
+                                item.get_state_set().contains(self.atspi.StateType.DEFUNCT)):
+                            continue
+                        text = self.atspi.Text.get_text(item, 0, -1)
+                        if text:
+                            self.references[name] = item
+                            return text
+            except self.glib.Error:
+                continue
+        return None
+
+    def read(self):
+        try:
+            stat = Path(f'/proc/{self.ui.pid}/stat').read_text()
+            if stat.split(') ', 1)[1].split()[0] == 'Z':
+                raise ProcessDisappeared('Alive exited before retirement')
+        except FileNotFoundError as error:
+            raise ProcessDisappeared('Alive disappeared before retirement') from error
+        diagnostics = self.accessible('Stream diagnostics')
+        record = json.loads(diagnostics) if diagnostics else None
+        if isinstance(record, dict):
+            self.last = record
+        running, frames = self.accessible('Transport playing'), self.accessible('Absolute frame')
+        if running not in ('true', 'false') or not frames or not frames.isascii() or not frames.isdecimal():
+            self.gap_log.write({'kind': 'transport_read_shape', 'monotonic': time.monotonic(),
+                                'running_valid': running in ('true', 'false'),
+                                'frame_valid': bool(frames and frames.isascii() and frames.isdecimal())})
+        return record, running, frames
+
+    def observe(self):
+        return self.observer.observe()
+
+    def sample(self):
+        try:
+            groups = ProcessGroups(app=ProcessSampler(self.ui.pid), sampler_capture_overhead=ProcessSampler(os.getpid()),
+                private_audio_server=ProcessSampler(int(os.environ['ULTRA_TEST_AUDIO_PID'])) if os.environ.get('ULTRA_TEST_AUDIO_PID') else None)
+            deadline = time.monotonic()
+            while not self.stop.is_set():
+                started = time.monotonic()
+                if started - self.start > MAX_WALL:
+                    raise RuntimeError('wall_limit')
+                observation = groups.sample()
+                now = time.monotonic()
+                if now - self.start > MAX_WALL:
+                    raise RuntimeError('wall_limit')
+                self.resource_log.write({'monotonic': now, 'sampling_started': started,
+                    'scheduled_monotonic': deadline, 'sampling_delay': max(0, started - deadline),
+                    'sampling_duration': now - started, 'action': self.measure.action_ordinal,
+                    'playing_seconds_proven': self.playing.seconds,
+                    'missed_cadences': max(0, int(now - deadline)), **observation})
+                deadline += 1
+                self.stop.wait(max(0, deadline - time.monotonic()))
+        except BaseException as error:
+            self.errors.append(error)
+            self.stop.set()
+
+    def health(self):
+        if self.errors:
+            raise RuntimeError('resource sampler failed') from self.errors[0]
+        if self.capture is not None and not self.finishing_capture and self.capture[0].process.poll() is not None:
+            raise RuntimeError('recorder supervisor exited before capture finalization')
+
+    def install(self):
+        self.thread = threading.Thread(target=self.sample, name='sustained-proc-sampler', daemon=True)
+        self.thread.start()
+        for name in ('click', 'text', 'keys'):
+            original = getattr(self.ui, name)
+            self.originals[name] = original
+            def wrapped(*args, _original=original, _name=name, **kwargs):
+                if self.observer.reading:
+                    return _original(*args, **kwargs)
+                label = f'{_name}: {args[0] if args else ""}'
+                return self.observer.action(label, lambda: _original(*args, **kwargs))
+            setattr(self.ui, name, wrapped)
+        def observed_sleep(seconds):
+            if self.observer.reading:
+                return self.raw_sleep(seconds)
+            if seconds <= 0:
+                return self.raw_sleep(seconds)
+            deadline = time.monotonic() + seconds
+            while time.monotonic() < deadline:
+                now = time.monotonic()
+                last = self.observer.last_observation
+                until_due = max(0, 1 - (now - last)) if last is not None else 0
+                if until_due == 0:
+                    self.observe()
+                else:
+                    self.raw_sleep(min(until_due, deadline - now))
+        time.sleep = observed_sleep
+
+    def cleanup(self):
+        time.sleep = self.raw_sleep
+        for name, original in self.originals.items():
+            setattr(self.ui, name, original)
+        failures = []
+        try:
+            self.stop_sampling()
+        except BaseException as error:
+            failures.append(error)
+        if self.capture is not None:
+            try:
+                result = self.capture[0].finish()
+                if not result.get('complete'): raise RuntimeError(f'recorder incomplete: {result}')
+                self.capture = None
+            except BaseException as error:
+                failures.append(error)
+        if len(failures) == 1: raise failures[0]
+        if failures: raise BaseExceptionGroup('sustained cleanup failures', failures)
+
+    def stop_sampling(self):
+        self.stop.set()
+        if self.thread is not None:
+            self.thread.join(timeout=5)
+            if self.thread.is_alive(): raise RuntimeError('resource sampler did not stop')
+
+    def retired(self):
+        return self.terminal.retire(lambda: self.measure.finalize(self.read, 15, self.raw_sleep))
+
+    def growth(self, audio_path):
+        with self.lock:
+            metadata = sum(path.stat().st_size for path in self.ui.output.iterdir()
+                           if path.is_file() and path.suffix in ('.json', '.jsonl', '.log'))
+            active = self.last.get('active') if self.last else None
+            attempts = max(self.epochs.cursor, int(active['epoch_id']) if active else 0)
+            return {'monotonic': time.monotonic(), 'audio_bytes': audio_path.stat().st_size,
+                    'metadata_bytes': metadata, 'epoch_attempts': attempts,
+                    'playing_seconds': self.playing.seconds}
+
+    def manifest(self):
+        return {'complete': self.terminal.complete, 'playing_seconds_proven': self.playing.seconds,
+                'excluded_seconds': self.playing.excluded, 'completed_epochs': self.epochs.cursor,
+                'last_diagnostics': self.last, 'wall_seconds': time.monotonic() - self.start,
+                'epochs': self.epoch_log.manifest(), 'gaps': self.gap_log.manifest(),
+                'actions': self.action_log.manifest(), 'resources': self.resource_log.manifest(),
+                'playing': self.playing_log.manifest(),
+                'physical_audio': False, 'physical_underruns': None,
+                'cpu_coverage': 'observed identities; transient workers and exited final deltas unavailable'}
diff --git a/apps/ultra/tests/stage_alive_session.py b/apps/ultra/tests/stage_alive_session.py
new file mode 100644
index 0000000..7502b2a
--- /dev/null
+++ b/apps/ultra/tests/stage_alive_session.py
@@ -0,0 +1,19 @@
+#!/usr/bin/env python3
+"""Stage a session for desktop tests while retaining its file envelope."""
+import json
+import sys
+from pathlib import Path
+
+
+def stage(source, target):
+    session = json.loads(source.read_text())
+    score = session['score'] if session.get('format') == 'alive-session-v5' else session
+    for track in score['tracks']:
+        instrument = track.get('device') or track.get('chain', {}).get('instrument')
+        for device in ([instrument] if instrument else []) + track.get('effects', []):
+            device['path'] = str((source.parent / device['path']).resolve(strict=True))
+    target.write_text(json.dumps(session, indent=2) + '\n')
+
+
+if __name__ == '__main__':
+    stage(*map(Path, sys.argv[1:]))
diff --git a/apps/ultra/tests/sustained_measurement.py b/apps/ultra/tests/sustained_measurement.py
new file mode 100644
index 0000000..fc1b0b9
--- /dev/null
+++ b/apps/ultra/tests/sustained_measurement.py
@@ -0,0 +1,138 @@
+"""Driving-thread coordination for bounded sustained measurement.
+
+The caller owns UI access, resource sampling, recorder supervision and cleanup.
+"""
+from contextlib import contextmanager
+import math
+import threading
+
+
+class ProcessDisappeared(RuntimeError):
+    """The driving thread has confirmed that the observed process exited."""
+
+
+class SustainedMeasurement:
+    def __init__(self, epochs, playing, gap_log, action_log, clock):
+        self.epochs, self.playing = epochs, playing
+        self.gap_log, self.action_log, self.clock = gap_log, action_log, clock
+        self.action_ordinal, self._depth = 0, 0
+        self._thread = threading.get_ident()
+        self._health = lambda: None
+        self._disappearance = None
+
+    def _check(self):
+        if threading.get_ident() != self._thread:
+            raise RuntimeError('measurement_wrong_thread')
+        if self._disappearance is not None:
+            raise self._disappearance
+        self._health()
+
+    def _gap(self, reason):
+        self.playing.last = None
+        self.gap_log.write({'kind': 'observation_gap', 'monotonic': self.clock(), 'reason': reason})
+
+    def observe(self, read):
+        self._check()
+        try:
+            record, running, frames = read()
+        except ProcessDisappeared as error:
+            self._disappearance = error
+            self._gap('process_disappeared')
+            raise
+        except Exception:
+            self._gap('observation_failed')
+            return None
+        valid = (isinstance(record, dict) and 'error' not in record and
+                 isinstance(record.get('run_id'), str) and bool(record['run_id']) and
+                 isinstance(record.get('coverage_gap'), bool) and
+                 isinstance(record.get('completed'), list) and
+                 isinstance(record.get('complete'), bool) and 'active' in record and
+                 (record['active'] is None or isinstance(record['active'], dict)))
+        if not valid:
+            self._gap('diagnostics_unavailable_or_invalid')
+            return None
+        if (running not in ('true', 'false') or not isinstance(frames, str) or
+            not frames.isascii() or not frames.isdecimal() or len(frames) > 20):
+            self._gap('transport_unavailable_or_invalid')
+            return None
+        try:
+            frame = int(frames)
+        except ValueError:
+            self._gap('transport_unavailable_or_invalid')
+            return None
+        if frame > (1 << 64) - 1:
+            self._gap('transport_unavailable_or_invalid')
+            return None
+        try:
+            self.epochs.accept(record)
+        except Exception:
+            self._gap('diagnostics_rejected')
+            raise
+        if self._depth:
+            self.playing.last = None
+        else:
+            self.playing.observe(self.clock(), running == 'true', frame, self.action_ordinal)
+        return record
+
+    @contextmanager
+    def action(self, name):
+        self._check()
+        outer = self._depth == 0
+        if outer:
+            self.action_ordinal += 1
+            self._gap('action_boundary')
+            self.action_log.write({'monotonic': self.clock(), 'action': self.action_ordinal, 'control': name})
+        self._depth += 1
+        try:
+            yield
+        finally:
+            self._depth -= 1
+            self.playing.last = None
+
+    def finalize(self, read, timeout, sleep, interval=1):
+        self._check()
+        if not math.isfinite(timeout) or timeout <= 0 or not math.isfinite(interval) or interval <= 0:
+            raise ValueError('finite positive retirement timeout and interval required')
+        deadline = self.clock() + timeout
+        while self.clock() < deadline:
+            record = self.observe(read)
+            if record is not None and self.clock() <= deadline:
+                last = record.get('last_completed_epoch')
+                if (record['complete'] is True and record['active'] is None and
+                    record.get('retiring_epoch_id', False) is None and
+                    record.get('native_quiescent') is True and
+                    isinstance(last, str) and last.isascii() and last.isdecimal() and
+                    self.epochs.cursor > 0 and int(last) == self.epochs.cursor):
+                    return record
+            remaining = deadline - self.clock()
+            if remaining > 0: sleep(min(interval, remaining))
+        raise TimeoutError('retirement deadline exceeded')
+
+    @contextmanager
+    def owned(self, cleanup, health):
+        if threading.get_ident() != self._thread:
+            raise RuntimeError('measurement_wrong_thread')
+        old = self._health
+        failures = []
+        try:
+            self._check()
+            self._health = health
+            yield
+            self._check()
+        except BaseException as error:
+            failures.append(error)
+        finally:
+            try:
+                cleanup()
+            except BaseException as error:
+                failures.append(error)
+            try:
+                health()
+            except BaseException as error:
+                failures.append(error)
+            finally:
+                self._health = old
+        if len(failures) == 1:
+            raise failures[0]
+        if failures:
+            raise BaseExceptionGroup('measurement and cleanup failures', failures)
diff --git a/apps/ultra/tests/test_alive_workspace_navigation.py b/apps/ultra/tests/test_alive_workspace_navigation.py
new file mode 100644
index 0000000..341f50e
--- /dev/null
+++ b/apps/ultra/tests/test_alive_workspace_navigation.py
@@ -0,0 +1,27 @@
+import sys
+import types
+import unittest
+from unittest.mock import patch
+
+sys.modules.setdefault('gi', types.ModuleType('gi'))
+repository = types.ModuleType('gi.repository')
+repository.Atspi = types.SimpleNamespace(StateType=types.SimpleNamespace(EXPANDED='expanded', PRESSED='pressed'))
+sys.modules.setdefault('gi.repository', repository)
+import alive_workspace_navigation as navigation
+
+
+class NavigationTest(unittest.TestCase):
+    def test_apply_closes_expanded_audio_details_before_click(self):
+        calls = []
+        class Control:
+            def get_state_set(self): return self
+            def contains(self, state): return state == 'expanded'
+        ui = types.SimpleNamespace(click=lambda name: calls.append(name), text=lambda *args: None,
+                                   wait_for=lambda name: Control())
+        windows = types.SimpleNamespace(scope='Alive')
+        navigation.install(ui, windows, None, None)
+        ui.click('Prepare / Apply')
+        self.assertEqual(calls, ['Audio details', 'Prepare / Apply'])
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/apps/ultra/tests/test_chooser_observation.py b/apps/ultra/tests/test_chooser_observation.py
new file mode 100644
index 0000000..06343b0
--- /dev/null
+++ b/apps/ultra/tests/test_chooser_observation.py
@@ -0,0 +1,54 @@
+import unittest
+
+from chooser_observation import find_web_ancestor, planned_hit_path
+
+
+class Node:
+    def __init__(self, name, role='button', parent=None, child=None):
+        self.name, self.role, self.parent, self.child = name, role, parent, child
+    def get_name(self): return self.name
+    def get_role_name(self): return self.role
+    def get_parent(self): return self.parent
+
+
+class ChooserObservationTest(unittest.TestCase):
+    def test_ancestor_depth_limit_reports_truncation(self):
+        web = Node('document', 'document web')
+        middle = Node('middle', parent=web)
+        button = Node('button', parent=middle)
+        result, status = find_web_ancestor(button, max_nodes=2)
+        self.assertIsNone(result)
+        self.assertEqual(status['status'], 'truncated')
+        self.assertEqual(status['reason'], 'node_limit')
+        self.assertEqual(status['nodes'], 2)
+
+    def test_hit_depth_limit_does_not_claim_complete(self):
+        leaf = Node('button')
+        middle = Node('middle', child=leaf)
+        web = Node('document', 'document web', child=middle)
+        result = planned_hit_path(web, lambda node: node.child, max_nodes=2)
+        self.assertEqual([row['name'] for row in result['path']], ['document', 'middle'])
+        self.assertEqual(result['status'], 'truncated')
+        self.assertEqual(result['reason'], 'node_limit')
+
+    def test_failure_and_time_budget_are_explicit(self):
+        node = Node('document', 'document web')
+        def fail(_): raise RuntimeError('unavailable')
+        failed = planned_hit_path(node, fail)
+        self.assertEqual(failed['status'], 'unavailable')
+        self.assertEqual(failed['error_type'], 'RuntimeError')
+        ticks = iter([0, 1])
+        result, status = find_web_ancestor(node, seconds=.1, clock=lambda: next(ticks))
+        self.assertIsNone(result)
+        self.assertEqual(status['status'], 'truncated')
+        self.assertEqual(status['reason'], 'time_limit')
+
+    def test_complete_path_stops_at_leaf(self):
+        leaf = Node('Replace Harmony device')
+        web = Node('document', 'document web', child=leaf)
+        result = planned_hit_path(web, lambda node: node.child)
+        self.assertEqual(result['status'], 'complete')
+        self.assertEqual(result['path'][-1]['name'], 'Replace Harmony device')
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/apps/ultra/tests/test_desktop_checkpoint.py b/apps/ultra/tests/test_desktop_checkpoint.py
new file mode 100644
index 0000000..6c4c15c
--- /dev/null
+++ b/apps/ultra/tests/test_desktop_checkpoint.py
@@ -0,0 +1,227 @@
+"""GI-free acceptance tests for the sustained desktop lifecycle seam."""
+import importlib
+import importlib.util
+import unittest
+
+
+class DesktopCheckpointTests(unittest.TestCase):
+    def setUp(self):
+        spec = importlib.util.find_spec('desktop_checkpoint')
+        self.assertIsNotNone(spec, 'desktop checkpoint lifecycle seam is missing')
+        self.checkpoint = importlib.import_module('desktop_checkpoint')
+
+    def test_retirement_precedes_terminal_quit_and_success(self):
+        events = []
+        state = self.checkpoint.DesktopCheckpoint()
+        state.retire(lambda: events.append('retired'))
+        self.assertFalse(state.complete)
+        state.quit(lambda: events.append('quit and exit verified'))
+        self.assertEqual(events, ['retired', 'quit and exit verified'])
+        self.assertTrue(state.complete)
+
+    def test_failed_retirement_or_quit_never_produces_success(self):
+        def fail():
+            raise RuntimeError('failure')
+        state = self.checkpoint.DesktopCheckpoint()
+        with self.assertRaisesRegex(RuntimeError, 'failure'):
+            state.retire(fail)
+        with self.assertRaises(RuntimeError):
+            state.quit(lambda: self.fail('quit must not run before retirement'))
+        self.assertFalse(state.complete)
+        state.retire(lambda: None)
+        with self.assertRaisesRegex(RuntimeError, 'failure'):
+            state.quit(fail)
+        self.assertFalse(state.complete)
+
+    def test_pilot_projects_fixed_overhead_and_all_limits(self):
+        projected = self.checkpoint.project_pilot(
+            playing_seconds=60, capture_wall_seconds=100, audio_bytes=38400000,
+            metadata_bytes=60000, epoch_attempts=4, fixed_wall_seconds=20,
+            fixed_audio_bytes=7680000, fixed_metadata_bytes=10000,
+            fixed_epoch_attempts=1, target_seconds=1800)
+        self.assertEqual(projected['wall_seconds'], 2420)
+        self.assertEqual(projected['audio_bytes'], 929280000)
+        self.assertEqual(projected['metadata_bytes'], 1510000)
+        self.assertEqual(projected['epoch_attempts'], 91)
+        self.assertTrue(projected['within_limits'])
+        self.assertIn('headroom_fraction', projected)
+        self.assertIn('headroom', projected)
+        self.assertAlmostEqual(projected['headroom_fraction']['wall_seconds'], 280 / 2700)
+        self.assertEqual(projected['headroom']['audio_bytes'], (1 << 30) - 929280000)
+        exceeded = self.checkpoint.project_pilot(
+            playing_seconds=60, capture_wall_seconds=110, audio_bytes=44000000,
+            metadata_bytes=60000, epoch_attempts=10, fixed_wall_seconds=20,
+            fixed_audio_bytes=7680000, fixed_metadata_bytes=10000,
+            fixed_epoch_attempts=1, target_seconds=1800)
+        self.assertFalse(exceeded['within_limits'])
+        self.assertIn('wall_seconds', exceeded['exceeded_limits'])
+        self.assertIn('audio_bytes', exceeded['exceeded_limits'])
+        self.assertIn('epoch_attempts', exceeded['exceeded_limits'])
+
+    def test_pilot_rejects_zero_or_invalid_playing_time(self):
+        for playing in (0, -1, float('nan'), float('inf')):
+            with self.subTest(playing=playing), self.assertRaises(ValueError):
+                self.checkpoint.project_pilot(
+                    playing_seconds=playing, capture_wall_seconds=100, audio_bytes=100,
+                    metadata_bytes=100, epoch_attempts=2, fixed_wall_seconds=1,
+                    fixed_audio_bytes=1, fixed_metadata_bytes=1,
+                    fixed_epoch_attempts=1, target_seconds=1800)
+
+    def test_projection_uses_cycle_playing_and_collector_lifetime(self):
+        import inspect
+        params = inspect.signature(self.checkpoint.project_pilot).parameters
+        self.assertIn('cycle_playing_seconds', params)
+        self.assertIn('collector_wall_seconds', params)
+        result = self.checkpoint.project_pilot(
+            playing_seconds=60, cycle_playing_seconds=50, collector_wall_seconds=130,
+            capture_wall_seconds=100, audio_bytes=1000, metadata_bytes=100,
+            epoch_attempts=4, fixed_wall_seconds=20, fixed_collector_wall_seconds=50,
+            fixed_audio_bytes=200, fixed_metadata_bytes=20, fixed_epoch_attempts=1,
+            target_seconds=160, variability=0, minimum_headroom_fraction=0)
+        # Ten setup-playing seconds and fixed resources occur only once.
+        self.assertEqual(result['wall_seconds'], 260)
+        self.assertEqual(result['collector_wall_seconds'], 290)
+        self.assertEqual(result['audio_bytes'], 2600)
+        self.assertEqual(result['epoch_attempts'], 10)
+        limited = self.checkpoint.project_pilot(
+            playing_seconds=60, cycle_playing_seconds=50, collector_wall_seconds=700,
+            capture_wall_seconds=100, audio_bytes=1000, metadata_bytes=100,
+            epoch_attempts=4, fixed_wall_seconds=20, fixed_collector_wall_seconds=620,
+            fixed_audio_bytes=200, fixed_metadata_bytes=20, fixed_epoch_attempts=1,
+            target_seconds=1360, variability=0, minimum_headroom_fraction=0)
+        self.assertLess(limited['wall_seconds'], 2700)
+        self.assertGreater(limited['collector_wall_seconds'], 2700)
+        self.assertIn('collector_wall_seconds', limited['exceeded_limits'])
+
+    def test_projection_applies_variability_and_required_headroom(self):
+        result = self.checkpoint.project_pilot(
+            playing_seconds=100, cycle_playing_seconds=100, capture_wall_seconds=100,
+            collector_wall_seconds=100, audio_bytes=100, metadata_bytes=100,
+            epoch_attempts=1, fixed_wall_seconds=0, fixed_collector_wall_seconds=0,
+            fixed_audio_bytes=0, fixed_metadata_bytes=0, fixed_epoch_attempts=0,
+            target_seconds=2300, variability=.1, minimum_headroom_fraction=.1)
+        self.assertAlmostEqual(result['wall_seconds'], 2530)
+        self.assertNotIn('wall_seconds', result['exceeded_limits'])
+        self.assertIn('wall_seconds', result['below_required_headroom'])
+        self.assertFalse(result['within_limits'])
+
+    def test_playing_dwell_is_bounded_by_remaining_target(self):
+        self.assertTrue(hasattr(self.checkpoint, 'playing_dwell'), 'playing dwell policy is missing')
+        self.assertEqual(self.checkpoint.playing_dwell(1800, 0), 180)
+        self.assertEqual(self.checkpoint.playing_dwell(1800, 1780), 20)
+        self.assertEqual(self.checkpoint.playing_dwell(1800, 1801), 0)
+
+    def test_playing_audit_records_actual_frame_and_time_credit(self):
+        self.assertTrue(hasattr(self.checkpoint, 'AuditedPlayingIntervals'), 'playing audit is missing')
+        class Log:
+            def __init__(self): self.rows = []
+            def write(self, row): self.rows.append(row)
+        log = Log()
+        playing = self.checkpoint.AuditedPlayingIntervals(log)
+        playing.observe(0, True, 0, 1)
+        playing.observe(1, True, 48000, 1)
+        playing.observe(4, True, 192000, 1)
+        self.assertEqual([row['credited_seconds'] for row in log.rows], [0, 1, 0])
+        self.assertEqual(log.rows[1]['previous_frame'], 0)
+        self.assertEqual(log.rows[1]['frame'], 48000)
+        self.assertEqual(log.rows[1]['elapsed_seconds'], 1)
+        self.assertEqual(log.rows[2]['elapsed_seconds'], 3)
+
+    def test_epoch_qualification_distinguishes_errors_from_budget_exceedances(self):
+        self.assertTrue(hasattr(self.checkpoint, 'qualify_epochs'), 'epoch qualification is missing')
+        metrics = {'native_render_failures': '0', 'invalid_callback_shape': '0',
+                   'cpal_error_total': '0', 'cpal_xrun_reports': '0',
+                   'cpal_non_xrun_reports': '0', 'over_buffer_budget_count': '2'}
+        result = self.checkpoint.qualify_epochs([{'epoch_id': '1', 'metrics': metrics}])
+        self.assertTrue(result['qualified'])
+        self.assertEqual(result['totals']['over_buffer_budget_count'], 2)
+        metrics = {**metrics, 'native_render_failures': '1'}
+        result = self.checkpoint.qualify_epochs([{'epoch_id': '1', 'metrics': metrics}])
+        self.assertFalse(result['qualified'])
+        self.assertEqual(result['epochs'][0]['native_render_failures'], 1)
+        with self.assertRaises(ValueError):
+            self.checkpoint.qualify_epochs([{'epoch_id': '1', 'metrics': {**metrics, 'cpal_error_total': 'bad'}}])
+
+
+class DrivingObserverTests(unittest.TestCase):
+    def test_action_boundaries_observe_before_and_after_without_counting_action_time(self):
+        import desktop_checkpoint
+        self.assertTrue(hasattr(desktop_checkpoint, 'DrivingObserver'), 'driving observer seam is missing')
+        DrivingObserver = desktop_checkpoint.DrivingObserver
+        from sustained_measurement import SustainedMeasurement
+        from stream_measurement import EpochCollector, PlayingIntervals
+        from test_sustained_measurement import Clock, diagnostics
+        class Log:
+            def write(self, value): pass
+        clock = Clock()
+        playing = PlayingIntervals()
+        measure = SustainedMeasurement(EpochCollector(), playing, Log(), Log(), clock)
+        read = lambda: (diagnostics(), 'true', str(int(clock.now * 48000)))
+        observer = DrivingObserver(measure, read, clock, clock.sleep)
+        observer.observe()
+        clock.sleep(1)
+        observer.action('numeric', lambda: clock.sleep(1))
+        clock.sleep(1)
+        observer.observe()
+        self.assertEqual(playing.seconds, 2)
+        self.assertEqual(measure.action_ordinal, 1)
+
+    def test_wait_observes_at_most_one_second_apart(self):
+        import desktop_checkpoint
+        self.assertTrue(hasattr(desktop_checkpoint, 'DrivingObserver'), 'driving observer seam is missing')
+        DrivingObserver = desktop_checkpoint.DrivingObserver
+        from sustained_measurement import SustainedMeasurement
+        from stream_measurement import EpochCollector, PlayingIntervals
+        from test_sustained_measurement import Clock, diagnostics
+        class Log:
+            def write(self, value): pass
+        clock = Clock()
+        playing = PlayingIntervals()
+        measure = SustainedMeasurement(EpochCollector(), playing, Log(), Log(), clock)
+        observer = DrivingObserver(measure, lambda: (diagnostics(), 'true', str(int(clock.now * 48000))), clock, clock.sleep)
+        observer.observe()
+        observer.sleep(3.2)
+        self.assertAlmostEqual(playing.seconds, 3.2)
+
+    def test_nested_action_has_one_outer_observation_boundary(self):
+        from desktop_checkpoint import DrivingObserver
+        from sustained_measurement import SustainedMeasurement
+        from stream_measurement import EpochCollector, PlayingIntervals
+        from test_sustained_measurement import Clock, diagnostics
+        class Log:
+            def write(self, value): pass
+        clock = Clock()
+        reads = []
+        measure = SustainedMeasurement(EpochCollector(), PlayingIntervals(), Log(), Log(), clock)
+        def read():
+            reads.append(clock.now)
+            return diagnostics(), 'true', str(int(clock.now * 48000))
+        observer = DrivingObserver(measure, read, clock, clock.sleep)
+        observer.action('numeric', lambda: observer.action('keyboard', lambda: clock.sleep(.1)))
+        self.assertEqual(len(reads), 2)
+        self.assertEqual(measure.action_ordinal, 1)
+
+    def test_action_failure_and_post_observation_failure_are_both_preserved(self):
+        from desktop_checkpoint import DrivingObserver
+        from sustained_measurement import SustainedMeasurement
+        from stream_measurement import EpochCollector, PlayingIntervals
+        from test_sustained_measurement import Clock, diagnostics
+        class Log:
+            def write(self, value): pass
+        clock = Clock()
+        measure = SustainedMeasurement(EpochCollector(), PlayingIntervals(), Log(), Log(), clock)
+        calls = []
+        def read():
+            calls.append(True)
+            if len(calls) == 2:
+                raise __import__('sustained_measurement').ProcessDisappeared('exited')
+            return diagnostics(), 'true', '0'
+        observer = DrivingObserver(measure, read, clock, clock.sleep)
+        def fail(): raise ValueError('control failed')
+        with self.assertRaises(BaseExceptionGroup) as caught:
+            observer.action('seek', fail)
+        self.assertEqual([str(error) for error in caught.exception.exceptions], ['control failed', 'exited'])
+
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/apps/ultra/tests/test_desktop_launch_config.py b/apps/ultra/tests/test_desktop_launch_config.py
new file mode 100644
index 0000000..692f358
--- /dev/null
+++ b/apps/ultra/tests/test_desktop_launch_config.py
@@ -0,0 +1,51 @@
+import os
+from pathlib import Path
+import subprocess
+import unittest
+import tempfile
+
+HELPER = Path(__file__).with_name('desktop_launch_config.sh')
+
+def run_function(function, argument=None, size=None):
+    env = os.environ.copy()
+    env.pop('ULTRA_TEST_SCREEN_SIZE', None)
+    if size is not None:
+        env['ULTRA_TEST_SCREEN_SIZE'] = size
+    return subprocess.run(['bash', '-c', 'source "$1"; "$2" "${3-}"', 'test',
+                           str(HELPER), function, argument or ''], env=env,
+                          text=True, capture_output=True)
+
+class DesktopLaunchConfigTest(unittest.TestCase):
+    def test_default_and_valid_size(self):
+        self.assertEqual(run_function('desktop_screen_size').stdout.strip(), '1280x840')
+        self.assertEqual(run_function('desktop_screen_size', size='1600x1000').stdout.strip(), '1600x1000')
+        self.assertEqual(run_function('desktop_screen_size', size='3840x2160').stdout.strip(), '3840x2160')
+
+    def test_invalid_size_is_rejected(self):
+        for size in ('', '1280x839', '1279x840', '3841x1000', '1600x2161', '1600x1000x24', '1;touch x', 'abc'):
+            with self.subTest(size=size):
+                self.assertNotEqual(run_function('desktop_screen_size', size=size).returncode, 0)
+
+    def test_restart_binary_is_absolute_canonical_launch_identity(self):
+        with tempfile.TemporaryDirectory() as directory:
+            executable = Path(directory) / 'alive'
+            executable.write_text('#!/bin/sh\nexit 0\n')
+            executable.chmod(0o755)
+            alias = Path(directory) / 'alias'
+            alias.symlink_to(executable)
+            actual = run_function('desktop_alive_binary', str(alias))
+            self.assertEqual(actual.returncode, 0)
+            self.assertEqual(actual.stdout.strip(), str(executable.resolve()))
+
+    def test_alive_override_selects_adjacent_ultra_for_startup_preflight(self):
+        with tempfile.TemporaryDirectory() as directory:
+            alive = Path(directory) / 'alive'
+            ultra = Path(directory) / 'ultra'
+            alive.write_text('alive'); ultra.write_text('ultra')
+            alias = Path(directory) / 'alive-alias'
+            alias.symlink_to(alive)
+            actual = run_function('desktop_startup_binary', str(alias))
+            self.assertEqual(actual.returncode, 0, actual.stderr)
+            self.assertEqual(actual.stdout.strip(), str(ultra.resolve()))
+
+if __name__ == '__main__': unittest.main()
diff --git a/apps/ultra/tests/test_desktop_process_helpers.py b/apps/ultra/tests/test_desktop_process_helpers.py
new file mode 100644
index 0000000..bb14fb6
--- /dev/null
+++ b/apps/ultra/tests/test_desktop_process_helpers.py
@@ -0,0 +1,59 @@
+import subprocess
+import sys
+import tempfile
+import time
+import unittest
+from pathlib import Path
+
+import desktop_process_helpers as helpers
+
+class ProcessHelpersTest(unittest.TestCase):
+    def test_process_identity_compares_real_launch_and_restart_mappings(self):
+        processes = []
+        try:
+            with tempfile.TemporaryDirectory() as directory:
+                alias = Path(directory) / 'alive'
+                alias.symlink_to(Path(sys.executable).resolve())
+                config = Path(__file__).with_name('desktop_launch_config.sh')
+                resolved = subprocess.check_output(['bash', '-c', 'source "$1"; desktop_alive_binary "$2"',
+                                                    'test', str(config), str(alias)], text=True).strip()
+                for _ in range(2):
+                    process = subprocess.Popen([resolved, '-c', 'import time; time.sleep(30)'])
+                    processes.append(process)
+                    time.sleep(.2)
+                first, second = (helpers.process_identity(p.pid, 'libc.so') for p in processes)
+                self.assertEqual(first['executable_path'], resolved)
+                helpers.assert_same_identity(first, second)
+                second['libraries'][0]['sha256'] = 'changed'
+                with self.assertRaises(AssertionError):
+                    helpers.assert_same_identity(first, second)
+        finally:
+            for process in processes:
+                process.kill()
+                process.wait()
+
+    def test_hung_recorder_is_killed_and_cleanup_keeps_original_error(self):
+        recorder = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'], stdin=subprocess.PIPE)
+        calls = []
+        try:
+            try:
+                raise ValueError('journey failure')
+            finally:
+                errors = helpers.cleanup_independently([
+                    lambda: helpers.stop_recorder(recorder, timeout=.05),
+                    lambda: (_ for _ in ()).throw(RuntimeError('cleanup failure')),
+                    lambda: calls.append('remaining cleanup'),
+                ])
+        except ValueError as error:
+            self.assertEqual(str(error), 'journey failure')
+        else:
+            self.fail('original failure was lost')
+        finally:
+            if recorder.poll() is None:
+                recorder.kill()
+                recorder.wait()
+        self.assertIsNotNone(recorder.poll())
+        self.assertEqual(calls, ['remaining cleanup'])
+        self.assertEqual(len(errors), 2)
+
+if __name__ == '__main__': unittest.main()
diff --git a/apps/ultra/tests/test_desktop_sustained_integration.py b/apps/ultra/tests/test_desktop_sustained_integration.py
new file mode 100644
index 0000000..5df58e6
--- /dev/null
+++ b/apps/ultra/tests/test_desktop_sustained_integration.py
@@ -0,0 +1,250 @@
+"""GI-free tests of the actual desktop measurement adapter."""
+import tempfile
+import unittest
+from pathlib import Path
+from unittest.mock import patch
+
+from desktop_sustained import DesktopSustained
+from sustained_measurement import ProcessDisappeared
+from test_sustained_measurement import diagnostics
+
+
+class UI:
+    pid = 123
+    def __init__(self, output): self.output = output
+
+
+class DesktopSustainedIntegrationTests(unittest.TestCase):
+    def setUp(self):
+        self.tmp = tempfile.TemporaryDirectory()
+        self.addCleanup(self.tmp.cleanup)
+        self.driver = DesktopSustained(UI(Path(self.tmp.name)), None, None, None)
+
+    def test_real_adapter_feeds_diagnostics_and_transport_to_collector(self):
+        import json
+        values = {'Stream diagnostics': json.dumps(diagnostics()), 'Transport playing': 'true', 'Absolute frame': '48000'}
+        self.driver.accessible = values.get
+        with patch('pathlib.Path.read_text', return_value='123 (alive) S 1'):
+            self.driver.observe()
+        self.assertEqual(self.driver.epochs.cursor, 1)
+        self.assertEqual(self.driver.playing.last[1], True)
+
+    def test_confirmed_process_disappearance_is_latched(self):
+        with patch('pathlib.Path.read_text', side_effect=FileNotFoundError):
+            with self.assertRaises(ProcessDisappeared): self.driver.observe()
+        with self.assertRaises(ProcessDisappeared): self.driver.observe()
+
+    def test_accessible_reference_is_reused_and_replaced_after_stale_read(self):
+        class Stale(Exception): pass
+        class Node:
+            def __init__(self, text): self.text = text
+            def get_name(self): return 'Stream diagnostics'
+            def get_interfaces(self): return ['Text']
+        class Text:
+            @staticmethod
+            def get_text(node, _start, _end):
+                if node.text is None: raise Stale()
+                return node.text
+        class Atspi: pass
+        class GLib: pass
+        Atspi.Text, GLib.Error = Text, Stale
+        class Windows:
+            def __init__(self): self.calls = 0
+            def app_frames(self): self.calls += 1; return [object()]
+        class FakeUI(UI):
+            node = Node('first')
+            def walk(self, _frame): return iter([self.node])
+        ui, windows = FakeUI(Path(self.tmp.name)), Windows()
+        driver = DesktopSustained(ui, windows, Atspi, GLib)
+        self.assertEqual(driver.accessible('Stream diagnostics'), 'first')
+        self.assertEqual(driver.accessible('Stream diagnostics'), 'first')
+        self.assertEqual(windows.calls, 1)
+        ui.node.text = None
+        ui.node = Node('replacement')
+        self.assertEqual(driver.accessible('Stream diagnostics'), 'replacement')
+        self.assertEqual(windows.calls, 2)
+        ui.node.text = ''
+        ui.node = Node('fresh after empty')
+        self.assertEqual(driver.accessible('Stream diagnostics'), 'fresh after empty')
+        self.assertEqual(windows.calls, 3)
+
+    def test_defunct_diagnostics_without_replacement_breaks_playing_continuity(self):
+        import json
+        class Stale(Exception): pass
+        class Node:
+            def __init__(self, name, text): self.name, self.text = name, text
+            def get_name(self): return self.name
+            def get_interfaces(self): return ['Text']
+        class Text:
+            @staticmethod
+            def get_text(node, _start, _end):
+                if node.text is None: raise Stale()
+                return node.text
+        class Atspi: pass
+        class GLib: pass
+        Atspi.Text, GLib.Error = Text, Stale
+        class Windows:
+            def app_frames(self): return [object()]
+        class FakeUI(UI):
+            def walk(self, _frame): return iter(self.nodes)
+        ui = FakeUI(Path(self.tmp.name))
+        diagnostic = Node('Stream diagnostics', json.dumps(diagnostics()))
+        ui.nodes = [diagnostic, Node('Transport playing', 'true'), Node('Absolute frame', '0')]
+        driver = DesktopSustained(ui, Windows(), Atspi, GLib)
+        with patch('pathlib.Path.read_text', return_value='123 (alive) S 1'):
+            driver.observe()
+            self.assertIsNotNone(driver.playing.last)
+            diagnostic.text = None
+            ui.nodes.remove(diagnostic)
+            driver.observe()
+        self.assertIsNone(driver.playing.last)
+        self.assertIsNone(driver.accessible('Stream diagnostics'))
+
+    def test_defunct_handle_is_not_reused_even_if_it_returns_text(self):
+        class State:
+            def __init__(self, node): self.node = node
+            def contains(self, _state): return self.node.defunct
+        class Node:
+            def __init__(self, text): self.text, self.defunct = text, False
+            def get_name(self): return 'Absolute frame'
+            def get_interfaces(self): return ['Text']
+            def get_state_set(self): return State(self)
+        class Text:
+            @staticmethod
+            def get_text(node, _start, _end): return node.text
+        class Atspi:
+            class StateType: DEFUNCT = 'defunct'
+        class GLib: Error = RuntimeError
+        Atspi.Text = Text
+        class Windows:
+            def app_frames(self): return [object()]
+        class FakeUI(UI):
+            def walk(self, _frame): return iter([self.node])
+        ui = FakeUI(Path(self.tmp.name))
+        ui.node = Node('100')
+        driver = DesktopSustained(ui, Windows(), Atspi, GLib)
+        self.assertEqual(driver.accessible('Absolute frame'), '100')
+        ui.node.defunct = True
+        ui.node = Node('200')
+        self.assertEqual(driver.accessible('Absolute frame'), '200')
+
+
+    def test_install_brackets_real_ui_action_and_cleanup_restores_hooks(self):
+        events = []
+        class FakeUI(UI):
+            def click(self, name): events.append(('click', name))
+            def text(self, name, value): events.append(('text', name, value))
+            def keys(self, key): events.append(('keys', key))
+        class FakeThread:
+            def __init__(self, **kwargs): pass
+            def start(self): events.append(('sampler_started',))
+            def join(self, timeout): events.append(('sampler_joined',))
+            def is_alive(self): return False
+        import time
+        original_sleep = time.sleep
+        ui = FakeUI(Path(self.tmp.name))
+        driver = DesktopSustained(ui, None, None, None)
+        driver.observer.read = lambda: (diagnostics(), 'true', '0')
+        original_click = ui.click
+        with patch('desktop_sustained.threading.Thread', FakeThread):
+            try:
+                driver.install()
+                ui.click('Seek transport')
+                self.assertEqual(driver.measure.action_ordinal, 1)
+                self.assertEqual(driver.epochs.cursor, 1)
+                self.assertIn(('click', 'Seek transport'), events)
+            finally:
+                driver.cleanup()
+        self.assertEqual(ui.click, original_click)
+        self.assertIs(time.sleep, original_sleep)
+        self.assertIn(('sampler_joined',), events)
+
+    def test_short_sleeps_do_not_insert_reads_between_native_clicks(self):
+        class Clock:
+            now = 0.
+            def monotonic(self): return self.now
+            def sleep(self, seconds): self.now += seconds
+        class FakeUI(UI):
+            def click(self, _name): pass
+            def text(self, _name, _value): pass
+            def keys(self, _key): pass
+        class FakeThread:
+            def __init__(self, **_kwargs): pass
+            def start(self): pass
+            def join(self, timeout): pass
+            def is_alive(self): return False
+        clock, reads = Clock(), []
+        with patch('desktop_sustained.time', clock), patch('desktop_sustained.threading.Thread', FakeThread):
+            driver = DesktopSustained(FakeUI(Path(self.tmp.name)), None, None, None)
+            def read():
+                reads.append(clock.now)
+                return diagnostics(), 'true', str(int(clock.now * 48000))
+            driver.observer.read = read
+            driver.observe()
+            try:
+                driver.install()
+                clock.sleep(.07); clock.sleep(.07)
+                self.assertEqual(len(reads), 1)
+                clock.sleep(2.1)
+                self.assertGreaterEqual(len(reads), 3)
+            finally:
+                driver.cleanup()
+
+    def test_resource_sampling_continues_while_ui_action_waits(self):
+        import threading
+        blocking, sampled, release = threading.Event(), threading.Event(), threading.Event()
+        class FakeUI(UI):
+            def click(self, _name):
+                blocking.set()
+                if not release.wait(4): raise RuntimeError('fixture release timed out')
+            def text(self, _name, _value): pass
+            def keys(self, _key): pass
+        class FakeSampler:
+            def __init__(self, _pid): pass
+        class FakeGroups:
+            def __init__(self, **_groups): pass
+            def sample(self):
+                if blocking.is_set(): sampled.set()
+                return {'app': None, 'sampler_capture_overhead': None, 'private_audio_server': None}
+        driver = DesktopSustained(FakeUI(Path(self.tmp.name)), None, None, None)
+        driver.observer.read = lambda: (diagnostics(), 'true', '0')
+        result = []
+        def unblock():
+            blocking.wait(2)
+            result.append(sampled.wait(2))
+            release.set()
+        helper = threading.Thread(target=unblock)
+        with patch('desktop_sustained.ProcessSampler', FakeSampler), patch('desktop_sustained.ProcessGroups', FakeGroups):
+            try:
+                driver.install()
+                helper.start()
+                driver.ui.click('long UI action')
+            finally:
+                release.set()
+                helper.join(timeout=5)
+                driver.cleanup()
+        self.assertEqual(result, [True], 'resource sampler was blocked by the UI action')
+        import json
+        rows = [json.loads(line) for line in driver.resource_log.path.read_text().splitlines()]
+        self.assertTrue(rows)
+        for row in rows:
+            self.assertGreaterEqual(row['monotonic'], row['sampling_started'])
+            self.assertAlmostEqual(row['sampling_duration'], row['monotonic'] - row['sampling_started'])
+            self.assertAlmostEqual(row['sampling_delay'], max(0, row['sampling_started'] - row['scheduled_monotonic']))
+
+    def test_exited_recorder_and_sampler_fail_health(self):
+        class Process:
+            def poll(self): return 1
+        class Capture:
+            process = Process()
+        self.driver.capture = (Capture(), Path('capture'))
+        with self.assertRaisesRegex(RuntimeError, 'recorder supervisor'):
+            self.driver.health()
+        self.driver.finishing_capture = True
+        self.driver.health()
+        self.driver.finishing_capture = False
+        self.driver.capture = None
+        self.driver.errors.append(ValueError('sampler'))
+        with self.assertRaisesRegex(RuntimeError, 'resource sampler') as caught:
+            self.driver.health()
+        self.assertEqual(str(caught.exception.__cause__), 'sampler')
diff --git a/apps/ultra/tests/test_slider_help_fixture.py b/apps/ultra/tests/test_slider_help_fixture.py
new file mode 100644
index 0000000..4d07222
--- /dev/null
+++ b/apps/ultra/tests/test_slider_help_fixture.py
@@ -0,0 +1,47 @@
+import ast
+from pathlib import Path
+import unittest
+
+
+def load_validator():
+    source = Path(__file__).with_name('check_canvas_desktop.py').read_text()
+    module = ast.parse(source)
+    functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'slider_help_targets']
+    if not functions:
+        return None
+    namespace = {}
+    exec(compile(ast.Module(body=functions, type_ignores=[]), '<slider fixture>', 'exec'), namespace)
+    return namespace['slider_help_targets']
+
+
+def fixture():
+    nodes = [{'id': i, 'type': 'comment' if i in (1, 2, 3, 4, 5) else 'toggle'} for i in range(1, 22)]
+    executable = [node for node in nodes if node['type'] != 'comment']
+    executable[3]['type'] = 'slider'
+    executable[8]['type'] = 'number_int'
+    edges = [{'from': executable[3]['id'], 'outlet': 0, 'to': executable[8]['id'], 'inlet': 0}]
+    edges.extend({'from': 6, 'outlet': 0, 'to': 7, 'inlet': 0} for _ in range(9))
+    return {'nodes': nodes, 'edges': edges}
+
+
+class SliderHelpFixtureTest(unittest.TestCase):
+    def test_resolves_executable_roles_including_comments(self):
+        validate = load_validator()
+        self.assertIsNotNone(validate, 'slider help validator is missing')
+        self.assertEqual(validate(fixture()), (9, 14))
+
+    def test_rejects_count_type_and_connection_drift(self):
+        validate = load_validator()
+        self.assertIsNotNone(validate, 'slider help validator is missing')
+        for mutation in (
+            lambda patch: patch['nodes'].pop(),
+            lambda patch: patch['nodes'][8].update(type='toggle'),
+            lambda patch: patch['edges'][0].update(to=7),
+            lambda patch: patch['edges'].pop(),
+        ):
+            patch = fixture()
+            mutation(patch)
+            with self.subTest(mutation=mutation), self.assertRaises(AssertionError):
+                validate(patch)
+
+if __name__ == '__main__': unittest.main()
diff --git a/apps/ultra/tests/test_stage_alive_session.py b/apps/ultra/tests/test_stage_alive_session.py
new file mode 100644
index 0000000..6ce33dd
--- /dev/null
+++ b/apps/ultra/tests/test_stage_alive_session.py
@@ -0,0 +1,27 @@
+import json
+import tempfile
+import unittest
+from pathlib import Path
+
+from stage_alive_session import stage
+
+
+class StageSessionTest(unittest.TestCase):
+    def test_bare_and_envelope_rebase_devices(self):
+        with tempfile.TemporaryDirectory() as folder:
+            root = Path(folder)
+            (root / 'device.ultra').write_text('{}')
+            score = {'format': 'alive-session-v2', 'tracks': [{'device': {'path': 'device.ultra'}, 'effects': []}]}
+            for session in (score, {'format': 'alive-session-v5', 'score': score, 'master': {'gain': 0.5}}):
+                source, target = root / 'source.alive', root / 'target.alive'
+                source.write_text(json.dumps(session))
+                stage(source, target)
+                staged = json.loads(target.read_text())
+                staged_score = staged.get('score', staged)
+                self.assertEqual(staged_score['tracks'][0]['device']['path'], str(root / 'device.ultra'))
+                if 'master' in session:
+                    self.assertEqual(staged['master'], {'gain': 0.5})
+
+
+if __name__ == '__main__':
+    unittest.main()
diff --git a/apps/ultra/tests/test_sustained_measurement.py b/apps/ultra/tests/test_sustained_measurement.py
new file mode 100644
index 0000000..6774e3e
--- /dev/null
+++ b/apps/ultra/tests/test_sustained_measurement.py
@@ -0,0 +1,218 @@
+import json
+import tempfile
+import unittest
+from pathlib import Path
+
+from stream_measurement import EpochCollector, JsonLines, PlayingIntervals
+from sustained_measurement import SustainedMeasurement
+
+
+def diagnostics(**changes):
+    return {**{'run_id': 'run', 'coverage_gap': False, 'oldest_retained_epoch': '1',
+               'completed': [{'epoch_id': '1', 'final': True}], 'last_completed_epoch': '1',
+               'complete': True, 'active': None, 'retiring_epoch_id': None,
+               'native_quiescent': True}, **changes}
+
+
+class Clock:
+    def __init__(self): self.now = 0
+    def __call__(self): return self.now
+    def sleep(self, seconds): self.now += seconds
+
+
+class SustainedTests(unittest.TestCase):
+    def setUp(self):
+        self.tmp = tempfile.TemporaryDirectory()
+        self.addCleanup(self.tmp.cleanup)
+        self.clock = Clock()
+        self.log = JsonLines(Path(self.tmp.name) / 'epochs.jsonl')
+        self.actions = JsonLines(Path(self.tmp.name) / 'actions.jsonl')
+        self.epochs = EpochCollector(self.log)
+        self.playing = PlayingIntervals()
+        self.measure = SustainedMeasurement(self.epochs, self.playing, self.log, self.actions, self.clock)
+
+    def observe(self, frame, record=None):
+        return self.measure.observe(lambda: (diagnostics() if record is None else record, 'true', str(frame)))
+
+    def test_diagnostics_gap_breaks_continuity_even_when_frames_advance(self):
+        self.observe(0)
+        self.clock.sleep(1)
+        self.measure.observe(lambda: (None, 'true', '48000'))
+        self.clock.sleep(1)
+        self.observe(96000)
+        self.assertEqual(self.playing.seconds, 0)
+        self.clock.sleep(1)
+        self.observe(144000)
+        self.assertEqual(self.playing.seconds, 1)
+        rows = [json.loads(line) for line in self.log.path.read_text().splitlines()]
+        self.assertTrue(any(row.get('kind') == 'observation_gap' for row in rows))
+
+    def test_nested_numeric_seek_and_apply_boundaries_never_accrue_action_time(self):
+        self.observe(0)
+        for name in ('numeric', 'seek', 'Apply'):
+            self.clock.sleep(.5)
+            with self.measure.action(name):
+                with self.measure.action('nested'):
+                    self.clock.sleep(.5)
+                    self.observe(int(self.clock.now * 48000))
+            self.clock.sleep(.5)
+            self.observe(int(self.clock.now * 48000))
+        self.assertEqual(self.playing.seconds, 0)
+        self.clock.sleep(1)
+        self.observe(int(self.clock.now * 48000))
+        self.assertEqual(self.playing.seconds, 1)
+        self.assertEqual(self.measure.action_ordinal, 3)
+
+    def test_finalization_requires_complete_inactive_observation_before_deadline(self):
+        active = diagnostics(complete=False, active={'epoch_id': '2'}, retiring_epoch_id='2', native_quiescent=False)
+        with self.assertRaisesRegex(TimeoutError, 'retirement'):
+            self.measure.finalize(lambda: (active, 'false', '0'), 2, self.clock.sleep, 1)
+        records = iter([active, diagnostics()])
+        result = self.measure.finalize(lambda: (next(records), 'false', '0'), 2, self.clock.sleep, 1)
+        self.assertTrue(result['complete'])
+        self.assertEqual(self.epochs.cursor, 1)
+
+    def test_failed_health_poll_propagates_and_cleanup_runs(self):
+        cleaned = []
+        def fail(): raise RuntimeError('audio_limit')
+        with self.assertRaises(BaseExceptionGroup) as failure:
+            with self.measure.owned(cleanup=lambda: cleaned.append(True), health=fail):
+                self.observe(0)
+        self.assertEqual(cleaned, [True])
+        self.assertEqual([str(e) for e in failure.exception.exceptions], ['audio_limit', 'audio_limit'])
+
+    def test_missing_last_epoch_cannot_finalize(self):
+        record = diagnostics(completed=[], oldest_retained_epoch=None)
+        del record['last_completed_epoch']
+        with self.assertRaisesRegex(TimeoutError, 'retirement'):
+            self.measure.finalize(lambda: (record, 'false', '0'), 1, self.clock.sleep, 1)
+
+    def test_cleanup_health_detects_recorder_limit(self):
+        state = {'reason': None}
+        def cleanup(): state['reason'] = 'metadata_limit'
+        def health():
+            if state['reason']: raise RuntimeError(state['reason'])
+        with self.assertRaisesRegex(RuntimeError, 'metadata_limit'):
+            with self.measure.owned(cleanup, health):
+                self.observe(0)
+
+    def test_invalid_transport_and_callback_failure_break_continuity(self):
+        self.observe(0)
+        self.clock.sleep(1)
+        self.measure.observe(lambda: (diagnostics(), None, '48000'))
+        self.clock.sleep(1)
+        self.observe(96000)
+        self.clock.sleep(1)
+        def failed(): raise OSError('process vanished')
+        self.measure.observe(failed)
+        self.clock.sleep(1)
+        self.observe(192000)
+        self.assertEqual(self.playing.seconds, 0)
+
+    def test_collector_rejections_remain_fatal_and_break_continuity(self):
+        self.observe(0)
+        for record, reason in [
+            (diagnostics(run_id='other'), 'epoch_run_changed'),
+            (diagnostics(completed=[{'epoch_id': '2', 'final': False}]), 'epoch_not_final'),
+            (diagnostics(completed=[{'epoch_id': '2', 'final': True, 'metrics': {'counter_overflow': '1'}}]), 'epoch_counter_overflow'),
+            (diagnostics(coverage_gap=True, oldest_retained_epoch='3', completed=[]), 'epoch_coverage_gap'),
+            (diagnostics(active={'epoch_id': '257'}), 'epoch_limit'),
+        ]:
+            with self.subTest(reason=reason), self.assertRaisesRegex(RuntimeError, reason):
+                self.observe(48000, record)
+            self.assertIsNone(self.playing.last)
+
+    def test_metadata_limit_propagates_with_cleanup(self):
+        self.log.limit = 1
+        cleaned = []
+        with self.assertRaisesRegex(RuntimeError, 'metadata_limit'):
+            with self.measure.owned(lambda: cleaned.append(True), lambda: None):
+                self.observe(0)
+        self.assertEqual(cleaned, [True])
+
+    def test_empty_or_disappeared_process_cannot_finalize(self):
+        empty = diagnostics(completed=[], oldest_retained_epoch=None, last_completed_epoch=None)
+        with self.assertRaisesRegex(TimeoutError, 'retirement'):
+            self.measure.finalize(lambda: (empty, 'false', '0'), 1, self.clock.sleep, 1)
+        with self.assertRaisesRegex(TimeoutError, 'retirement'):
+            self.measure.finalize(lambda: (None, None, None), 1, self.clock.sleep, 1)
+
+    def test_disappearance_is_fatal_even_if_later_observation_looks_valid(self):
+        from sustained_measurement import ProcessDisappeared
+        def gone(): raise ProcessDisappeared('process exited')
+        with self.assertRaisesRegex(ProcessDisappeared, 'process exited'):
+            self.measure.observe(gone)
+        with self.assertRaisesRegex(ProcessDisappeared, 'process exited'):
+            self.measure.finalize(lambda: (diagnostics(), 'false', '0'), 1, self.clock.sleep)
+
+    def test_transient_gap_can_recover_and_finalize(self):
+        self.measure.observe(lambda: (None, None, None))
+        result = self.measure.finalize(lambda: (diagnostics(), 'false', '0'), 1, self.clock.sleep)
+        self.assertTrue(result['complete'])
+
+    def test_body_cleanup_and_post_cleanup_health_errors_are_all_visible(self):
+        cleaned = []
+        def cleanup():
+            cleaned.append(True)
+            raise RuntimeError('cleanup failed')
+        def health():
+            if cleaned: raise RuntimeError('recorder limit')
+        with self.assertRaises(BaseExceptionGroup) as failure:
+            with self.measure.owned(cleanup, health):
+                raise ValueError('body failed')
+        self.assertEqual(cleaned, [True])
+        self.assertEqual([str(e) for e in failure.exception.exceptions],
+                         ['body failed', 'cleanup failed', 'recorder limit'])
+
+    def test_body_failure_and_post_cleanup_health_are_both_visible(self):
+        cleaned = []
+        def health():
+            if cleaned: raise RuntimeError('sampler limit')
+        with self.assertRaises(BaseExceptionGroup) as failure:
+            with self.measure.owned(lambda: cleaned.append(True), health):
+                raise ValueError('body failed')
+        self.assertEqual([str(e) for e in failure.exception.exceptions], ['body failed', 'sampler limit'])
+
+    def test_latched_disappearance_on_entry_still_cleans_up(self):
+        from sustained_measurement import ProcessDisappeared
+        def gone(): raise ProcessDisappeared('process exited')
+        with self.assertRaises(ProcessDisappeared): self.measure.observe(gone)
+        events = []
+        def cleanup():
+            events.append('cleanup')
+            raise RuntimeError('cleanup failed')
+        def health():
+            events.append('health')
+            raise RuntimeError('recorder limit')
+        with self.assertRaises(BaseExceptionGroup) as failure:
+            with self.measure.owned(cleanup, health):
+                self.fail('body must not run')
+        self.assertEqual(events, ['cleanup', 'health'])
+        self.assertEqual([str(e) for e in failure.exception.exceptions],
+                         ['process exited', 'cleanup failed', 'recorder limit'])
+
+    def test_outer_health_failure_on_nested_entry_still_cleans_up(self):
+        events = []
+        def outer_health(): raise RuntimeError('outer limit')
+        with self.assertRaises(BaseExceptionGroup) as failure:
+            with self.measure.owned(lambda: events.append('outer cleanup'), outer_health):
+                with self.measure.owned(lambda: events.append('inner cleanup'), lambda: events.append('inner health')):
+                    self.fail('body must not run')
+        self.assertEqual(events, ['inner cleanup', 'inner health', 'outer cleanup'])
+        self.assertEqual(str(failure.exception.exceptions[0]), 'outer limit')
+
+    def test_oversized_frame_breaks_continuity_before_valid_read(self):
+        self.observe(0)
+        self.clock.sleep(1)
+        self.measure.observe(lambda: (diagnostics(), 'true', '9' * 5000))
+        self.clock.sleep(1)
+        self.observe(96000)
+        self.assertEqual(self.playing.seconds, 0)
+        self.assertTrue(any(json.loads(line).get('reason') == 'transport_unavailable_or_invalid'
+                            for line in self.log.path.read_text().splitlines()))
+
+    def test_frame_native_u64_range_is_enforced(self):
+        self.measure.observe(lambda: (diagnostics(), 'true', str((1 << 64) - 1)))
+        self.assertIsNotNone(self.playing.last)
+        self.measure.observe(lambda: (diagnostics(), 'true', str(1 << 64)))
+        self.assertIsNone(self.playing.last)
diff --git a/apps/ultra/tests/windows/CMakeLists.txt b/apps/ultra/tests/windows/CMakeLists.txt
new file mode 100644
index 0000000..26b7169
--- /dev/null
+++ b/apps/ultra/tests/windows/CMakeLists.txt
@@ -0,0 +1,23 @@
+cmake_minimum_required(VERSION 3.20)
+project(master_resolver_fixtures C)
+
+foreach(case IN ITEMS old partial full bad_limits forwarded)
+  if(case STREQUAL "bad_limits")
+    set(exports full.def)
+  else()
+    set(exports ${case}.def)
+  endif()
+  add_library(fixture_${case} SHARED master_fixture.c ${exports})
+  if(case STREQUAL "bad_limits")
+    target_compile_definitions(fixture_${case} PRIVATE FIXTURE_BAD_LIMITS=1)
+  else()
+    target_compile_definitions(fixture_${case} PRIVATE FIXTURE_BAD_LIMITS=0)
+  endif()
+  set_target_properties(fixture_${case} PROPERTIES OUTPUT_NAME ultra_native
+    RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/${case}"
+    ARCHIVE_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/${case}")
+endforeach()
+add_library(master_forward_target SHARED master_forward_target.c forward_target.def)
+set_target_properties(master_forward_target PROPERTIES
+  RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/forwarded"
+  ARCHIVE_OUTPUT_DIRECTORY_RELEASE "${CMAKE_BINARY_DIR}/forwarded")
diff --git a/apps/ultra/tests/windows/forward_target.def b/apps/ultra/tests/windows/forward_target.def
new file mode 100644
index 0000000..d4db8ac
--- /dev/null
+++ b/apps/ultra/tests/windows/forward_target.def
@@ -0,0 +1,3 @@
+LIBRARY master_forward_target
+EXPORTS
+    alive_session_master_set
diff --git a/apps/ultra/tests/windows/forwarded.def b/apps/ultra/tests/windows/forwarded.def
new file mode 100644
index 0000000..9f7d501
--- /dev/null
+++ b/apps/ultra/tests/windows/forwarded.def
@@ -0,0 +1,9 @@
+LIBRARY ultra_native
+EXPORTS
+    alive_session_state_v2
+    alive_session_master_limits
+    alive_session_master_set=master_forward_target.alive_session_master_set
+    alive_session_master_reset_clip
+    alive_session_master_snapshot_v2
+    alive_session_master_snapshot_v3
+    alive_session_master_snapshot_v4
diff --git a/apps/ultra/tests/windows/full.def b/apps/ultra/tests/windows/full.def
new file mode 100644
index 0000000..722bb19
--- /dev/null
+++ b/apps/ultra/tests/windows/full.def
@@ -0,0 +1,9 @@
+LIBRARY ultra_native
+EXPORTS
+    alive_session_state_v2
+    alive_session_master_limits
+    alive_session_master_set
+    alive_session_master_reset_clip
+    alive_session_master_snapshot_v2
+    alive_session_master_snapshot_v3
+    alive_session_master_snapshot_v4
diff --git a/apps/ultra/tests/windows/master_fixture.c b/apps/ultra/tests/windows/master_fixture.c
new file mode 100644
index 0000000..1382fa2
--- /dev/null
+++ b/apps/ultra/tests/windows/master_fixture.c
@@ -0,0 +1,18 @@
+#include <stdint.h>
+
+typedef struct { uint32_t version, bytes, features, ramp; double max_gain; } Limits;
+int alive_session_state_v2(void *out) { (void)out; return 1; }
+int alive_session_master_limits(Limits *out) {
+    out->version = 1; out->bytes = sizeof(*out); out->features = 7;
+    out->ramp = 64; out->max_gain = FIXTURE_BAD_LIMITS ? 3.0 : 4.0;
+    return 1;
+}
+int alive_session_master_set(uint32_t parameter, double value, uint64_t serial) {
+    (void)parameter; (void)value; (void)serial; return 1;
+}
+int alive_session_master_reset_clip(uint32_t mask, uint64_t serial) {
+    (void)mask; (void)serial; return 1;
+}
+int alive_session_master_snapshot_v2(void *state, void *master) { (void)state; (void)master; return 1; }
+int alive_session_master_snapshot_v3(void *state, void *master) { (void)state; (void)master; return 1; }
+int alive_session_master_snapshot_v4(void *state, void *master) { (void)state; (void)master; return 1; }
diff --git a/apps/ultra/tests/windows/master_forward_target.c b/apps/ultra/tests/windows/master_forward_target.c
new file mode 100644
index 0000000..9e1dfc9
--- /dev/null
+++ b/apps/ultra/tests/windows/master_forward_target.c
@@ -0,0 +1,4 @@
+#include <stdint.h>
+int alive_session_master_set(uint32_t parameter, double value, uint64_t serial) {
+    (void)parameter; (void)value; (void)serial; return 1;
+}
diff --git a/apps/ultra/tests/windows/master_resolver_fixtures.ps1 b/apps/ultra/tests/windows/master_resolver_fixtures.ps1
new file mode 100644
index 0000000..d42f071
--- /dev/null
+++ b/apps/ultra/tests/windows/master_resolver_fixtures.ps1
@@ -0,0 +1,66 @@
+param(
+    [string]$NativeDir = "apps/ultra/build",
+    [string]$StagedDir = "apps/ultra/src-tauri/target/x86_64-pc-windows-msvc/release",
+    [string]$ResultsDir = "test-results/windows-master-resolver"
+)
+$ErrorActionPreference = "Stop"
+$sourceDir = $PSScriptRoot
+$results = [IO.Path]::GetFullPath($ResultsDir)
+if (Test-Path $results) { throw "Refusing to overwrite existing results: $results" }
+New-Item -ItemType Directory -Path $results | Out-Null
+Start-Transcript -Path (Join-Path $results "report.txt") | Out-Null
+try {
+    $native = (Resolve-Path $NativeDir).Path
+    $staged = (Resolve-Path $StagedDir).Path
+    Write-Host "native=$native staged=$staged results=$results"
+    Write-Host "rustc=$(rustc --version) cmake=$(cmake --version | Select-Object -First 1)"
+    $build = Join-Path $results "build"
+    & cmake -S $sourceDir -B $build -G "Visual Studio 17 2022" -A x64
+    if ($LASTEXITCODE -ne 0) { throw "fixture CMake configure failed: $LASTEXITCODE" }
+    & cmake --build $build --config Release
+    if ($LASTEXITCODE -ne 0) { throw "fixture CMake build failed: $LASTEXITCODE" }
+
+    $vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio/Installer/vswhere.exe"
+    $vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
+    if ($LASTEXITCODE -ne 0 -or !$vs) { throw "Visual Studio C++ tools not found" }
+    $vcvars = Join-Path $vs "VC/Auxiliary/Build/vcvars64.bat"
+    $rustc = (Get-Command rustc).Source
+    $probe = Join-Path $results "master_resolver_probe.exe"
+    $probeSource = Join-Path $sourceDir "master_resolver_probe.rs"
+    & (Join-Path $sourceDir "master_resolver_launcher_diagnostic.ps1") $vcvars $rustc $probeSource $native $probe
+
+    $failed = @()
+    foreach ($case in @("real", "full", "old", "partial", "forwarded", "bad_limits")) {
+        try {
+            $dir = Join-Path $results $case
+            New-Item -ItemType Directory -Path $dir | Out-Null
+            Copy-Item $probe (Join-Path $dir "master_resolver_probe.exe")
+            if ($case -eq "real") {
+                Copy-Item (Join-Path $staged "ultra_native.dll") $dir
+                foreach ($name in Get-Content (Join-Path $native "windows-runtime-libraries.txt")) {
+                    if ($name -ne [IO.Path]::GetFileName($name)) { throw "Invalid runtime name: $name" }
+                    Copy-Item (Join-Path $native $name) $dir
+                }
+            } else {
+                Copy-Item (Join-Path $build "$case/ultra_native.dll") $dir
+                if ($case -eq "forwarded") { Copy-Item (Join-Path $build "forwarded/master_forward_target.dll") $dir }
+            }
+            $dll = Join-Path $dir "ultra_native.dll"
+            $sourceDll = if ($case -eq "real") { Join-Path $staged "ultra_native.dll" } else { Join-Path $build "$case/ultra_native.dll" }
+            $sourceHash = (Get-FileHash -Algorithm SHA256 $sourceDll).Hash
+            $stagedHash = (Get-FileHash -Algorithm SHA256 $dll).Hash
+            Write-Host "source=$sourceDll SHA256=$sourceHash staged=$dll SHA256=$stagedHash"
+            if ($sourceHash -ne $stagedHash) { throw "Staged DLL hash differs from source" }
+            Get-FileHash -Algorithm SHA256 (Join-Path $dir "*.dll") | Format-Table -AutoSize | Out-String | Write-Host
+            & (Join-Path $dir "master_resolver_probe.exe") $case $dll
+            if ($LASTEXITCODE -ne 0) { throw "probe failed: $LASTEXITCODE" }
+            Write-Host "PASS $case"
+        } catch {
+            Write-Host "FAIL $case : $_"
+            $failed += $case
+        }
+    }
+    if ($failed.Count) { throw "Fixture cases failed: $($failed -join ', ')" }
+} finally {
+    Stop-Transcript | Out-Null
+}
diff --git a/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1 b/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1
new file mode 100644
index 0000000..ea7d64d
--- /dev/null
+++ b/apps/ultra/tests/windows/master_resolver_launcher_diagnostic.ps1
@@ -0,0 +1,72 @@
+param(
+    [Parameter(Mandatory)] [string]$Vcvars,
+    [Parameter(Mandatory)] [string]$Rustc,
+    [Parameter(Mandatory)] [string]$ProbeSource,
+    [Parameter(Mandatory)] [string]$Native,
+    [Parameter(Mandatory)] [string]$Probe
+)
+
+# Feed commands on stdin to keep vcvars and rustc in one cmd process without /c quoting.
+$commands = @(
+    'echo launcher-diagnostic vcvars-start',
+    "call `"$Vcvars`"",
+    'set "launcher_exit=%errorlevel%"',
+    'echo launcher-diagnostic vcvars-exit=%launcher_exit%',
+    'if not "%launcher_exit%"=="0" exit /b %launcher_exit%',
+    'echo launcher-diagnostic rustc-start',
+    "`"$Rustc`" --edition=2021 -C opt-level=2 `"$ProbeSource`" -L `"native=$Native`" -o `"$Probe`"",
+    'set "launcher_exit=%errorlevel%"',
+    'echo launcher-diagnostic rustc-exit=%launcher_exit%',
+    'exit /b %launcher_exit%'
+)
+Write-Host "launcher-diagnostic input:"
+$commands | ForEach-Object { Write-Host $_ }
+$info = [Diagnostics.ProcessStartInfo]::new()
+$info.FileName = $env:ComSpec
+$info.Arguments = '/d /q'
+$info.UseShellExecute = $false
+$info.RedirectStandardInput = $true
+# Inherit output handles: redirected output pipes could fill and block cmd.
+$process = [Diagnostics.Process]::new()
+$process.StartInfo = $info
+$started = $false
+$cleanupPending = $false
+$clock = [Diagnostics.Stopwatch]::StartNew()
+try {
+    $started = $process.Start()
+    if (!$started) { throw 'cmd start returned false' }
+    Write-Host "launcher-diagnostic cmd-pid=$($process.Id)"
+    $inputText = ($commands -join "`r`n") + "`r`n"
+    $write = $process.StandardInput.WriteAsync($inputText)
+    $remaining = [Math]::Max(0, 45000 - [int]$clock.ElapsedMilliseconds)
+    if (!$write.Wait($remaining)) { throw 'stdin write timed out' }
+    $flush = $process.StandardInput.FlushAsync()
+    $remaining = [Math]::Max(0, 45000 - [int]$clock.ElapsedMilliseconds)
+    if (!$flush.Wait($remaining)) { throw 'stdin flush timed out' }
+    $remaining = [Math]::Max(0, 45000 - [int]$clock.ElapsedMilliseconds)
+    if (!$process.WaitForExit($remaining)) { throw 'cmd timed out' }
+    Write-Host "launcher-diagnostic cmd-exit=$($process.ExitCode) probe-exists=$(Test-Path -LiteralPath $Probe)"
+    if ($process.ExitCode -ne 0) { throw "probe compile failed: $($process.ExitCode)" }
+    if (!(Test-Path -LiteralPath $Probe -PathType Leaf)) { throw 'probe compile produced no output' }
+} catch {
+    Write-Host "launcher-diagnostic error: $_"
+    throw
+} finally {
+    if ($started -and !$process.HasExited) {
+        try {
+            # Run tree termination separately so cleanup itself has a finite wait.
+            $method = [Diagnostics.Process].GetMethod('Kill', [type[]]@([bool]))
+            $call = [Linq.Expressions.Expression]::Call(
+                [Linq.Expressions.Expression]::Constant($process), $method,
+                [Linq.Expressions.Expression[]]@([Linq.Expressions.Expression]::Constant($true)))
+            $kill = [Linq.Expressions.Expression]::Lambda([Action], $call, [Linq.Expressions.ParameterExpression[]]@()).Compile()
+            $cleanup = [Threading.Tasks.Task]::Run($kill)
+            $cleanupPending = !$cleanup.Wait(5000)
+            if ($cleanupPending) { Write-Host 'launcher-diagnostic cleanup timed out' }
+            else { Write-Host 'launcher-diagnostic tree termination requested' }
+        } catch {
+            Write-Host "launcher-diagnostic cleanup error: $_"
+        }
+    }
+    if (!$cleanupPending) { $process.Dispose() }
+}
diff --git a/apps/ultra/tests/windows/master_resolver_probe.rs b/apps/ultra/tests/windows/master_resolver_probe.rs
new file mode 100644
index 0000000..f9f5ff3
--- /dev/null
+++ b/apps/ultra/tests/windows/master_resolver_probe.rs
@@ -0,0 +1,84 @@
+#![allow(dead_code)]
+#[path = "../../src-tauri/src/session/native_master.rs"]
+mod native_master;
+
+use std::{ffi::{c_char, c_void}, path::{Path, PathBuf}, ptr};
+
+#[link(name = "ultra_native")]
+extern "C" { fn alive_session_state_v2(state: *mut c_void) -> i32; }
+#[link(name = "kernel32")]
+extern "system" {
+    fn GetModuleHandleExW(flags: u32, address: *const u16, module: *mut *mut c_void) -> i32;
+    fn GetModuleFileNameW(module: *mut c_void, path: *mut u16, size: u32) -> u32;
+    fn GetProcAddress(module: *mut c_void, name: *const c_char) -> *mut c_void;
+    fn FreeLibrary(module: *mut c_void) -> i32;
+}
+
+unsafe fn module_for(address: *const c_void) -> *mut c_void {
+    let mut module = ptr::null_mut();
+    assert!(!address.is_null() && GetModuleHandleExW(4, address.cast(), &mut module) != 0);
+    assert!(!module.is_null());
+    module
+}
+unsafe fn module_path(module: *mut c_void) -> PathBuf {
+    let mut buf = [0u16; 32768];
+    let len = GetModuleFileNameW(module, buf.as_mut_ptr(), buf.len() as u32) as usize;
+    assert!(len > 0 && len < buf.len(), "module path unavailable or truncated");
+    PathBuf::from(std::ffi::OsString::from_wide(&buf[..len]))
+}
+use std::os::windows::ffi::OsStringExt;
+
+fn same_path(actual: &Path, expected: &Path) -> bool {
+    std::fs::canonicalize(actual).unwrap() == std::fs::canonicalize(expected).unwrap()
+}
+
+fn main() {
+    let args: Vec<_> = std::env::args_os().collect();
+    assert_eq!(args.len(), 3, "probe <case> <expected DLL path>");
+    let case = args[1].to_str().unwrap();
+    assert!(["real", "full", "old", "partial", "forwarded", "bad_limits"].contains(&case));
+    let anchor = alive_session_state_v2 as *const () as *const c_void;
+    unsafe {
+        let module = module_for(anchor);
+        let path = module_path(module);
+        println!("case={case} anchor={anchor:p} mapped={}", path.display());
+        assert!(same_path(&path, Path::new(&args[2])), "unexpected anchor module");
+        let exported = GetProcAddress(module, b"alive_session_state_v2\0".as_ptr().cast());
+        assert_eq!(exported, anchor.cast_mut(), "anchor is not its module's export");
+        let names: [&[u8]; 6] = [b"alive_session_master_limits\0", b"alive_session_master_set\0", b"alive_session_master_reset_clip\0", b"alive_session_master_snapshot_v2\0", b"alive_session_master_snapshot_v3\0", b"alive_session_master_snapshot_v4\0"];
+        let mut symbols = Vec::new();
+        for name in names {
+            let address = GetProcAddress(module, name.as_ptr().cast());
+            let label = std::str::from_utf8(&name[..name.len()-1]).unwrap();
+            if address.is_null() {
+                println!("symbol={label} missing");
+            } else {
+                let owner = module_for(address);
+                let owner_path = module_path(owner);
+                println!("symbol={label} owner={}", owner_path.display());
+                if case == "forwarded" && label == "alive_session_master_set" {
+                    let expected_target = Path::new(&args[2]).parent().unwrap().join("master_forward_target.dll");
+                    assert_ne!(owner, module);
+                    assert!(same_path(&owner_path, &expected_target));
+                } else { assert_eq!(owner, module, "unexpected symbol owner for {label}"); }
+                assert_ne!(FreeLibrary(owner), 0);
+            }
+            symbols.push(address);
+        }
+        let count = symbols.iter().filter(|p| !p.is_null()).count();
+        assert_eq!(count, match case { "old" => 0, "partial" => 1, _ => 6 });
+        if count == 6 {
+            let get_limits: unsafe extern "C" fn(*mut native_master::Limits) -> i32 = std::mem::transmute(symbols[0]);
+            let mut limits = native_master::Limits { version: 1, struct_bytes: std::mem::size_of::<native_master::Limits>() as u32, ..Default::default() };
+            assert_eq!(get_limits(&mut limits), 1);
+            println!("limits version={} bytes={} features={} ramp={} max_gain={}", limits.version, limits.struct_bytes, limits.features, limits.ramp_frames, limits.max_gain);
+            assert_eq!((limits.version, limits.struct_bytes, limits.features, limits.ramp_frames), (1, 24, 7, 64));
+            assert_eq!(limits.max_gain, if case == "bad_limits" { 3.0 } else { 4.0 });
+        }
+        let actual = native_master::resolve(anchor).is_some();
+        let expected = case == "real" || case == "full";
+        println!("resolve={actual} expected={expected}");
+        assert_eq!(actual, expected);
+        assert_ne!(FreeLibrary(module), 0);
+    }
+}
diff --git a/apps/ultra/tests/windows/old.def b/apps/ultra/tests/windows/old.def
new file mode 100644
index 0000000..d5b553f
--- /dev/null
+++ b/apps/ultra/tests/windows/old.def
@@ -0,0 +1,3 @@
+LIBRARY ultra_native
+EXPORTS
+    alive_session_state_v2
diff --git a/apps/ultra/tests/windows/partial.def b/apps/ultra/tests/windows/partial.def
new file mode 100644
index 0000000..494d8d5
--- /dev/null
+++ b/apps/ultra/tests/windows/partial.def
@@ -0,0 +1,4 @@
+LIBRARY ultra_native
+EXPORTS
+    alive_session_state_v2
+    alive_session_master_limits
diff --git a/apps/ultra/ui/alive-dom.test.mjs b/apps/ultra/ui/alive-dom.test.mjs
index a628932..edc7341 100644
--- a/apps/ultra/ui/alive-dom.test.mjs
+++ b/apps/ultra/ui/alive-dom.test.mjs
@@ -340,6 +340,19 @@ test('successful file keeps its result with failed refresh and clears only refre
   assert.equal(native.calls.filter(c=>c.name==='alive_file').length,1);view.dispose();
 });
 
+test('migrated save feedback remains visible when the follow-up refresh fails',async()=>{
+  const page=dom('./alive.html'),native=backend(state());let failSnapshot=false;
+  const invoke=async(name,args)=>{
+    if(name==='alive_current'&&failSnapshot)throw Error(snapshotError);
+    const result=await native.invoke(name,args);
+    if(name==='alive_file'){result.notice='Saved in Alive session v5 format';failSnapshot=true;}
+    return result;
+  };
+  const view=mountAlive({...page,invoke});await settle();await page.ids.get('save').fire('click');
+  assert.equal(page.ids.get('notice').textContent,`Saved in Alive session v5 format Refresh delayed: Error: ${snapshotError}`);
+  view.dispose();
+});
+
 test('ordinary periodic refresh retains ready status and a later explicit file action replaces an old refusal',async()=>{
   const page=dom('./alive.html'),native=backend(state());let refuse=true;
   const invoke=async(name,args)=>{const result=await native.invoke(name,args);if(name==='alive_file'&&refuse)throw Error(dependencyError);return result;};
@@ -351,6 +364,17 @@ test('ordinary periodic refresh retains ready status and a later explicit file a
   assert.deepEqual(native.calls.filter(c=>c.name==='alive_file').map(c=>c.args.action),['open','save']);view.dispose();
 });
 
+test('workspace conversion feedback does not misidentify a v5 envelope as a v4 file',async()=>{
+  const initial=state();initial.state.playing=0;initial.capabilities={workspaceConversionAvailable:true,clipBank:false};
+  const page=dom('./alive.html'),native=backend(initial);
+  const invoke=async(name,args)=>name==='alive_enable_workspaces'?structuredClone(native.snapshot):native.invoke(name,args);
+  const view=mountAlive({...page,invoke});await settle();
+  await page.find('Enable MIDI workspaces').fire('click');
+  const status=page.ids.get('notice').textContent;
+  assert.match(status,/MIDI workspaces prepared/);assert.doesNotMatch(status,/Save writes v4/);
+  view.dispose();
+});
+
 test('queued Add note cannot cross successful removal into a reused track index',async()=>{
   const initial=state();initial.state.playing=0;
   const page=dom('./alive.html'),native=backend(initial),boundary=delayedBoundary(native,'alive_device',snapshot=>{
@@ -812,12 +836,37 @@ function timelineBackend(initial=workspaceState()){
     else if(op.kind==='sourceIndependent'){const p=document.placements.find(p=>p.id===op.occurrence.placementId),source=structuredClone(document.sources.find(s=>s.id===p.sourceId));source.id=`independent-${initial.draftRevision}`;source.notes.forEach(n=>n.id+='-copy');document.sources.push(source);p.sourceId=source.id;Object.assign(affected,{trackId:p.trackId,sourceId:source.id,placementId:p.id});}
     else if(op.kind==='noteUpdate'){const source=document.sources.find(s=>s.id===op.sourceId),note=source.notes.find(n=>n.id===op.noteId);Object.assign(note,{beat:op.beat,duration:op.duration,pitch:op.pitch,velocity:op.velocity});affected.trackId=source.trackId;affected.noteId=note.id;}
     else if(op.kind==='sourceRename'){const source=document.sources.find(s=>s.id===op.sourceId);source.name=op.name;affected.trackId=source.trackId;}
+    else if(op.kind==='sourceLength'){const source=document.sources.find(s=>s.id===op.sourceId);source.lengthBeats=op.lengthBeats;affected.trackId=source.trackId;}
     else if(op.kind==='slotAssign'){const t=document.tracks.find(t=>t.id===op.trackId);affected.slotId=`assigned-${initial.draftRevision}`;t.slots[op.slot]={id:affected.slotId,name:op.name,sourceId:op.sourceId,sourceOffset:op.sourceOffset,loopEnabled:op.loopEnabled};}
     else if(op.kind==='transportRange'){const {kind,...values}=op;Object.assign(document,values);}
     else throw Error(`Unsupported test operation ${op.kind}`);
     history.push(structuredClone(initial.draft??initial.document));future.length=0;initial.draft=document;initial.draftRevision++;initial.history={canUndo:true,canRedo:false};return{snapshot:structuredClone(initial),affected};
   };return{...native,invoke};
 }
+for(const field of ['MIDI source length','Arrangement source name','Add note'])test(`queued ${field} refuses a source rewired by independence`,async()=>{
+  const initial=workspaceState(),page=dom('./alive.html'),native=timelineBackend(initial);let release,held=true;
+  const view=mountAlive({...page,invoke:async(name,args)=>{if(name==='alive_workspace_edit'&&held){held=false;await new Promise(resolve=>release=resolve);}return native.invoke(name,args);}});await settle();
+  await page.find('Select placement placement-0').fire('click');const input=page.find(field),originalId=initial.document.sources[0].id;
+  await page.find('Make placement independent').fire('click');if(field==='Add note')await input.fire('click');else{input.value=field.includes('length')?'16':'Changed';await input.fire('change');}await page.find('Select Harmony slot 1').fire('click');release();await settle();await settle();
+  const document=view.model.document(),independentId=document.placements[0].sourceId;
+  assert.notEqual(independentId,originalId);assert.equal(document.sources.find(s=>s.id===originalId).lengthBeats,8);assert.equal(document.sources.find(s=>s.id===originalId).name,initial.document.sources[0].name);
+  assert.equal(document.sources.find(s=>s.id===originalId).notes.length,initial.document.sources[0].notes.length);
+  assert.equal(native.calls.filter(c=>c.name==='alive_workspace_edit').length,1);assert.match(page.ids.get('notice').textContent,/source.*changed/i);view.dispose();
+});
+test('queued base edit retains its generation across Open with a reused instance',async()=>{
+  const page=dom('./alive.html'),native=backend(state()),boundary=delayedBoundary(native,'alive_file',snapshot=>{snapshot.generation++;snapshot.draftRevision++;}),view=mountAlive({...page,invoke:boundary.invoke});await settle();
+  await page.ids.get('open').fire('click');const input=page.find('Cutoff base');input.value='3200';await input.fire('change');boundary.release();await settle();await settle();
+  assert.equal(native.snapshot.document.tracks[0].device.parameters.cutoff,2400);const call=native.calls.find(c=>c.name==='alive_base');assert.ok(!call||call.args.generation===1);view.dispose();
+});
+test('loop-only edit updates the Arrangement brace disabled state',async()=>{
+  const page=dom('./alive.html'),native=timelineBackend(),view=mountAlive({...page,invoke:native.invoke});await settle();
+  const loop=page.ids.get('loop');loop.checked=false;await loop.fire('change');
+  assert.equal(page.find('Song loop brace').classList.contains('disabled'),!view.model.document().loopEnabled);view.dispose();
+});
+test('duplicate refuses an out-of-song destination without changing placements',async()=>{
+  const page=dom('./alive.html'),native=timelineBackend(),view=mountAlive({...page,invoke:native.invoke});await settle();await page.find('Select placement placement-0').fire('click');
+  await page.find('Duplicate placement').fire('click');assert.equal(view.model.document().placements.length,2);assert.equal(native.calls.filter(c=>c.name==='alive_workspace_edit').length,0);assert.match(page.ids.get('notice').textContent,/fit inside the song/i);view.dispose();
+});
 test('Arrangement creates an accessible unplaced source then a separate placement and source note',async()=>{
   const initial=workspaceState();initial.document.placements=[];const page=dom('./alive.html'),native=timelineBackend(initial),view=mountAlive({...page,invoke:native.invoke});await settle();
   await page.find('Create MIDI source').fire('click');assert.equal(view.model.document().sources.length,3);assert.equal(view.model.document().placements.length,0);
@@ -876,3 +925,36 @@ test('Arrangement gain uses shared mixer state and retains queued track identity
   assert.equal(view.model.document().tracks[0].gain,.713);assert.equal(Number(page.find('Pulse gain').value),.713);assert.equal(page.ids.get('arrangement-workspace').hidden,false);
   assert.equal(native.calls.filter(c=>c.name==='alive_mixer').length,1);assert.equal(native.calls.find(c=>c.name==='alive_mixer').args.track,0);assert.ok(page.find('Harmony Arrangement gain'));view.dispose();
 });
+
+test('Master controls use one native owner and display separate interval channels',async()=>{
+  const initial=clipState();initial.master={gain:1,acceptedSerial:'3',available:true,unavailableReason:null,observationStale:false,observation:{targetGain:1,currentGain:1,peakLeft:.2,peakRight:.8,clipMask:2,appliedSerial:'3',appliedFrame:'64',observationStartFrame:'0',observationEndFrame:'64'}};
+  const page=dom('./alive.html'),native=backend(initial),view=mountAlive({...page,invoke:native.invoke});await settle();
+  assert.ok(page.find('Master gain fader'));assert.ok(page.find('Master left peak'));assert.ok(page.find('Master right peak'));
+  assert.match(page.find('Master right peak').textContent,/0\.800/);view.dispose();
+});
+
+for(const [label,commandName] of [
+  ['Bypass Pulse Stereo Utility effect 1','alive_bypass'],
+  ['Move Pulse Stereo Utility effect 1 later','alive_device'],
+  ['Remove Pulse track','alive_device'],
+  ['Replace Pulse device','alive_device'],
+  ['Open Pulse editor','alive_editor'],
+  ['Edit selected device in Ultra','alive_editor'],
+])for(const succeeds of [true,false])test(`queued ${label} ${succeeds?'cannot affect replacement':'survives failed Open'} with reused IDs`,async()=>{
+  const initial=withChain();initial.state.playing=commandName==='alive_bypass'?1:0;
+  const page=dom('./alive.html'),native=backend(initial);
+  const boundary=delayedBoundary(native,'alive_file',snapshot=>{if(succeeds){snapshot.generation++;snapshot.draftRevision++;snapshot.document.title='Replacement';}},succeeds?'snapshot':'error');
+  const invoke=async(name,args)=>{
+    if(name===commandName){
+      if(args.generation!==native.snapshot.generation){native.calls.push({name,args:structuredClone(args)});throw Error('Stale generation');}
+      if(name==='alive_device'){native.calls.push({name,args:structuredClone(args)});native.snapshot.document.title='Device mutation';return structuredClone(native.snapshot);}
+    }
+    return boundary.invoke(name,args);
+  };
+  const view=mountAlive({...page,invoke});await settle();
+  await page.ids.get('open').fire('click');await page.find(label).fire('click');boundary.release();await settle();await settle();
+  const calls=native.calls.filter(c=>c.name===commandName);
+  if(succeeds){assert.equal(native.snapshot.document.title,'Replacement');assert.equal(native.snapshot.document.tracks[0].effects[0].bypassed,false);assert.ok(calls.length===0||calls.every(c=>c.args.generation===1));}
+  else{assert.equal(calls.length,1);assert.equal(calls[0].args.generation,1);if(commandName==='alive_bypass'){assert.deepEqual(calls[0].args,{instanceId:'effect-0',bypassed:true,generation:1});assert.equal(native.snapshot.document.tracks[0].effects[0].bypassed,true);assert.equal(native.snapshot.state.playing,1);}if(commandName==='alive_device'){assert.equal(calls[0].args.trackId,'track-1');assert.equal(native.snapshot.document.title,'Device mutation');}if(commandName==='alive_editor')assert.equal(calls[0].args.instanceId,initial.document.tracks[0].device.instanceId);}
+  view.dispose();
+});
diff --git a/apps/ultra/ui/alive-master-producer.test.mjs b/apps/ultra/ui/alive-master-producer.test.mjs
new file mode 100644
index 0000000..368c971
--- /dev/null
+++ b/apps/ultra/ui/alive-master-producer.test.mjs
@@ -0,0 +1,79 @@
+import test from 'node:test';
+import assert from 'node:assert/strict';
+import {createMasterProducer} from './alive-master.mjs';
+
+const tick=()=>new Promise(resolve=>setImmediate(resolve));
+const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject};};
+
+test('one in flight, reset precedes superseding gain, and second reset is refused',async()=>{
+  const calls=[],pending=[];const notices=[];
+  const producer=createMasterProducer({invoke:(name,args)=>{calls.push([name,args]);const d=deferred();pending.push(d);return d.promise;},onStatus:s=>notices.push(s)});
+  producer.setGeneration(7);producer.gain(.1);producer.gain(.2);producer.reset();producer.gain(.3);
+  assert.equal(producer.reset(),false);assert.match(notices.at(-1).message,/pending/i);
+  assert.deepEqual(calls,[['alive_master',{generation:7,gain:.1}]]);
+  pending[0].resolve({generation:7,acceptedGain:.1,acceptedSerial:'1',changed:true});await tick();
+  assert.deepEqual(calls[1],['alive_master_reset_clip',{generation:7}]);
+  pending[1].resolve({generation:7,acceptedSerial:'2'});await tick();
+  assert.deepEqual(calls[2],['alive_master',{generation:7,gain:.3}]);
+  pending[2].resolve({generation:7,acceptedGain:.3,acceptedSerial:'3',changed:true});await tick();
+});
+
+test('busy retains final gain and one retry timer; generation cancels late work',async()=>{
+  const calls=[],pending=[],timers=[];const notices=[];
+  const producer=createMasterProducer({invoke:(name,args)=>{calls.push([name,args]);const d=deferred();pending.push(d);return d.promise;},onStatus:s=>notices.push(s),setTimer:fn=>{timers.push(fn);return timers.length;},clearTimer:()=>{}});
+  producer.setGeneration(1);producer.gain(.25);pending[0].reject({code:'BUSY',message:'retiring'});await tick();
+  assert.equal(timers.length,1);producer.gain(.75);assert.equal(calls.length,1);
+  timers[0]();await tick();assert.deepEqual(calls[1],['alive_master',{generation:1,gain:.75}]);
+  producer.setGeneration(2);pending[1].resolve({generation:1,acceptedGain:.75,acceptedSerial:'1',changed:true});await tick();
+  assert.equal(notices.some(s=>s.receipt?.generation===1),false);
+});
+
+test('retry preserves reset ordering and permanent failures never retry',async()=>{
+  const calls=[],pending=[],timers=[],status=[];
+  const producer=createMasterProducer({invoke:(name,args)=>{calls.push([name,args]);const d=deferred();pending.push(d);return d.promise;},onStatus:s=>status.push(s),setTimer:fn=>(timers.push(fn),timers.length)});
+  producer.setGeneration(3);producer.reset();producer.gain(.2);
+  pending[0].reject({code:'FULL',message:'queue full'});await tick();assert.equal(timers.length,1);
+  producer.gain(.9);assert.equal(producer.reset(),false);timers[0]();
+  assert.equal(calls[1][0],'alive_master_reset_clip');pending[1].resolve({generation:3,acceptedSerial:'10'});await tick();
+  assert.deepEqual(calls[2],['alive_master',{generation:3,gain:.9}]);pending[2].reject({code:'INVALID',message:'invalid value'});await tick();
+  assert.equal(timers.length,1);assert.match(status.at(-1).message,/invalid value/);
+});
+
+test('ordinal exhaustion refuses intent without wrapping',()=>{
+  const calls=[],status=[];const producer=createMasterProducer({invoke:(name,args)=>(calls.push([name,args]),new Promise(()=>{})),onStatus:s=>status.push(s),maxOrdinal:1});
+  producer.setGeneration(1);assert.equal(producer.gain(.5),true);assert.equal(producer.gain(.6),false);assert.match(status.at(-1).message,/exhausted/);assert.equal(calls.length,1);
+});
+
+test('malformed receipts are refused and unavailable generation cannot send',async()=>{
+  const statuses=[];const pending=deferred();let calls=0;
+  const producer=createMasterProducer({invoke:()=>{calls++;return pending.promise;},onStatus:s=>statuses.push(s)});
+  assert.equal(producer.gain(.4),false);assert.equal(calls,0);
+  producer.setGeneration(4);producer.gain(.4);pending.resolve({generation:4,acceptedGain:.4,acceptedSerial:'bad',changed:true});await tick();
+  assert.match(statuses.at(-1).message,/receipt/i);assert.equal(statuses.at(-1).error,true);
+});
+
+test('permanent gain refusal retains the requested value in visible status',async()=>{
+  const pending=deferred(),statuses=[];const producer=createMasterProducer({invoke:()=>pending.promise,onStatus:s=>statuses.push(s)});
+  producer.setGeneration(1);producer.gain(.42);pending.reject({code:'UNSUPPORTED',message:'unavailable'});await tick();
+  assert.equal(statuses.at(-1).value,.42);assert.equal(statuses.at(-1).error,true);
+});
+
+test('permanent bridge codes do not retry, even if message mentions busy',async()=>{
+  for(const code of ['STALE_GENERATION','INVALID','UNSUPPORTED','UNCONFIGURED','EXHAUSTED','INTERNAL']){
+    const pending=deferred(),status=[],timers=[];const producer=createMasterProducer({invoke:()=>pending.promise,onStatus:s=>status.push(s),setTimer:fn=>timers.push(fn)});
+    producer.setGeneration(1);producer.gain(.7);pending.reject({code,message:'busy, try again'});await tick();assert.equal(timers.length,0,code);assert.equal(status.at(-1).error,true,code);assert.equal(status.at(-1).value,.7,code);
+  }
+});
+
+test('generation change cancels pending retry and late failure cannot affect new generation',async()=>{
+  const calls=[],pending=[],timers=new Map(),status=[];let id=0;
+  const producer=createMasterProducer({invoke:(name,args)=>{calls.push([name,args]);const d=deferred();pending.push(d);return d.promise;},onStatus:s=>status.push(s),setTimer:fn=>(timers.set(++id,fn),id),clearTimer:id=>timers.delete(id)});
+  producer.setGeneration(1);producer.gain(.2);pending[0].reject({code:'FULL',message:'full'});await tick();assert.equal(timers.size,1);producer.setGeneration(2);assert.equal(timers.size,0);
+  producer.gain(.6);assert.deepEqual(calls.at(-1),['alive_master',{generation:2,gain:.6}]);producer.setGeneration(3);producer.gain(.9);pending[1].reject({code:'UNSUPPORTED',message:'old generation'});await tick();assert.deepEqual(calls.at(-1),['alive_master',{generation:3,gain:.9}]);assert.equal(status.some(s=>s.message.includes('old generation')),false);
+  pending[2].resolve({generation:3,acceptedGain:.9,acceptedSerial:'9',changed:true});await tick();
+});
+
+test('admission receipt must carry a nonzero native serial',async()=>{
+  const pending=deferred(),status=[];const producer=createMasterProducer({invoke:()=>pending.promise,onStatus:s=>status.push(s)});
+  producer.setGeneration(1);producer.gain(.4);pending.resolve({generation:1,acceptedGain:.4,acceptedSerial:'0',changed:true});await tick();assert.equal(status.at(-1).error,true);assert.equal(status.at(-1).value,.4);
+});
diff --git a/apps/ultra/ui/alive-master.mjs b/apps/ultra/ui/alive-master.mjs
new file mode 100644
index 0000000..d3ef0c1
--- /dev/null
+++ b/apps/ultra/ui/alive-master.mjs
@@ -0,0 +1,52 @@
+export function nativeInteger(value){if(typeof value!=='string'||! /^(0|[1-9][0-9]*)$/.test(value))throw Error('Native identity requires a canonical decimal string.');const result=BigInt(value);if(result>18446744073709551615n)throw Error('Native identity exceeds u64.');return result;}
+
+export function validateMaster(master){
+  const invalid=()=>{throw Error('Invalid Master snapshot.');};
+  const number=(value,min,max)=>typeof value==='number'&&Number.isFinite(value)&&value>=min&&value<=max;
+  if(!master||typeof master!=='object'||!number(master.gain,0,4)||typeof master.available!=='boolean'||!(master.unavailableReason===null||typeof master.unavailableReason==='string')||typeof master.observationStale!=='boolean')invalid();
+  nativeInteger(master.acceptedSerial);
+  const observation=master.observation;
+  if(observation!==null){
+    if(!observation||typeof observation!=='object'||!number(observation.targetGain,0,4)||!number(observation.currentGain,0,4)||!number(observation.peakLeft,0,Infinity)||!number(observation.peakRight,0,Infinity)||!Number.isInteger(observation.clipMask)||observation.clipMask<0||observation.clipMask>3)invalid();
+    for(const key of ['appliedSerial','appliedFrame','observationStartFrame','observationEndFrame'])nativeInteger(observation[key]);
+  }
+  return master;
+}
+
+// One producer owns admission for every Master control in both views.
+export function createMasterProducer({invoke,onStatus=()=>{},setTimer=setTimeout,clearTimer=clearTimeout,maxOrdinal=Number.MAX_SAFE_INTEGER}={}){
+  let generation=null,ordinal=0,inFlight=null,gain=null,reset=null,timer=null,epoch=0;
+  const report=(message,extra={})=>onStatus({message,...extra});
+  function nextOrdinal(){if(ordinal>=maxOrdinal){report('Master command ordinal exhausted.',{error:true});return null;}return ++ordinal;}
+  function pump(){
+    if(inFlight||timer!==null||generation===null)return;
+    const op=!gain?reset:!reset?gain:gain.ordinal<reset.ordinal?gain:reset;
+    if(!op)return;
+    if(op===gain)gain=null;else reset=null;
+    inFlight=op;const currentEpoch=epoch;
+    let request;try{request=invoke(op.kind==='gain'?'alive_master':'alive_master_reset_clip',op.kind==='gain'?{generation:op.generation,gain:op.value}:{generation:op.generation});}catch(error){request=Promise.reject(error);}
+    Promise.resolve(request).then(receipt=>{
+      if(currentEpoch!==epoch)return;
+      try{
+        if(receipt?.generation!==generation)throw Error();
+        if(nativeInteger(receipt.acceptedSerial)===0n)throw Error();
+        if(op.kind==='gain'&&(typeof receipt.acceptedGain!=='number'||!Number.isFinite(receipt.acceptedGain)||receipt.acceptedGain<0||receipt.acceptedGain>4||typeof receipt.changed!=='boolean'))throw Error();
+      }catch{report('Invalid or stale Master receipt.',{error:true,ordinal:op.ordinal,kind:op.kind,...(op.kind==='gain'?{value:op.value}:{})});return;}
+      report(op.kind==='gain'?'Master gain admitted.':'Digital overload reset admitted.',{receipt,ordinal:op.ordinal,kind:op.kind,value:op.value});
+    },error=>{
+      if(currentEpoch!==epoch)return;
+      const message=error?.message??String(error);
+      if(error?.code==='FULL'||error?.code==='BUSY'){
+        if(op.kind==='reset')reset=op;else if(!gain||gain.ordinal<op.ordinal)gain=op;
+        report(`Master waiting: ${message}`,{pending:true});
+        timer=setTimer(()=>{timer=null;pump();},100);
+      }else report(`Master refused: ${message}`,{error:true,ordinal:op.ordinal,kind:op.kind,...(op.kind==='gain'?{value:op.value}:{})});
+    }).finally(()=>{inFlight=null;pump();});
+  }
+  return {
+    setGeneration(value){if(value===generation)return;generation=value;epoch++;ordinal=0;gain=reset=null;if(timer!==null){clearTimer(timer);timer=null;}pump();},
+    gain(value){if(generation===null){report('Master is unavailable.',{error:true});return false;}if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>4){report('Master gain must be between 0 and 4.',{error:true});return false;}const n=nextOrdinal();if(n===null)return false;gain={kind:'gain',value,generation,ordinal:n};report('Master gain pending admission.',{pending:true,value,ordinal:n,kind:'gain'});pump();return true;},
+    reset(){if(generation===null){report('Master is unavailable.',{error:true});return false;}if(reset||inFlight?.kind==='reset'&&inFlight.generation===generation){report('Digital overload reset already pending.',{error:true});return false;}const n=nextOrdinal();if(n===null)return false;reset={kind:'reset',generation,ordinal:n};report('Digital overload reset pending admission.',{pending:true,ordinal:n,kind:'reset'});pump();return true;},
+    dispose(){generation=null;epoch++;gain=reset=null;if(timer!==null){clearTimer(timer);timer=null;}}
+  };
+}
diff --git a/apps/ultra/ui/alive-master.test.mjs b/apps/ultra/ui/alive-master.test.mjs
new file mode 100644
index 0000000..975df95
--- /dev/null
+++ b/apps/ultra/ui/alive-master.test.mjs
@@ -0,0 +1,23 @@
+import test from 'node:test';
+import assert from 'node:assert/strict';
+import {validateMaster} from './alive-master.mjs';
+
+const observation=()=>({targetGain:.25,currentGain:.3,peakLeft:.8,peakRight:1.2,clipMask:2,appliedSerial:'9007199254740993',appliedFrame:'9007199254740995',observationStartFrame:'9007199254740995',observationEndFrame:'9007199254741059'});
+const master=()=>({gain:.5,acceptedSerial:'9007199254740994',available:true,unavailableReason:null,observation:observation(),observationStale:false});
+
+test('valid Master DTO retains separate accepted and applied identities and nullable observation',()=>{
+  const value=master();assert.equal(validateMaster(value),value);
+  assert.equal(value.acceptedSerial,'9007199254740994');assert.equal(value.observation.appliedSerial,'9007199254740993');
+  assert.doesNotThrow(()=>validateMaster({gain:.5,acceptedSerial:'0',available:false,unavailableReason:'Unavailable',observation:null,observationStale:false}));
+  value.observationStale=true;assert.doesNotThrow(()=>validateMaster(value));
+});
+
+test('invalid Master DTO values are refused rather than coerced',()=>{
+  for(const [key,value] of [['gain',NaN],['gain',4.1],['available',1],['unavailableReason',undefined],['observationStale',null],['acceptedSerial','01'],['acceptedSerial','18446744073709551616']]){
+    const dto=master();dto[key]=value;assert.throws(()=>validateMaster(dto),undefined,key);
+  }
+  for(const [key,value] of [['targetGain',-1],['currentGain',Infinity],['peakLeft',-1],['peakRight',NaN],['clipMask',4],['appliedSerial',1],['appliedFrame','-1'],['observationStartFrame','1.5'],['observationEndFrame','18446744073709551616']]){
+    const dto=master();dto.observation[key]=value;assert.throws(()=>validateMaster(dto),undefined,key);
+  }
+  assert.throws(()=>validateMaster(null));
+});
diff --git a/apps/ultra/ui/alive-model.mjs b/apps/ultra/ui/alive-model.mjs
index 894f4f5..a6681a5 100644
--- a/apps/ultra/ui/alive-model.mjs
+++ b/apps/ultra/ui/alive-model.mjs
@@ -1,10 +1,15 @@
-export function nativeInteger(value){if(typeof value!=='string'||! /^(0|[1-9][0-9]*)$/.test(value))throw Error('Native identity requires a canonical decimal string.');const result=BigInt(value);if(result>18446744073709551615n)throw Error('Native identity exceeds u64.');return result;}
+import {nativeInteger,validateMaster} from './alive-master.mjs';
+export {nativeInteger} from './alive-master.mjs';
 export function instrumentOf(track){return track?.chain?(track.chain.kind==='midi'?track.chain.instrument:null):track?.device??null;}
 export function actualDevices(track){return [instrumentOf(track),...(track?.effects??[])].filter(Boolean);}
 export function createAliveModel(){
   let current=null,draft=null;
   const clone=value=>structuredClone(value);
   function fresh(snapshot){
+    // Once a stream supplies these fields, an older mock cannot downgrade it.
+    if(current)for(const key of ['master','snapshotSequence','preparationRevision'])if(current[key]!==undefined&&snapshot[key]===undefined)return false;
+    // Older mock snapshots may omit Master; present DTOs must be complete.
+    if(Object.hasOwn(snapshot,'master'))validateMaster(snapshot.master);
     for(const key of ['generation','draftRevision'])if(snapshot[key]!==undefined&&(!Number.isSafeInteger(snapshot[key])||snapshot[key]<0))throw Error('Invalid desktop revision.');
     for(const key of ['preparationRevision','snapshotSequence'])if(snapshot[key]!==undefined)nativeInteger(snapshot[key]);
     if(!current)return true;
diff --git a/apps/ultra/ui/alive-model.test.mjs b/apps/ultra/ui/alive-model.test.mjs
index d169898..4d3b275 100644
--- a/apps/ultra/ui/alive-model.test.mjs
+++ b/apps/ultra/ui/alive-model.test.mjs
@@ -4,6 +4,49 @@ import {createAliveModel, parameterReading} from './alive-model.mjs';
 
 const document=()=>({format:'alive-session-v2',title:'Test',tempo:120,lengthBeats:8,loopEnabled:true,tracks:[{id:'a',name:'Pulse',effects:[],device:{instanceId:'instrument',sourceSha256:'0'.repeat(64),bypassed:false,id:'synth',path:'a.ultra',version:1,parameters:{cutoff:1000}},gain:.7,mute:false,solo:false,notes:[{beat:0,pitch:60,duration:1,velocity:90}],automation:[{instanceId:'instrument',key:'cutoff',enabled:true,points:[{beat:0,value:700}]}]}]});
 const snapshot=(doc=document())=>({generation:1,document:doc,devices:[],state:{position:0,playing:1,tracks:[{effective:[700],owned:[1]}]}});
+const master=()=>({gain:.5,acceptedSerial:'9007199254740994',available:true,unavailableReason:null,observation:{targetGain:.25,currentGain:.3,peakLeft:.8,peakRight:1.2,clipMask:2,appliedSerial:'9007199254740993',appliedFrame:'9007199254740995',observationStartFrame:'9007199254740995',observationEndFrame:'9007199254741059'},observationStale:false});
+
+for(const method of ['accept','applied'])for(const missing of ['master','snapshotSequence','preparationRevision']){
+  test(`${method} refuses a delayed response missing established ${missing}`,()=>{
+    const model=createAliveModel();
+    assert.equal(model.accept(snapshot()),true); // Legacy-only streams remain usable.
+    const current={...snapshot(),draftRevision:1,preparationRevision:'20',snapshotSequence:'20',master:master()};
+    assert.equal(model.accept(current),true);model.edit(d=>{d.tempo=140;});
+    const late=structuredClone(current);delete late[missing];late.document.tempo=80;
+    assert.equal(model[method](late),false);
+    assert.equal(model.snapshot(),current);assert.equal(model.document().tempo,140);assert.equal(model.pending(),true);assert.deepEqual(model.snapshot().master,current.master);
+    const next=structuredClone(current);next.snapshotSequence='21';next.master.gain=.75;
+    assert.equal(model.accept(next),true);assert.equal(model.snapshot().master.gain,.75);assert.equal(model.document().tempo,140);
+  });
+}
+
+test('malformed Master identities are rejected before changing current or draft',()=>{
+  const model=createAliveModel(),initial={...snapshot(),draftRevision:1,snapshotSequence:'1',master:master()};
+  model.accept(initial);model.edit(d=>{d.tempo=140;});
+  const invalid=structuredClone(initial);invalid.draftRevision=2;invalid.snapshotSequence='2';invalid.master.observation.appliedSerial=9007199254740993;
+  assert.throws(()=>model.accept(invalid),/decimal string/);
+  assert.equal(model.snapshot(),initial);assert.equal(model.document().tempo,140);assert.equal(model.pending(),true);
+  assert.throws(()=>model.applied(invalid),/decimal string/);
+  assert.equal(model.snapshot(),initial);assert.equal(model.document().tempo,140);
+});
+
+test('Master survives score editing, live merge, apply and discard independently',()=>{
+  const model=createAliveModel(),initial={...snapshot(),draftRevision:1,snapshotSequence:'1',master:master()};
+  model.accept(initial);model.edit(d=>{d.tempo=140;});
+  const next=structuredClone(initial);next.snapshotSequence='2';next.master.gain=.75;next.master.acceptedSerial='9007199254740995';next.document.tracks[0].gain=.4;model.accept(next);
+  assert.equal(model.document().tempo,140);assert.equal(model.document().tracks[0].gain,.4);assert.deepEqual(model.snapshot().master,next.master);assert.equal(model.document().master,undefined);
+  const applied=structuredClone(next);applied.snapshotSequence='3';applied.document.tempo=140;model.applied(applied);
+  assert.equal(model.pending(),false);assert.deepEqual(model.snapshot().master,next.master);
+  model.edit(d=>{d.tempo=150;});model.discard();assert.equal(model.document().tempo,140);assert.deepEqual(model.snapshot().master,next.master);
+});
+
+test('nullable and stale observations and older snapshots preserve authoritative Master',()=>{
+  const model=createAliveModel(),initial={...snapshot(),draftRevision:4,preparationRevision:'4',snapshotSequence:'10',master:master()};model.accept(initial);model.edit(d=>{d.tempo=140;});
+  const stale=structuredClone(initial);stale.snapshotSequence='11';stale.master.observationStale=true;model.accept(stale);assert.equal(model.snapshot().master.observationStale,true);assert.equal(model.document().tempo,140);
+  const unavailable=structuredClone(stale);unavailable.snapshotSequence='12';unavailable.master={gain:.5,acceptedSerial:'0',available:false,unavailableReason:'Upgrade native library',observation:null,observationStale:false};model.accept(unavailable);assert.deepEqual(model.snapshot().master,unavailable.master);
+  for(const old of [{...initial,snapshotSequence:'9'}, {...initial,generation:0,snapshotSequence:'13'}, {...initial,draftRevision:3,snapshotSequence:'13'}, {...initial,preparationRevision:'3',snapshotSequence:'13'}]){assert.equal(model.accept(old),false);assert.deepEqual(model.snapshot().master,unavailable.master);}
+  assert.equal(model.document().tempo,140);
+});
 
 test('polling preserves musical drafts and merges newer live base and mixer values',()=>{
   const model=createAliveModel();model.accept(snapshot());
diff --git a/apps/ultra/ui/alive-timeline.mjs b/apps/ultra/ui/alive-timeline.mjs
index 4c4b441..45dafac 100644
--- a/apps/ultra/ui/alive-timeline.mjs
+++ b/apps/ultra/ui/alive-timeline.mjs
@@ -50,11 +50,12 @@ export function mountTimeline({doc,win,state,choose,edit,placementEdit,transport
         const change=changes=>placementEdit(p.trackId,p.id,p.sourceId,changes);
         fields.start=number('Placement start',p.start,start=>change({start}));fields.duration=number('Placement duration',p.duration,duration=>change({duration}));fields.offset=number('Placement source offset',p.sourceOffset.value,value=>change({sourceOffset:{kind:'beats',value}}));
         fields.loop=make('input');fields.loop.type='checkbox';fields.loop.checked=p.loopEnabled;fields.loop.setAttribute('aria-label','Loop source suffix');const loop=fields.loop;loop.addEventListener('change',guard(()=>change({loopEnabled:loop.checked})));
-        fields.destination=number('Duplicate placement start',p.start+p.duration,()=>{});const destination=fields.destination;
-        container.append(field('Start',fields.start),field('Duration',fields.duration),field('Offset',fields.offset),field('Loop suffix',fields.loop),field('Copy to',fields.destination),button('Duplicate placement',()=>edit({kind:'placementDuplicate',placementId:p.id,start:Number(destination.value)})),button('Make placement independent',()=>edit({kind:'sourceIndependent',occurrence:{kind:'placement',placementId:p.id}})),button('Delete placement',()=>edit({kind:'placementDelete',placementId:p.id})));
+        const candidates=[p.start+p.duration,0,...s.document.placements.filter(q=>q.trackId===p.trackId).map(q=>q.start+q.duration)];
+        fields.destination=number('Duplicate placement start',candidates.find(start=>!placementError({...p,id:null,start},source,s.document.placements,s.document.lengthBeats))??p.start+p.duration,()=>{});const destination=fields.destination;
+        container.append(field('Start',fields.start),field('Duration',fields.duration),field('Offset',fields.offset),field('Loop suffix',fields.loop),field('Copy to',fields.destination),button('Duplicate placement',()=>{const value=destination.value,start=Number(value);return edit(()=>{const current=state().document,original=current.placements.find(q=>q.id===p.id&&q.trackId===p.trackId);if(!original||original.sourceId!==p.sourceId)throw Error('The originating placement or source changed.');const error=value===''||!Number.isFinite(start)?'Enter a valid duplicate start.':placementError({...original,id:null,start},current.sources.find(q=>q.id===original.sourceId),current.placements,current.lengthBeats);if(error)throw Error(error);return{kind:'placementDuplicate',placementId:p.id,start};});}),button('Make placement independent',()=>edit({kind:'sourceIndependent',occurrence:{kind:'placement',placementId:p.id}})),button('Delete placement',()=>edit({kind:'placementDelete',placementId:p.id})));
       }else container.append(make('span','muted','Select an occurrence to edit its timing. Source notes stay in Clip detail.'));
     }
-    updateInput(fields.gain,track.gain);if(fields.name)updateInput(fields.name,source.name);
+    updateInput(fields.gain,Number(track.gain.toFixed(3)));fields.gain.title=`${track.name} track gain: ${track.gain}`;if(fields.name)updateInput(fields.name,source.name);
     if(p){updateInput(fields.start,p.start);updateInput(fields.duration,p.duration);updateInput(fields.offset,p.sourceOffset.value);if(doc.activeElement!==fields.loop&&!preserves(fields.loop))fields.loop.checked=p.loopEnabled;}
     updateInput($('song-loop-start'),s.document.loopStartBeats);updateInput($('song-loop-end'),s.document.loopEndBeats);
     const receipts=s.snapshot.runtime?.requests.filter(r=>r.kind==='return')??[];
@@ -65,22 +66,22 @@ export function mountTimeline({doc,win,state,choose,edit,placementEdit,transport
     root.hidden=!enabled;$('arrangement-placeholder').hidden=!!enabled;if(!enabled)return;
     if(gesture&&(gesture.generation!==snapshot.generation||gesture.revision!==snapshot.draftRevision||gesture.token!==s.token)){cancel();return;}
     inspector(s);const r=getRange();$('timeline-range').textContent=`Range ${r.start} - ${r.start+r.duration} beats`;
-    const width=document.lengthBeats*scale,visibleLeft=(scroll.scrollLeft??0)/scale,visibleRight=visibleLeft+(scroll.clientWidth||1000)/scale;
-    const next=JSON.stringify([snapshot.generation,document.tracks.map(t=>[t.id,t.name,t.color]),document.sources,document.placements,document.lengthBeats,document.loopStartBeats,document.loopEndBeats,scale,range,preview,s.selection,visibleLeft,visibleRight]);
-    if(next!==key){key=next;canvas.replaceChildren();canvas.style.width=`${width+176}px`;canvas.style.minHeight=`${48+64*document.tracks.length}px`;
-      const ruler=make('div','timeline-ruler');ruler.style.width=`${width}px`;ruler.style.marginLeft='176px';
+    const width=document.lengthBeats*scale,laneWidth=Math.max(width,(scroll.clientWidth||1000)-176),visibleLeft=(scroll.scrollLeft??0)/scale,visibleRight=visibleLeft+(scroll.clientWidth||1000)/scale;
+    const next=JSON.stringify([snapshot.generation,document.tracks.map(t=>[t.id,t.name,t.color]),document.sources,document.placements,document.lengthBeats,document.loopEnabled,document.loopStartBeats,document.loopEndBeats,scale,range,preview,s.selection,visibleLeft,visibleRight]);
+    if(next!==key){key=next;canvas.replaceChildren();canvas.style.width=`${laneWidth+176}px`;canvas.style.minHeight=`${48+64*document.tracks.length}px`;
+      const ruler=make('div','timeline-ruler');ruler.style.width=`${laneWidth}px`;ruler.style.marginLeft='0px';
       for(let beat=0;beat<=document.lengthBeats;beat+=Math.max(1,Math.ceil(40/scale))){const tick=button(`${Math.floor(beat/4)+1}.${beat%4+1}`,()=>action({kind:'seek',beat}),'timeline-tick');tick.setAttribute('aria-label',`Seek to beat ${beat}`);tick.style.left=`${beat*scale}px`;ruler.append(tick);}canvas.append(ruler);
       const brace=make('div','timeline-brace'),start=preview?.loopStartBeats??document.loopStartBeats,end=preview?.loopEndBeats??document.loopEndBeats;
-      brace.setAttribute('aria-label','Song loop brace');brace.style.left=`${176+start*scale}px`;brace.style.width=`${(end-start)*scale}px`;brace.textContent=`Song loop ${start} - ${end}`;brace.classList.toggle('disabled',!document.loopEnabled);
+      brace.setAttribute('aria-label','Song loop brace');brace.style.left=`${start*scale}px`;brace.style.width=`${(end-start)*scale}px`;brace.textContent=`Song loop ${start} - ${end}`;brace.classList.toggle('disabled',!document.loopEnabled);
       for(const side of ['left','right']){const handle=make('span','timeline-edge '+side);handle.dataset.braceEdge=side;brace.append(handle);}canvas.append(brace);
       document.tracks.forEach(t=>{
-        const row=make('div','timeline-row');row.dataset.trackId=t.id;row.style.setProperty('--track-color',t.color);row.style.width=`${width+176}px`;
+        const row=make('div','timeline-row');row.dataset.trackId=t.id;row.style.setProperty('--track-color',t.color);row.style.width=`${laneWidth+176}px`;
         const header=make('div','timeline-header'),name=button(t.name,()=>select(t.id,null),'timeline-track-name');name.setAttribute('aria-label',`Select ${t.name} Arrangement track`);name.title=t.name;header.append(name);
         const authority=make('output','timeline-authority');authority.setAttribute('aria-label',`${t.name} Arrangement authority`);
         const back=button(`Return ${t.name}`,()=>action({kind:'return',trackIds:[t.id]}),'timeline-return');back.textContent='Return';back.title=`Return ${t.name} to Arrangement`;
         const mute=button(`${t.name} Arrangement mute`,()=>mix(t.id,{mute:!state().document.tracks.find(q=>q.id===t.id).mute}),'timeline-mute'),solo=button(`${t.name} Arrangement solo`,()=>mix(t.id,{solo:!state().document.tracks.find(q=>q.id===t.id).solo}),'timeline-solo');mute.textContent='M';solo.textContent='S';
-        header.append(mute,solo,authority,back);row.append(header);
-        const lane=make('div','timeline-lane');lane.dataset.trackId=t.id;lane.style.width=`${width}px`;lane.style.backgroundSize=`${4*scale}px 100%`;
+        header.append(mute,solo,authority,back);
+        const lane=make('div','timeline-lane');lane.dataset.trackId=t.id;lane.style.width=`${laneWidth}px`;lane.style.backgroundSize=`${4*scale}px 100%`;
         if(r.trackId===t.id){const selected=make('div','timeline-range');selected.style.left=`${r.start*scale}px`;selected.style.width=`${r.duration*scale}px`;lane.append(selected);}
         for(const installed of snapshot.document.placements.filter(p=>p.trackId===t.id)){
           const draft=document.placements.find(p=>p.id===installed.id);if(JSON.stringify(draft)===JSON.stringify(installed))continue;
@@ -96,7 +97,7 @@ export function mountTimeline({doc,win,state,choose,edit,placementEdit,transport
           const marks=doc.createElementNS('http://www.w3.org/2000/svg','svg');marks.setAttribute('viewBox',`0 0 ${p.duration*scale} 30`);marks.setAttribute('preserveAspectRatio','none');
           if(source?.kind==='midi')for(const m of midiMarks(source,p,visibleLeft,visibleRight,scale)){const line=doc.createElementNS('http://www.w3.org/2000/svg','rect');for(const [k,v]of Object.entries({x:(m.start-p.start)*scale,y:26-Math.max(0,Math.min(1,(m.pitch-36)/60))*24,width:Math.max(1,(m.end-m.start)*scale),height:2}))line.setAttribute(k,String(v));marks.append(line);}occurrence.append(marks);
           for(const side of ['left','right']){const handle=make('span','timeline-edge '+side);handle.dataset.edge=side;occurrence.append(handle);}lane.append(occurrence);
-        }row.append(lane);canvas.append(row);
+        }row.append(lane,header);canvas.append(row);
       });const playhead=make('div','timeline-playhead');canvas.append(playhead);
     }
     for(const row of canvas.children){if(!row.dataset.trackId)continue;const observation=snapshot.runtime?.tracks.find(t=>t.trackId===row.dataset.trackId),authority=observation?.authority;
@@ -104,7 +105,7 @@ export function mountTimeline({doc,win,state,choose,edit,placementEdit,transport
       row.classList.toggle('session-override',authority==='session');const output=row.querySelector('.timeline-authority');output.textContent=authority==='session'?(observation.activeSourceId?'Session override':'Session silence'):authority==='arrangement'?(observation.activeSourceId?'Arrangement':'Arrangement gap'):'Unavailable';if(observation?.pendingAction)output.textContent+=` / pending ${observation.pendingAction}`;output.title=output.textContent;
       const lane=row.querySelector('.timeline-lane');for(const item of lane.children){if(item.dataset.placementId)item.classList.toggle('playing',!!snapshot.state.playing&&observation?.activePlacementId===item.dataset.placementId&&observation.activeSourceId===document.placements.find(p=>p.id===item.dataset.placementId)?.sourceId);if(item.dataset.preparedId)item.classList.toggle('playing',!!snapshot.state.playing&&observation?.activePlacementId===item.dataset.preparedId);}
     }
-    const playhead=canvas.querySelector('.timeline-playhead');if(playhead){const value=snapshot.state.position,frames=BigInt(value??0),beat=Number(frames*1000000n/48000n)/1000000*snapshot.document.tempo/60;playhead.style.left=`${176+beat*scale}px`;}
+    const playhead=canvas.querySelector('.timeline-playhead');if(playhead){const value=snapshot.state.position,frames=BigInt(value??0),beat=Number(frames*1000000n/48000n)/1000000*snapshot.document.tempo/60;playhead.style.left=`${beat*scale}px`;}
   }
   canvas.addEventListener('pointerdown',guard(event=>{
     if(event.button!==0||event.target.closest?.('.timeline-header,.timeline-ruler'))return;
@@ -130,8 +131,9 @@ export function mountTimeline({doc,win,state,choose,edit,placementEdit,transport
   canvas.addEventListener('pointercancel',cancel);canvas.addEventListener('lostpointercapture',cancel);
   const escape=event=>{if(event.key==='Escape')cancel();if(!event.defaultPrevented&&(event.key==='Delete'||event.key==='Backspace')&&!root.hidden&&!$('arrangement-workspace').hidden&&event.target.closest?.('#arrangement-workspace')&&!event.target.closest?.('input,select,textarea,button,[contenteditable],[role]')){const p=state().selection?.occurrence?.placementId;if(p){event.preventDefault();guard(()=>edit({kind:'placementDelete',placementId:p}))();}}};doc.addEventListener('keydown',escape);win?.addEventListener('blur',cancel);
   scroll.addEventListener('scroll',()=>render());
+  const resizeObserver=win?.ResizeObserver?new win.ResizeObserver(()=>{key='';render();}):null;resizeObserver?.observe(scroll);
   for(const [id,factor] of [['timeline-zoom-in',1.5],['timeline-zoom-out',1/1.5]])$(id).addEventListener('click',()=>{cancel();scale=Math.max(1,Math.min(192,scale*factor));key='';render();});
   $('timeline-fit').addEventListener('click',()=>{cancel();scale=Math.max(1,Math.min(192,((scroll.clientWidth||1000)-176)/last.document.lengthBeats));scroll.scrollLeft=0;key='';render();});
   for(const [id,key]of [['song-loop-start','loopStartBeats'],['song-loop-end','loopEndBeats']])$(id).addEventListener('change',guard(()=>{if($(id).value===''||!Number.isFinite(Number($(id).value)))throw Error('Enter a valid song loop beat.');return transportRange({[key]:Number($(id).value)});}));
-  return{render,cancel,getRange,dispose(){doc.removeEventListener('keydown',escape);win?.removeEventListener('blur',cancel);}};
+  return{render,cancel,getRange,dispose(){resizeObserver?.disconnect();doc.removeEventListener('keydown',escape);win?.removeEventListener('blur',cancel);}};
 }
diff --git a/apps/ultra/ui/alive-workspace.mjs b/apps/ultra/ui/alive-workspace.mjs
index dcf4af5..df7cbdd 100644
--- a/apps/ultra/ui/alive-workspace.mjs
+++ b/apps/ultra/ui/alive-workspace.mjs
@@ -1,13 +1,13 @@
 // Workspace navigation owns only presentation. Native state and editor nodes stay mounted.
 export function mountWorkspace({doc,win,onNavigate=()=>{}}){
   const $=id=>doc.getElementById(id);
-  let view='session',detail='clip',expanded=true,browser=true,height=220,resize=null;
+  let view='session',detail='clip',previousDetail='clip',expanded=true,browser=true,height=220,resize=null,browserWidth=220,browserResize=null;
   const handle=$('detail-resizer'),shell=$('workspace-shell');
   const parked=new Map();
-  const detailRoot=()=>$(detail==='clip'?'clip-detail':'device-detail');
+  const detailRoot=()=>$(detail==='clip'?'clip-detail':detail==='master'?'master-detail':'device-detail');
   const maxHeight=()=>Math.max(160,shell.clientHeight-$('schedule-controls').getBoundingClientRect().height-($('detail-panel').getBoundingClientRect().height-$('detail-content').getBoundingClientRect().height)-150);
   function park(root){const element=doc.activeElement;if(root.contains?.(element)&&element.matches?.('input,select,textarea'))parked.set(element,{root,value:element.value,visible:false,changed:parked.get(element)?.changed??false});}
-  function restore(root){for(const [element,state]of parked){if(element.isConnected===false){parked.delete(element);continue;}if(state.root!==root||state.visible)continue;element.value=state.value;state.visible=true;if(!doc.activeElement?.closest?.('input,select,textarea,button,[contenteditable]'))element.focus();}}
+  function restore(root){for(const [element,state]of parked){if(element.isConnected===false){parked.delete(element);continue;}if(state.root!==root||state.visible||element.closest?.('[hidden]'))continue;element.value=state.value;state.visible=true;if(!doc.activeElement?.closest?.('input,select,textarea,button,[contenteditable]'))element.focus();}}
   // display:none blurs inputs and emits change. Keep that navigation local,
   // then publish a suppressed change only on a later user change or blur.
   const change=event=>{const state=parked.get(event.target);if(!state)return;if(!state.visible){state.changed=true;event.stopImmediatePropagation();}else parked.delete(event.target);};
@@ -16,17 +16,19 @@ export function mountWorkspace({doc,win,onNavigate=()=>{}}){
   function paint(){
     $('session-workspace').hidden=view!=='session';$('arrangement-workspace').hidden=view!=='arrangement';
     for(const name of ['session','arrangement'])$('view-'+name).setAttribute('aria-pressed',String(view===name));
-    $('workspace-browser').hidden=!browser;$('toggle-browser').setAttribute('aria-expanded',String(browser));
+    $('workspace-browser').hidden=!browser;$('browser-resizer').hidden=!browser;$('toggle-browser').setAttribute('aria-expanded',String(browser));$('timeline-inspector').hidden=view!=='arrangement';
+    shell.style.setProperty('--browser-width',`${browserWidth}px`);$('browser-resizer').setAttribute('aria-valuenow',browserWidth);
     $('detail-content').hidden=!expanded;handle.hidden=!expanded;
     $('toggle-detail').setAttribute('aria-expanded',String(expanded));
     for(const name of ['clip','devices']){$('detail-'+name).setAttribute('aria-pressed',String(detail===name));$(name==='clip'?'clip-detail':'device-detail').hidden=detail!==name;}
+    $('master-detail').hidden=detail!=='master';for(const id of ['master-select-session','master-select-arrangement'])$(id).setAttribute('aria-pressed',String(detail==='master'));
     shell.style.setProperty('--detail-height',`${height}px`);handle.setAttribute('aria-valuenow',height);handle.setAttribute('aria-valuemax',maxHeight());
     restore($(view+'-workspace'));
-    if(expanded)restore(detailRoot());
+    if(expanded){restore(detailRoot());if(view==='arrangement'&&detail==='clip')restore($('timeline-inspector'));}
   }
   function setHeight(value){height=Math.round(Math.max(160,Math.min(maxHeight(),value)));paint();}
   function cancelResize(){if(!resize)return;const old=resize;resize=null;setHeight(old.height);if(handle.hasPointerCapture?.(old.id))handle.releasePointerCapture(old.id);}
-  function navigate(name){cancelResize();if(name!==view){park($(view+'-workspace'));onNavigate(name);}view=name;paint();}
+  function navigate(name){cancelResize();const changed=name!==view;if(changed){park($(view+'-workspace'));if(view==='arrangement')park($('timeline-inspector'));}view=name;paint();if(changed)onNavigate(name);}
   for(const name of ['session','arrangement'])$('view-'+name).addEventListener('click',()=>navigate(name));
   // A pointer navigation must not blur an unfinished field and publish its change.
   for(const id of ['view-session','view-arrangement','toggle-browser','toggle-detail','detail-clip','detail-devices'])$(id).addEventListener('pointerdown',event=>event.preventDefault());
@@ -38,13 +40,22 @@ export function mountWorkspace({doc,win,onNavigate=()=>{}}){
   handle.addEventListener('pointerup',event=>{if(resize?.id!==event.pointerId)return;resize=null;handle.releasePointerCapture?.(event.pointerId);});
   handle.addEventListener('pointercancel',cancelResize);handle.addEventListener('lostpointercapture',cancelResize);
   handle.addEventListener('keydown',event=>{if(['ArrowUp','ArrowDown','Home','End'].includes(event.key)){event.preventDefault();setHeight(event.key==='Home'?160:event.key==='End'?maxHeight():height+(event.key==='ArrowUp'?1:-1)*(event.shiftKey?50:20));}});
+  const browserHandle=$('browser-resizer');
+  function setBrowserWidth(value){browserWidth=Math.round(Math.max(180,Math.min(280,value)));paint();}
+  function cancelBrowserResize(){if(!browserResize)return;const old=browserResize;browserResize=null;setBrowserWidth(old.width);if(browserHandle.hasPointerCapture?.(old.id))browserHandle.releasePointerCapture(old.id);}
+  browserHandle.addEventListener('pointerdown',event=>{if(event.button!==0)return;browserResize={id:event.pointerId,x:event.clientX,width:browserWidth};browserHandle.setPointerCapture?.(event.pointerId);event.preventDefault();});
+  browserHandle.addEventListener('pointermove',event=>{if(browserResize?.id===event.pointerId)setBrowserWidth(browserResize.width+event.clientX-browserResize.x);});
+  browserHandle.addEventListener('pointerup',event=>{if(browserResize?.id!==event.pointerId)return;browserResize=null;browserHandle.releasePointerCapture?.(event.pointerId);});
+  browserHandle.addEventListener('pointercancel',cancelBrowserResize);browserHandle.addEventListener('lostpointercapture',cancelBrowserResize);
+  browserHandle.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();setBrowserWidth(event.key==='Home'?180:event.key==='End'?280:browserWidth+(event.key==='ArrowRight'?1:-1)*(event.shiftKey?20:5));}});
+  $('track-width').addEventListener('input',event=>shell.style.setProperty('--track-width',`${event.target.value}px`));
   const interactive='input,select,textarea,button,summary,a,[contenteditable],[role]';
   const keydown=event=>{
-    if(event.key==='Escape'){cancelResize();return;}
+    if(event.key==='Escape'){cancelResize();cancelBrowserResize();return;}
     if(event.defaultPrevented||event.key!=='Tab'||event.shiftKey||event.ctrlKey||event.altKey||event.metaKey||event.target?.closest?.(interactive))return;
     event.preventDefault();navigate(view==='session'?'arrangement':'session');
     $(view+'-workspace').focus();
   };
   const fit=()=>{cancelResize();setHeight(height);};doc.addEventListener('keydown',keydown);win?.addEventListener('blur',cancelResize);win?.addEventListener('resize',fit);paint();
-  return{preserves:element=>parked.has(element),openClip(){if(expanded&&detail!=='clip')park(detailRoot());detail='clip';expanded=true;paint();},dispose(){doc.removeEventListener('keydown',keydown);doc.removeEventListener('change',change,true);doc.removeEventListener('blur',blur,true);parked.clear();win?.removeEventListener('blur',cancelResize);win?.removeEventListener('resize',fit);}};
+  return{preserves:element=>parked.has(element),openMaster(){if(detail!=='master'){previousDetail=detail;if(expanded)park(detailRoot());}detail='master';expanded=true;paint();},returnMusic(){if(detail==='master'){park(detailRoot());detail=previousDetail;expanded=true;paint();}},openClip(){if(expanded&&detail!=='clip')park(detailRoot());detail='clip';expanded=true;paint();},dispose(){doc.removeEventListener('keydown',keydown);doc.removeEventListener('change',change,true);doc.removeEventListener('blur',blur,true);parked.clear();win?.removeEventListener('blur',cancelResize);win?.removeEventListener('resize',fit);}};
 }
diff --git a/apps/ultra/ui/alive.css b/apps/ultra/ui/alive.css
index de4daa1..f95533d 100644
--- a/apps/ultra/ui/alive.css
+++ b/apps/ultra/ui/alive.css
@@ -55,3 +55,37 @@ footer{flex-shrink:0;background:var(--chrome);border-top:1px solid var(--line);p
 .clip-controls select{height:26px;min-height:26px;line-height:18px;padding:1px 5px;max-width:180px}.source-scope{font-size:10px;color:var(--muted)}
 #timeline-scroll{scrollbar-color:#777 var(--chrome);scrollbar-width:thin}
 .timeline-prepared{position:absolute;top:2px;height:59px;border:1px dotted #88c5c7;color:#88c5c7;font-size:9px;overflow:hidden;white-space:nowrap;pointer-events:none;padding:0 3px;background:#88c5c70b}.timeline-prepared.playing{border-style:solid}
+
+/* Compact workspace and the shared native output owner. */
+:root{--slot-height:24px;--track-head:28px;--track-width:128px;--browser-width:220px}
+.document-bar{min-height:25px;height:25px;padding:1px 8px;gap:8px}.document-bar nav button{min-height:21px;padding:1px 5px}
+.transport{min-height:27px;height:27px;padding:1px 8px;gap:6px;flex-wrap:nowrap}.transport button,.transport input{min-height:21px;height:21px;padding-top:1px;padding-bottom:1px}
+.workspace-tools{min-height:27px;height:27px;padding:1px 8px;gap:6px}.workspace-tools button{min-height:22px;padding:1px 5px}.track-width-label{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--muted)}.track-width-label input{width:65px;min-height:16px}
+#workspace-browser{flex-basis:var(--browser-width);padding:10px}#browser-resizer{flex:0 0 5px;cursor:ew-resize;background:#252525;touch-action:none}#browser-resizer:focus-visible{outline:2px solid var(--selection);outline-offset:-2px}
+.track-name{flex-direction:row;align-items:center;padding:3px 7px}.track-name small{display:none}.track-name>span{line-height:18px;min-height:18px}
+.scene-column{flex-basis:128px;width:128px;display:flex;flex-direction:column}.master-heading{height:var(--track-head);min-height:var(--track-head);width:100%;border:0;border-radius:0;border-bottom:1px solid var(--line);background:#756039;color:#fff;text-align:left;padding:3px 8px;font-weight:600}
+#master-session{display:flex;flex:1;min-height:0;padding-top:50px}.session-board:has(.track-return) #master-session{padding-top:75px}
+.master-controls{display:flex;flex-direction:column;gap:3px;min-width:0;width:100%;padding:6px;background:#2b2b2b;border-top:1px solid var(--line)}.master-controls input.master-number{width:100%;height:23px}.master-db,.master-state{font-size:10px;font-variant-numeric:tabular-nums}.master-state{overflow-wrap:anywhere;color:var(--muted)}.master-state.error{color:var(--error)}.master-controls button{min-height:22px;padding:2px 4px;font-size:10px}.master-fader-area{display:flex;justify-content:center;gap:10px;min-height:65px;flex:1}.master-fader,.track input.gain-fader{writing-mode:vertical-lr;direction:rtl;width:24px;min-height:65px;flex:none;cursor:ns-resize;appearance:none;-webkit-appearance:none;background:linear-gradient(to right,transparent 10px,#777 10px,#777 13px,transparent 13px);border:0;touch-action:none}.master-fader::-webkit-slider-thumb,.track input.gain-fader::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:8px;background:#c9c9c4;border:1px solid #171717;border-radius:0}.master-fader::-moz-range-thumb,.track input.gain-fader::-moz-range-thumb{width:22px;height:8px;background:#c9c9c4;border:1px solid #171717;border-radius:0}.master-meter-area{display:flex;flex-direction:column;min-height:0;gap:2px}.master-bars{display:flex;align-items:flex-end;gap:2px;flex:1;min-height:55px;width:18px;border:1px solid #555;background:#171717;padding:2px}.master-bars i{display:block;width:5px;max-height:100%;background:var(--stereo)}.master-meter-area output{font-size:9px;white-space:nowrap}.scene-history{flex:none;max-height:100px;overflow:auto}
+#master-detail{padding:8px 12px;font-size:11px}#master-detail h2{font-size:12px;margin:0 0 5px}#master-detail p{margin:4px 0}
+.timeline-header{left:auto;right:0;border-right:0;border-left:1px solid #686868}.timeline-ruler{left:0}#master-arrangement-lane{display:flex;flex:none;min-height:90px;background:#2b2b2b;border-top:1px solid var(--line)}#master-arrangement-lane .master-heading{width:128px;height:auto;min-height:0;flex:none}#master-arrangement{flex:1;min-width:0}#master-arrangement .master-controls{height:100%;display:grid;grid-template-columns:65px 75px minmax(120px,1fr) 60px 105px minmax(150px,2fr);align-items:center;border:0}#master-arrangement .master-fader-area{height:80px;min-height:0}#master-arrangement .master-fader{height:72px;min-height:0}#master-arrangement .master-bars{min-height:40px}
+@media(max-width:1300px){#workspace-browser{flex-basis:var(--browser-width)}}
+.master-controls input.master-fader{width:24px;min-width:24px}.master-meter-area{min-width:70px}.master-state{line-height:1.15}.scene-column .scene-history{position:absolute;top:calc(var(--track-head) + 4 * var(--slot-height));left:0;right:0;max-height:none;overflow:visible;z-index:3}.scene-column .scene-history[open]{background:var(--chrome);border:1px solid var(--line)}
+#master-session{padding-bottom:22px}.master-fader-area{gap:2px;min-height:55px}.master-controls input.master-fader{min-height:55px}.master-meter-area{min-width:45px}.master-meter-area output{font-size:8px}.master-marks{position:relative;width:23px;min-height:40px;font-size:9px;color:var(--muted)}.master-marks span{position:absolute;left:0}.master-marks span:first-child{top:0}.master-marks span:nth-child(2){bottom:25%}.master-marks span:last-child{bottom:0}.master-actions{display:flex;gap:2px}.master-actions button{flex:1;min-width:0;font-size:9px;padding:1px}#master-arrangement .master-actions{display:flex}#master-arrangement .master-controls{grid-template-columns:65px 75px minmax(120px,1fr) 160px minmax(150px,2fr)}
+.master-meter-area .master-bars{height:0;min-height:25px}.master-controls button{min-height:18px}.master-controls .master-state{font-size:9px}.master-meter-area output{line-height:9px}
+.master-actions button svg{width:10px;height:10px;margin-right:2px;stroke-width:1.4}
+.master-heading[aria-pressed=true]{background:#756039;box-shadow:inset 0 -3px var(--selection)}
+/* Align both mixer faces; detailed output state remains in Master detail. */
+.track-mixer{padding-left:6px;padding-right:6px}.track-gain{gap:2px}.track-gain input{width:80px}
+.track-inspector{position:relative}.track-inspector[open] .track-actions{position:absolute;left:0;right:0;bottom:100%;padding:6px 8px;background:var(--chrome);border:1px solid var(--line);z-index:5}
+#master-session .master-controls{display:grid;grid-template-rows:23px minmax(67px,1fr) 25px;gap:5px;padding:7px 6px;min-height:140px}
+.master-gain-top{display:flex;align-items:center;gap:3px;min-width:0}.master-controls .master-gain-top input.master-number{width:65px;flex:0 0 65px}.master-gain-top .master-db{white-space:nowrap}
+#master-session .master-fader-area{height:100%;min-height:0}.master-controls input.master-fader{height:100%;min-height:0}.master-meter-area{height:100%;gap:0}.master-meter-area .master-bars{min-height:0}
+#master-session .master-state{position:absolute;left:6px;right:6px;top:calc(var(--track-head) + 4 * var(--slot-height) + 24px);max-height:48px;overflow:hidden}
+#master-arrangement-lane{justify-content:flex-end}#master-arrangement-lane .master-heading{width:80px}#master-arrangement{flex:0 0 336px;width:336px}
+#master-arrangement .master-controls{display:grid;grid-template-columns:112px 96px 1fr;grid-template-rows:minmax(0,1fr) 20px;gap:2px;height:100%;padding:4px 6px}
+#master-arrangement .master-gain-top{grid-column:1;grid-row:1}#master-arrangement .master-fader-area{grid-column:2;grid-row:1;height:60px;min-height:0}#master-arrangement .master-fader{height:60px;min-height:0}#master-arrangement .master-actions{grid-column:3;grid-row:1}#master-arrangement .master-state{grid-column:1 / -1;grid-row:2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
+#master-session .master-state{max-height:25px}.session-board:has(.track-return) #master-session .master-state{max-height:48px}
+/* Keep working values readable while preserving the common rail baseline. */
+.track-width-label,.master-db,.master-state,.master-marks,.master-controls button,.master-meter-area output,.track-meter output{font-size:11px}
+.master-controls .master-state{font-size:11px;line-height:12px}.master-meter-area{min-width:58px}.master-meter-area output{font-size:11px;line-height:12px}.track-meter output{font-size:11px;line-height:19px}.master-actions{gap:1px}.master-actions button{font-size:11px;padding:1px 0}
+#master-arrangement-lane .master-heading{width:64px}#master-arrangement{flex-basis:360px;width:360px}#master-arrangement .master-controls{grid-template-columns:102px 112px 1fr}.master-marks{flex:0 0 23px}
diff --git a/apps/ultra/ui/alive.html b/apps/ultra/ui/alive.html
index 1f11521..ff470ea 100644
--- a/apps/ultra/ui/alive.html
+++ b/apps/ultra/ui/alive.html
@@ -6,20 +6,20 @@
 <button id="start" class="primary" aria-label="Start transport"><svg viewBox="0 0 18 18" aria-hidden="true"><path d="M5 3 14 9 5 15Z"/></svg>Start</button><button id="stop" aria-label="Stop transport"><svg viewBox="0 0 18 18" aria-hidden="true"><path d="M4 4H14V14H4Z"/></svg>Stop</button>
 <label>Tempo <input id="tempo" aria-label="Tempo" type="number" min="30" max="240" step="1"><span class="muted">BPM</span></label><label>Transport length <input id="length" aria-label="Transport length beats" type="number" min="0.015625" max="256" step="1"><span class="muted">beats</span></label><label><input id="loop" aria-label="Loop session" type="checkbox">Loop</label>
 <output id="position" aria-label="Transport position">0.000 beats</output><label class="seek">Seek <input id="seek" type="number" value="0" min="0" step="0.25" aria-label="Seek beat"></label><button id="seek-go" aria-label="Seek transport">Go</button>
-<div class="master"><span>Master</span><div id="master-meter" class="stereo-meter" aria-label="Master stereo peak"><i></i><i></i></div><output id="master-peak" aria-label="Master peak">0 / 0</output></div>
+
 </section>
-<div class="workspace-tools"><button id="toggle-browser" aria-label="Toggle browser" aria-controls="workspace-browser">Browser</button><nav aria-label="Workspaces" title="Tab changes view outside controls"><button id="view-session" aria-label="Session workspace">Session</button><button id="view-arrangement" aria-label="Arrangement workspace">Arrangement</button></nav><span id="workspace-authority" class="workspace-authority">Session playback</span><button id="return-all" hidden>Return all</button></div>
+<div class="workspace-tools"><button id="toggle-browser" aria-label="Toggle browser" aria-controls="workspace-browser">Browser</button><nav aria-label="Workspaces" title="Tab changes view outside controls"><button id="view-session" aria-label="Session workspace">Session</button><button id="view-arrangement" aria-label="Arrangement workspace">Arrangement</button></nav><label class="track-width-label">Track width <input id="track-width" type="range" min="112" max="180" value="128" aria-label="Track column width"></label><span id="workspace-authority" class="workspace-authority">Session playback</span><button id="return-all" hidden>Return all</button></div>
 <main id="workspace-shell">
-<aside id="workspace-browser" aria-label="Device and file browser"><h2>Browser</h2><button id="add-track" aria-label="Add instrument track" title="Choose a saved .ultra instrument in the native file picker">Add instrument...</button><button id="add-effect" aria-label="Add effect" title="Choose a saved .ultra effect for the selected track">Add effect...</button><details><summary>Supported media</summary><p>MIDI clip banks and saved Ultra instruments and effects. Choose a .ultra device in the native file picker. MIDI Arrangement requires an admitted v4 project. Use Open for the MIDI Arrangement example. Audio clips are unavailable.</p></details></aside>
+<aside id="workspace-browser" aria-label="Device and file browser"><h2>Browser</h2><button id="add-track" aria-label="Add instrument track" title="Choose a saved .ultra instrument in the native file picker">Add instrument...</button><button id="add-effect" aria-label="Add effect" title="Choose a saved .ultra effect for the selected track">Add effect...</button><details><summary>Supported media</summary><p>MIDI clip banks and saved Ultra instruments and effects. Choose a .ultra device in the native file picker. MIDI Arrangement requires an admitted v4 project. Use Open for the MIDI Arrangement example. Audio clips are unavailable.</p></details></aside><div id="browser-resizer" role="separator" tabindex="0" aria-label="Resize browser" aria-orientation="vertical" aria-valuemin="180" aria-valuemax="280" aria-valuenow="220"></div>
 <div class="workspace-column">
 <section id="session-workspace" class="workspace" aria-label="Session workspace" tabindex="-1"><div class="session-board">
 <p id="scene-help" class="muted" hidden>Launches this prepared row. Empty slots stop their tracks.</p>
-<section id="tracks" aria-label="Instrument tracks"></section><aside class="scene-column"><h2>Scenes</h2><section id="scene-controls" aria-label="Prepared scene rows" hidden></section><details id="scene-history" class="scene-history" hidden><summary>Scene receipts</summary><div id="scene-receipts"></div></details></aside></div></section>
-<section id="arrangement-workspace" class="workspace" aria-label="Arrangement workspace" tabindex="-1" hidden><div id="arrangement-placeholder" class="unavailable"><h1>Arrangement</h1><p id="arrangement-unavailable">Arrangement playback and timeline editing are unavailable in this version.</p><p class="muted">Session clip banks remain active. Switch to Session to launch or edit clips.</p></div><div id="timeline" hidden><div class="timeline-tools"><output id="timeline-range">Select a range</output><span class="muted">Drag a blank lane to choose a range</span><button id="timeline-zoom-out" aria-label="Zoom timeline out">-</button><button id="timeline-zoom-in" aria-label="Zoom timeline in">+</button><button id="timeline-fit" aria-label="Fit timeline">Fit</button><label>Loop from <input id="song-loop-start" aria-label="Song loop start" type="number" min="0" step="0.25"></label><label>to <input id="song-loop-end" aria-label="Song loop end" type="number" min="0" step="0.25"></label><details class="return-receipt"><summary>Return receipts</summary><output id="return-receipts"></output></details></div><div id="timeline-inspector" class="timeline-inspector"></div><div id="timeline-scroll"><div id="timeline-canvas"></div></div></div></section>
+<section id="tracks" aria-label="Instrument tracks"></section><aside class="scene-column"><button id="master-select-session" class="master-heading" aria-label="Select Master output">Master</button><section id="scene-controls" aria-label="Prepared scene rows" hidden></section><div id="master-session"></div><details id="scene-history" class="scene-history" hidden><summary>Scene receipts</summary><div id="scene-receipts"></div></details></aside></div></section>
+<section id="arrangement-workspace" class="workspace" aria-label="Arrangement workspace" tabindex="-1" hidden><div id="arrangement-placeholder" class="unavailable"><h1>Arrangement</h1><p id="arrangement-unavailable">Arrangement playback and timeline editing are unavailable in this version.</p><p class="muted">Session clip banks remain active. Switch to Session to launch or edit clips.</p></div><div id="timeline" hidden><div class="timeline-tools"><output id="timeline-range">Select a range</output><span class="muted">Drag a blank lane to choose a range</span><button id="timeline-zoom-out" aria-label="Zoom timeline out">-</button><button id="timeline-zoom-in" aria-label="Zoom timeline in">+</button><button id="timeline-fit" aria-label="Fit timeline">Fit</button><label>Loop from <input id="song-loop-start" aria-label="Song loop start" type="number" min="0" step="0.25"></label><label>to <input id="song-loop-end" aria-label="Song loop end" type="number" min="0" step="0.25"></label><details class="return-receipt"><summary>Return receipts</summary><output id="return-receipts"></output></details></div><div id="timeline-scroll"><div id="timeline-canvas"></div></div><div id="master-arrangement-lane"><button id="master-select-arrangement" class="master-heading" aria-label="Select Master output in Arrangement">Master</button><div id="master-arrangement"></div></div></div></section>
 <div id="schedule-controls" class="schedule-bar"><span id="draft-status">Prepared schedule</span><span class="muted">Prepare / Apply requires stopped transport.</span><button id="undo" aria-label="Undo pending edit">Undo pending edit</button><button id="redo" aria-label="Redo pending edit">Redo pending edit</button><button id="apply" class="primary" aria-label="Prepare / Apply">Prepare / Apply</button><button id="discard" aria-label="Discard edits">Discard edits</button></div>
-<section id="detail-panel" aria-label="Selected track detail"><div id="detail-resizer" role="separator" tabindex="0" aria-label="Resize detail area" aria-orientation="horizontal" aria-valuemin="160" aria-valuemax="570"></div><header id="detail-tabs" class="detail-tabs"><button id="detail-clip" aria-label="Clip detail">Clip</button><button id="detail-devices" aria-label="Devices detail">Devices</button><span id="clip-bank-notice" class="muted"></span><button id="toggle-detail" aria-label="Toggle detail" aria-controls="detail-content">Detail</button></header><div id="detail-content"><div id="device-detail" hidden><section class="chain-section" aria-labelledby="chain-title"><header class="section-heading"><h2 id="chain-title">Selected track chain</h2><span class="muted">Instrument &rarr; effects &rarr; mixer. Selection does not start playback.</span></header><div id="chain"></div><p id="chain-status" class="muted"></p></section>
+<section id="detail-panel" aria-label="Selected track detail"><div id="detail-resizer" role="separator" tabindex="0" aria-label="Resize detail area" aria-orientation="horizontal" aria-valuemin="160" aria-valuemax="570"></div><header id="detail-tabs" class="detail-tabs"><button id="detail-clip" aria-label="Clip detail">Clip</button><button id="detail-devices" aria-label="Devices detail">Devices</button><span id="clip-bank-notice" class="muted"></span><button id="toggle-detail" aria-label="Toggle detail" aria-controls="detail-content">Detail</button></header><div id="detail-content"><div id="master-detail" hidden><h2>Master output</h2><p id="master-detail-status"></p><p>Digital overload indicates a post-gain sample above full scale. It does not measure physical clipping.</p></div><div id="device-detail" hidden><section class="chain-section" aria-labelledby="chain-title"><header class="section-heading"><h2 id="chain-title">Selected track chain</h2><span class="muted">Instrument &rarr; effects &rarr; mixer. Selection does not start playback.</span></header><div id="chain"></div><p id="chain-status" class="muted"></p></section>
 <section class="device-section" aria-labelledby="device-title"><header class="section-heading"><h2 id="device-title">Device</h2><span id="device-path" class="muted"></span><span class="muted">Saved base / prepared effective</span><button id="edit-device" aria-label="Edit selected device in Ultra">Edit in Ultra</button></header><div id="parameters"></div></section>
-</div><div id="clip-detail"><div id="clip-controls" class="clip-controls" aria-label="Selected clip controls"></div>
+</div><div id="clip-detail"><div id="timeline-inspector" class="timeline-inspector" hidden></div><div id="clip-controls" class="clip-controls" aria-label="Selected clip controls"></div>
 <section class="clip-section" aria-labelledby="clip-title"><header class="section-heading"><h1 id="clip-title">Clip</h1><span class="muted">Clip length is independent. Global loop wrap resets active phases.</span><button id="add-note" aria-label="Add note">Add note</button></header><div class="clip-editors"><div class="piano-area"><svg id="piano-roll" aria-label="Selected clip piano roll" aria-describedby="piano-help" role="group" tabindex="0"></svg><p id="piano-help" class="muted">1/16 grid. Double-click to add; drag to move or resize the right edge. Arrows move; Shift + Left/Right resizes. Delete removes; Escape cancels. Apply begins a new pending-edit history.</p><label class="note-velocity">Selected velocity <input id="note-velocity" type="range" min="1" max="127" step="1" aria-label="Selected note velocity"><output id="velocity-value"></output></label></div><details class="note-table"><summary>Note inspector</summary><table><thead><tr><th>Beat</th><th>Pitch</th><th>Duration</th><th>Velocity</th><th><span class="sr-only">Remove</span></th></tr></thead><tbody id="notes"></tbody></table></details></div></section>
 <details class="automation-section" aria-label="Selected clip automation"><summary>Automation inspector</summary><header class="section-heading"><h2>Automation</h2><span class="muted">Step / hold. Prepared lanes own effective values; draft lanes apply after Prepare / Apply.</span></header><div class="automation-target"><label for="automation-target">Target</label><select id="automation-target" aria-label="Automation target"></select><button id="add-lane" aria-label="Add automation lane">Add lane</button></div><div id="lanes"></div></details></div></div></section></div>
 </main>
diff --git a/apps/ultra/ui/alive.mjs b/apps/ultra/ui/alive.mjs
index a80dde3..3f42128 100644
--- a/apps/ultra/ui/alive.mjs
+++ b/apps/ultra/ui/alive.mjs
@@ -4,12 +4,13 @@ import {mountAudioSettings} from './audio-settings.mjs';
 import {mountWorkspace} from './alive-workspace.mjs';
 import {workspaceMusicEdit} from './alive-workspace-edits.mjs';
 import {mountTimeline,placementError} from './alive-timeline.mjs';
+import {createMasterProducer,nativeInteger as masterInteger} from './alive-master.mjs';
 
 export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke=win?.__TAURI__?.core?.invoke}={}){
   const $=id=>doc.getElementById(id),make=(tag,cls,text)=>{const e=doc.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;};
   const model=createAliveModel();let selected=0,selectedInstance=null,chainKey='',queue=Promise.resolve(),disposed=false,trackKey='',musicKey='',parameterKey='',laneKey='';
   let timeline,sourceSelection=null,activeEditSource=null;
-  const workspace=mountWorkspace({doc,win,onNavigate:()=>timeline?.cancel()});
+  const workspace=mountWorkspace({doc,win,onNavigate:()=>{timeline?.cancel();timeline?.render();}});
   let selectedSlots=new Map(),selectionToken=0,activeEditClip=null,selectedNote=null,gesture=null,preview=null,pianoGeometry=null,velocityCanceled=false,listRevision=0,scopeRevision=0,transportRequestKey='';
   const trackViews=[],chainViews=[],parameterViews=new Map(),diagnostics=new Map();let audioSettings;
   let operationText=$('notice').textContent,operationError=false,noticeOwner=null,refreshError='';
@@ -28,7 +29,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   }
   function svgElement(tag,attrs={}){const e=doc.createElementNS('http://www.w3.org/2000/svg',tag);for(const[key,value]of Object.entries(attrs))e.setAttribute(key,String(value));return e;}
   function icon(kind){
-    const paths={play:'M5 3 14 9 5 15Z',stop:'M4 4H14V14H4Z',browser:'M2 3H16V15H2ZM6 3V15M9 6H13M9 9H13',session:'M3 3H7V15H3ZM11 3H15V15H11Z',arrangement:'M3 4H15V7H3ZM3 11H11V14H3Z',clip:'M3 4H15V14H3ZM6 7H9M10 11H13',devices:'M2 5H7V13H2ZM11 5H16V13H11ZM7 9H11',detail:'M3 5 9 11 15 5M3 15H15',instrument:'M2 4H16V14H2ZM5 4V10M8 4V10M11 4V10M14 4V10',effect:'M3 5H15M3 13H15M6 2V8M12 10V16',file:'M4 2H11L15 6V16H4ZM10 2V7H15',save:'M3 2H13L16 5V16H3ZM6 2V7H12M6 11H13V16',edit:'M3 12 11 4 14 7 6 15H3ZM11 4 13 2 16 5 14 7',duplicate:'M6 6H15V15H6ZM3 11V3H11',remove:'M4 5H14M7 5V2H11V5M5 5 6 16H12L13 5',undo:'M7 3 3 7 7 11M3 7H11Q16 7 15 14',redo:'M11 3 15 7 11 11M15 7H7Q2 7 3 14'};
+    const paths={play:'M5 3 14 9 5 15Z',stop:'M4 4H14V14H4Z',browser:'M2 3H16V15H2ZM6 3V15M9 6H13M9 9H13',session:'M3 3H7V15H3ZM11 3H15V15H11Z',arrangement:'M3 4H15V7H3ZM3 11H11V14H3Z',clip:'M3 4H15V14H3ZM6 7H9M10 11H13',devices:'M2 5H7V13H2ZM11 5H16V13H11ZM7 9H11',detail:'M3 5 9 11 15 5M3 15H15',instrument:'M2 4H16V14H2ZM5 4V10M8 4V10M11 4V10M14 4V10',effect:'M3 5H15M3 13H15M6 2V8M12 10V16',file:'M4 2H11L15 6V16H4ZM10 2V7H15',save:'M3 2H13L16 5V16H3ZM6 2V7H12M6 11H13V16',edit:'M3 12 11 4 14 7 6 15H3ZM11 4 13 2 16 5 14 7',duplicate:'M6 6H15V15H6ZM3 11V3H11',remove:'M4 5H14M7 5V2H11V5M5 5 6 16H12L13 5',reset:'M14 7A5 5 0 1 0 14 11M14 3V7H10',undo:'M7 3 3 7 7 11M3 7H11Q16 7 15 14',redo:'M11 3 15 7 11 11M15 7H7Q2 7 3 14'};
     const svg=svgElement('svg',{viewBox:'0 0 18 18','aria-hidden':'true',focusable:'false'});svg.append(svgElement('path',{d:paths[kind]??paths.file}));return svg;
   }
   function decorate(button,kind,label,{only=false}={}){button.replaceChildren(icon(kind),make('span',only?'sr-only':'',label));button.title=button.getAttribute('aria-label')??label;}
@@ -36,6 +37,45 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   for(const[id,kind]of [['start','play'],['stop','stop']])decorate($(id),kind,id==='start'?'Start':'Stop',{only:true});
   function meter(element,left,right){const bars=element.children,axis=element.classList.contains('vertical-meter')?'height':'width';bars[0].style[axis]=`${Math.min(1,left)*100}%`;bars[1].style[axis]=`${Math.min(1,right)*100}%`;}
   function peak(left,right){return`${left.toFixed(3)} / ${right.toFixed(3)}`;}
+  let masterIntent=null,masterReceipt=null,masterStatus='',masterError=false,masterGeneration=null,masterPendingReset=false;
+  const masterProducer=createMasterProducer({invoke:(name,args)=>invoke(name,args),onStatus:status=>{
+    masterStatus=status.message;masterError=!!status.error;notice(status.message,masterError,'master');
+    if(status.pending&&status.kind==='gain')masterIntent={ordinal:status.ordinal,value:status.value};if(status.pending&&status.kind==='reset')masterPendingReset=true;
+    if(status.receipt){if(status.kind==='reset')masterPendingReset=false;if(status.kind==='gain')masterReceipt=status.receipt;if(status.kind==='gain'&&masterIntent?.ordinal===status.ordinal)masterIntent=null;}
+    if(status.error&&status.kind==='reset')masterPendingReset=false;if(status.error&&status.kind==='gain'&&masterIntent?.ordinal===status.ordinal)masterIntent={...masterIntent,refused:true};
+    renderMaster();
+  }});
+  function makeMaster(container){
+    const root=make('div','master-controls'),gain=make('input','master-fader'),number=make('input','master-number'),readout=make('output','master-db'),bars=make('div','master-bars'),left=make('i'),right=make('i'),leftText=make('output'),rightText=make('output'),state=make('output','master-state'),unity=make('button','','Unity'),reset=make('button','','Overload');
+    gain.type='range';gain.min='0';gain.max='4';gain.step='.01';gain.setAttribute('aria-label','Master gain fader');gain.setAttribute('aria-orientation','vertical');
+    number.type='number';number.min='0';number.max='4';number.step='.01';number.setAttribute('aria-label','Master gain');
+    leftText.setAttribute('aria-label','Master left peak');rightText.setAttribute('aria-label','Master right peak');readout.setAttribute('aria-label','Master gain decibels');state.setAttribute('aria-label','Master output status');unity.setAttribute('aria-label','Reset Master gain to unity');reset.setAttribute('aria-label','Reset Master digital overload');decorate(unity,'reset','Unity');decorate(reset,'reset','Overload');
+    bars.setAttribute('aria-label','Master stereo peak');bars.append(left,right);const meterArea=make('div','master-meter-area');meterArea.append(bars,leftText,rightText);const marks=make('div','master-marks');marks.append(make('span','','+12'),make('span','','0'),make('span','','-inf'));const faderArea=make('div','master-fader-area');faderArea.append(gain,marks,meterArea);const actions=make('div','master-actions');actions.append(unity,reset);const top=make('div','master-gain-top');top.append(number,readout);root.append(top,faderArea,actions,state);container.append(root);
+    gain.addEventListener('input',()=>masterProducer.gain(Number(gain.value)));gain.addEventListener('dblclick',()=>masterProducer.gain(1));
+    number.addEventListener('change',()=>{const value=Number(number.value);if(number.value===''||!Number.isFinite(value)||value<0||value>4){masterStatus='Master gain must be between 0 and 4.';masterError=true;notice(masterStatus,true,'master');renderMaster();return;}masterProducer.gain(value);});
+    unity.addEventListener('click',()=>masterProducer.gain(1));reset.addEventListener('click',()=>masterProducer.reset());
+    return{gain,number,readout,left,right,leftText,rightText,state,unity,reset};
+  }
+  const masterViews=[makeMaster($('master-session')),makeMaster($('master-arrangement'))];
+  function db(value){return value===0?'-inf':`${(20*Math.log10(value)).toFixed(1)} dB`;}
+  function renderMaster(){
+    if(!masterViews)return;const m=model.snapshot()?.master,available=!!m?.available,observation=m?.observation;
+    if(m&&masterReceipt&&masterInteger(m.acceptedSerial)>=masterInteger(masterReceipt.acceptedSerial))masterReceipt=null;
+    const display=masterIntent?.value??masterReceipt?.acceptedGain??m?.gain;
+    const applied=observation&&m&&!m.observationStale&&masterInteger(observation.appliedSerial)>=masterInteger(m.acceptedSerial);
+    const description=!m?'Master unavailable.':!available?`Master unavailable: ${m.unavailableReason??'native capability unavailable'}`:[`Saved target ${db(m.gain)}`,masterReceipt?`admitted ${db(masterReceipt.acceptedGain)} awaiting snapshot`:null,!observation?'observation unavailable':`${m.observationStale?'stale observation: ':''}${applied?'applied':'current'} ${db(observation.currentGain)}${!m.observationStale&&!applied?' (awaiting application)':''}${observation.observationStartFrame===observation.observationEndFrame?' (empty interval)':''}`,observation?.clipMask?`digital overload ${observation.clipMask===3?'L/R':observation.clipMask===1?'L':'R'}`:null,masterIntent?`${masterIntent.refused?'refused':'pending'} intent ${db(masterIntent.value)}`:null].filter(Boolean).join('; ')+'.';
+    for(const v of masterViews){
+      for(const input of [v.gain,v.number,v.unity,v.reset])input.disabled=!available;
+      if(display!==undefined&&doc.activeElement!==v.number&&!workspace.preserves(v.number))v.number.value=String(display);
+      if(display!==undefined&&doc.activeElement!==v.gain)v.gain.value=String(display);
+      v.readout.textContent=display===undefined?'Unavailable':db(display);v.gain.setAttribute('aria-valuetext',display===undefined?'Unavailable':db(display));
+      v.left.style.height=observation?`${Math.min(1,observation.peakLeft)*100}%`:'0%';v.right.style.height=observation?`${Math.min(1,observation.peakRight)*100}%`:'0%';
+      v.leftText.textContent=observation?`L ${observation.peakLeft.toFixed(3)}${observation.clipMask&1?' !':''}`:'L unavailable';v.rightText.textContent=observation?`R ${observation.peakRight.toFixed(3)}${observation.clipMask&2?' !':''}`:'R unavailable';
+      v.state.textContent=[masterStatus,description].filter(Boolean).join(' ');v.state.title=v.state.textContent;v.state.classList.toggle('error',masterError);
+    }
+    $('master-detail-status').textContent=[description,masterStatus].filter(Boolean).join(' ');
+  }
+  for(const id of ['master-select-session','master-select-arrangement']){$(id).addEventListener('pointerdown',event=>event.preventDefault());$(id).addEventListener('click',()=>workspace.openMaster());}
   function cancelGesture(){
     if(!gesture&&!preview)return;
     const old=gesture;if(old?.kind==='velocity')velocityCanceled=true;gesture=null;preview=null;
@@ -98,7 +138,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     try{snapshot=await current();}catch{}
     if(snapshot){applySnapshot(snapshot);if(result){trackKey=musicKey=parameterKey='';selectedNote=null;}render();}
     if(failed)throw failure;
-    if(result)notice(action.startsWith('save')?'Session saved.':'Session ready.');
+    if(result)notice(action.startsWith('save')?(result.notice?.includes('Saved in Alive session v5 format')?result.notice:'Session saved.'):'Session ready.');
   });}
   function transport(action){
     const intent={generation:generation(),preparationRevision:model.snapshot()?.preparationRevision},v4=isWorkspace(),beat=Number($('seek').value);
@@ -198,8 +238,11 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     return enqueue(async()=>{const result=await invoke(v4?'alive_workspace_action':'alive_clip_action',{action,...intent});await refresh();if(result){const observed=observedRequest(result);notice(requestText(observed,model.snapshot()),observed.status==='rejected');}});
   }
   function workspaceEdit(operation,selectResult=false){
-    const scope=scopeRevision,token=selectionToken;
-    return enqueue(async()=>{if(scope!==scopeRevision)throw Error('The source scope changed. Select it and try again.');const resolved=typeof operation==='function'?operation():operation;const result=await command('alive_workspace_edit',{operation:resolved});if(!model.applied(result.snapshot))return result;listRevision++;
+    const scope=scopeRevision,token=selectionToken,origin=generation();
+    const sourceTarget=typeof operation!=='function'&&['sourceRename','sourceLength','noteCreate'].includes(operation.kind)?{sourceId:operation.sourceId,trackId:model.document().tracks[selected].id,slotId:selectedClip()?.id,placementId:sourceSelection?.occurrence?.placementId}:null;
+    return enqueue(async()=>{if(scope!==scopeRevision||origin!==generation())throw Error('The source scope changed. Select it and try again.');
+      if(sourceTarget){const d=model.document(),actual=sourceTarget.placementId?d.placements.find(p=>p.id===sourceTarget.placementId&&p.trackId===sourceTarget.trackId)?.sourceId:sourceTarget.slotId?d.tracks.find(t=>t.id===sourceTarget.trackId)?.slots.find(s=>s?.id===sourceTarget.slotId)?.sourceId:d.sources.find(s=>s.id===sourceTarget.sourceId&&s.trackId===sourceTarget.trackId)?.id;if(actual!==sourceTarget.sourceId)throw Error('The originating source changed. Select it and try again.');}
+      const resolved=typeof operation==='function'?operation():operation;const result=await command('alive_workspace_edit',{operation:resolved});if(!model.applied(result.snapshot))return result;listRevision++;
       if(token===selectionToken){const a=result.affected,track=model.document().tracks.find(t=>t.id===a.trackId);if(selectResult&&track&&a.sourceId&&(a.placementId||!sourceSelection||resolved.kind==='sourceCreateMidi'))sourceSelection={trackId:a.trackId,sourceId:a.sourceId,occurrence:a.placementId?{kind:'placement',placementId:a.placementId}:null};if(sourceSelection?.occurrence?.placementId){const p=model.document().placements.find(p=>p.id===sourceSelection.occurrence.placementId);sourceSelection={...sourceSelection,sourceId:p?.sourceId??sourceSelection.sourceId,occurrence:p?sourceSelection.occurrence:null};}if(a.slotId&&track){const slot=track.slots.findIndex(s=>s?.id===a.slotId);if(slot>=0)selectedSlots.set(a.trackId,slot);}selectedNote=a.noteId??null;}
       musicKey=clipControlsKey=trackKey='';render();return result;});
   }
@@ -211,8 +254,9 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     });
   }
   function chooseSource(value){
-    cancelGesture();const index=model.document().tracks.findIndex(t=>t.id===value.trackId);if(index<0)return;
-    if(selected!==index)selectedInstance=null;selected=index;sourceSelection=value;selectionToken++;selectedNote=null;musicKey=clipControlsKey='';if(value.occurrence)workspace.openClip();render();
+    workspace.returnMusic();const index=model.document().tracks.findIndex(t=>t.id===value.trackId);if(index<0)return;
+    if(selected===index&&sourceSelection?.trackId===value.trackId&&sourceSelection?.sourceId===value.sourceId&&(sourceSelection?.occurrence?.placementId??null)===(value.occurrence?.placementId??null)){render();return;}
+    cancelGesture();if(selected!==index)selectedInstance=null;selected=index;sourceSelection=value;selectionToken++;selectedNote=null;musicKey=clipControlsKey='';if(value.occurrence)workspace.openClip();render();
   }
   function placementEdit(trackId,placementId,sourceId,changes){return workspaceEdit(()=>{
     const document=model.document(),p=document.placements.find(p=>p.id===placementId&&p.trackId===trackId);
@@ -243,7 +287,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   function buildSlots(bank,track,index){
     for(let slot=0;slot<4;slot++){
       const c=track.slots[slot],cell=make('div','clip-slot'),choose=make('button','clip-select',c?.name??''),launch=make('button','clip-launch'),status=make('small','sr-only');
-      choose.setAttribute('aria-label',`Select ${track.name} slot ${slot+1}`);choose.addEventListener('click',()=>{cancelGesture();selected=index;sourceSelection=null;selectedSlots.set(track.id,slot);selectionToken++;selectedNote=null;musicKey=clipControlsKey='';render();});
+      choose.setAttribute('aria-label',`Select ${track.name} slot ${slot+1}`);choose.addEventListener('click',()=>{workspace.returnMusic();if(selected===index&&!sourceSelection&&slotOf(track)===slot){render();return;}cancelGesture();selected=index;sourceSelection=null;selectedSlots.set(track.id,slot);selectionToken++;selectedNote=null;musicKey=clipControlsKey='';render();});
       choose.title=c?.name??`Empty slot ${slot+1}. Double-click to create a clip.`;
       choose.addEventListener('dblclick',guard(async()=>{
         const current=model.document().tracks[selected],key=`${track.id}:${slot}`;
@@ -284,8 +328,8 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
       if(!source){container.append(make('span','muted','Choose or create a source; drag a blank timeline range, then Place.'));return;}
       const references=document.tracks.reduce((n,t)=>n+t.slots.filter(s=>s?.sourceId===source.id).length,0)+document.placements.filter(p=>p.sourceId===source.id).length;
       container.append(make('span','source-scope',`${references} references. Notes and automation edit every reference.`));
-      const name=make('input');name.value=source.name;name.setAttribute('aria-label','MIDI source name');name.addEventListener('change',guard(()=>workspaceEdit({kind:'sourceRename',sourceId:source.id,name:name.value})));container.append(name);
-      const lengthLabel=make('label','','Source length');lengthLabel.append(numeric('MIDI source length',source.lengthBeats,{min:1/64,max:256},lengthBeats=>workspaceEdit({kind:'sourceLength',sourceId:source.id,lengthBeats})));container.append(lengthLabel);
+      const name=make('input');name.value=source.name;name.setAttribute('aria-label','MIDI source name');name.addEventListener('change',guard(()=>workspaceEdit({kind:'sourceRename',sourceId:source.id,name:name.value})));const nameLabel=make('label','','Source name');nameLabel.append(name);container.append(nameLabel);
+      const lengthLabel=make('label');lengthLabel.append(make('span','','Source length'),numeric('MIDI source length',source.lengthBeats,{min:1/64,max:256},lengthBeats=>workspaceEdit({kind:'sourceLength',sourceId:source.id,lengthBeats})),make('span','muted','beats'));container.append(lengthLabel);
       const destination=make('select');destination.setAttribute('aria-label','Assign source to Session slot');track.slots.forEach((s,i)=>{if(!s){const option=make('option','',`Slot ${i+1}`);option.value=String(i);destination.append(option);}});destination.value=destination.children[0]?.value??'';container.append(destination);
       button('Assign source to Session',()=>workspaceEdit({kind:'slotAssign',trackId:track.id,slot:Number(destination.value),sourceId:source.id,name:source.name,sourceOffset:{kind:'beats',value:0},loopEnabled:true})).disabled=!destination.children.length;
       return;
@@ -294,8 +338,8 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     if(!source){container.append(make('span','muted','Source unavailable'));return;}
     const references=document.tracks.reduce((n,t)=>n+t.slots.filter(s=>s?.sourceId===source.id).length,0)+document.placements.filter(p=>p.sourceId===source.id).length;
     container.append(make('span','source-scope',`${source.name} / shared source: ${references} references. Notes and automation edit every reference.`));
-    const name=make('input');name.value=slot.name;name.setAttribute('aria-label','Clip name');name.maxLength=64;name.addEventListener('change',guard(()=>clipEdit({kind:'rename',trackId:track.id,clipId:slot.id,sourceId:source.id,name:name.value})));container.append(name);
-    if(source.kind==='midi'){container.append(numeric('Selected clip length',source.lengthBeats,{min:1/64,max:256},lengthBeats=>workspaceEdit({kind:'sourceLength',sourceId:source.id,lengthBeats})));container.append(numeric('Slot source offset',slot.sourceOffset.value,{min:0,max:source.lengthBeats},value=>workspaceSlotEdit(track.id,slot.id,source.id,{sourceOffset:{kind:'beats',value}})));}
+    const name=make('input');name.value=slot.name;name.setAttribute('aria-label','Clip name');name.maxLength=64;name.addEventListener('change',guard(()=>clipEdit({kind:'rename',trackId:track.id,clipId:slot.id,sourceId:source.id,name:name.value})));const nameLabel=make('label','','Clip name');nameLabel.append(name);container.append(nameLabel);
+    if(source.kind==='midi'){const length=make('label'),offset=make('label');length.append(make('span','','Source length'),numeric('Selected clip length',source.lengthBeats,{min:1/64,max:256},lengthBeats=>workspaceEdit({kind:'sourceLength',sourceId:source.id,lengthBeats})),make('span','muted','beats'));offset.append(make('span','','Offset'),numeric('Slot source offset',slot.sourceOffset.value,{min:0,max:source.lengthBeats},value=>workspaceSlotEdit(track.id,slot.id,source.id,{sourceOffset:{kind:'beats',value}})),make('span','muted','beats'));container.append(length,offset);}
     const destination=make('select');destination.setAttribute('aria-label','Duplicate destination');track.slots.forEach((s,i)=>{if(!s){const option=make('option','',`Slot ${i+1}`);option.value=String(i);destination.append(option);}});destination.value=destination.children[0]?.value??'';container.append(destination);
     button('Duplicate clip',()=>workspaceEdit({kind:'slotDuplicate',trackId:track.id,slotId:slot.id,destinationSlot:Number(destination.value)})).disabled=!destination.children.length;
     button('Make source independent',()=>workspaceEdit({kind:'sourceIndependent',occurrence:{kind:'slot',trackId:track.id,slotId:slot.id}}));
@@ -318,7 +362,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     }
     const key=JSON.stringify([enabled,track.id,slotOf(track),clip?.id,clip?.name,clip?.lengthBeats,track.defaultClipId,track.slots?.map(c=>c?.id),snapshot.generation]);if(key===clipControlsKey)return;clipControlsKey=key;container.replaceChildren();
     const button=(text,fn)=>{const b=make('button','',text);b.setAttribute('aria-label',text);b.addEventListener('click',guard(fn));container.append(b);return b;};
-    if(snapshot.capabilities?.workspaceConversionAvailable){const b=button('Enable MIDI workspaces',()=>enqueue(async()=>{applySnapshot(await command('alive_enable_workspaces'));trackKey=musicKey=clipControlsKey='';render();notice('MIDI workspaces prepared. Arrangement starts at zero; Save writes v4.');}));b.disabled=!!snapshot.state.playing||model.pending();b.title='Explicit stopped conversion. Complete native admission can refuse this project while preserving current playback.';}
+    if(snapshot.capabilities?.workspaceConversionAvailable){const b=button('Enable MIDI workspaces',()=>enqueue(async()=>{applySnapshot(await command('alive_enable_workspaces'));trackKey=musicKey=clipControlsKey='';render();notice('MIDI workspaces prepared. Arrangement starts at zero.');}));b.disabled=!!snapshot.state.playing||model.pending();b.title='Explicit stopped conversion. Complete native admission can refuse this project while preserving current playback.';}
     if(!enabled){const b=button('Enable clip bank',()=>enqueue(async()=>{applySnapshot(await command('alive_enable_clips'));trackKey=musicKey=clipControlsKey='';render();}));b.disabled=!!snapshot.state.playing||model.pending();return;}
     const trackId=track.id,slot=slotOf(track);
     if(!clip){button('Create clip',()=>clipEdit({kind:'create',trackId,slot}));container.append(make('span','muted',`Empty slot ${slot+1}`));return;}
@@ -332,8 +376,8 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     $('tracks').replaceChildren();trackViews.length=0;slotViews=[];
     document.tracks.forEach((track,index)=>{
       const row=make('article','track'),name=make('button','track-name'),title=make('span','',`${index+1}  ${track.name}`),detail=make('small','',`${(track.notes?.length??0)} notes / stereo`),clip=make('button','clip-preview'),svg=svgElement('svg');
-      name.append(title,detail);name.setAttribute('aria-label',`Select ${track.name} track`);clip.setAttribute('aria-label',`${track.name} clip`);clip.append(svg);
-      const choose=()=>{if(selected!==index){cancelGesture();selectedNote=null;selectionToken++;selected=index;selectedInstance=null;}musicKey=parameterKey='';render();};name.addEventListener('click',choose);clip.addEventListener('click',choose);
+      name.append(title,detail);name.setAttribute('aria-label',`Select ${track.name} track`);name.title=track.name;clip.setAttribute('aria-label',`${track.name} clip`);clip.append(svg);
+      const choose=()=>{workspace.returnMusic();if(selected!==index){cancelGesture();selectedNote=null;selectionToken++;selected=index;selectedInstance=null;musicKey=parameterKey='';}render();};name.addEventListener('click',choose);clip.addEventListener('click',choose);
       const gainLabel=make('label','track-gain','Gain'),gain=numeric(`${track.name} gain`,track.gain,{min:0,max:2,step:.05},value=>mix(index,{gain:value}));gainLabel.append(gain);
       const fader=make('input','gain-fader');fader.type='range';fader.min='0';fader.max='2';fader.step='any';fader.value=String(track.gain);fader.setAttribute('aria-label',`${track.name} gain fader`);fader.setAttribute('aria-orientation','vertical');fader.title='Linear gain, 0 to 2';
       let faderEditing=false;fader.addEventListener('input',()=>{faderEditing=true;});fader.addEventListener('change',guard(()=>{faderEditing=false;return mix(index,{gain:Number(fader.value)});}));fader.addEventListener('pointercancel',()=>{faderEditing=false;render();});
@@ -342,10 +386,11 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
       const meters=make('div','track-meter'),bar=make('div','stereo-meter vertical-meter'),readout=make('output');bar.append(make('i'),make('i'));bar.setAttribute('aria-label',`${track.name} stereo peak`);readout.setAttribute('aria-label',`${track.name} peak`);meters.append(bar,readout);
       const actions=make('div','track-actions');for(const[action,label]of [['editor','Editor'],['load','Replace'],['remove','Remove track']]){
         const button=make('button','',label);button.setAttribute('aria-label',action==='editor'?`Open ${track.name} editor`:action==='remove'?`Remove ${track.name} track`:`${label} ${track.name} device`);
-        button.disabled=action!=='remove'&&!instrumentOf(track);button.addEventListener('click',guard(()=>enqueue(async()=>{
+        button.disabled=action!=='remove'&&!instrumentOf(track);button.addEventListener('click',guard(()=>{const origin=generation();return enqueue(async()=>{
+          if(generation()!==origin)throw Error('The originating device session changed.');
           if(action!=='editor'){commitFocused();cancelGesture();selectedNote=null;}
           if(action==='editor')await command('alive_editor',{instanceId:instrumentOf(track)?.instanceId});else{const result=isWorkspace()&&action==='remove'?await command('alive_workspace_track',{operation:{kind:'remove',trackId:track.id}}):await command('alive_device',{trackId:track.id,instanceId:instrumentOf(track)?.instanceId,action});applySnapshot(result.snapshot??result);trackKey=musicKey=parameterKey='';render();notice('Device updated. Start transport when ready.');}
-        })));actions.append(button);
+        });}));actions.append(button);
       }
       row.dataset.trackId=track.id;row.style.setProperty('--track-color',track.color??['#efbb62','#88c5c7','#91b9ed','#d8a0a7','#b4c98b','#d3b48a','#a5b9ce','#c5b6cf'][index%8]);
       const mixer=make('div','track-mixer'),toggles=make('div','mixer-toggles'),inspector=make('details','track-inspector'),summary=make('summary','','Device / track');
@@ -358,8 +403,8 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   function instanceName(reference,index){const isInstrument=reference.instanceId===instrumentOf(model.document().tracks[selected])?.instanceId,effect=index+(instrumentOf(model.document().tracks[selected])?0:1);return `${instanceView(reference.instanceId)?.manifest.name??'Device'}${isInstrument?' instrument':` effect ${effect}`}`;}
   function structural(reference,action,beforeInstanceId){
     commitFocused();cancelGesture();selectedNote=null;
-    const trackId=model.document().tracks[selected].id,instanceId=reference?.instanceId;
-    return enqueue(async()=>{const snapshot=await command('alive_device',{trackId,instanceId,action,...(action==='reorder'?{beforeInstanceId}: {})});applySnapshot(snapshot);trackKey=musicKey=parameterKey=chainKey='';render();notice('Chain prepared. Start transport when ready.');});
+    const trackId=model.document().tracks[selected].id,instanceId=reference?.instanceId,origin=generation();
+    return enqueue(async()=>{if(generation()!==origin)throw Error('The originating device session changed.');const snapshot=await command('alive_device',{trackId,instanceId,action,...(action==='reorder'?{beforeInstanceId}: {})});applySnapshot(snapshot);trackKey=musicKey=parameterKey=chainKey='';render();notice('Chain prepared. Start transport when ready.');});
   }
   function buildChain(){
     const track=model.document().tracks[selected],devices=chainDevices(track);
@@ -368,7 +413,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
       const name=instanceName(reference,index),context=`${track.name} ${name}`,row=make('div','chain-device'),choose=make('button','chain-select',name),bypass=make('button','','Bypass'),actions=[];
       choose.setAttribute('aria-label',`Select ${context}`);choose.addEventListener('click',()=>{selectedInstance=reference.instanceId;parameterKey='';render();});
       bypass.setAttribute('aria-label',`Bypass ${context}`);const isInstrument=reference.instanceId===instrumentOf(track)?.instanceId;bypass.disabled=isInstrument;bypass.title=isInstrument?'Only effects support bypass. Use track mute to silence this track.':'Live bypass keeps the device state warm; audio output stays open.';
-      bypass.addEventListener('click',guard(()=>{const instanceId=reference.instanceId,bypassed=!chainDevices().find(d=>d.instanceId===instanceId).bypassed;return enqueue(async()=>{await command('alive_bypass',{instanceId,bypassed});await refresh();});}));
+      bypass.addEventListener('click',guard(()=>{const instanceId=reference.instanceId,bypassed=!chainDevices().find(d=>d.instanceId===instanceId).bypassed,origin=generation();return enqueue(async()=>{if(generation()!==origin)throw Error('The originating device session changed.');await command('alive_bypass',{instanceId,bypassed});await refresh();});}));
       row.append(choose,bypass);
       const action=(label,aria,fn,blocked=false)=>{const button=make('button','',label);button.setAttribute('aria-label',aria);button.addEventListener('click',guard(fn));row.append(button);actions.push({button,blocked});};
       action('Replace...',`Replace ${context}`,()=>structural(reference,'replace'));
@@ -439,7 +484,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
       output.setAttribute('aria-label',`${binding.label} effective ownership`);base.append(number,unit);section.append(label,range,base,output);$('parameters').append(section);parameterViews.set(binding.key,{section,number,range,output});
     }
   }
-  function setBase(instanceId,key,value){return enqueue(async()=>{await command('alive_base',{instanceId,key,value});await refresh();});}
+  function setBase(instanceId,key,value){const origin=generation();return enqueue(async()=>{if(generation()!==origin)throw Error('The originating device session changed.');await invoke('alive_base',{instanceId,key,value,generation:origin});await refresh();});}
   const piano=$('piano-roll'),velocity=$('note-velocity');
   function context(){return {sourceId:sourceOf()?.id,occurrence:sourceSelection?.occurrence,trackId:model.document().tracks[selected].id,clipId:selectedClip()?.id??null,noteId:typeof selectedNote==='string'?selectedNote:null,scope:scopeRevision,generation:generation(),revision:model.snapshot()?.draftRevision??0};}
   function paintSelection(){paintPiano(piano,preview??editorDocument().tracks[selected].notes,editorDocument().lengthBeats,true);render();}
@@ -488,7 +533,8 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   function render(){
     if(sourceSelection&&model.document()){const d=model.document(),p=d.placements?.find(p=>p.id===sourceSelection.occurrence?.placementId);if(!d.sources?.some(s=>s.id===sourceSelection.sourceId))sourceSelection=null;else if(sourceSelection.occurrence)sourceSelection={...sourceSelection,sourceId:p?.sourceId??sourceSelection.sourceId,occurrence:p?sourceSelection.occurrence:null};}
     const snapshot=model.snapshot(),document=editorDocument();if(!snapshot||!document)return;
-    renderTransportRequest(snapshot);
+    if(masterGeneration!==snapshot.generation){const canceled=masterGeneration!==null&&(!!masterIntent||masterPendingReset);masterGeneration=snapshot.generation;masterIntent=masterReceipt=null;masterPendingReset=false;masterStatus=canceled?'Master pending intent canceled on session change.':'';masterError=false;masterProducer.setGeneration(snapshot.generation);if(canceled)notice(masterStatus,false,'master');else if(noticeOwner==='master')notice('Master state refreshed for this session.',false,'master');}
+    renderMaster();renderTransportRequest(snapshot);
     selected=Math.min(selected,document.tracks.length-1);
     if(!chainDevices().some(d=>d.instanceId===selectedInstance))selectedInstance=chainDevices()[0]?.instanceId??null;
     $('edit-device').disabled=!selectedInstance;$('session-title').textContent=document.title;$('dirty').textContent=snapshot.dirty||model.pending()?'Modified':'';doc.title=`${snapshot.dirty||model.pending()?'* ':''}${document.title} - Alive`;
@@ -511,7 +557,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     const nextParameters=JSON.stringify([snapshot.generation,selected,selectedInstance]);if(nextParameters!==parameterKey){parameterKey=nextParameters;buildParameters(snapshot);}
     document.tracks.forEach((track,index)=>{
       const view=trackViews[index],runtime=snapshot.state.tracks[index];view.row.classList.toggle('selected',selected===index);view.row.setAttribute('aria-label',`${track.name} track`);view.detail.textContent=`${(track.notes?.length??0)} notes / stereo`;
-      if(doc.activeElement!==view.gain&&!workspace.preserves(view.gain))view.gain.value=track.gain;view.mute.setAttribute('aria-pressed',String(track.mute));view.solo.setAttribute('aria-pressed',String(track.solo));
+      if(doc.activeElement!==view.gain&&!workspace.preserves(view.gain))view.gain.value=String(Number(track.gain.toFixed(3)));view.gain.title=`Exact gain: ${track.gain}`;view.mute.setAttribute('aria-pressed',String(track.mute));view.solo.setAttribute('aria-pressed',String(track.solo));
       if(!view.faderEditing()&&!workspace.preserves(view.fader))view.fader.value=track.gain;
       const key=JSON.stringify([track.notes,document.lengthBeats]);if(view.paintKey!==key){view.paintKey=key;paintPiano(view.svg,track.notes??[],document.lengthBeats);}
       meter(view.bar,runtime.peakLeft,runtime.peakRight);view.readout.textContent=peak(runtime.peakLeft,runtime.peakRight);
@@ -524,7 +570,6 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
     }
     const frameBeat=value=>typeof value==='string'?Number(nativeInteger(value)*1000000n/48000n)/1000000*snapshot.document.tempo/60:value/(48000*60/snapshot.document.tempo);const beat=frameBeat(snapshot.state.position);$('position').textContent=`${beat.toFixed(3)} beats`;
     for(const svg of [...trackViews.map(v=>v.svg),$('piano-roll')]){const line=svg.querySelector('.playhead');if(line){const detailed=svg===$('piano-roll'),pad=detailed?32:0,x=pad+(snapshot.runtime?frameBeat(snapshot.runtime.tracks.find(t=>t.trackId===document.tracks[detailed?selected:trackViews.findIndex(v=>v.svg===svg)]?.id)?.phase??'0'):beat)/(detailed?document.lengthBeats:document.tracks[trackViews.findIndex(v=>v.svg===svg)]?.clipLength??document.lengthBeats)*(640-pad);if(isWorkspace()){const t=document.tracks[detailed?selected:trackViews.findIndex(v=>v.svg===svg)],r=snapshot.runtime?.tracks.find(r=>r.trackId===t?.id);line.setAttribute('visibility',r?.phase!=null&&!!t?.sourceId&&r?.activeSourceId===t?.sourceId?'visible':'hidden');}else line.setAttribute('visibility','visible');line.setAttribute('x1',x);line.setAttribute('x2',x);}}
-    meter($('master-meter'),snapshot.state.peakLeft,snapshot.state.peakRight);$('master-peak').textContent=peak(snapshot.state.peakLeft,snapshot.state.peakRight);
     const a=snapshot.audio,s=snapshot.state,values=[a.host||a.config.host,a.device||a.config.device,a.config.sample_rate,a.observed_buffer_frames,a.callbacks,a.stream_errors,String(a.failed),a.message,String(!!s.playing),s.absoluteFrame,s.rejected,s.generation,...Array.from({length:8},(_,index)=>s.tracks[index]?.activeVoices??0),...Array.from({length:8},(_,index)=>{const r=snapshot.runtime?.tracks.find(t=>t.trackId===snapshot.document.tracks[index]?.id);return[r?.authority??'-',r?.activeSourceId??'-',r?.activePlacementId??'-'];}).flat()];
     diagnosticNames.forEach((name,index)=>{diagnostics.get(name).textContent=String(values[index]);});
     const observations=snapshot.runtime?.tracks??[],overridden=observations.filter(t=>t.authority==='session').length,pending=observations.filter(t=>t.pendingAction).length;
@@ -553,7 +598,7 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   bind('undo','Undo pending edit',()=>history('undo'));bind('redo','Redo pending edit',()=>history('redo'));
   bind('add-note','Add note',()=>{const trackId=model.document().tracks[selected].id;if(model.document().format==='alive-session-v3'||isWorkspace()){const c=isWorkspace()?sourceOf():selectedClip();if(!c)throw Error('Create a clip first.');let note=null;for(let beat=0;beat+.25<=c.lengthBeats&&!note;beat+=.25)for(let pitch=60;pitch<=127;pitch++)if(!c.notes.some(n=>n.pitch===pitch&&n.beat<beat+.25&&n.beat+n.duration>beat)){note={beat,pitch,duration:.25,velocity:100};break;}if(!note)throw Error('No room for a note.');return isWorkspace()?workspaceEdit({kind:'noteCreate',sourceId:c.id,...note}):clipEdit({kind:'noteCreate',trackId,clipId:c.id,...note});}return edit(document=>{const notes=trackById(document,trackId).notes;let note=null;for(let beat=0;beat+.25<=document.lengthBeats&&!note;beat+=.25)for(let pitch=60;pitch<=127;pitch++)if(!notes.some(n=>n.pitch===pitch&&n.beat<beat+.25&&n.beat+n.duration>beat)){note={beat,pitch,duration:.25,velocity:100};break;}if(!note)throw Error('No room for a note. Move or delete an existing note.');notes.push(note);if(model.document().tracks[selected].id===trackId)selectedNote=notes.length-1;},true,'Add note');});
   bind('add-effect','Add effect',()=>structural(null,'add'));
-  bind('edit-device','Edit selected device in Ultra',()=>{const instanceId=selectedInstance;return enqueue(()=>command('alive_editor',{instanceId}));});
+  bind('edit-device','Edit selected device in Ultra',()=>{const instanceId=selectedInstance,origin=generation();return enqueue(()=>{if(generation()!==origin)throw Error('The originating device session changed.');return command('alive_editor',{instanceId});});});
   bind('add-lane','Add automation lane',()=>{if(!$('automation-target').value)throw Error('Select a device parameter first.');const trackId=model.document().tracks[selected].id,[instanceId,key]=JSON.parse($('automation-target').value);return edit(document=>{const track=trackById(document,trackId);if(!track.automation.some(l=>l.instanceId===instanceId&&l.key===key))track.automation.push({instanceId,key,enabled:false,points:[]});});});
   bind('add-track','Add instrument track',()=>{cancelGesture();return enqueue(async()=>{const result=isWorkspace()?await command('alive_workspace_track',{operation:{kind:'addMidi',path:null}}):await command('alive_device',{trackId:`track-${Date.now()}`,action:'load'});applySnapshot(result.snapshot??result);trackKey=musicKey=parameterKey='';render();});});
   const keydown=guard(event=>{if(event.defaultPrevented)return;if(event.key==='Escape'&&!$('alive-audio-settings').hidden){event.preventDefault();closeAudioSettings();return;}if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();return file(event.shiftKey?'saveAs':'save');}if(event.code==='Space'&&!event.target.matches('input,select,button,summary')){event.preventDefault();return transport(model.snapshot()?.state.playing?'stop':'start');}});doc.addEventListener('keydown',keydown);
@@ -571,6 +616,6 @@ export function mountAlive({doc=globalThis.document,win=globalThis.window,invoke
   }
   if(invoke)win.setTimeout(pollMeasurements,1000);
   if(invoke){enqueue(refresh,true).then(()=>notice('Ready. Select a clip to edit notes or automation.')).catch(()=>{});win.setTimeout(poll,80);}else notice('Open the native app with bash apps/alive/run.sh. This page does not synthesize audio.',true);
-  return{model,refresh,dispose(){disposed=true;workspace.dispose();timeline?.dispose();win?.removeEventListener('blur',cancelGesture);unlisten?.();doc.removeEventListener('keydown',keydown);}};
+  return{model,refresh,dispose(){disposed=true;masterProducer.dispose();workspace.dispose();timeline?.dispose();win?.removeEventListener('blur',cancelGesture);unlisten?.();doc.removeEventListener('keydown',keydown);}};
 }
 if(globalThis.document)mountAlive();
diff --git a/apps/ultra/ui/canvas-device-panel.mjs b/apps/ultra/ui/canvas-device-panel.mjs
index 522deae..43f5166 100644
--- a/apps/ultra/ui/canvas-device-panel.mjs
+++ b/apps/ultra/ui/canvas-device-panel.mjs
@@ -4,11 +4,12 @@ import {createDevicePlayer} from './canvas-device-player.mjs';
 import {REGISTRY} from './canvas-model.mjs';
 import {treeNodes} from './canvas-hierarchy.mjs';
 
-export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{}}){
+export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{},drafts}){
   const $=id=>doc.querySelector('#'+id),panel=$('instrument-panel');
   const make=(tag,className,text)=>{const node=doc.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
   const guard=fn=>(...args)=>{try{return Promise.resolve(fn(...args)).catch(error=>controller.notice(error));}catch(error){controller.notice(error);return Promise.resolve();}};
   const current=()=>controller.getState().document??controller.getState().patch;
+  const deviceIdentity=state=>{const device=(state.document??state.patch).device;return JSON.stringify(device?{id:device.id,midi:device.midi,parameters:device.parameters}:null);};
   let identity='',presetsKey='',bindings=[],midi=null,opened=false;
   const inputs=new Map(),keys=new Map();
   const player=createDevicePlayer({
@@ -41,13 +42,26 @@ export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{}}){
       };
       range.addEventListener('input',guard(()=>{numeric.value=range.value;write(Number(range.value),!editing);editing=true;}));
       for(const name of ['change','pointerup','pointercancel','blur'])range.addEventListener(name,()=>{editing=false;});
-      numeric.addEventListener('change',guard(()=>write(Number(numeric.value))));
+      let numericDirty=false,original='';
+      numeric.addEventListener('input',()=>{if(!numericDirty)original=range.value;numericDirty=true;});
+      numeric.commitDraft=()=>{
+        if(!numericDirty)return true;
+        const value=numeric.value===''?NaN:Number(numeric.value);
+        if(!Number.isFinite(value)||value<binding.min||value>binding.max)return false;
+        numericDirty=false;
+        try{write(value);return true;}catch(error){numericDirty=true;controller.notice(error);return false;}
+      };
+      numeric.cancelDraft=()=>{numericDirty=false;numeric.value=original;};
+      numeric.hasDraft=()=>numericDirty;drafts?.watch(numeric,()=>numericDirty);
+      numeric.addEventListener('change',()=>{if(!numericDirty)numericDirty=true;if(!numeric.commitDraft())numeric.focus();});
+      numeric.addEventListener('blur',()=>{if(!numeric.commitDraft())numeric.focus();});
+      numeric.addEventListener('keydown',e=>{if(e.key==='Escape'&&numericDirty){e.preventDefault();e.stopPropagation();numeric.cancelDraft();}else if(['Enter','Tab'].includes(e.key)&&!numeric.commitDraft())e.preventDefault();});
       row.append(label,range,numeric,unit);$('instrument-controls').append(row);inputs.set(binding.key,{range,numeric});
     }
   }
   function update(state){
     const patch=state.document??state.patch,device=patch.device;
-    const next=JSON.stringify(device?{id:device.id,midi:device.midi,parameters:device.parameters}:null);
+    const next=deviceIdentity(state);
     if(identity!==next){release();identity=next;build(device);presetsKey='';}
     if(!opened)return;
     $('instrument-title').textContent=device?.name??'Instrument';
@@ -56,12 +70,12 @@ export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{}}){
     $('instrument-package').disabled=state.closing||state.applying;
     if(!device)return;
     $('instrument-keyboard').hidden=!midi;$('instrument-release').hidden=!midi;
-    $('instrument-package').disabled=state.closing||state.applying||device.kind==='audioEffect';
+    $('instrument-package').disabled=state.closing||state.applying;
     const values=deviceValues(patch);
     for(const binding of bindings){
       const {range,numeric}=inputs.get(binding.key),value=values[binding.key];
       if(range.value!==String(value))range.value=String(value);
-      if(doc.activeElement!==numeric)numeric.value=String(Number(value.toFixed(4)));
+      if(doc.activeElement!==numeric&&!numeric.hasDraft?.())numeric.value=String(Number(value.toFixed(4)));
       range.disabled=numeric.disabled=!!state.closing||state.faulted;
     }
     const newPresets=JSON.stringify(device.presets.map(preset=>preset.name));
@@ -97,7 +111,7 @@ export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{}}){
   $('show-instrument').addEventListener('click',()=>opened?close():open());
   $('instrument-close').addEventListener('click',close);
   $('instrument-package').addEventListener('click',guard(async()=>{
-    await controller.flush();const patch=current(),name=$('instrument-name').value.trim()||'Subtractive instrument';
+    await controller.flush();const patch=current(),name=$('instrument-name').value.trim()||patch.device?.name||'Subtractive instrument';
     controller.load(packageInstrument(patch,{name,id:patch.device?.id??'org.alive.instrument'}));await controller.flush();open();
   }));
   $('instrument-recall').addEventListener('click',guard(async()=>{
@@ -112,5 +126,5 @@ export function mountDevicePanel({doc,win,controller,invoke,beforeOpen=()=>{}}){
   }));
   $('instrument-instance').addEventListener('click',guard(async()=>{await controller.flush();await invoke('document_instantiate');}));
   $('instrument-release').addEventListener('click',guard(async()=>{await player.releaseAll();await controller.stop();}));
-  return{open,close,update,isOpen:()=>opened,dispose(){release();win.removeEventListener?.('keyup',keyup);win.removeEventListener?.('blur',release);doc.removeEventListener?.('visibilitychange',visibility);}};
+  return{open,close,update,wouldRebuild:state=>identity!==deviceIdentity(state),isOpen:()=>opened,dispose(){release();win.removeEventListener?.('keyup',keyup);win.removeEventListener?.('blur',release);doc.removeEventListener?.('visibilitychange',visibility);}};
 }
diff --git a/apps/ultra/ui/canvas-documents-view.mjs b/apps/ultra/ui/canvas-documents-view.mjs
index 54c5d0e..ee09b24 100644
--- a/apps/ultra/ui/canvas-documents-view.mjs
+++ b/apps/ultra/ui/canvas-documents-view.mjs
@@ -31,7 +31,8 @@ export function mountDocuments({doc,win,invoke,getPatch,adopt,beforeSave,beforeC
       win.setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Patch download requested.');return{...descriptor,title:link.download,kind:'patch'};
     },
   };
-  const session=createDocumentSession({invoke,getPatch,adopt,beforeSave,beforeClose,inspect,notice,browser,metadata:value=>{
+  const session=createDocumentSession({invoke,getPatch,adopt,beforeSave,beforeClose,inspect,notice,browser,
+    setTimer:(fn,ms)=>win.setTimeout(fn,ms),clearTimer:id=>win.clearTimeout(id),onSaveReleased:onCloseCancelled,metadata:value=>{
     const title=value.viewTitle||value.title;
     $('document-title').textContent=title;$('document-title').title=value.path||value.title;$('document-dirty').hidden=!value.dirty;
     doc.title=`${value.dirty?'* ':''}${title} - Ultra`;onDocument(value);
@@ -95,6 +96,8 @@ export function mountDocuments({doc,win,invoke,getPatch,adopt,beforeSave,beforeC
     listen('document-action',event=>actions[event.payload]?.()),
     listen('document-save-before-close',event=>session.saveBeforeClose(event.payload)),
     listen('document-flush-before-close',async event=>{if(readyTask)await readyTask;return session.flushBeforeClose(event.payload);}),
+    listen('document-flush-before-save',async event=>{if(readyTask)await readyTask;return session.flushBeforeSave(event.payload);}),
+    listen('document-save-flush-released',event=>{const barrier=session.releaseSave(event.payload);if(barrier)return onCloseCancelled(barrier);}),
     listen('document-close-cancelled',async event=>{if(readyTask)await readyTask;session.cancelClose(event.payload);return onCloseCancelled(event.payload);}),
     listen('document-error',event=>notice(event.payload)),
     listen('document-changed',event=>{if(session.acceptDescriptor(event.payload))return onDescriptor(event.payload);}),
@@ -104,5 +107,5 @@ export function mountDocuments({doc,win,invoke,getPatch,adopt,beforeSave,beforeC
     const webview=win.__TAURI__?.webview?.getCurrentWebview?.();
     if(webview?.onDragDropEvent)webview.onDragDropEvent(guard(async event=>{if(event.payload.type==='drop')for(const path of event.payload.paths||[])await session.open(path);})).then(off=>{if(disposed)off();else unlisten.push(off);}).catch(notice);
   }
-  return{session,openLibrary,openHelp:key=>session.openHelp(key),action:action=>actions[action]?.(),ready:()=>readyTask??=(async()=>{await subscriptions;return session.ready();})(),update:()=>session.update(),isOpen:()=>$('help-library').open,dispose(){disposed=true;unlisten.splice(0).forEach(off=>off());}};
+  return{session,openLibrary,openHelp:key=>session.openHelp(key),action:action=>actions[action]?.(),ready:()=>readyTask??=(async()=>{await subscriptions;return session.ready();})(),update:()=>session.update(),isOpen:()=>$('help-library').open,dispose(){disposed=true;session.dispose();unlisten.splice(0).forEach(off=>off());}};
 }
diff --git a/apps/ultra/ui/canvas-documents.mjs b/apps/ultra/ui/canvas-documents.mjs
index 172f59c..b1bb1c0 100644
--- a/apps/ultra/ui/canvas-documents.mjs
+++ b/apps/ultra/ui/canvas-documents.mjs
@@ -1,9 +1,26 @@
 const copy=value=>JSON.parse(JSON.stringify(value));
 const fingerprint=value=>JSON.stringify(value,(_,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
 
-export function createDocumentSession({invoke,getPatch,adopt,beforeSave=async()=>{},beforeClose=beforeSave,metadata=()=>{},notice=()=>{},inspect=()=>{},browser={}}){
+export function createDocumentSession({invoke,getPatch,adopt,beforeSave=async()=>{},beforeClose=beforeSave,metadata=()=>{},notice=()=>{},inspect=()=>{},browser={},setTimer,clearTimer,onSaveReleased=()=>{}}){
   let descriptor={title:'Untitled patch',kind:'patch'},baseline=null,dirty=false,active=false,reported=null,notifications=Promise.resolve(),saving=null;
-  const closing=new Map();
+  const closing=new Map(),saveFlushes=new Map(),releasedSaves=new Map();
+  function scheduleSaveCheck(owner,pending){
+    if(!setTimer||!invoke)return;
+    pending.timer=setTimer(async()=>{
+      if(saveFlushes.get(owner)!==pending)return;
+      try{
+        if(await invoke('document_save_barrier_active',{owner,token:pending.token})===false){
+          const barrier=releaseSave({owner,token:pending.token});if(barrier)onSaveReleased(barrier);return;
+        }
+      }catch{/* A later check can recover a transient IPC failure. */}
+      if(saveFlushes.get(owner)===pending)scheduleSaveCheck(owner,pending);
+    },1000);
+  }
+  function releaseSave(request){
+    releasedSaves.set(request.owner,Math.max(releasedSaves.get(request.owner)??0,request.token));
+    const pending=saveFlushes.get(request.owner);
+    if(pending?.token===request.token){saveFlushes.delete(request.owner);if(pending.timer!==undefined)clearTimer?.(pending.timer);return pending.barrier;}
+  }
   const publish=()=>metadata({...descriptor,dirty});
   function acceptDescriptor(value){
     if(!value||typeof value!=='object')return false;
@@ -59,6 +76,16 @@ export function createDocumentSession({invoke,getPatch,adopt,beforeSave=async()=
       if(invoke)await invoke('document_close_flushed',request);
     },
     cancelClose(request){if(closing.get(request.requestLabel)?.token===request.token)closing.delete(request.requestLabel);},
+    async flushBeforeSave(request){
+      if((releasedSaves.get(request.owner)??0)>=request.token)return;
+      const barrier={requestLabel:`save/${request.owner}`,token:request.token,purpose:'save'},pending={token:request.token,barrier};
+      saveFlushes.set(request.owner,pending);scheduleSaveCheck(request.owner,pending);let error;
+      try{await beforeClose(barrier);}catch(reason){error=String(reason?.message||reason);}
+      if(saveFlushes.get(request.owner)!==pending)return;
+      if(invoke)await invoke('document_save_flushed',{owner:request.owner,token:request.token,error});
+    },
+    releaseSave,
+    dispose(){for(const pending of saveFlushes.values())if(pending.timer!==undefined)clearTimer?.(pending.timer);saveFlushes.clear();},
     async saveBeforeClose(request){
       const args=request?.quitToken===undefined?undefined:{quitToken:request.quitToken};
       let confirmed=false;
diff --git a/apps/ultra/ui/canvas-documents.test.mjs b/apps/ultra/ui/canvas-documents.test.mjs
index 5350616..289cdcb 100644
--- a/apps/ultra/ui/canvas-documents.test.mjs
+++ b/apps/ultra/ui/canvas-documents.test.mjs
@@ -1,6 +1,31 @@
 import assert from 'node:assert/strict';
 import {test} from 'node:test';
 
+test('save flush waits for the local barrier and suppresses a late acknowledgement after release',async()=>{
+  const {createDocumentSession}=await import('./canvas-documents.mjs');const calls=[];let release;
+  const session=createDocumentSession({getPatch:()=>({}),adopt:()=>{},beforeClose:()=>new Promise(resolve=>release=resolve),invoke:async(name,args)=>{calls.push({name,args});}});
+  const request={owner:'main',token:9},flushing=session.flushBeforeSave(request);
+  assert.deepEqual(calls,[]);assert.deepEqual(session.releaseSave(request),{requestLabel:'save/main',token:9,purpose:'save'});
+  release();await flushing;assert.deepEqual(calls,[]);
+  await session.flushBeforeSave(request);assert.deepEqual(calls,[]);
+});
+test('invalid save flush reports an error to the owner preflight',async()=>{
+  const {createDocumentSession}=await import('./canvas-documents.mjs');const calls=[];
+  const session=createDocumentSession({getPatch:()=>({}),adopt:()=>{},beforeClose:()=>{throw Error('invalid draft');},invoke:async(name,args)=>{calls.push({name,args});}});
+  await session.flushBeforeSave({owner:'main',token:12});
+  assert.deepEqual(calls,[{name:'document_save_flushed',args:{owner:'main',token:12,error:'invalid draft'}}]);
+});
+test('a lost release event reconciles and unfreezes the live save barrier',async()=>{
+  const {createDocumentSession}=await import('./canvas-documents.mjs');const timers=[],released=[],calls=[];let active=true;
+  const session=createDocumentSession({getPatch:()=>({}),adopt:()=>{},beforeClose:async()=>{},
+    setTimer:fn=>{timers.push(fn);return timers.length;},clearTimer:()=>{},onSaveReleased:barrier=>released.push(barrier),
+    invoke:async(name,args)=>{calls.push({name,args});return name==='document_save_barrier_active'?active:true;}});
+  await session.flushBeforeSave({owner:'main',token:11});await timers.shift()();assert.deepEqual(released,[]);
+  active=false;await timers.shift()();assert.deepEqual(released,[{requestLabel:'save/main',token:11,purpose:'save'}]);
+  assert.equal(calls.filter(call=>call.name==='document_save_flushed').length,1);
+  session.dispose();
+});
+
 const patch=()=>({version:1,profile:'ultra-canvas-v1',nodes:[],edges:[]});
 async function setup(responses={}){
   const {createDocumentSession}=await import('./canvas-documents.mjs');
diff --git a/apps/ultra/ui/canvas-dom.test.mjs b/apps/ultra/ui/canvas-dom.test.mjs
index 968d49d..14594dd 100644
--- a/apps/ultra/ui/canvas-dom.test.mjs
+++ b/apps/ultra/ui/canvas-dom.test.mjs
@@ -3,6 +3,7 @@ import {test} from 'node:test';
 import {readFileSync} from 'node:fs';
 import {OBJECTS} from './canvas-catalog.mjs';
 import {CanvasDocument,makeNode} from './canvas-model.mjs';
+import {subtractivePatch} from './canvas-instrument.mjs';
 
 // This executes the real page module with a small DOM adapter. It does not prove rendered geometry or native sound.
 class Element {
@@ -40,6 +41,17 @@ async function mount(native=false,{documentCurrent=null,tauri,observeInvoke=()=>
   const {mountCanvas}=await import('./canvas.mjs');const page=mountCanvas({document,window,invoke});await page.ready;await page.controller.flush();await settle();
   return{...page,ids,calls,timeouts,navigations,previews,observed,consoleRecords,popupSnapshots,windowEvents,documentEvents,document,all:id=>descendants(ids.get(id))};
 }
+test('Perform renames a device without replacing authored controls or presets',async()=>{
+  const p=await mount(true),patch=subtractivePatch();
+  patch.device.parameters[4]={...patch.device.parameters[4],key:'tone',label:'Tone',min:100,max:9000};
+  for(const preset of patch.device.presets){preset.values.tone=preset.values.cutoff;delete preset.values.cutoff;}
+  p.controller.load(patch);await p.controller.flush();await p.ids.get('show-instrument').fire('click');
+  p.ids.get('instrument-name').value='Renamed';await p.ids.get('instrument-package').fire('click');
+  const after=p.controller.getState().document;
+  assert.equal(after.device.name,'Renamed');assert.deepEqual(after.device.parameters,patch.device.parameters);assert.deepEqual(after.device.presets,patch.device.presets);
+  assert.ok(p.all('instrument-controls').some(e=>e.attrs['aria-label']==='Tone'));
+  await p.dispose();
+});
 test('effect panel exposes live parameters and presets without a keyboard claim',async()=>{
   const p=await mount(true);
   const patch={version:1,profile:'ultra-canvas-v1',nodes:[makeNode('audio_in',1),makeNode('line_signal',2,0,0,{value:1})],edges:[],
@@ -51,6 +63,8 @@ test('effect panel exposes live parameters and presets without a keyboard claim'
   assert.equal(p.ids.get('instrument-keyboard').hidden,true);
   assert.equal(p.ids.get('instrument-release').hidden,true);
   assert.match(p.ids.get('instrument-keyboard-note').textContent,/host.*audio/i);
+  p.ids.get('instrument-name').value='Renamed effect';await p.ids.get('instrument-package').fire('click');
+  assert.deepEqual(p.controller.getState().document.device,{...patch.device,name:'Renamed effect'});
   const control=p.all('instrument-controls').find(e=>e.tagName==='INPUT'&&e.type==='number');
   control.value='0.5';await control.fire('change');await p.controller.flush();
   assert.equal(p.controller.getState().document.nodes.find(n=>n.id===2).params.value,.5);
@@ -64,6 +78,29 @@ test('effect panel exposes live parameters and presets without a keyboard claim'
   assert.ok(p.calls.some(c=>c.name==='canvas_event'&&c.args.node===1&&c.args.inlet===0));
   await p.dispose();
 });
+test('saving a focused Perform value commits it before the snapshot',async()=>{
+  const p=await mount(true);
+  const patch={version:1,profile:'ultra-canvas-v1',nodes:[makeNode('audio_in',1),makeNode('line_signal',2,0,0,{value:1})],edges:[],
+    device:{version:2,kind:'audioEffect',id:'org.alive.test.utility',name:'Utility',midi:{input:null,output:null},
+      audio:{input:{node:1,bundle:{channels:2,layout:'stereo'}},output:{channels:2,layout:'stereo'}},
+      parameters:[{key:'gain',label:'Gain',node:2,param:'value',min:0,max:2}],presets:[]}};
+  p.controller.load(patch);await p.controller.flush();await p.ids.get('show-instrument').fire('click');
+  const input=p.all('instrument-controls').find(e=>e.type==='number');p.document.activeElement=input;
+  input.value='0.5';await input.fire('input');await p.documents.action('save');
+  assert.equal(p.calls.filter(c=>c.name==='document_save').at(-1).args.patch.nodes.find(n=>n.id===2).params.value,.5);
+  await p.dispose();
+});
+test('rebuilding Perform controls captures their focused value',async()=>{
+  const p=await mount(true);
+  const patch={version:1,profile:'ultra-canvas-v1',nodes:[makeNode('audio_in',1),makeNode('line_signal',2,0,0,{value:1})],edges:[],
+    device:{version:2,kind:'audioEffect',id:'org.alive.test.utility',name:'Utility',midi:{input:null,output:null},
+      audio:{input:{node:1,bundle:{channels:2,layout:'stereo'}},output:{channels:2,layout:'stereo'}},
+      parameters:[{key:'gain',label:'Gain',node:2,param:'value',min:0,max:2}],presets:[]}};
+  p.controller.load(patch);await p.controller.flush();await p.ids.get('show-instrument').fire('click');
+  const input=p.all('instrument-controls').find(e=>e.type==='number');p.document.activeElement=input;input.value='0.5';await input.fire('input');
+  const changed=structuredClone(patch);changed.device.parameters[0].label='Level';p.controller.load(changed);await p.controller.flush();
+  assert.equal(p.controller.getState().document.nodes.find(n=>n.id===2).params.value,.5);await p.dispose();
+});
 test('help shell hosts Basic while question/reference navigation preserves the native runtime',async()=>{
   const patch=helpPatch(),descriptor={shared:true,id:0,label:'main',ownerLabel:'main',title:'Help.ultra',kind:'patch',patch,dirty:false,viewPath:[],authoringRevision:1,runtimeRevision:9};
   const p=await mount(true,{documentCurrent:descriptor,helpReference:async name=>reference(name)});
@@ -392,6 +429,125 @@ test('number display follows native observations without changing saved paramete
   p.render({...state,observations:{15:{value:72,pulses:1}}});
   assert.equal(input.value,'72');assert.equal(node.params.value,150);
 });
+test('saving a focused number commits its draft before taking the snapshot',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});
+  await p.controller.flush();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');
+  p.document.activeElement=input;input.value='42';await input.fire('input');
+  await p.windowEvents.fire('keydown',{key:'s',ctrlKey:true,target:input});
+  const saved=p.calls.filter(c=>c.name==='document_save').at(-1);
+  assert.equal(saved.args.patch.nodes[0].params.value,42);
+  assert.equal(p.controller.getState().document.nodes[0].params.value,42);
+  await p.dispose();
+});
+test('rebuilding the node container captures the focused draft first',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});await p.controller.flush();
+  await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='42';await input.fire('input');p.controller.add('bang',100,100);await p.controller.flush();
+  assert.equal(p.controller.getState().document.nodes.find(n=>n.id===1).params.value,42);
+  await p.dispose();
+});
+test('saving an invalid focused number refuses the snapshot until cancelled',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});
+  await p.controller.flush();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='';await input.fire('input');
+  await p.windowEvents.fire('keydown',{key:'s',ctrlKey:true,target:input});
+  assert.equal(p.calls.filter(c=>c.name==='document_save').length,0);
+  await input.fire('keydown',{key:'Escape'});
+  assert.equal(input.value,'10');
+  await p.windowEvents.fire('keydown',{key:'s',ctrlKey:true,target:input});
+  assert.equal(p.calls.filter(c=>c.name==='document_save').length,1);
+  await p.dispose();
+});
+test('a parked invalid number blocks Save and close after focus moves',async()=>{
+  const p=await mountHistoryControl();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='';await input.fire('input');await input.fire('blur');p.document.activeElement=p.ids.get('document-save');
+  await p.documents.action('save').catch(()=>{});
+  assert.equal(p.operations.filter(c=>c.name==='document_save').length,0);
+  await assert.rejects(p.documents.session.flushBeforeClose({requestLabel:'owner',token:55}),/invalid focused edit/);
+  assert.equal(p.operations.find(c=>c.name==='document_close_flushed').args.token,55);
+  assert.match(p.operations.find(c=>c.name==='document_close_flushed').args.error,/invalid focused edit/);
+  assert.equal(input.value,'');await p.dispose();
+});
+test('parked invalid number survives container reconstruction',async()=>{
+  const p=await mount(true);p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});await p.controller.flush();
+  await p.ids.get('lock-patch').fire('click');const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='';await input.fire('input');await input.fire('blur');p.document.activeElement=p.ids.get('document-save');
+  p.controller.add('bang',100,100);await p.controller.flush();
+  assert.equal(p.ids.get('objects').children.length,1);assert.equal(p.all('objects').find(e=>e.dataset.parameter==='value'),input);assert.equal(input.value,'');
+  await input.fire('keydown',{key:'Escape'});assert.equal(p.ids.get('objects').children.length,2);await p.dispose();
+});
+test('preflight commits valid parked drafts and rejects another invalid draft',async()=>{
+  const p=await mount(true);p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10}),makeNode('number',2,100,0,{value:20})],edges:[]});await p.controller.flush();
+  await p.ids.get('lock-patch').fire('click');const inputs=p.all('objects').filter(e=>e.dataset.parameter==='value');
+  p.document.activeElement=inputs[0];inputs[0].value='42';await inputs[0].fire('input');
+  p.document.activeElement=inputs[1];inputs[1].value='';await inputs[1].fire('input');p.document.activeElement=p.ids.get('document-save');
+  await p.documents.action('save').catch(()=>{});assert.equal(p.calls.filter(c=>c.name==='document_save').length,0);
+  assert.equal(p.controller.getState().document.nodes[0].params.value,42);assert.equal(inputs[1].value,'');await p.dispose();
+});
+test('an out-of-range number draft is not clamped by Enter',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});
+  await p.controller.flush();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value=String(Number(input.max)+1);await input.fire('input');await input.fire('keydown',{key:'Enter'});
+  assert.equal(p.controller.getState().document.nodes[0].params.value,10);
+  assert.equal(input.value,String(Number(input.max)+1));
+  await p.dispose();
+});
+test('saving a focused inspector field commits its draft',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});
+  await p.controller.flush();
+  const node=p.all('objects').find(e=>e.dataset.node==='1');await descendants(node).find(e=>e.dataset.drag).fire('click');
+  const input=p.all('inspector').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='42';await input.fire('input');
+  await p.windowEvents.fire('keydown',{key:'s',ctrlKey:true,target:input});
+  assert.equal(p.calls.filter(c=>c.name==='document_save').at(-1).args.patch.nodes[0].params.value,42);
+  await p.dispose();
+});
+test('changing selection captures a focused inspector draft before rebuilding',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10}),makeNode('bang',2)],edges:[]});await p.controller.flush();
+  const select=id=>descendants(p.all('objects').find(e=>e.dataset.node===String(id))).find(e=>e.dataset.drag).fire('click');
+  await select(1);const input=p.all('inspector').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='42';await input.fire('input');await select(2);await p.controller.flush();
+  assert.equal(p.controller.getState().document.nodes.find(n=>n.id===1).params.value,42);
+  await p.dispose();
+});
+test('saving a focused appearance value commits its draft',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[makeNode('number',1,0,0,{value:10})],edges:[]});await p.controller.flush();
+  const node=p.all('objects').find(e=>e.dataset.node==='1');await descendants(node).find(e=>e.dataset.drag).fire('click');
+  const input=p.all('inspector').find(e=>e.dataset.style==='fontsize');assert.ok(input);p.document.activeElement=input;
+  input.value='24';await input.fire('input');await p.documents.action('save');
+  assert.equal(p.calls.filter(c=>c.name==='document_save').at(-1).args.patch.nodes[0].style.fontsize,24);
+  await p.dispose();
+});
+test('saving an open object entry commits its draft',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[],edges:[]});await p.controller.flush();
+  await p.windowEvents.fire('keydown',{key:'n'});
+  const input=p.ids.get('object-text');p.document.activeElement=input;input.value='number 42';await input.fire('input');
+  await p.documents.action('save');
+  assert.equal(p.calls.filter(c=>c.name==='document_save').at(-1).args.patch.nodes[0].params.value,42);
+  await p.dispose();
+});
+test('saving through a toolbar commits the open object entry after focus moves',async()=>{
+  const p=await mount(true);
+  p.controller.load({version:1,profile:'ultra-canvas-v1',nodes:[],edges:[]});await p.controller.flush();
+  await p.windowEvents.fire('keydown',{key:'n'});
+  const input=p.ids.get('object-text');input.value='number 42';await input.fire('input');
+  p.document.activeElement=p.ids.get('document-save');await p.ids.get('document-save').fire('click');
+  assert.equal(p.calls.filter(c=>c.name==='document_save').at(-1).args.patch.nodes[0].params.value,42);
+  await p.dispose();
+});
 test('controls can return a live observed value to the saved value without duplicate native events',async()=>{
   for(const type of ['number','flonum','slider']){
     const p=await mount(true);
@@ -771,12 +927,14 @@ test('unchanged stopped status polls preserve cable paths while cable inputs inv
 // Delayed history still runs through the real shared controller and node views.
 async function mountHistoryControl(type='number') {
   let patch=new CanvasDocument({version:2,profile:'ultra-patcher-v2',nodes:[makeNode(type,1,40,50,{value:150})],edges:[]}).document;
-  let revision=1,hold=false,release;
-  const past=[],future=[],descriptor=()=>({shared:true,id:1,label:'owner',ownerLabel:'owner',title:'Numeric',kind:'patch',viewPath:[],
+  let revision=1,hold=false,release,holdCommit=false,releaseCommit,cancelSave=false;
+  const operations=[],past=[],future=[],descriptor=()=>({shared:true,id:1,label:'owner',ownerLabel:'owner',title:'Numeric',kind:'patch',viewPath:[],
     patch:structuredClone(patch),authoringRevision:revision,runtimeRevision:revision,canUndo:past.length>0,canRedo:future.length>0});
   const p=await mount(true,{documentCurrent:descriptor(),invokeOverride:async(name,args,fallback)=>{
+    operations.push({name,args});
     if(name==='document_current')return descriptor();
     if(name==='document_commit'){
+      if(holdCommit)await new Promise(resolve=>releaseCommit=resolve);
       assert.equal(args.baseRevision,revision);past.push(structuredClone(patch));future.length=0;
       patch=new CanvasDocument(args.patch).document;revision++;
       return{accepted:true,document:descriptor()};
@@ -789,15 +947,88 @@ async function mountHistoryControl(type='number') {
       return{accepted:true,document:descriptor()};
     }
     if(name==='canvas_status')return{revision,active:true,nodes:[],console:[]};
+    if(name==='document_save'&&cancelSave)return null;
     return fallback(name,args);
   }});
   p.controller.parameter(1,'value',20);await p.controller.flush();
-  return{...p,get canonical(){return patch;},async holdHistory(direction){
+  return{...p,operations,get canonical(){return patch;},get ownerRevision(){return revision;},pauseCommit(){holdCommit=true;return()=>{holdCommit=false;releaseCommit();};},cancelNextSave(){cancelSave=true;},async holdHistory(direction){
     hold=true;const promise=p.controller[direction]();await settle();
     return{promise,release(){hold=false;release();}};
   }};
 }
 
+test('close flush acknowledges only after the focused shared edit reaches its owner',async()=>{
+  const p=await mountHistoryControl();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='42';await input.fire('input');const start=p.operations.length;
+  await p.documents.session.flushBeforeClose({requestLabel:'owner',token:31});
+  assert.equal(p.canonical.nodes[0].params.value,42);
+  const calls=p.operations.slice(start),commit=calls.findIndex(c=>c.name==='document_commit'),ack=calls.findIndex(c=>c.name==='document_close_flushed');
+  assert.ok(commit>=0&&ack>commit);assert.equal(calls.filter(c=>c.name==='document_commit').length,1);
+  assert.equal(calls[ack].args.error,undefined);
+  await p.dispose();
+});
+test('owner Save waits for a linked focused draft and its delayed native admission',async()=>{
+  let patch=new CanvasDocument({version:2,profile:'ultra-patcher-v2',nodes:[makeNode('number',1,0,0,{value:10}),
+    {...makeNode('patcher',3),patcher:{nodes:[makeNode('number',13,0,0,{value:10})],edges:[]}}],edges:[]}).document;
+  let revision=1,release;const calls=[],listeners=new Map();
+  const descriptor=label=>({shared:true,id:1,label,ownerLabel:'owner',title:'Shared',kind:'patch',viewPath:label==='child'?[3]:[],patch:structuredClone(patch),authoringRevision:revision,runtimeRevision:1,dirty:false});
+  const tauri=label=>({event:{listen:async(name,handler)=>{listeners.set(`${label}/${name}`,handler);return()=>{};}},webviewWindow:{getCurrentWebviewWindow:()=>({label})}});
+  const invokeOverride=label=>async(name,args,fallback)=>{
+    calls.push({label,name,args});
+    if(name==='document_current')return descriptor(label);
+    if(name==='document_commit'){
+      assert.equal(args.baseRevision,revision);await new Promise(resolve=>release=resolve);
+      patch=new CanvasDocument(args.patch).document;revision++;return{accepted:true,document:descriptor(label)};
+    }
+    if(name==='document_save'){
+      await listeners.get('child/document-flush-before-save')({payload:{owner:'owner',token:7}});
+      calls.push({name:'snapshot',patch:structuredClone(patch)});
+      await listeners.get('child/document-save-flush-released')({payload:{owner:'owner',token:7}});
+      return descriptor(label);
+    }
+    if(name==='document_save_flushed')return true;
+    if(name==='canvas_status')return{revision:1,active:true,nodes:[],console:[]};
+    return fallback(name,args);
+  };
+  const owner=await mount(true,{documentCurrent:descriptor('owner'),tauri:tauri('owner'),invokeOverride:invokeOverride('owner')});
+  const child=await mount(true,{documentCurrent:descriptor('child'),tauri:tauri('child'),invokeOverride:invokeOverride('child')});
+  await child.ids.get('lock-patch').fire('click');const input=child.all('objects').find(e=>e.dataset.parameter==='value');
+  child.document.activeElement=input;input.value='73';await input.fire('input');
+  const saving=owner.documents.action('save');await settle();assert.equal(typeof release,'function');
+  assert.equal(calls.some(call=>call.name==='snapshot'||call.name==='document_save_flushed'),false);
+  release();assert.equal(await saving,true);
+  const commit=calls.findIndex(call=>call.name==='document_commit'),ack=calls.findIndex(call=>call.name==='document_save_flushed'),snapshot=calls.findIndex(call=>call.name==='snapshot');
+  assert.ok(commit>=0&&commit<ack&&ack<snapshot);assert.equal(calls.filter(call=>call.name==='document_commit').length,1);
+  assert.equal(calls[snapshot].patch.nodes[1].patcher.nodes[0].params.value,73);assert.equal(revision,2);
+  await child.dispose();await owner.dispose();
+});
+test('close flush reports a focused invalid draft without admitting or acknowledging success',async()=>{
+  const p=await mountHistoryControl();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;
+  input.value='';await input.fire('input');const start=p.operations.length;
+  await assert.rejects(p.documents.session.flushBeforeClose({requestLabel:'owner',token:32}),/invalid focused edit/);
+  const calls=p.operations.slice(start);assert.equal(calls.filter(c=>c.name==='document_commit').length,0);
+  assert.match(calls.find(c=>c.name==='document_close_flushed').args.error,/invalid focused edit/);
+  assert.equal(p.canonical.nodes[0].params.value,20);await p.dispose();
+});
+test('close acknowledgement waits for delayed owner admission and advances exactly one revision',async()=>{
+  const p=await mountHistoryControl();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;input.value='42';await input.fire('input');
+  const before=p.ownerRevision,release=p.pauseCommit(),start=p.operations.length,closing=p.documents.session.flushBeforeClose({requestLabel:'owner',token:33});
+  await settle();assert.equal(p.ownerRevision,before);assert.equal(p.operations.slice(start).some(c=>c.name==='document_close_flushed'),false);
+  release();await closing;assert.equal(p.ownerRevision,before+1);assert.equal(p.canonical.nodes[0].params.value,42);
+  const calls=p.operations.slice(start);assert.equal(calls.filter(c=>c.name==='document_commit').length,1);
+  assert.ok(calls.findIndex(c=>c.name==='document_commit')<calls.findIndex(c=>c.name==='document_close_flushed'));await p.dispose();
+});
+test('cancelled Save As retains the committed focused draft in the owner',async()=>{
+  const p=await mountHistoryControl();await p.ids.get('lock-patch').fire('click');
+  const input=p.all('objects').find(e=>e.dataset.parameter==='value');p.document.activeElement=input;input.value='42';await input.fire('input');
+  const before=p.ownerRevision;p.cancelNextSave();assert.equal(await p.documents.action('save-as'),false);
+  assert.equal(p.ownerRevision,before+1);assert.equal(p.canonical.nodes[0].params.value,42);
+  assert.equal(p.operations.filter(c=>c.name==='document_save').at(-1).args.saveAs,true);await p.dispose();
+});
+
 for(const type of ['number','number_int','flonum'])for(const direction of ['undo','redo']) {
   test(`${type} preserves a rejected ${direction} draft through blur and retries Enter`,async()=>{
     const p=await mountHistoryControl(type);if(direction==='redo')await p.controller.undo();
diff --git a/apps/ultra/ui/canvas-entry.mjs b/apps/ultra/ui/canvas-entry.mjs
index d10de3d..bcba546 100644
--- a/apps/ultra/ui/canvas-entry.mjs
+++ b/apps/ultra/ui/canvas-entry.mjs
@@ -1,6 +1,6 @@
 import {completionFor} from './canvas-completion.mjs';
 
-export function createObjectEntry({document:doc,window:win,commit,onClose=()=>{}}) {
+export function createObjectEntry({document:doc,window:win,commit,onClose=()=>{},drafts}) {
   const $=id=>doc.querySelector('#'+id),box=$('object-entry'),input=$('object-text'),list=$('object-suggestions'),guide=$('object-arguments'),assistance=$('entry-assistance');
   let choices=[],active=0,context=null,completion=null,anchor={x:80,y:140},lastSelection='',entryWidth=100,entryHeight=24,fontSize=12,multiline=false,originalText='',originalDisplay='';
   const selection=()=>`${input.selectionStart}:${input.selectionEnd}`;
@@ -68,19 +68,29 @@ export function createObjectEntry({document:doc,window:win,commit,onClose=()=>{}
     const caret=s.start+s.insert.length+(separator.length||suffix.match(/^\s+/)?.[0].length||0);
     input.setSelectionRange?.(caret,caret);active=0;render();
   }
-  function close() {box.hidden=true;context=null;$('object-error').textContent='';onClose();}
+  function close() {drafts?.forget(input);box.hidden=true;context=null;$('object-error').textContent='';onClose();}
   function open({text='',clientX=80,clientY=140,width=100,height=24,fontSize:font=12,...rest}={}) {
     context=rest;active=0;originalText=text;input.value=text;originalDisplay=input.value;input.setAttribute('aria-invalid','false');$('object-error').textContent='';box.hidden=false;
     anchor={x:clientX,y:clientY};
     entryWidth=width;entryHeight=height;fontSize=font;
     box.style.setProperty('--entry-scale',String(height/24));
-    input.focus();if(text)input.select();render();
+    drafts?.add(input);input.focus();if(text)input.select();render();
   }
+  function commitDraft(){
+    if(box.hidden)return true;
+    if(!input.value.trim()&&!context.nodeId){close();return true;}
+    try{
+      commit(multiline&&input.value===originalDisplay?originalText:input.value,context);close();return true;
+    }catch(error){$('object-error').textContent=error.message;assistance.hidden=false;input.setAttribute('aria-invalid','true');return false;}
+  }
+  input.commitDraft=commitDraft;input.cancelDraft=close;
+  drafts?.watch(input);
   input.addEventListener('input',()=>{active=0;input.setAttribute('aria-invalid','false');$('object-error').textContent='';render();});
   input.addEventListener('click',()=>{active=0;render();});
   input.addEventListener('select',()=>{if(selection()!==lastSelection){active=0;render();}});
   input.addEventListener('keyup',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){active=0;render();}});
   input.addEventListener('keydown',e=>{
+    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s')return;
     e.stopPropagation();
     if(selection()!==lastSelection){active=0;render();}
     if(e.key==='Escape'){e.preventDefault();close();}
@@ -91,13 +101,10 @@ export function createObjectEntry({document:doc,window:win,commit,onClose=()=>{}
     } else if(e.key==='Tab'){e.preventDefault();complete();}
     else if(e.key==='Enter'){
       e.preventDefault();
-      if(!input.value.trim()&&!context.nodeId){close();return;}
-      try{
-        const name=input.value.trim().split(/\s+/)[0];
-        if(completion.mode==='objects'&&choices.length&&!choices.some(s=>s.object.name===name||s.object.aliases.includes(name)))complete();
-        commit(multiline&&input.value===originalDisplay?originalText:input.value,context);close();
-      }catch(error){$('object-error').textContent=error.message;assistance.hidden=false;input.setAttribute('aria-invalid','true');}
+      const name=input.value.trim().split(/\s+/)[0];
+      if(completion.mode==='objects'&&choices.length&&!choices.some(s=>s.object.name===name||s.object.aliases.includes(name)))complete();
+      input.commitDraft();
     }
   });
-  return{open,close,isOpen:()=>!box.hidden};
+  return{open,close,commitDraft:()=>input.commitDraft(),isOpen:()=>!box.hidden};
 }
diff --git a/apps/ultra/ui/canvas-focused-drafts.mjs b/apps/ultra/ui/canvas-focused-drafts.mjs
new file mode 100644
index 0000000..0cf929a
--- /dev/null
+++ b/apps/ultra/ui/canvas-focused-drafts.mjs
@@ -0,0 +1,17 @@
+export function createFocusedDrafts({onCancel=()=>{}}={}){
+  const pending=new Set();let serial=0;
+  function watch(input,isDirty=()=>true){
+    const commit=input.commitDraft,cancel=input.cancelDraft;
+    input.commitDraft=()=>{const accepted=commit();if(accepted!==false&&pending.delete(input))serial++;return accepted;};
+    input.cancelDraft=()=>{cancel();if(pending.delete(input))onCancel();};
+    input.addEventListener('input',()=>{if(isDirty())pending.add(input);});
+  }
+  function commitWhere(predicate=()=>true){
+    for(const input of [...pending]){
+      if(!predicate(input))continue;
+      if(input.commitDraft()===false){input.focus();return false;}
+    }
+    return true;
+  }
+  return{watch,add:input=>pending.add(input),forget:input=>pending.delete(input),commitWhere,clear:()=>pending.clear(),get serial(){return serial;}};
+}
diff --git a/apps/ultra/ui/canvas-inspector.mjs b/apps/ultra/ui/canvas-inspector.mjs
index 861e3b6..52a735e 100644
--- a/apps/ultra/ui/canvas-inspector.mjs
+++ b/apps/ultra/ui/canvas-inspector.mjs
@@ -12,8 +12,25 @@ function inheritedColor(node,key){
 }
 const toHex=rgba=>'#'+rgba.slice(0,3).map(value=>Math.round(value*255).toString(16).padStart(2,'0')).join('');
 const fromHex=value=>[1,3,5].map(offset=>parseInt(value.slice(offset,offset+2),16)/255);
+function appearanceDraft(input,apply,valid,drafts){
+  let dirty=false,original=input.value;
+  input.addEventListener('focus',()=>{if(!dirty)original=input.value;});
+  input.addEventListener('input',()=>{dirty=true;});
+  input.commitDraft=()=>{
+    if(!dirty)return true;
+    if(!valid())return false;
+    dirty=false;
+    try{if(apply()===false){dirty=true;return false;}return true;}
+    catch{dirty=true;return false;}
+  };
+  input.cancelDraft=()=>{dirty=false;input.value=original;};
+  input.hasDraft=()=>dirty;drafts?.watch(input,()=>dirty);
+  input.addEventListener('change',()=>{dirty=true;if(!input.commitDraft())input.focus();});
+  input.addEventListener('blur',()=>{if(!input.commitDraft())input.focus();});
+  input.addEventListener('keydown',e=>{if(e.key==='Escape'&&dirty){e.preventDefault();e.stopPropagation();input.cancelDraft();}else if(['Enter','Tab'].includes(e.key)&&!input.commitDraft())e.preventDefault();});
+}
 
-export function createParameterField({doc,node,key,definition,change}){
+export function createParameterField({doc,node,key,definition,change,drafts}){
   const label=doc.createElement('label');label.className='field';
   const name=doc.createElement('span');name.className='field-name';
   const sliderLabels={value:'Value',size:'Range Size',min:'Output Minimum',mult:'Output Multiplier',floatoutput:'Output Mode'};
@@ -29,7 +46,22 @@ export function createParameterField({doc,node,key,definition,change}){
     input.type=textual?'text':'number';
     if(textual)input.maxLength=node.type==='patcher'?127:31;else{input.min=definition.min;input.max=definition.max;input.step=definition.integer||(key==='rhs'&&node.params.numericmode===1)?1:'any';}
   }
-  input.value=String(node.params[key]);input.addEventListener('change',()=>change(textual?input.value:Number(input.value)));
+  input.value=String(node.params[key]);let dirty=false,original=input.value;
+  input.addEventListener('focus',()=>{if(!dirty)original=input.value;});
+  input.addEventListener('input',()=>{dirty=true;});
+  input.commitDraft=()=>{
+    if(!dirty)return true;
+    const value=textual?input.value:Number(input.value);
+    if(!textual&&(input.value===''||!Number.isFinite(value)||value<definition.min||value>definition.max))return false;
+    dirty=false;
+    if(change(value)===false){dirty=true;return false;}
+    original=input.value;return true;
+  };
+  input.cancelDraft=()=>{dirty=false;input.value=original;};
+  input.hasDraft=()=>dirty;drafts?.watch(input,()=>dirty);
+  input.addEventListener('change',()=>{if(!dirty)dirty=true;input.commitDraft();});
+  input.addEventListener('blur',()=>{if(!input.commitDraft())input.focus();});
+  input.addEventListener('keydown',e=>{if(e.key==='Escape'&&dirty){e.preventDefault();e.stopPropagation();input.cancelDraft();}else if(['Enter','Tab'].includes(e.key)&&!input.commitDraft())e.preventDefault();});
   label.append(name,input);return{label,input};
 }
 
@@ -38,7 +70,7 @@ function sliderOutputDescription(node){
   return `${floatoutput?'Float':'Integer'} output: ${format(min)} to ${format(min+(size-1)*mult)}. Output = position * multiplier + minimum. Position runs from 0 to ${size-1}.`;
 }
 
-export function mountAppearanceFields({doc,area,node,change,reset}) {
+export function mountAppearanceFields({doc,area,node,change,reset,drafts}) {
   const make=(tag,className,text)=>{const element=doc.createElement(tag);if(className)element.className=className;if(text!==undefined)element.textContent=text;return element;};
   const controls=new Map();let current=node,outputRange=null;
   if(node.type==='slider'){
@@ -54,14 +86,14 @@ export function mountAppearanceFields({doc,area,node,change,reset}) {
       alpha.type='number';alpha.min=0;alpha.max=1;alpha.step=0.05;alpha.dataset.styleAlpha=field.key;
       alpha.setAttribute('aria-label',`${field.label} opacity, selected object ${node.id}`);
       input.addEventListener('change',()=>change(field.key,[...fromHex(input.value),(current.style?.[field.key]??inheritedColor(current,field.key))[3]]));
-      alpha.addEventListener('change',()=>change(field.key,[...(current.style?.[field.key]??inheritedColor(current,field.key)).slice(0,3),Number(alpha.value)]));
+      appearanceDraft(alpha,()=>change(field.key,[...(current.style?.[field.key]??inheritedColor(current,field.key)).slice(0,3),Number(alpha.value)]),()=>alpha.value!==''&&Number.isFinite(Number(alpha.value))&&Number(alpha.value)>=0&&Number(alpha.value)<=1,drafts);
       group.append(input,alpha);label.append(group);controls.set(field.key,{input,alpha,field});
     }else{
       if(field.kind==='enum'){
         const automatic=make('option','','Default');automatic.value='';input.append(automatic);
         for(const choice of field.options){const option=make('option','',choice.label);option.value=String(choice.value);input.append(option);}
       }else{input.type='number';input.min=field.min;input.max=field.max;input.step=field.step??'any';input.placeholder='Auto';}
-      input.addEventListener('change',()=>change(field.key,input.value===''?null:Number(input.value)));
+      appearanceDraft(input,()=>change(field.key,input.value===''?null:Number(input.value)),()=>field.kind==='enum'||input.value===''||(Number.isFinite(Number(input.value))&&Number(input.value)>=field.min&&Number(input.value)<=field.max),drafts);
       label.append(input);controls.set(field.key,{input,field});
     }
     area.append(label);
@@ -76,8 +108,8 @@ export function mountAppearanceFields({doc,area,node,change,reset}) {
       if(field.kind==='color'){
         const rgba=current.style?.[key]??inheritedColor(current,key);
         if(doc.activeElement!==input)input.value=toHex(rgba);
-        if(doc.activeElement!==alpha)alpha.value=String(rgba[3]);
-      }else if(doc.activeElement!==input)input.value=String(current.style?.[key]??'');
+        if(doc.activeElement!==alpha&&!alpha.hasDraft?.())alpha.value=String(rgba[3]);
+      }else if(doc.activeElement!==input&&!input.hasDraft?.())input.value=String(current.style?.[key]??'');
     }
     clear.disabled=locked||!current.style;
   }};
diff --git a/apps/ultra/ui/canvas-instrument.mjs b/apps/ultra/ui/canvas-instrument.mjs
index 55b6334..9011f16 100644
--- a/apps/ultra/ui/canvas-instrument.mjs
+++ b/apps/ultra/ui/canvas-instrument.mjs
@@ -1,7 +1,12 @@
 import {makeNode,validatePatch} from './canvas-model.mjs';
 import {deviceValues} from './canvas-device.mjs';
 
-export function packageInstrument(patch,{id='org.alive.instrument',name='Subtractive instrument'}={}){
+export function packageInstrument(patch,{id=patch.device?.id??'org.alive.instrument',name=patch.device?.name??'Subtractive instrument'}={}){
+  if(Object.hasOwn(patch,'device')){
+    // Validate the existing interface against the graph before changing its identity.
+    validatePatch(patch);
+    return validatePatch({...patch,device:{...patch.device,id,name}});
+  }
   const all=scope=>scope.nodes.flatMap(node=>[node,...(node.type==='patcher'?all(node.patcher):[])]);
   const nodes=all(patch),find=type=>{
     const matches=nodes.filter(node=>node.type===type);
diff --git a/apps/ultra/ui/canvas-instrument.test.mjs b/apps/ultra/ui/canvas-instrument.test.mjs
index 56778e2..37957fe 100644
--- a/apps/ultra/ui/canvas-instrument.test.mjs
+++ b/apps/ultra/ui/canvas-instrument.test.mjs
@@ -4,6 +4,7 @@ import {makeNode, nodeSpec, validatePatch, CanvasDocument} from './canvas-model.
 import {parseObjectText, objectText} from './canvas-catalog.mjs';
 import {readFileSync} from 'node:fs';
 import {deviceValues,presetParameters} from './canvas-device.mjs';
+import {packageInstrument,subtractivePatch} from './canvas-instrument.mjs';
 
 const manifest=()=>({version:1,id:'org.alive.test',name:'Test synth',midi:{node:1,inlet:0},
   audio:{inputs:0,outputs:2,layout:'stereo'},parameters:[{key:'cutoff',label:'Cutoff',node:3,param:'cutoff',min:20,max:20000,unit:'Hz'}],
@@ -17,6 +18,33 @@ const graph = () => ({version:1,profile:'ultra-canvas-v1',nodes:[
   [5,0,6,0],[6,0,7,0],[7,0,8,0],[7,0,8,1],[8,0,9,0]]
   .map(([from,outlet,to,inlet])=>({from,outlet,to,inlet}))});
 
+test('repackaging retains authored bindings, ranges, presets and interfaces',()=>{
+  const before=subtractivePatch();
+  before.device.parameters[4]={...before.device.parameters[4],key:'tone',label:'Tone',min:100,max:9000,unit:'Hz'};
+  for(const preset of before.device.presets){preset.values.tone=preset.values.cutoff;delete preset.values.cutoff;}
+  const after=packageInstrument(before,{id:before.device.id,name:'Renamed'});
+  assert.deepEqual(after.device.presets,before.device.presets);
+  assert.deepEqual(after.device.parameters,before.device.parameters);
+  assert.deepEqual(after.device.midi,before.device.midi);
+  assert.deepEqual(after.device.audio,before.device.audio);
+  assert.equal(after.device.name,'Renamed');
+  assert.deepEqual(before,subtractivePatchWithTone());
+});
+function subtractivePatchWithTone(){
+  const patch=subtractivePatch();patch.device.parameters[4]={...patch.device.parameters[4],key:'tone',label:'Tone',min:100,max:9000,unit:'Hz'};
+  for(const preset of patch.device.presets){preset.values.tone=preset.values.cutoff;delete preset.values.cutoff;}return patch;
+}
+test('repackaging rejects incompatible saved bindings without changing the input',()=>{
+  const before=subtractivePatch();before.device.parameters[0].node=999;const snapshot=structuredClone(before);
+  assert.throws(()=>packageInstrument(before,{id:before.device.id,name:'Renamed'}),/binding.*attack/i);
+  assert.deepEqual(before,snapshot);
+});
+test('repackaging accepts a valid non-template version 2 device',()=>{
+  const before={...graph(),device:{...manifest(),version:2,kind:'instrument',midi:{input:{node:1,inlet:0},output:null},audio:{input:null,output:{channels:2,layout:'stereo'}}}};
+  const after=packageInstrument(before,{id:before.device.id,name:'Renamed'});
+  assert.deepEqual(after.device,{...before.device,name:'Renamed'});
+});
+
 test('a subtractive voice graph connects through an explicit four-lane mixdown to stereo',()=>{
   const patch=validatePatch(graph());
   assert.equal(patch.nodes.length,9);
diff --git a/apps/ultra/ui/canvas-node.mjs b/apps/ultra/ui/canvas-node.mjs
index 4e998ab..3185aae 100644
--- a/apps/ultra/ui/canvas-node.mjs
+++ b/apps/ultra/ui/canvas-node.mjs
@@ -2,7 +2,7 @@ import {OBJECTS, objectText, portHelp} from './canvas-catalog.mjs';
 import {nodeSpec} from './canvas-model.mjs';
 import {printPopupText} from './canvas-print-ui.mjs';
 
-export function createNodeView(node,{doc,select,dragStart,edit,portClick,portDown,hover,unhover,context,operate,parameter,tab,resize,resized,getZoom=()=>1}) {
+export function createNodeView(node,{doc,select,dragStart,edit,portClick,portDown,hover,unhover,context,operate,parameter,tab,resize,resized,drafts,getZoom=()=>1}) {
   const s={...OBJECTS[node.type],...nodeSpec(node)},make=(tag,className,text)=>{const e=doc.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;};
   const message=['message','message_box'].includes(node.type);
   const portCount=Math.max(s.inlets.length,s.outlets.length),minimumWidth=node.type==='gain'?30:portCount>1?portCount*18:12;
@@ -138,13 +138,20 @@ export function createNodeView(node,{doc,select,dragStart,edit,portClick,portDow
     const input=make('input',node.type==='gain'?'gain-input':node.type==='slider'?'slider-input':'number-input');input.type=ranged?'range':'number';
     const p=s.params.value;input.min=p.min;input.max=p.max;input.step=p.integer?'1':'any';input.value=node.params.value;input.dataset.parameter='value';
     input.setAttribute('aria-label',`${s.name} value, object ${node.id}`);
+    input.commitDraft=()=>{
+      if(!dirty)return true;
+      const value=input.value===''?NaN:Number(input.value),{min,max}=bounds();
+      if(!Number.isFinite(value)||value<min||value>max)return false;
+      setValue(value);return !dirty;
+    };
+    input.cancelDraft=()=>{dirty=false;input.value=String(displayedValue);};
     input.addEventListener('input',()=>{if(!ranged){dirty=true;return;}if(isLocked)setValue(Number(input.value),!keyContinuous);});
-    input.addEventListener('change',()=>{if(canOperate({})||!input.readOnly)setValue(Number(input.value));});
+    input.addEventListener('change',()=>{if(canOperate({})||!input.readOnly){if(!dirty)dirty=true;if(!input.commitDraft())input.focus();}});
     input.addEventListener('keydown',e=>{
+      if(e.key==='Escape'&&dirty){e.preventDefault();e.stopPropagation();input.cancelDraft();return;}
       if(!canOperate(e)&&input.readOnly){if(e.key!=='Tab')e.preventDefault();return;}
       if(e.key==='Tab'||e.key==='Enter'){
-        if(dirty)setValue(input.value===''?NaN:Number(input.value));
-        if(dirty){if(e.key==='Enter')e.preventDefault();return;}
+        if(!input.commitDraft()){e.preventDefault();return;}
         if(['flonum','number_int'].includes(node.type)&&e.key==='Tab')tab(node.id);
         if(e.key==='Enter'){e.preventDefault();input.select();}return;
       }
@@ -155,7 +162,8 @@ export function createNodeView(node,{doc,select,dragStart,edit,portClick,portDow
       }
     });
     input.addEventListener('keyup',()=>{keyContinuous=false;});
-    input.addEventListener('blur',()=>{if(dirty)setValue(input.value===''?NaN:Number(input.value));finishControl();});
+    input.addEventListener('blur',()=>{if(!input.commitDraft()){input.focus();return;}finishControl();});
+    drafts?.watch(input,()=>dirty);
     inputs.set('value',input);body.append(input);
     if(node.type==='gain'){level=make('span','gain-value',String(node.params.value));body.append(level);}
     if(node.type==='slider'){level=make('span','slider-value',String(node.params.value));body.append(level);}
@@ -236,7 +244,7 @@ export function createNodeView(node,{doc,select,dragStart,edit,portClick,portDow
     }
     for(const direction of ['in','out'])portElements[direction].forEach((b,i)=>{b.tabIndex=locked&&control?-1:0;b.classList.toggle('pending',pending?.id===current.id&&pending.direction===direction&&pending.index===i);});
   }
-  return{type:node.type,configuration:nodeConfiguration(node),element,header,inputs,ports:portElements,minimumWidth,update,get resizePreview(){return sizing?{width:sizing.width,height:sizing.height}:null;},cancelInteraction,dispose(){cancelInteraction();doc.defaultView?.removeEventListener('blur',windowBlur);}};
+  return{type:node.type,configuration:nodeConfiguration(node),element,header,inputs,ports:portElements,minimumWidth,update,get resizePreview(){return sizing?{width:sizing.width,height:sizing.height}:null;},cancelInteraction,dispose(){for(const input of inputs.values())drafts?.forget(input);cancelInteraction();doc.defaultView?.removeEventListener('blur',windowBlur);}};
 }
 
 export const nodeConfiguration=node=>JSON.stringify([node.params.args,node.params.name,node.params.channels,node.patcher?.nodes.filter(child=>['inlet','outlet'].includes(child.type)).map(child=>[child.id,child.type,child.x])]);
diff --git a/apps/ultra/ui/canvas-shared.mjs b/apps/ultra/ui/canvas-shared.mjs
index 5c76eac..e099cc2 100644
--- a/apps/ultra/ui/canvas-shared.mjs
+++ b/apps/ultra/ui/canvas-shared.mjs
@@ -194,7 +194,10 @@ export function createSharedCanvasController({invoke,onState=()=>{}}={}) {
     return edit((...args)=>root?document.parameterRoot(...args):document.parameter(...args),[id,key,value,{history}],{history,parameter,messageText});
   }
   function event(node,inlet=0,value=null,action,root=false) {
-    if(disposed||detaching||closeBarriers.size||!descriptor)return Promise.resolve(false);
+    const releasingDeviceNote=closeBarriers.size&&root&&inlet===0&&Array.isArray(value)&&value.length===2&&value[1]===0&&
+      treeNodes(document.document).some(target=>target.id===node&&target.type==='poly_note');
+    if(disposed||detaching||!descriptor||closeBarriers.size&&
+      (!releasingDeviceNote||[...closeBarriers.values()].some(barrier=>barrier.purpose!=='save')))return Promise.resolve(false);
     const target=(root?treeNodes(document.document):document.patch.nodes).find(item=>item.id===node),port=target&&nodeSpec(target).inlets[inlet];
     if(!port||!(port.accepts??[port.type]).includes('control'))throw Error('Events require an inlet that accepts control messages.');
     if(typeof value==='string'){
@@ -244,7 +247,7 @@ export function createSharedCanvasController({invoke,onState=()=>{}}={}) {
   }
   async function flushBeforeClose(request) {
     const existing=closeBarriers.get(request.requestLabel);
-    if(!existing||existing.token!==request.token)closeBarriers.set(request.requestLabel,{token:request.token,error:null});
+    if(!existing||existing.token!==request.token)closeBarriers.set(request.requestLabel,{token:request.token,purpose:request.purpose,error:null});
     emit();await flush();
     const barrier=closeBarriers.get(request.requestLabel);
     if(barrier?.token===request.token&&barrier.error)throw barrier.error;
diff --git a/apps/ultra/ui/canvas-shared.test.mjs b/apps/ultra/ui/canvas-shared.test.mjs
index 0d74793..5988b05 100644
--- a/apps/ultra/ui/canvas-shared.test.mjs
+++ b/apps/ultra/ui/canvas-shared.test.mjs
@@ -120,6 +120,20 @@ test('optimistic edits serialize and stale disjoint edits rebase without overwri
   const commits=host.calls.filter(call=>call.name==='document_commit');
   assert.ok(commits.some(call=>call.args.baseRevision===1));assert.equal(host.revision,3);
 });
+test('overlapping root and child authoring settles before the child close barrier completes',async()=>{
+  const {host,owner,child}=await views({broadcast:true}),release=host.holdNextCommit();
+  child.parameter(4,'value',73);await tick();
+  const closing=child.flushBeforeClose({requestLabel:'child',token:7});
+  owner.parameter(1,'value',42);await owner.flush();
+  assert.equal(host.revision,2);assert.equal(host.patch.nodes[0].params.value,42);
+  let closed=false;closing.then(()=>{closed=true;});await tick();assert.equal(closed,false);
+  release();await closing;
+  assert.equal(host.revision,3);assert.equal(host.patch.nodes[0].params.value,42);
+  assert.equal(host.patch.nodes[2].patcher.nodes[0].params.value,73);
+  const commits=host.calls.filter(call=>call.name==='document_commit');
+  assert.deepEqual(commits.map(call=>[call.label,call.args.baseRevision]),[['child',1],['owner',1],['child',2]]);
+  assert.equal(child.getState().closing,true);child.cancelClose({requestLabel:'child',token:7});
+});
 test('simultaneous changes to one field retain the canonical tree and report conflict',async()=>{
   const {host,owner,child}=await views();child.reveal(1);
   owner.move(1,100,100);await owner.flush();child.move(1,200,200);await child.flush();
@@ -269,6 +283,31 @@ test('an acknowledged view blocks new authoring until every matching close barri
   child.cancelClose(second);assert.equal(child.getState().closing,false);
   child.move(4,200,200);await child.flush();assert.equal(host.patch.nodes[2].patcher.nodes[0].x,200);
 });
+test('Save preflight allows held device note release without stopping the patch',async()=>{
+  const {createDevicePlayer}=await import('./canvas-device-player.mjs');
+  const {host,owner}=await views({patch:{version:2,profile:'ultra-patcher-v2',nodes:[makeNode('poly_note',2)],edges:[]}});
+  const player=createDevicePlayer({send:note=>owner.deviceEvent(2,0,note),stop:()=>owner.stop()});
+  assert.equal(await player.press(60,'key:a'),true);
+  await owner.flushBeforeClose({requestLabel:'save/owner',token:1,purpose:'save'});
+  assert.throws(()=>owner.parameter(2,'voices',3),/clos/i);
+  assert.equal(await player.release('key:a'),true);await owner.flush();
+  const events=host.calls.filter(call=>call.name==='canvas_event');assert.deepEqual(events.map(call=>call.args.value),[[60,100],[60,0]]);
+  assert.equal(host.calls.filter(call=>call.name==='canvas_stop').length,0);
+  await owner.flushBeforeClose({requestLabel:'owner',token:2});
+  assert.equal(await owner.deviceEvent(2,0,[61,0]),false,'an overlapping genuine close keeps its veto');
+  owner.cancelClose({requestLabel:'owner',token:2});
+  owner.cancelClose({requestLabel:'save/owner',token:1});
+});
+test('a genuine close barrier retains the existing device release Stop fallback',async()=>{
+  const {createDevicePlayer}=await import('./canvas-device-player.mjs');
+  const {host,owner}=await views({patch:{version:2,profile:'ultra-patcher-v2',nodes:[makeNode('poly_note',2)],edges:[]}});
+  const player=createDevicePlayer({send:note=>owner.deviceEvent(2,0,note),stop:()=>owner.stop()});
+  assert.equal(await player.press(60,'key:a'),true);await owner.flushBeforeClose({requestLabel:'owner',token:2});
+  assert.equal(await player.release('key:a'),false);await owner.flush();
+  assert.deepEqual(host.calls.filter(call=>call.name==='canvas_event').map(call=>call.args.value),[[60,100]]);
+  assert.equal(host.calls.filter(call=>call.name==='canvas_stop').length,1);
+  owner.cancelClose({requestLabel:'owner',token:2});
+});
 
 test('a pending undo rejected by owner CAS cancels the close flush',async()=>{
   const {owner,child}=await views();child.parameter(4,'value',23);await child.flush();
diff --git a/apps/ultra/ui/canvas.html b/apps/ultra/ui/canvas.html
index 4be2b01..71acdf3 100644
--- a/apps/ultra/ui/canvas.html
+++ b/apps/ultra/ui/canvas.html
@@ -117,7 +117,7 @@
       <p id="instrument-keyboard-note"></p><div id="instrument-keyboard" aria-label="Instrument keyboard" role="group" tabindex="0"></div>
       <div class="instrument-actions"><button id="instrument-release">Release all</button><button id="instrument-instance">New instance</button></div>
     </section>
-    <section><label class="instrument-name-field">Instrument name<input id="instrument-name" maxlength="64" placeholder="Subtractive instrument"></label><button id="instrument-package" class="panel-action">Package instrument</button><p>Save the patch to keep its device interface and presets. Alive currently hosts instruments; effect chains are pending.</p></section>
+    <section><label class="instrument-name-field">Device name<input id="instrument-name" maxlength="64" placeholder="Subtractive instrument"></label><button id="instrument-package" class="panel-action">Package device</button><p>Save the patch to keep its device interface and presets. Alive hosts instruments and stereo effects.</p></section>
   </aside>
 </main>
 <section id="patch-console" aria-label="Console" hidden>
diff --git a/apps/ultra/ui/canvas.mjs b/apps/ultra/ui/canvas.mjs
index f5af683..fbffa0d 100644
--- a/apps/ultra/ui/canvas.mjs
+++ b/apps/ultra/ui/canvas.mjs
@@ -17,6 +17,7 @@ import {cableBounds,cablePath} from './canvas-cable-path.mjs';
 import {translatedMidpoints} from './canvas-cable-geometry.mjs';
 import {canvasRenderKey,createCanvasPoller} from './canvas-poll.mjs';
 import {mountDevicePanel} from './canvas-device-panel.mjs';
+import {createFocusedDrafts} from './canvas-focused-drafts.mjs';
 
 export function mountCanvas({document:doc=globalThis.document,window:win=globalThis.window,invoke=win?.__TAURI__?.core?.invoke}={}) {
   const $=id=>doc.querySelector('#'+id),make=(tag,className,text)=>{const e=doc.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;};
@@ -43,7 +44,8 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
   const maxDialog=mountMaxImportDialog({doc,invoke});
   const consoleView=mountConsole({doc,controller,select:source=>guard(()=>revealSource(source))()});
   const guard=fn=>(...args)=>{try{return Promise.resolve(fn(...args)).catch(error=>controller.notice(error));}catch(error){controller.notice(error);}};
-  const devicePanel=mountDevicePanel({doc,win,controller,invoke,beforeOpen:()=>{panel=null;applyPanel();}});
+  const drafts=createFocusedDrafts({onCancel:()=>{if(initialized)render(controller.getState());}});
+  const devicePanel=mountDevicePanel({doc,win,controller,invoke,drafts,beforeOpen:()=>{panel=null;applyPanel();}});
   helpView=mountHelpShell({doc,win,invoke,onChange:()=>{if(initialized)render(controller.getState());},beforeRead:()=>controller.flush(),
     beforeNavigate:async()=>{finishDrag();entry.close();closeMenus();cancelWire(false);for(const view of views.values())view.cancelInteraction?.();await controller.flush();},
     hostBasic:()=>controller.hostHelpBasic()});
@@ -64,7 +66,7 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
     const size=node?views.get(node.id)?.element.getBoundingClientRect():null;
     entry.open({text,nodeId:node?.id,x:p.x,y:p.y,clientX:rect.left+p.x*zoom,clientY:rect.top+p.y*zoom,width:size?.width??100*zoom,height:24*zoom,fontSize:(node?.style?.fontsize??12)*zoom});
   }
-  const entry=createObjectEntry({document:doc,window:win,onClose:()=>{$('workspace').focus();},commit:(text,context)=>{
+  const entry=createObjectEntry({document:doc,window:win,drafts,onClose:()=>{$('workspace').focus();},commit:(text,context)=>{
     if(locked)throw Error('Unlock the patch before editing.');
     const parsed=parseObjectText(text,context.nodeId?getNode(context.nodeId):null);
     if(context.nodeId)controller.configure(context.nodeId,parsed.type,parsed.params);
@@ -380,17 +382,17 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
         const helper=n.type==='help_helper',spec=helper?{name:'Help annotation',summary:`${n.params.role} layout for ${helpView.object}.`,params:{}}:OBJECTS[n.type];
         area.append(make('h2','',spec.name),make('p','',selected.size>1?`${selected.size} selected. Drag or delete the group.`:spec.summary));
         for(const [key,p] of Object.entries(spec.params)){
-          const {label,input}=createParameterField({doc,node:n,key,definition:p,change:value=>parameter(n.id,key,value)});
+          const {label,input}=createParameterField({doc,node:n,key,definition:p,drafts,change:value=>parameter(n.id,key,value)});
           fields.set(key,input);area.append(label);
         }
         area.append(make('p','panel-note',helper?'This annotation is part of the help layout. Reference text comes from the local Max installation.':n.type==='message_box'?'Text edits replace this message silently. Incoming messages change the live display; saved text stays here.':isArithmetic(n.type)?'Numeric mode is structural: unlock to change it and reset this runtime. The stored right operand updates live.':'Parameters update live. Object text and connection edits stop timers and clear notes.'));
-        appearanceInspector=mountAppearanceFields({doc,area,node:n,change:guard((key,value)=>controller.style(n.id,key,value)),reset:guard(()=>controller.style(n.id,null))});
+        appearanceInspector=mountAppearanceFields({doc,area,node:n,drafts,change:(key,value)=>{try{controller.style(n.id,key,value);return true;}catch(error){controller.notice(error);return false;}},reset:guard(()=>controller.style(n.id,null))});
         const b=make('button','panel-action',helper?'Reference':`Help for ${spec.name}`);b.addEventListener('click',guard(()=>helper?helpView.openReference(helpView.object):documents.openHelp(`help:${n.type}`)));area.append(b);
       } else if(selection?.kind==='edge') {
         const edge=state.patch.edges[selection.index];if(edge)area.append(make('h2','','Patch cord'),make('p','',`Object ${edge.from} outlet ${edge.outlet} to object ${edge.to} inlet ${edge.inlet}. Fan-out follows saved cable order.`));
       } else area.append(make('p','','Select an object to inspect its parameters. Right-click a port for accepted messages or emitted data.'));
     }
-    if(n)for(const [key,input] of fields){input.disabled=locked&&structuralParameter(n.type,key);if(doc.activeElement!==input)input.value=String(n.params[key]);}
+    if(n)for(const [key,input] of fields){input.disabled=locked&&structuralParameter(n.type,key);if(doc.activeElement!==input&&!input.hasDraft?.())input.value=String(n.params[key]);}
     if(n)appearanceInspector?.update(n,locked);
     $('edit-object').disabled=!n||locked||n.type==='help_helper';$('delete-selection').disabled=!selection||locked;
     const observation=n?state.observations[n.id]:null;
@@ -423,7 +425,21 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
     }
     area.append(make('p','panel-note',s.help),make('p','panel-note','Original Ultra help. Similar names do not imply Max semantics. Native observations summarize a node; they are not a scope or message history.'));
   }
+  let capturingRender=false;
   function render(state) {
+    if(capturingRender)return;
+    const container=$('objects');
+    const rebuild=state.patch.nodes.length!==container.children.length||state.patch.nodes.some((node,index)=>{
+      const view=views.get(node.id),configuration=node.type==='help_helper'?JSON.stringify(node.params):nodeConfiguration(node);
+      return !view||view.type!==node.type||view.configuration!==configuration||container.children[index]!==view.element;
+    });
+    const inspected=currentNode(),nextInspectorKey=selection?.kind==='edge'?`edge/${selection.index}`:inspected?`${inspected.id}/${inspected.type}/${inspected.params.numericmode??''}/${selected.size}`:'none';
+    const within=(element,root)=>{while(element&&element!==root)element=element.parentElement;return element===root;};
+    const replaces=input=>rebuild&&within(input,container)||nextInspectorKey!==inspectorKey&&within(input,$('inspector'))||devicePanel.wouldRebuild(state)&&within(input,$('instrument-controls'));
+    const previousDraftSerial=drafts.serial;capturingRender=true;let accepted;
+    try{accepted=drafts.commitWhere(replaces);}finally{capturingRender=false;}
+    if(!accepted)return;
+    if(drafts.serial!==previousDraftSerial)state=controller.getState();
     documents?.update();
     helpView.update(state);
     renderPatcherPath(state);
@@ -451,12 +467,12 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
       const configuration=node.type==='help_helper'?JSON.stringify(node.params):nodeConfiguration(node);
       if(!views.has(node.id)||views.get(node.id).type!==node.type||views.get(node.id).configuration!==configuration){
         views.get(node.id)?.dispose?.();
-        const v=node.type==='help_helper'?createHelpHelperView(node,{doc,select:selectNode,dragStart}):createNodeView(node,{doc,select:selectNode,dragStart,edit:id=>{if(getNode(id)?.type==='patcher')guard(()=>navigatePatcher(id))();else if(locked&&getNode(id)?.type==='print')consoleView.open();else editNode(id);},portClick,portDown,hover:hoverPort,unhover,context:contextMenu,operate,parameter,resize:guard((id,size)=>controller.resize(id,size)),getZoom:()=>zoom,resized:()=>drawCables(controller.getState().patch),tab:id=>guard(()=>controller.tab(id))()});
+        const v=node.type==='help_helper'?createHelpHelperView(node,{doc,select:selectNode,dragStart}):createNodeView(node,{doc,drafts,select:selectNode,dragStart,edit:id=>{if(getNode(id)?.type==='patcher')guard(()=>navigatePatcher(id))();else if(locked&&getNode(id)?.type==='print')consoleView.open();else editNode(id);},portClick,portDown,hover:hoverPort,unhover,context:contextMenu,operate,parameter,resize:guard((id,size)=>controller.resize(id,size)),getZoom:()=>zoom,resized:()=>drawCables(controller.getState().patch),tab:id=>guard(()=>controller.tab(id))()});
         for(const target of [v.element,v.header]){target.addEventListener('pointermove',dragMove);target.addEventListener('pointerup',finishDrag);target.addEventListener('pointercancel',finishDrag);target.addEventListener('lostpointercapture',finishDrag);}views.set(node.id,v);
       }
       const view=views.get(node.id);view.update(node,state,{selected:selected.has(node.id),locked,pending,moving:!!drag&&selected.has(node.id),reference:helpView.reference,object:helpView.object});applyNodeAppearance(view,node,doc);children.push(view.element);
     }
-    const container=$('objects');if(container.children.length!==children.length||children.some((e,i)=>container.children[i]!==e))container.replaceChildren(...children);
+    if(container.children.length!==children.length||children.some((e,i)=>container.children[i]!==e))container.replaceChildren(...children);
     const bounds=cableBounds(state.patch.edges);
     const width=Math.max(760,(bounds?.right??0)+35,...state.patch.nodes.map(n=>n.x+Math.max(350,n.style?.width??0))),height=Math.max(740,(bounds?.bottom??0)+35,...state.patch.nodes.map(n=>n.y+Math.max(160,n.style?.height??0)));
     $('canvas').style.width=`${width}px`;$('canvas').style.height=`${height}px`;$('canvas').style.transform=`translate(${panX}px, ${panY}px) scale(${zoom})`;
@@ -565,7 +581,7 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
     if($('patch-dialog').open||documents?.isOpen())return;
     if(e.key==='Escape'&&helpView.dismiss()){e.preventDefault();e.stopPropagation();return;}
     if(e.target?.closest?.('#help-reference-pane, #help-reference-menu'))return;
-    if(entry.isOpen()){if(e.key==='Escape'){e.preventDefault();entry.close();}return;}
+    if(entry.isOpen()&&!((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s')){if(e.key==='Escape'){e.preventDefault();entry.close();}return;}
     if(e.key==='Escape'){e.preventDefault();for(const view of views.values())view.cancelInteraction?.();cancelWire();closeMenus();releaseNavigation();render(controller.getState());return controller.stop();}
     const command=e.ctrlKey||e.metaKey,key=e.key.toLowerCase();
     if(command&&key==='s'){e.preventDefault();return documents.action(e.shiftKey?'save-as':'save');}
@@ -598,7 +614,7 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
   win.addEventListener('blur',()=>{for(const view of views.values())view.cancelInteraction?.();cancelWire();releaseNavigation();finishDrag();});
   doc.addEventListener('visibilitychange',()=>{poller.visibilityChanged();if(doc.hidden){for(const view of views.values())view.cancelInteraction?.();cancelWire();releaseNavigation();finishDrag();}});
   win.addEventListener('pagehide',()=>{
-    leaving=true;poller.stop();devicePanel.dispose();documents?.dispose();
+    leaving=true;poller.stop();devicePanel.dispose();documents?.dispose();drafts.clear();
     // Native close may already have removed this document's graph.
     controller.disposeDocument?.().catch(()=>{});
   });
@@ -628,8 +644,14 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
     }
     controller.adoptDescriptor(descriptor);
   }
-  documents=mountDocuments({doc,win,invoke,getPatch:()=>controller.getState().document,adopt:adoptDocument,beforeSave:()=>controller.flush(),
-    beforeClose:request=>controller.flushBeforeClose?.(request)??controller.flush(),onCloseCancelled:request=>controller.cancelClose?.(request),
+  function captureFocusedDraft(){
+    capturingRender=true;let accepted;
+    try{accepted=drafts.commitWhere();}finally{capturingRender=false;}
+    render(controller.getState());
+    if(!accepted)throw Error('Finish or cancel the invalid focused edit before saving or closing.');
+  }
+  documents=mountDocuments({doc,win,invoke,getPatch:()=>controller.getState().document,adopt:adoptDocument,beforeSave:()=>{captureFocusedDraft();return controller.flush();},
+    beforeClose:request=>{captureFocusedDraft();return controller.flushBeforeClose?.(request)??controller.flush();},onCloseCancelled:request=>controller.cancelClose?.(request),
     onDescriptor:descriptor=>controller.acceptDescriptor?.(descriptor),onReveal:acceptReveal,
     notice:error=>controller.notice(error),inspect:(source,name)=>{dialog('open');$('patch-json').value=source;return maxDialog.inspect(source,name);}});
   $('object-profile-note').textContent=`${Object.keys(OBJECTS).length} supported objects. Names and arguments belong to Ultra's bounded profile.`;
@@ -643,6 +665,6 @@ export function mountCanvas({document:doc=globalThis.document,window:win=globalT
     if(!leaving)poller.start();
   }).catch(error=>{controller.notice(error);controller.prepare();if(!leaving)poller.start();});
   win.addEventListener('resize',()=>{closeMenus();entry.close();drawCables(controller.getState().patch);});
-  return{controller,render,ready,documents,devicePanel,dispose:async()=>{leaving=true;devicePanel.dispose();helpView.dispose();documents.dispose();poller.stop();for(const view of views.values())view.dispose?.();await controller.dispose();}};
+  return{controller,render,ready,documents,devicePanel,dispose:async()=>{leaving=true;devicePanel.dispose();helpView.dispose();documents.dispose();poller.stop();for(const view of views.values())view.dispose?.();drafts.clear();await controller.dispose();}};
 }
 if(typeof document!=='undefined'&&typeof window!=='undefined')mountCanvas();
```
