#!/usr/bin/env python3
"""Time the original native disclosure path; run the unchanged journey via runpy."""
import functools
import json
import runpy
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
TESTS = ROOT / 'apps/ultra/tests'
sys.path.insert(0, str(TESTS))
import check_alive_desktop as alive

MAX_ROWS = 4096
MAX_BYTES = 1024 * 1024
rows = []
encoded_bytes = 0
dropped = 0
active = False
attempt = 0


def add(row):
    global encoded_bytes, dropped
    try:
        data = json.dumps(row, separators=(',', ':')).encode('utf-8')
        if len(rows) >= MAX_ROWS or encoded_bytes + len(data) + 1 > MAX_BYTES:
            dropped += 1
            return
        rows.append(data)
        encoded_bytes += len(data) + 1
    except Exception:
        dropped += 1


def flush():
    try:
        # Reserve the byte cap for receipt rows; report dropped count in stderr.
        (alive.ui.output / 'disclosure-probe.jsonl').write_bytes(b''.join(row + b'\n' for row in rows))
        if dropped:
            print(f'disclosure probe: {dropped} receipt rows dropped', file=sys.stderr, flush=True)
    except Exception as error:
        print(f'disclosure probe output unavailable: {error!r}', file=sys.stderr, flush=True)


def instrument(label, function, describe=lambda args, result: {}):
    @functools.wraps(function)
    def measured(*args, **kwargs):
        if not active:
            return function(*args, **kwargs)
        started = time.monotonic_ns()
        result = None
        error = None
        try:
            result = function(*args, **kwargs)
            return result
        except BaseException as exc:
            error = exc
            raise
        finally:
            ended = time.monotonic_ns()
            try:
                fields = describe(args, result) if error is None else {}
                add({'attempt': attempt, 'call': label, 'start_ns': started,
                     'end_ns': ended, 'elapsed_ns': ended - started,
                     'error': repr(error)[:512] if error is not None else None, **fields})
            except Exception:
                pass
    return measured


alive.prepare_workspace_control = instrument('prepare', alive.prepare_workspace_control)
alive.ui.wait_for = instrument('wait_for', alive.ui.wait_for)
alive.ui.find = instrument('find', alive.ui.find)
alive.owned_frame_window = instrument('owned_frame_window', alive.owned_frame_window,
                                      lambda args, result: {'owner': int(result)})
alive.reorder_point = instrument('point', alive.reorder_point,
                                 lambda args, result: {'rect': result[0], 'point': result[1]})
alive.native_hit_path = instrument('hit_path', alive.native_hit_path,
                                   lambda args, result: {'point': list(args), 'path': result})
alive.ui.t.XTestFakeMotionEvent = instrument(
    'motion', alive.ui.t.XTestFakeMotionEvent,
    lambda args, result: {'point': [args[2], args[3]], 'result': int(result)})
original_click = alive.native_control_click


@functools.wraps(original_click)
def click(name, kind, *args, **kwargs):
    global active, attempt
    if name != 'Audio details' or kind != 'disclosure':
        return original_click(name, kind, *args, **kwargs)
    attempt += 1
    active = True
    started = time.monotonic_ns()
    error = None
    try:
        return original_click(name, kind, *args, **kwargs)
    except BaseException as exc:
        error = exc
        raise
    finally:
        ended = time.monotonic_ns()
        add({'attempt': attempt, 'call': 'attempt', 'start_ns': started,
             'end_ns': ended, 'elapsed_ns': ended - started,
             'error': repr(error)[:512] if error is not None else None})
        active = False
        flush()


alive.native_control_click = click
runpy.run_path(str(TESTS / 'check_alive_arrangement.py'), run_name='__main__')
